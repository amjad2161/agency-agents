"""
AI-OS Unit Tests - Risk Classification
"""
import pytest

from services.execution_engine.app.executor import ExecutionEngine, ExecutionRiskLevel


class TestRiskClassification:
    """Test execution risk classification"""

    @pytest.fixture
    def engine(self):
        return ExecutionEngine()

    def test_low_risk_action(self, engine):
        """Test low risk action classification"""
        risk_level, factors = engine.classify_risk(
            action="read",
            parameters={"path": "/tmp/test.txt"},
            context={},
        )

        assert risk_level == ExecutionRiskLevel.LOW
        assert len(factors) == 0

    def test_query_risk(self, engine):
        """Test query action classification"""
        risk_level, factors = engine.classify_risk(
            action="query",
            parameters={"database": "testdb"},
            context={},
        )

        assert risk_level == ExecutionRiskLevel.LOW

    def test_write_risk(self, engine):
        """Test write action classification"""
        risk_level, factors = engine.classify_risk(
            action="write",
            parameters={"path": "/data/output.txt", "content": "test"},
            context={},
        )

        assert risk_level == ExecutionRiskLevel.MEDIUM
        assert len(factors) > 0

    def test_delete_risk(self, engine):
        """Test delete action classification"""
        risk_level, factors = engine.classify_risk(
            action="delete",
            parameters={"path": "/data/file.txt"},
            context={},
        )

        assert risk_level == ExecutionRiskLevel.HIGH

    def test_critical_risk(self, engine):
        """Test critical action classification"""
        risk_level, factors = engine.classify_risk(
            action="sudo",
            parameters={"command": "rm -rf /"},
            context={},
        )

        assert risk_level == ExecutionRiskLevel.CRITICAL
        assert len(factors) > 0

    def test_risk_with_sensitive_params(self, engine):
        """Test risk with sensitive parameters"""
        risk_level, factors = engine.classify_risk(
            action="create_user",
            parameters={
                "username": "newuser",
                "password": "secret123",
            },
            context={},
        )

        # Should detect sensitive data
        assert len(factors) > 0
        assert any("password" in str(f).lower() for f in factors)

    def test_risk_with_external_access(self, engine):
        """Test risk with external resource access"""
        risk_level, factors = engine.classify_risk(
            action="fetch",
            parameters={
                "url": "https://malicious-site.com",
            },
            context={},
        )

        assert len(factors) > 0
        assert any("external" in str(f).lower() for f in factors)

    def test_risk_command_injection(self, engine):
        """Test detection of command injection patterns"""
        risk_level, factors = engine.classify_risk(
            action="execute",
            parameters={
                "command": "echo 'hello' && rm -rf /",
            },
            context={},
        )

        # Should detect dangerous characters
        assert len(factors) > 0

    def test_combined_risk_factors(self, engine):
        """Test multiple risk factors combined"""
        risk_level, factors = engine.classify_risk(
            action="delete",
            parameters={
                "path": "/data",
                "password": "admin123",
                "url": "https://external.com/api",
            },
            context={},
        )

        # Should have multiple risk factors
        assert len(factors) >= 2


class TestApprovalWorkflow:
    """Test approval workflow"""

    @pytest.fixture
    def engine(self):
        return ExecutionEngine()

    @pytest.mark.asyncio
    async def test_request_approval(self, engine):
        """Test requesting approval"""
        approval_id = await engine.request_approval(
            task_id="task-001",
            tenant_id="tenant-001",
            requested_by="user-001",
            risk_level=ExecutionRiskLevel.HIGH,
            action_description="Delete all user data",
            affected_resources=[
                {"type": "database", "id": "users"},
            ],
        )

        assert approval_id is not None
        assert approval_id in engine.pending_approvals

        request = engine.pending_approvals[approval_id]
        assert request.risk_level == ExecutionRiskLevel.HIGH
        assert request.status.value == "pending"

    @pytest.mark.asyncio
    async def test_approve_request(self, engine):
        """Test approving a request"""
        approval_id = await engine.request_approval(
            task_id="task-002",
            tenant_id="tenant-001",
            requested_by="user-001",
            risk_level=ExecutionRiskLevel.HIGH,
            action_description="Delete all user data",
            affected_resources=[],
        )

        result = await engine.process_approval(
            approval_id=approval_id,
            decision="approve",
            decided_by="admin-001",
            reason="Verified as cleanup task",
        )

        assert result["status"] == "approved"

        request = engine.pending_approvals[approval_id]
        assert request.status.value == "approved"
        assert request.responded_by == "admin-001"

    @pytest.mark.asyncio
    async def test_reject_request(self, engine):
        """Test rejecting a request"""
        approval_id = await engine.request_approval(
            task_id="task-003",
            tenant_id="tenant-001",
            requested_by="user-001",
            risk_level=ExecutionRiskLevel.HIGH,
            action_description="Delete all user data",
            affected_resources=[],
        )

        result = await engine.process_approval(
            approval_id=approval_id,
            decision="reject",
            decided_by="admin-001",
            reason="Insufficient justification",
        )

        assert result["status"] == "rejected"

    @pytest.mark.asyncio
    async def test_approval_with_conditions(self, engine):
        """Test approval with conditions"""
        approval_id = await engine.request_approval(
            task_id="task-004",
            tenant_id="tenant-001",
            requested_by="user-001",
            risk_level=ExecutionRiskLevel.MEDIUM,
            action_description="Update configuration",
            affected_resources=[],
        )

        result = await engine.process_approval(
            approval_id=approval_id,
            decision="approve",
            decided_by="admin-001",
            reason="Approved with conditions",
            conditions={
                "max_age_hours": 24,
                "notification_required": True,
            },
        )

        request = engine.pending_approvals[approval_id]
        assert request.conditions is not None
        assert request.conditions["max_age_hours"] == 24

    @pytest.mark.asyncio
    async def test_nonexistent_approval(self, engine):
        """Test processing non-existent approval"""
        result = await engine.process_approval(
            approval_id="nonexistent-id",
            decision="approve",
            decided_by="admin-001",
        )

        assert not result["success"]
        assert "not found" in result["error"].lower()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])