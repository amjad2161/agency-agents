"""
AI-OS Unit Tests - Tool Runtime
"""
import pytest
import asyncio
from datetime import datetime

from services.tool_runtime.app.tool_registry import (
    BaseTool,
    WebSearchTool,
    CodeExecutionTool,
    HTTPRequestTool,
    ToolRegistry,
    ToolCategory,
    ToolExecutionResult,
    ToolPermissionLevel,
)


class TestBaseTool:
    """Test base tool functionality"""

    def test_get_manifest(self):
        """Test getting tool manifest"""
        tool = BaseTool(
            tool_id="test_tool",
            name="Test Tool",
            description="A test tool",
            category=ToolCategory.WEB,
            input_schema={"type": "object", "properties": {}},
            output_schema={"type": "object", "properties": {}},
        )

        manifest = tool.get_manifest()

        assert manifest.tool_id == "test_tool"
        assert manifest.name == "Test Tool"
        assert manifest.category == ToolCategory.WEB
        assert manifest.timeout_seconds == 60

    @pytest.mark.asyncio
    async def test_validate_input_required_fields(self):
        """Test input validation with required fields"""
        tool = BaseTool(
            tool_id="test_tool",
            name="Test Tool",
            description="Test",
            category=ToolCategory.WEB,
            input_schema={
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "value": {"type": "number"},
                },
                "required": ["name"],
            },
            output_schema={},
        )

        valid, error = await tool.validate_input({"name": "test"})
        assert valid

        valid, error = await tool.validate_input({})
        assert not valid
        assert "name" in error.lower()


class TestWebSearchTool:
    """Test web search tool"""

    @pytest.fixture
    def tool(self):
        return WebSearchTool()

    @pytest.mark.asyncio
    async def test_execute(self, tool):
        """Test tool execution"""
        result = await tool.execute(
            parameters={"query": "test query", "num_results": 5},
            context={},
        )

        assert "results" in result
        assert len(result["results"]) == 5
        assert "total_results" in result

    @pytest.mark.asyncio
    async def test_manifest(self, tool):
        """Test tool manifest"""
        manifest = tool.get_manifest()

        assert manifest.tool_id == "web_search"
        assert manifest.category == ToolCategory.WEB
        assert manifest.timeout_seconds == 30


class TestCodeExecutionTool:
    """Test code execution tool"""

    @pytest.fixture
    def tool(self):
        return CodeExecutionTool()

    @pytest.mark.asyncio
    async def test_execute_python(self, tool):
        """Test Python code execution"""
        result = await tool.execute(
            parameters={
                "code": "print('Hello')",
                "language": "python",
            },
            context={},
        )

        assert "output" in result
        assert result["exit_code"] == 0

    @pytest.mark.asyncio
    async def test_execute_javascript(self, tool):
        """Test JavaScript code execution"""
        result = await tool.execute(
            parameters={
                "code": "console.log('Hello')",
                "language": "javascript",
            },
            context={},
        )

        assert "output" in result


class TestToolRegistry:
    """Test tool registry"""

    @pytest.fixture
    def registry(self):
        return ToolRegistry()

    def test_register_tool(self, registry):
        """Test tool registration"""
        tool = WebSearchTool()
        registry.register_tool(tool)

        manifest = registry.get_manifest("web_search")
        assert manifest is not None
        assert manifest.tool_id == "web_search"

    def test_register_default_tools(self, registry):
        """Test registering default tools"""
        registry.register_default_tools()

        assert registry.get_manifest("web_search") is not None
        assert registry.get_manifest("code_execution") is not None
        assert registry.get_manifest("http_request") is not None

    @pytest.mark.asyncio
    async def test_execute_tool(self, registry):
        """Test tool execution through registry"""
        registry.register_default_tools()

        result = await registry.execute_tool(
            tool_id="web_search",
            parameters={"query": "test"},
            context={"tenant_id": "test-tenant"},
        )

        assert result.success
        assert result.tool_id == "web_search"

    @pytest.mark.asyncio
    async def test_execute_nonexistent_tool(self, registry):
        """Test executing non-existent tool"""
        result = await registry.execute_tool(
            tool_id="nonexistent",
            parameters={},
            context={},
        )

        assert not result.success
        assert result.status == "failed"

    @pytest.mark.asyncio
    async def test_execute_with_permission_denied(self, registry):
        """Test execution with denied permission"""
        registry.register_default_tools()

        # No permission set - should fail
        result = await registry.execute_tool(
            tool_id="web_search",
            parameters={"query": "test"},
            context={"tenant_id": "unauthorized-tenant"},
        )

        assert not result.success
        assert result.status == "permission_denied"

    @pytest.mark.asyncio
    async def test_execute_with_permission_granted(self, registry):
        """Test execution with granted permission"""
        registry.register_default_tools()

        # Set permission
        registry.set_permission(
            tool_id="web_search",
            tenant_id="authorized-tenant",
            permission_level=ToolPermissionLevel.EXECUTE,
            granted_by="admin",
        )

        result = await registry.execute_tool(
            tool_id="web_search",
            parameters={"query": "test"},
            context={"tenant_id": "authorized-tenant"},
        )

        assert result.success

    def test_set_permission(self, registry):
        """Test setting tool permission"""
        registry.register_default_tools()

        registry.set_permission(
            tool_id="web_search",
            tenant_id="test-tenant",
            permission_level=ToolPermissionLevel.READ,
            granted_by="admin",
        )

        permission = registry.get_permission("web_search", "test-tenant")
        assert permission is not None
        assert permission.permission_level == ToolPermissionLevel.READ


class TestToolExecutionResult:
    """Test execution result model"""

    def test_create_success_result(self):
        """Test creating successful result"""
        result = ToolExecutionResult(
            invocation_id="inv-001",
            tool_id="web_search",
            success=True,
            status="completed",
            output={"results": []},
            execution_time_ms=100,
        )

        assert result.success
        assert result.invocation_id == "inv-001"
        assert result.execution_time_ms == 100

    def test_create_failure_result(self):
        """Test creating failure result"""
        result = ToolExecutionResult(
            invocation_id="inv-002",
            tool_id="web_search",
            success=False,
            status="failed",
            error="Tool execution failed",
            execution_time_ms=50,
        )

        assert not result.success
        assert result.error == "Tool execution failed"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])