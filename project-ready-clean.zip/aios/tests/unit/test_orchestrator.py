"""
AI-OS Unit Tests - Orchestrator Task Graph
"""
import pytest
import asyncio
from datetime import datetime

from services.orchestrator.app.task_graph import (
    TaskGraph,
    TaskNode,
    TaskEdge,
    NodeType,
    NodeStatus,
    create_graph_for_task_type,
)
from services.orchestrator.app.orchestrator import OrchestratorService, OrchestratorConfig


class TestTaskGraph:
    """Test task graph creation and manipulation"""

    def test_create_empty_graph(self):
        """Test creating an empty graph"""
        graph = TaskGraph(
            graph_id="test-001",
            name="Test Graph",
            nodes=[],
            edges=[],
        )

        assert graph.graph_id == "test-001"
        assert len(graph.nodes) == 0
        assert len(graph.edges) == 0

    def test_add_nodes(self):
        """Test adding nodes to graph"""
        graph = TaskGraph(
            graph_id="test-002",
            name="Test Graph",
            nodes=[],
            edges=[],
        )

        node1 = TaskNode(
            node_id="node-1",
            node_type=NodeType.PLAN,
            label="Plan step",
        )
        node2 = TaskNode(
            node_id="node-2",
            node_type=NodeType.REASON,
            label="Reason step",
        )

        graph.nodes.append(node1)
        graph.nodes.append(node2)

        assert len(graph.nodes) == 2
        assert graph.get_node("node-1") == node1
        assert graph.get_node("node-2") == node2

    def test_add_edges(self):
        """Test adding edges to graph"""
        graph = TaskGraph(
            graph_id="test-003",
            name="Test Graph",
            nodes=[],
            edges=[],
        )

        node1 = TaskNode(node_id="node-1", node_type=NodeType.PLAN)
        node2 = TaskNode(node_id="node-2", node_type=NodeType.REASON)

        graph.nodes.extend([node1, node2])

        edge = TaskEdge(
            source_node_id="node-1",
            target_node_id="node-2",
        )
        graph.edges.append(edge)

        assert len(graph.edges) == 1

        deps = graph.get_dependencies("node-2")
        assert len(deps) == 1
        assert deps[0].node_id == "node-1"

    def test_topological_sort(self):
        """Test topological sorting of nodes"""
        graph = TaskGraph(
            graph_id="test-004",
            name="Test Graph",
            nodes=[],
            edges=[],
        )

        # Create linear chain: A -> B -> C -> D
        node_ids = ["a", "b", "c", "d"]
        nodes = [
            TaskNode(node_id=id, node_type=NodeType.REASON)
            for id in node_ids
        ]
        graph.nodes.extend(nodes)

        for i in range(len(node_ids) - 1):
            graph.edges.append(TaskEdge(
                source_node_id=node_ids[i],
                target_node_id=node_ids[i + 1],
            ))

        sorted_nodes = graph.topological_sort()

        assert len(sorted_nodes) == 4
        # Verify order
        sorted_ids = [n.node_id for n in sorted_nodes]
        assert sorted_ids == ["a", "b", "c", "d"]

    def test_get_ready_nodes(self):
        """Test getting nodes ready for execution"""
        graph = TaskGraph(
            graph_id="test-005",
            name="Test Graph",
            nodes=[],
            edges=[],
        )

        # Create: A -> B -> C
        nodes = [
            TaskNode(node_id="a", node_type=NodeType.PLAN, status=NodeStatus.COMPLETED),
            TaskNode(node_id="b", node_type=NodeType.REASON, status=NodeStatus.PENDING),
            TaskNode(node_id="c", node_type=NodeType.FINALIZE, status=NodeStatus.PENDING),
        ]
        graph.nodes.extend(nodes)

        graph.edges.append(TaskEdge(source_node_id="a", target_node_id="b"))
        graph.edges.append(TaskEdge(source_node_id="b", target_node_id="c"))

        ready = graph.get_ready_nodes()

        # Only B should be ready (A is completed, C depends on B)
        assert len(ready) == 1
        assert ready[0].node_id == "b"

    def test_progress_calculation(self):
        """Test progress calculation"""
        graph = TaskGraph(
            graph_id="test-006",
            name="Test Graph",
            nodes=[
                TaskNode(node_id="a", node_type=NodeType.PLAN, status=NodeStatus.COMPLETED),
                TaskNode(node_id="b", node_type=NodeType.REASON, status=NodeStatus.COMPLETED),
                TaskNode(node_id="c", node_type=NodeType.FINALIZE, status=NodeStatus.PENDING),
            ],
            edges=[],
        )

        assert graph.progress == 66.67  # 2/3 completed

    def test_is_complete(self):
        """Test graph completion check"""
        graph = TaskGraph(
            graph_id="test-007",
            name="Test Graph",
            nodes=[
                TaskNode(node_id="a", node_type=NodeType.PLAN, status=NodeStatus.COMPLETED),
                TaskNode(node_id="b", node_type=NodeType.REASON, status=NodeStatus.COMPLETED),
            ],
            edges=[],
        )

        assert graph.is_complete()

        graph.nodes[1].status = NodeStatus.RUNNING
        assert not graph.is_complete()


class TestTaskNode:
    """Test task node functionality"""

    def test_can_retry(self):
        """Test retry check"""
        node = TaskNode(
            node_id="test",
            node_type=NodeType.REASON,
            retry_count=0,
            max_retries=3,
            status=NodeStatus.FAILED,
        )

        assert node.can_retry()

        node.retry_count = 3
        assert not node.can_retry()

        node.status = NodeStatus.COMPLETED
        assert not node.can_retry()

    def test_execution_time_calculation(self):
        """Test execution time calculation"""
        node = TaskNode(
            node_id="test",
            node_type=NodeType.REASON,
            started_at=datetime(2024, 1, 1, 12, 0, 0),
            completed_at=datetime(2024, 1, 1, 12, 0, 1),
        )

        assert node.execution_time_ms == 1000


class TestCreateGraphForTaskType:
    """Test graph creation for task types"""

    def test_create_chat_graph(self):
        """Test creating chat task graph"""
        graph = create_graph_for_task_type("chat", "task-001")

        assert graph.name == "chat_task-001"
        assert len(graph.nodes) == 5  # Plan, memory, reason, critique, finalize

        # Check node types
        node_types = [n.node_type for n in graph.nodes]
        assert NodeType.PLAN in node_types
        assert NodeType.REASON in node_types
        assert NodeType.FINALIZE in node_types

    def test_create_research_graph(self):
        """Test creating research task graph"""
        graph = create_graph_for_task_type("research", "task-002")

        assert len(graph.nodes) == 7  # More steps for research
        assert graph.entry_node_id == graph.nodes[0].node_id
        assert graph.exit_node_id == graph.nodes[-1].node_id


class TestOrchestratorService:
    """Test orchestrator service"""

    @pytest.fixture
    async def orchestrator(self):
        """Create orchestrator for testing"""
        config = OrchestratorConfig(max_concurrent_tasks=10)
        service = OrchestratorService(config)
        await service.initialize()
        yield service
        await service.shutdown()

    @pytest.mark.asyncio
    async def test_create_task(self, orchestrator):
        """Test task creation"""
        task_id = await orchestrator.create_task(
            task_type="chat",
            tenant_id="tenant-001",
            user_id="user-001",
            input_data={"message": "Hello"},
            priority="normal",
        )

        assert task_id is not None
        task = orchestrator.tasks.get(task_id)
        assert task is not None
        assert task["task_type"] == "chat"
        assert task["status"] == "pending"

    @pytest.mark.asyncio
    async def test_execute_task(self, orchestrator):
        """Test task execution"""
        task_id = await orchestrator.create_task(
            task_type="chat",
            tenant_id="tenant-001",
        )

        result = await orchestrator.execute_task(task_id)

        assert result["status"] == "completed"
        task = orchestrator.tasks[task_id]
        assert task["status"] == "completed"

    @pytest.mark.asyncio
    async def test_cancel_task(self, orchestrator):
        """Test task cancellation"""
        task_id = await orchestrator.create_task(
            task_type="chat",
            tenant_id="tenant-001",
        )

        success = await orchestrator.cancel_task(task_id)
        assert success

        task = orchestrator.tasks[task_id]
        assert task["status"] == "cancelled"

    @pytest.mark.asyncio
    async def test_get_metrics(self, orchestrator):
        """Test metrics retrieval"""
        # Create some tasks
        for i in range(3):
            await orchestrator.create_task(
                task_type="chat",
                tenant_id="tenant-001",
            )

        metrics = await orchestrator.get_metrics()

        assert "active_tasks" in metrics
        assert "queued_tasks" in metrics
        assert "total_tasks" in metrics
        assert metrics["total_tasks"] >= 3


if __name__ == "__main__":
    pytest.main([__file__, "-v"])