"""
AI-OS Unit Tests - Memory Retrieval
"""
import pytest
import asyncio
from datetime import UTC, datetime, timedelta

from services.memory_service.app import memory_manager as memory_manager_module

MemoryManager = memory_manager_module.MemoryManager  # type: ignore[attr-defined]
MemoryType = memory_manager_module.MemoryType  # type: ignore[attr-defined]


class TestMemoryManager:
    """Test memory manager"""

    @pytest.fixture
    async def memory(self):
        """Create memory manager for testing"""
        manager = MemoryManager()
        yield manager

    @pytest.mark.asyncio
    async def test_store_semantic_memory(self, memory):
        """Test storing semantic memory"""
        memory_id = await memory.store(
            memory_type=MemoryType.SEMANTIC,
            content="This is a test memory about AI systems",
            tenant_id="tenant-001",
            user_id="user-001",
            tags=["ai", "systems", "test"],
            embedding=[0.1] * 1536,
        )

        assert memory_id is not None
        assert memory_id in memory.stores[MemoryType.SEMANTIC]

    @pytest.mark.asyncio
    async def test_store_working_memory(self, memory):
        """Test storing working memory"""
        memory_id = await memory.store(
            memory_type=MemoryType.WORKING,
            content="session key: test_value",
            tenant_id="tenant-001",
            session_id="session-001",
            metadata={
                "key": "key",
                "value": "test_value",
                "scope": "session",
                "ttl_seconds": 3600,
            },
        )

        assert memory_id is not None

    @pytest.mark.asyncio
    async def test_retrieve_empty(self, memory):
        """Test retrieval with no results"""
        from packages.schemas.src import MemorySearchRequest

        request = MemorySearchRequest(
            query="nonexistent query",
            top_k=10,
        )

        results = await memory.retrieve(
            request=request,
            tenant_id="tenant-001",
        )

        assert len(results) == 0

    @pytest.mark.asyncio
    async def test_retrieve_with_results(self, memory):
        """Test retrieval with stored memories"""
        # Store some memories
        await memory.store(
            memory_type=MemoryType.SEMANTIC,
            content="AI systems can learn and adapt",
            tenant_id="tenant-001",
            embedding=[0.1] * 1536,
        )

        await memory.store(
            memory_type=MemoryType.SEMANTIC,
            content="Machine learning is a subset of AI",
            tenant_id="tenant-001",
            embedding=[0.2] * 1536,
        )

        from packages.schemas.src import MemorySearchRequest

        request = MemorySearchRequest(
            query="AI learning",
            top_k=10,
        )

        results = await memory.retrieve(
            request=request,
            tenant_id="tenant-001",
        )

        assert isinstance(results, list)

    @pytest.mark.asyncio
    async def test_get_working_memory(self, memory):
        """Test getting working memory for session"""
        # Store working memory entries
        await memory.store_working_memory(
            tenant_id="tenant-001",
            session_id="session-001",
            key="counter",
            value=42,
        )

        await memory.store_working_memory(
            tenant_id="tenant-001",
            session_id="session-001",
            key="name",
            value="test",
        )

        results = await memory.get_working_memory(
            tenant_id="tenant-001",
            session_id="session-001",
        )

        assert len(results) >= 2

    @pytest.mark.asyncio
    async def test_get_working_memory_by_key(self, memory):
        """Test getting specific working memory by key"""
        await memory.store_working_memory(
            tenant_id="tenant-001",
            session_id="session-001",
            key="specific_key",
            value="specific_value",
        )

        results = await memory.get_working_memory(
            tenant_id="tenant-001",
            session_id="session-001",
            key="specific_key",
        )

        assert len(results) >= 1
        # Check content
        found = any("specific_key" in r.get("content", "") for r in results)
        assert found

    @pytest.mark.asyncio
    async def test_clear_expired(self, memory):
        """Test clearing expired memories"""
        # Store working memory with short TTL
        manager = MemoryManager()
        manager.config = {
            MemoryType.WORKING: {"ttl_seconds": 1, "max_entries": None},
        }

        await manager.store(
            memory_type=MemoryType.WORKING,
            content="This will expire",
            tenant_id="tenant-001",
            metadata={"ttl_seconds": 1},
        )

        # Wait for expiration
        import asyncio
        await asyncio.sleep(2)

        cleared = await manager.clear_expired()

        assert cleared >= 1

    @pytest.mark.asyncio
    async def test_query_normalization(self, memory):
        """Test query normalization"""
        normalized = memory._normalize_query("  Hello World  ")
        assert normalized == "hello world"

        normalized = memory._normalize_query("UPPERCASE")
        assert normalized == "uppercase"

    @pytest.mark.asyncio
    async def test_recency_weighting(self, memory):
        """Test recency weighting calculation"""
        # Recent memory
        recent_result = type('Result', (), {
            'memory_id': '1',
            'memory_type': MemoryType.SEMANTIC,
            'content': 'test',
            'relevance_score': 0.8,
            'created_at': datetime.now(UTC).replace(tzinfo=None),
        })()

        weight = memory._calculate_recency_weight(recent_result)
        assert weight > 0.9  # Recent memory has high weight

        # Old memory
        old_result = type('Result', (), {
            'memory_id': '2',
            'memory_type': MemoryType.SEMANTIC,
            'content': 'test',
            'relevance_score': 0.8,
            'created_at': (datetime.now(UTC) - timedelta(days=30)).replace(tzinfo=None),
        })()

        weight = memory._calculate_recency_weight(old_result)
        assert weight < 0.5  # Old memory has lower weight

    @pytest.mark.asyncio
    async def test_tenant_filtering(self, memory):
        """Test that tenant filtering works"""
        # Store memory for tenant-001
        await memory.store(
            memory_type=MemoryType.SEMANTIC,
            content="Tenant 001 secret data",
            tenant_id="tenant-001",
        )

        # Store memory for tenant-002
        await memory.store(
            memory_type=MemoryType.SEMANTIC,
            content="Tenant 002 secret data",
            tenant_id="tenant-002",
        )

        from packages.schemas.src import MemorySearchRequest

        request = MemorySearchRequest(
            query="secret",
            top_k=10,
        )

        # Should not see tenant-002's memory when querying as tenant-001
        results = await memory.retrieve(
            request=request,
            tenant_id="tenant-001",
        )

        # Verify no cross-tenant contamination
        for result in results:
            record = memory._get_record(result.memory_id, result.memory_type)
            if record:
                assert record.get("tenant_id") in [None, "tenant-001", "default"]


class TestMemoryRetrievalPipeline:
    """Test complete retrieval pipeline"""

    @pytest.mark.asyncio
    async def test_full_pipeline(self):
        """Test full retrieval pipeline execution"""
        memory = MemoryManager()

        # Store test memories
        for i in range(10):
            await memory.store(
                memory_type=MemoryType.SEMANTIC,
                content=f"Memory content {i} about artificial intelligence",
                tenant_id="test-tenant",
                embedding=[0.1] * 1536,
            )

        from packages.schemas.src import MemorySearchRequest

        request = MemorySearchRequest(
            query="artificial intelligence",
            top_k=5,
            rerank=True,
            compress=False,
            min_relevance=0.0,
        )

        results = await memory.retrieve(
            request=request,
            tenant_id="test-tenant",
        )

        # Should return results (exact matching depends on implementation)
        assert isinstance(results, list)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])