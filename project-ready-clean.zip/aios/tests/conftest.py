import pytest

from services.orchestrator.app.orchestrator import OrchestratorConfig, OrchestratorService
from services.security_gateway.app.policy import SecurityGateway  # type: ignore[attr-defined]


@pytest.fixture
async def orchestrator():
    """Shared orchestrator fixture for tests that reference it globally."""
    config = OrchestratorConfig(max_concurrent_tasks=10, task_timeout_seconds=300)
    service = OrchestratorService(config)
    await service.initialize()
    try:
        yield service
    finally:
        await service.shutdown()


@pytest.fixture
async def security_gateway():
    """Shared security gateway fixture for tests that reference it globally."""
    return SecurityGateway()
