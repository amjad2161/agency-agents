"""Legacy compatibility package for the underscore agent_fabric path."""
