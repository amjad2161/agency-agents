from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from packages.schemas.src import AgentRole

from services.agent_fabric.app.base_agent import AgentRouter


def _utcnow() -> datetime:
    """Return a naive UTC timestamp for compatibility with existing registry values."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


class AgentRegistry:
    """Minimal agent registry used by the current test suite."""

    def __init__(self):
        self.agents: dict[str, dict[str, Any]] = {}
        self.agent_heartbeats: dict[str, datetime] = {}
        self.heartbeat_timeout_seconds = 60

    def register(
        self,
        agent_id: str,
        agent_type: str,
        role: AgentRole,
        capabilities: list[str],
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self.agents[agent_id] = {
            "agent_id": agent_id,
            "agent_type": agent_type,
            "role": role.value,
            "capabilities": capabilities,
            "status": "offline",
            "registered_at": _utcnow().isoformat(),
            "metadata": metadata or {},
        }

    def unregister(self, agent_id: str) -> None:
        if agent_id in self.agents:
            del self.agents[agent_id]
            self.agent_heartbeats.pop(agent_id, None)

    def update_heartbeat(self, agent_id: str) -> None:
        self.agent_heartbeats[agent_id] = _utcnow()
        if agent_id in self.agents:
            self.agents[agent_id]["last_heartbeat"] = _utcnow().isoformat()

    def update_status(self, agent_id: str, status: str) -> None:
        if agent_id in self.agents:
            self.agents[agent_id]["status"] = status

    def get_agent(self, agent_id: str) -> dict[str, Any] | None:
        return self.agents.get(agent_id)

    def get_all_agents(self) -> list[dict[str, Any]]:
        return list(self.agents.values())

    def get_agents_by_role(self, role: AgentRole) -> list[dict[str, Any]]:
        return [agent for agent in self.agents.values() if agent["role"] == role.value]


agent_registry = AgentRegistry()


__all__ = ["AgentRouter", "AgentRegistry", "agent_registry"]