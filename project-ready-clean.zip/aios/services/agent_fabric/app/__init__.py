"""Legacy compatibility package for the underscore agent_fabric app path."""
