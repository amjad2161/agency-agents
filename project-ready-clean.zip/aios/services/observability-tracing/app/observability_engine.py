"""
AI-OS Observability & Causal Tracing
Production-grade observability with distributed tracing, metrics, and causal analysis
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class TraceType(str, Enum):
    """Trace types for different operations"""
    AGENT = "agent"
    TOOL = "tool"
    REASONING = "reasoning"
    MEMORY = "memory"
    KNOWLEDGE = "knowledge"
    LANGUAGE = "language"
    GENERATION = "generation"


class MetricType(str, Enum):
    """Metric types"""
    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"
    TIMER = "timer"


class LogLevel(str, Enum):
    """Log levels"""
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class CausalRelationship(str, Enum):
    """Causal relationship types"""
    CAUSES = "causes"
    ENABLES = "enables"
    INHIBITS = "inhibits"
    CORRELATES = "correlates"


@dataclass
class TraceSpan:
    """Individual trace span"""
    span_id: str
    trace_id: str
    parent_span_id: str | None
    operation_name: str
    trace_type: TraceType
    start_time: datetime
    end_time: datetime | None
    duration_ms: float | None
    status: str = "started"
    attributes: dict[str, Any] = field(default_factory=dict)
    events: list[dict[str, Any]] = field(default_factory=list)
    logs: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class DistributedTrace:
    """Complete distributed trace"""
    trace_id: str
    root_span_id: str
    spans: dict[str, TraceSpan] = field(default_factory=dict)
    start_time: datetime
    end_time: datetime | None
    duration_ms: float | None
    metadata: dict[str, Any] = field(default_factory=dict)
    causal_graph: dict[str, list[str]] = field(default_factory=dict)


@dataclass
class MetricPoint:
    """Metric data point"""
    metric_id: str
    name: str
    metric_type: MetricType
    value: float
    timestamp: datetime
    labels: dict[str, str] = field(default_factory=dict)
    unit: str = ""


@dataclass
class LogEntry:
    """Structured log entry"""
    log_id: str
    timestamp: datetime
    level: LogLevel
    trace_id: str | None
    span_id: str | None
    service: str
    operation: str
    message: str
    attributes: dict[str, Any] = field(default_factory=dict)
    exception: str | None = None


@dataclass
class CausalNode:
    """Causal analysis node"""
    node_id: str
    event_type: str
    description: str
    timestamp: datetime
    properties: dict[str, Any] = field(default_factory=dict)
    impact_score: float = 0.0


@dataclass
class CausalLink:
    """Causal relationship between nodes"""
    link_id: str
    source_node_id: str
    target_node_id: str
    relationship: CausalRelationship
    strength: float = 1.0
    description: str = ""
    evidence: list[str] = field(default_factory=list)


@dataclass
class CausalGraph:
    """Complete causal graph"""
    graph_id: str
    nodes: dict[str, CausalNode] = field(default_factory=dict)
    links: dict[str, CausalLink] = field(default_factory=dict)
    created_at: datetime
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ObservabilityStats:
    """Observability statistics"""
    total_traces: int = 0
    total_spans: int = 0
    total_metrics: int = 0
    total_logs: int = 0
    error_rate: float = 0.0
    avg_latency_ms: float = 0.0
    p50_latency_ms: float = 0.0
    p95_latency_ms: float = 0.0
    p99_latency_ms: float = 0.0


@dataclass
class Alert:
    """Observability alert"""
    alert_id: str
    name: str
    severity: str
    condition: str
    current_value: float
    threshold: float
    triggered_at: datetime
    acknowledged: bool = False
    resolved_at: datetime | None = None


class TraceManager:
    """Distributed tracing manager"""

    def __init__(self):
        self.traces: dict[str, DistributedTrace] = {}
        self.spans_by_trace: dict[str, list[TraceSpan]] = {}

        # Statistics
        self.stats = {
            "total_traces": 0,
            "total_spans": 0,
            "active_traces": 0,
        }

        # Configuration
        self.max_traces = 1000
        self.trace_ttl_seconds = 3600

    async def start_trace(
        self,
        trace_type: TraceType,
        operation_name: str,
        parent_span_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> tuple[str, str]:
        """Start a new trace"""
        trace_id = hashlib.md5(f"{time.time()}_{operation_name}".encode()).hexdigest()[:16]
        span_id = hashlib.md5(f"{trace_id}_{time.time()}".encode()).hexdigest()[:16]

        trace = DistributedTrace(
            trace_id=trace_id,
            root_span_id=span_id,
            start_time=datetime.utcnow(),
            metadata=metadata or {},
        )

        root_span = TraceSpan(
            span_id=span_id,
            trace_id=trace_id,
            parent_span_id=None,
            operation_name=operation_name,
            trace_type=trace_type,
            start_time=datetime.utcnow(),
            end_time=None,
            duration_ms=None,
        )

        trace.spans[span_id] = root_span
        self.traces[trace_id] = trace
        self.spans_by_trace[trace_id] = [root_span]

        self.stats["total_traces"] += 1
        self.stats["active_traces"] += 1

        return trace_id, span_id

    async def start_span(
        self,
        trace_id: str,
        operation_name: str,
        parent_span_id: str | None = None,
        trace_type: TraceType = TraceType.TOOL,
    ) -> str:
        """Start a new span within existing trace"""
        if trace_id not in self.traces:
            # Auto-create trace if not exists
            trace_id, _ = await self.start_trace(trace_type, operation_name)

        span_id = hashlib.md5(f"{trace_id}_{time.time()}_{operation_name}".encode()).hexdigest()[:16]

        span = TraceSpan(
            span_id=span_id,
            trace_id=trace_id,
            parent_span_id=parent_span_id,
            operation_name=operation_name,
            trace_type=trace_type,
            start_time=datetime.utcnow(),
            end_time=None,
            duration_ms=None,
        )

        self.traces[trace_id].spans[span_id] = span
        self.spans_by_trace[trace_id].append(span)
        self.stats["total_spans"] += 1

        return span_id

    async def end_span(
        self,
        trace_id: str,
        span_id: str,
        status: str = "success",
        attributes: dict[str, Any] | None = None,
    ):
        """End a span"""
        if trace_id not in self.traces or span_id not in self.traces[trace_id].spans:
            return

        span = self.traces[trace_id].spans[span_id]
        span.end_time = datetime.utcnow()
        span.duration_ms = (span.end_time - span.start_time).total_seconds() * 1000
        span.status = status

        if attributes:
            span.attributes.update(attributes)

        # Update trace
        trace = self.traces[trace_id]
        if trace.end_time is None:
            trace.end_time = span.end_time
            trace.duration_ms = (trace.end_time - trace.start_time).total_seconds() * 1000

    async def add_span_event(
        self,
        trace_id: str,
        span_id: str,
        event_name: str,
        attributes: dict[str, Any] | None = None,
    ):
        """Add event to span"""
        if trace_id in self.traces and span_id in self.traces[trace_id].spans:
            event = {
                "name": event_name,
                "timestamp": datetime.utcnow().isoformat(),
                "attributes": attributes or {},
            }
            self.traces[trace_id].spans[span_id].events.append(event)

    async def add_span_log(
        self,
        trace_id: str,
        span_id: str,
        level: LogLevel,
        message: str,
        attributes: dict[str, Any] | None = None,
    ):
        """Add log to span"""
        if trace_id in self.traces and span_id in self.traces[trace_id].spans:
            log = {
                "level": level.value,
                "message": message,
                "timestamp": datetime.utcnow().isoformat(),
                "attributes": attributes or {},
            }
            self.traces[trace_id].spans[span_id].logs.append(log)

    async def end_trace(self, trace_id: str):
        """End a trace and mark as complete"""
        if trace_id in self.traces:
            trace = self.traces[trace_id]
            if trace.end_time is None:
                trace.end_time = datetime.utcnow()
                trace.duration_ms = (trace.end_time - trace.start_time).total_seconds() * 1000

            self.stats["active_traces"] -= 1

    def get_trace(self, trace_id: str) -> DistributedTrace | None:
        """Get trace by ID"""
        return self.traces.get(trace_id)

    def get_span(self, trace_id: str, span_id: str) -> TraceSpan | None:
        """Get span by ID"""
        if trace_id in self.traces:
            return self.traces[trace_id].spans.get(span_id)
        return None

    async def cleanup_old_traces(self):
        """Remove old traces"""
        cutoff = datetime.utcnow().timestamp() - self.trace_ttl_seconds
        to_delete = [
            trace_id for trace_id, trace in self.traces.items()
            if trace.start_time.timestamp() < cutoff
        ]
        for trace_id in to_delete:
            del self.traces[trace_id]
            if trace_id in self.spans_by_trace:
                del self.spans_by_trace[trace_id]

        return len(to_delete)

    def get_stats(self) -> dict[str, Any]:
        """Get trace statistics"""
        return {
            **self.stats,
            "stored_traces": len(self.traces),
        }


class MetricsCollector:
    """Metrics collection and aggregation"""

    def __init__(self):
        self.metrics: list[MetricPoint] = []
        self.aggregations: dict[str, list[float]] = {}

        # Pre-defined metrics
        self.defined_metrics = {
            "request_count": {"type": MetricType.COUNTER, "unit": "count"},
            "request_latency": {"type": MetricType.HISTOGRAM, "unit": "ms"},
            "error_count": {"type": MetricType.COUNTER, "unit": "count"},
            "cache_hit_rate": {"type": MetricType.GAUGE, "unit": "ratio"},
            "memory_usage": {"type": MetricType.GAUGE, "unit": "bytes"},
            "cpu_usage": {"type": MetricType.GAUGE, "unit": "percent"},
            "active_agents": {"type": MetricType.GAUGE, "unit": "count"},
            "queue_depth": {"type": MetricType.GAUGE, "unit": "count"},
        }

        self.stats = {
            "total_metrics": 0,
            "aggregations": {},
        }

    async def record(
        self,
        name: str,
        value: float,
        labels: dict[str, str] | None = None,
        unit: str = "",
    ):
        """Record a metric"""
        metric_id = hashlib.md5(
            f"{name}_{time.time()}_{value}".encode()
        ).hexdigest()[:16]

        metric = MetricPoint(
            metric_id=metric_id,
            name=name,
            metric_type=self.defined_metrics.get(name, {}).get("type", MetricType.GAUGE),
            value=value,
            timestamp=datetime.utcnow(),
            labels=labels or {},
            unit=unit or self.defined_metrics.get(name, {}).get("unit", ""),
        )

        self.metrics.append(metric)
        self.stats["total_metrics"] += 1

        # Update aggregations
        if name not in self.aggregations:
            self.aggregations[name] = []
        self.aggregations[name].append(value)

        return metric

    async def increment(self, name: str, labels: dict[str, str] | None = None):
        """Increment counter metric"""
        return await self.record(name, 1.0, labels)

    async def gauge(
        self,
        name: str,
        value: float,
        labels: dict[str, str] | None = None,
    ):
        """Set gauge metric"""
        return await self.record(name, value, labels)

    async def histogram(
        self,
        name: str,
        value: float,
        labels: dict[str, str] | None = None,
    ):
        """Record histogram value"""
        return await self.record(name, value, labels)

    def get_aggregations(self, metric_name: str) -> dict[str, float]:
        """Get aggregations for a metric"""
        values = self.aggregations.get(metric_name, [])
        if not values:
            return {}

        sorted_values = sorted(values)
        count = len(sorted_values)

        return {
            "count": count,
            "sum": sum(sorted_values),
            "mean": sum(sorted_values) / count,
            "min": sorted_values[0],
            "max": sorted_values[-1],
            "p50": sorted_values[int(count * 0.5)],
            "p95": sorted_values[int(count * 0.95)] if count > 20 else sorted_values[-1],
            "p99": sorted_values[int(count * 0.99)] if count > 100 else sorted_values[-1],
        }

    def get_stats(self) -> dict[str, Any]:
        """Get metrics statistics"""
        return {
            **self.stats,
            "defined_metrics": len(self.defined_metrics),
            "aggregated_metrics": len(self.aggregations),
        }


class CausalAnalyzer:
    """Causal analysis for AI operations"""

    def __init__(self):
        self.graphs: dict[str, CausalGraph] = {}
        self.event_history: list[dict[str, Any]] = []

        self.stats = {
            "total_nodes": 0,
            "total_links": 0,
            "anomalies_detected": 0,
        }

    async def create_graph(
        self,
        graph_id: str,
        metadata: dict[str, Any] | None = None,
    ) -> CausalGraph:
        """Create new causal graph"""
        graph = CausalGraph(
            graph_id=graph_id,
            created_at=datetime.utcnow(),
            metadata=metadata or {},
        )
        self.graphs[graph_id] = graph
        return graph

    async def add_node(
        self,
        graph_id: str,
        event_type: str,
        description: str,
        properties: dict[str, Any] | None = None,
        impact_score: float = 0.0,
    ) -> str:
        """Add node to causal graph"""
        if graph_id not in self.graphs:
            await self.create_graph(graph_id)

        graph = self.graphs[graph_id]
        node_id = hashlib.md5(
            f"{event_type}_{time.time()}".encode()
        ).hexdigest()[:16]

        node = CausalNode(
            node_id=node_id,
            event_type=event_type,
            description=description,
            timestamp=datetime.utcnow(),
            properties=properties or {},
            impact_score=impact_score,
        )

        graph.nodes[node_id] = node
        self.stats["total_nodes"] += 1

        return node_id

    async def add_link(
        self,
        graph_id: str,
        source_node_id: str,
        target_node_id: str,
        relationship: CausalRelationship,
        strength: float = 1.0,
        description: str = "",
        evidence: list[str] | None = None,
    ) -> str:
        """Add causal link between nodes"""
        if graph_id not in self.graphs:
            return ""

        graph = self.graphs[graph_id]
        if source_node_id not in graph.nodes or target_node_id not in graph.nodes:
            return ""

        link_id = hashlib.md5(
            f"{source_node_id}_{target_node_id}_{time.time()}".encode()
        ).hexdigest()[:16]

        link = CausalLink(
            link_id=link_id,
            source_node_id=source_node_id,
            target_node_id=target_node_id,
            relationship=relationship,
            strength=strength,
            description=description,
            evidence=evidence or [],
        )

        graph.links[link_id] = link
        self.stats["total_links"] += 1

        return link_id

    async def analyze_root_cause(
        self,
        graph_id: str,
        target_node_id: str,
    ) -> list[dict[str, Any]]:
        """Analyze root cause for an event"""
        if graph_id not in self.graphs:
            return []

        graph = self.graphs[graph_id]
        if target_node_id not in graph.nodes:
            return []

        # Build cause chain
        causes = []
        visited = set()

        def find_causes(node_id: str, depth: int = 0, path: list[str] | None = None):
            if depth > 10 or node_id in visited or path is None:
                return

            visited.add(node_id)
            path.append(node_id)

            # Find links pointing to this node
            for link in graph.links.values():
                if link.target_node_id == node_id:
                    source_node = graph.nodes.get(link.source_node_id)
                    if source_node:
                        cause_entry = {
                            "node": source_node,
                            "relationship": link.relationship.value,
                            "strength": link.strength,
                            "depth": depth,
                            "path": path.copy(),
                        }
                        causes.append(cause_entry)
                        find_causes(link.source_node_id, depth + 1, path)

            path.pop()
            visited.discard(node_id)

        find_causes(target_node_id, 0, [])

        return causes

    async def detect_anomaly(
        self,
        graph_id: str,
        expected_pattern: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Detect anomalies in causal graph"""
        if graph_id not in self.graphs:
            return []

        graph = self.graphs[graph_id]
        anomalies = []

        # Check for unexpected nodes
        for node_id, node in graph.nodes.items():
            if not any(
                pattern.get("event_type") == node.event_type
                for pattern in expected_pattern.get("expected_events", [])
            ):
                anomalies.append({
                    "type": "unexpected_event",
                    "node": node,
                    "description": f"Unexpected event type: {node.event_type}",
                })
                self.stats["anomalies_detected"] += 1

        # Check for broken causal chains
        for link in graph.links.values():
            if link.relationship == CausalRelationship.CAUSES and link.strength < 0.5:
                anomalies.append({
                    "type": "weak_causation",
                    "link": link,
                    "description": f"Weak causal relationship detected",
                })
                self.stats["anomalies_detected"] += 1

        return anomalies

    def get_graph(self, graph_id: str) -> CausalGraph | None:
        """Get causal graph by ID"""
        return self.graphs.get(graph_id)

    def get_stats(self) -> dict[str, Any]:
        """Get causal analysis statistics"""
        return {
            **self.stats,
            "active_graphs": len(self.graphs),
        }


class AlertManager:
    """Alert management system"""

    def __init__(self):
        self.alerts: dict[str, Alert] = {}
        self.alert_rules: list[dict[str, Any]] = []

        # Pre-defined alert rules
        self._initialize_rules()

        self.stats = {
            "total_alerts": 0,
            "active_alerts": 0,
            "acknowledged_alerts": 0,
        }

    def _initialize_rules(self):
        """Initialize default alert rules"""
        self.alert_rules = [
            {
                "name": "high_error_rate",
                "condition": "error_rate > 0.05",
                "threshold": 0.05,
                "severity": "critical",
            },
            {
                "name": "high_latency",
                "condition": "p99_latency > 1000",
                "threshold": 1000,
                "severity": "warning",
            },
            {
                "name": "memory_usage",
                "condition": "memory_usage > 0.9",
                "threshold": 0.9,
                "severity": "warning",
            },
            {
                "name": "queue_overflow",
                "condition": "queue_depth > 1000",
                "threshold": 1000,
                "severity": "critical",
            },
        ]

    async def evaluate_rules(
        self,
        metrics: dict[str, float],
    ) -> list[Alert]:
        """Evaluate alert rules against metrics"""
        triggered_alerts = []

        for rule in self.alert_rules:
            condition = rule["condition"]
            threshold = rule["threshold"]

            # Parse simple conditions
            if "error_rate >" in condition:
                metric_value = metrics.get("error_rate", 0)
                if metric_value > threshold:
                    alert = await self._create_alert(rule, metric_value)
                    triggered_alerts.append(alert)

            elif "p99_latency >" in condition:
                metric_value = metrics.get("p99_latency", 0)
                if metric_value > threshold:
                    alert = await self._create_alert(rule, metric_value)
                    triggered_alerts.append(alert)

            elif "memory_usage >" in condition:
                metric_value = metrics.get("memory_usage", 0)
                if metric_value > threshold:
                    alert = await self._create_alert(rule, metric_value)
                    triggered_alerts.append(alert)

            elif "queue_depth >" in condition:
                metric_value = metrics.get("queue_depth", 0)
                if metric_value > threshold:
                    alert = await self._create_alert(rule, metric_value)
                    triggered_alerts.append(alert)

        return triggered_alerts

    async def _create_alert(
        self,
        rule: dict[str, Any],
        current_value: float,
    ) -> Alert:
        """Create alert from triggered rule"""
        alert_id = hashlib.md5(
            f"{rule['name']}_{time.time()}".encode()
        ).hexdigest()[:16]

        alert = Alert(
            alert_id=alert_id,
            name=rule["name"],
            severity=rule["severity"],
            condition=rule["condition"],
            current_value=current_value,
            threshold=rule["threshold"],
            triggered_at=datetime.utcnow(),
        )

        self.alerts[alert_id] = alert
        self.stats["total_alerts"] += 1
        self.stats["active_alerts"] += 1

        return alert

    async def acknowledge_alert(self, alert_id: str):
        """Acknowledge an alert"""
        if alert_id in self.alerts:
            self.alerts[alert_id].acknowledged = True
            self.stats["acknowledged_alerts"] += 1

    async def resolve_alert(self, alert_id: str):
        """Resolve an alert"""
        if alert_id in self.alerts:
            self.alerts[alert_id].resolved_at = datetime.utcnow()
            self.stats["active_alerts"] -= 1

    def get_active_alerts(self) -> list[Alert]:
        """Get all active alerts"""
        return [
            alert for alert in self.alerts.values()
            if not alert.resolved_at
        ]

    def get_stats(self) -> dict[str, Any]:
        """Get alert statistics"""
        return {
            **self.stats,
            "alert_rules": len(self.alert_rules),
        }


class ObservabilityEngine:
    """
    Comprehensive Observability Engine for AI-OS.
    Combines distributed tracing, metrics, logging, and causal analysis.
    """

    def __init__(self):
        self.trace_manager = TraceManager()
        self.metrics_collector = MetricsCollector()
        self.causal_analyzer = CausalAnalyzer()
        self.alert_manager = AlertManager()

        self.enabled = True

    async def start_operation(
        self,
        operation_name: str,
        operation_type: TraceType,
        trace_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> tuple[str, str]:
        """Start an observable operation"""
        if trace_id is None:
            trace_id, span_id = await self.trace_manager.start_trace(
                operation_type, operation_name, metadata=metadata
            )
        else:
            span_id = await self.trace_manager.start_span(
                trace_id, operation_name, trace_type=operation_type
            )

        return trace_id, span_id

    async def end_operation(
        self,
        trace_id: str,
        span_id: str,
        status: str = "success",
        metrics: dict[str, Any] | None = None,
    ):
        """End an observable operation"""
        await self.trace_manager.end_span(trace_id, span_id, status)

        if metrics:
            for metric_name, value in metrics.items():
                await self.metrics_collector.record(metric_name, value)

    async def record_metric(
        self,
        name: str,
        value: float,
        labels: dict[str, str] | None = None,
    ):
        """Record a metric"""
        await self.metrics_collector.record(name, value, labels)

    async def create_causal_graph(
        self,
        graph_name: str,
        metadata: dict[str, Any] | None = None,
    ) -> CausalGraph:
        """Create a new causal graph"""
        graph_id = hashlib.md5(f"{graph_name}_{time.time()}".encode()).hexdigest()[:16]
        return await self.causal_analyzer.create_graph(graph_id, metadata)

    async def analyze_failure(
        self,
        trace_id: str,
    ) -> dict[str, Any]:
        """Analyze failure using causal tracing"""
        trace = self.trace_manager.get_trace(trace_id)
        if not trace:
            return {"error": "Trace not found"}

        # Find errors in spans
        error_spans = [
            span for span in trace.spans.values()
            if span.status == "error"
        ]

        if not error_spans:
            return {
                "trace_id": trace_id,
                "error_count": 0,
                "analysis": "No errors found",
            }

        # Root cause analysis
        root_causes = []
        for error_span in error_spans:
            causes = await self.causal_analyzer.analyze_root_cause(
                trace.metadata.get("causal_graph_id", ""),
                error_span.span_id,
            )
            root_causes.extend(causes)

        return {
            "trace_id": trace_id,
            "error_count": len(error_spans),
            "error_spans": [
                {
                    "span_id": span.span_id,
                    "operation": span.operation_name,
                    "duration_ms": span.duration_ms,
                }
                for span in error_spans
            ],
            "root_causes": root_causes,
        }

    async def check_alerts(
        self,
        current_metrics: dict[str, float],
    ) -> list[Alert]:
        """Check and trigger alerts"""
        return await self.alert_manager.evaluate_rules(current_metrics)

    async def log_event(
        self,
        trace_id: str | None,
        span_id: str | None,
        level: LogLevel,
        message: str,
        attributes: dict[str, Any] | None = None,
    ):
        """Log an event"""
        log_entry = LogEntry(
            log_id=hashlib.md5(f"{time.time()}_{message}".encode()).hexdigest()[:16],
            timestamp=datetime.utcnow(),
            level=level,
            trace_id=trace_id,
            span_id=span_id,
            service="ai-os",
            operation="logging",
            message=message,
            attributes=attributes or {},
        )

        # Add to trace if available
        if trace_id and span_id:
            await self.trace_manager.add_span_log(
                trace_id, span_id, level, message, attributes
            )

        return log_entry

    def get_comprehensive_stats(self) -> dict[str, Any]:
        """Get comprehensive observability statistics"""
        metrics = self.metrics_collector.get_aggregations("request_latency")

        return {
            "trace": self.trace_manager.get_stats(),
            "metrics": self.metrics_collector.get_stats(),
            "causal": self.causal_analyzer.get_stats(),
            "alerts": self.alert_manager.get_stats(),
            "latency": metrics,
        }

    async def cleanup(self):
        """Run cleanup tasks"""
        cleaned_traces = await self.trace_manager.cleanup_old_traces()
        return {
            "traces_cleaned": cleaned_traces,
        }


async def example():
    """Example observability system usage"""

    observability = ObservabilityEngine()

    print("=" * 60)
    print("AI-OS Observability & Causal Tracing Example")
    print("=" * 60)

    # Start a trace
    print("\n[Test 1] Distributed Tracing")
    trace_id, span_id = await observability.start_operation(
        operation_name="agent_process",
        operation_type=TraceType.AGENT,
        metadata={"user_id": "user_123"},
    )
    print(f"Started Trace: {trace_id}")
    print(f"Root Span: {span_id}")

    # Add child spans
    child_span_id = await observability.start_operation(
        operation_name="reasoning_chain",
        operation_type=TraceType.REASONING,
        trace_id=trace_id,
    )
    print(f"Child Span: {child_span_id}")

    # Record metrics
    print("\n[Test 2] Metrics Collection")
    await observability.record_metric("request_count", 1.0)
    await observability.record_metric("request_latency", 45.2)
    await observability.record_metric("cache_hit_rate", 0.85)
    await observability.record_metric("memory_usage", 0.6)

    # Simulate processing
    await observability.trace_manager.add_span_event(
        trace_id, span_id, "processing_started", {"batch_size": 10}
    )
    await observability.trace_manager.add_span_event(
        trace_id, span_id, "processing_completed", {"processed": 10}
    )

    # End child span
    await observability.end_operation(trace_id, child_span_id)

    # End root span
    await observability.end_operation(
        trace_id, span_id, metrics={"items_processed": 10}
    )

    # Record error metrics
    await observability.record_metric("error_count", 0.0)

    # Causal analysis
    print("\n[Test 3] Causal Analysis")
    graph = await observability.create_causal_graph(
        graph_name="agent_execution",
        metadata={"trace_id": trace_id},
    )

    node1_id = await observability.causal_analyzer.add_node(
        graph.graph_id,
        event_type="user_request",
        description="User made a request",
        impact_score=1.0,
    )

    node2_id = await observability.causal_analyzer.add_node(
        graph.graph_id,
        event_type="agent_processing",
        description="Agent is processing request",
        impact_score=0.8,
    )

    node3_id = await observability.causal_analyzer.add_node(
        graph.graph_id,
        event_type="error",
        description="An error occurred",
        impact_score=1.0,
    )

    await observability.causal_analyzer.add_link(
        graph.graph_id, node1_id, node2_id,
        CausalRelationship.CAUSES,
        strength=0.9,
        description="Request causes processing"
    )

    await observability.causal_analyzer.add_link(
        graph.graph_id, node2_id, node3_id,
        CausalRelationship.CAUSES,
        strength=0.7,
        description="Processing may cause error"
    )

    # Root cause analysis
    causes = await observability.causal_analyzer.analyze_root_cause(
        graph.graph_id, node3_id
    )
    print(f"Root Causes for Error: {len(causes)}")

    # Alert evaluation
    print("\n[Test 4] Alert Evaluation")
    current_metrics = {
        "error_rate": 0.02,
        "p99_latency": 500,
        "memory_usage": 0.6,
        "queue_depth": 100,
    }
    alerts = await observability.check_alerts(current_metrics)
    print(f"Active Alerts: {len(alerts)}")

    # Log events
    print("\n[Test 5] Structured Logging")
    log = await observability.log_event(
        trace_id=trace_id,
        span_id=span_id,
        level=LogLevel.INFO,
        message="Operation completed successfully",
        attributes={"duration_ms": 150, "items": 10},
    )
    print(f"Logged: {log.message}")

    # Comprehensive stats
    print("\n" + "=" * 60)
    print("Comprehensive Statistics")
    print("=" * 60)
    stats = observability.get_comprehensive_stats()

    for section, data in stats.items():
        print(f"\n{section}:")
        if isinstance(data, dict):
            for key, value in data.items():
                if isinstance(value, float):
                    print(f"  {key}: {value:.4f}")
                else:
                    print(f"  {key}: {value}")


if __name__ == "__main__":
    asyncio.run(example())
