"""
AI-OS Agent Fabric - Agent Router
Inter-agent communication and task routing
"""
from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, timezone
from typing import Any

from packages.schemas.src import (
    AgentMessage,
    AgentMessageType,
    AgentRole,
    MessageMetadata,
    MessagePayload,
    MessagePriority,
)

from .base_agent import AgentRouter, AgentCapability, router

logger = logging.getLogger(__name__)


def _utcnow() -> datetime:
    """Return a naive UTC timestamp for compatibility with existing schema fields."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


class AgentCommunicationProtocol:
    """
    Protocol for inter-agent communication.
    Handles message routing, delivery, and acknowledgement.
    """

    def __init__(self):
        self.pending_messages: dict[str, AgentMessage] = {}
        self.message_history: list[AgentMessage] = []
        self.max_history_size = 10000

    async def _deliver_direct_message(self, message: AgentMessage) -> None:
        """Deliver a message to a single explicit recipient."""
        recipient = message.recipient
        if recipient is None:
            return

        agent = router.get_agent(recipient)
        if agent:
            await agent.message_queue.put(message)
            logger.debug(f"Delivered message {message.id} to {recipient}")
            return
        logger.warning(f"Agent {recipient} not found")

    async def _deliver_role_broadcast(self, message: AgentMessage) -> None:
        """Deliver a message to all agents matching the target roles."""
        for role in message.recipient_roles:
            agents = router.get_available_agents(role=role)
            for agent in agents:
                await agent.message_queue.put(message)
        logger.debug(f"Broadcast message {message.id} to {len(message.recipient_roles)} roles")

    async def _deliver_global_broadcast(self, message: AgentMessage) -> None:
        """Deliver a message to all available agents except the sender."""
        agents = router.get_available_agents()
        for agent in agents:
            if agent.agent_id != message.sender:
                await agent.message_queue.put(message)
        logger.debug(f"Broadcast message {message.id} to {len(agents)} agents")

    async def send_message(
        self,
        sender: str,
        recipient: str | None,
        message_type: AgentMessageType,
        payload: dict[str, Any],
        task_id: str | None = None,
        priority: MessagePriority = MessagePriority.NORMAL,
        recipient_roles: list[AgentRole] | None = None,
    ) -> AgentMessage:
        """Send a message to another agent or broadcast"""

        message = AgentMessage(
            trace_id=str(uuid.uuid4()),
            task_id=task_id,
            sender=sender,
            recipient=recipient,
            sender_role=AgentRole.COORDINATOR,  # Would be dynamic
            message_type=message_type,
            priority=priority,
            payload=MessagePayload(**payload),
            recipient_roles=recipient_roles or [],
            metadata=MessageMetadata(
                correlation_id=str(uuid.uuid4()),
                custom={"sent_at": _utcnow().isoformat()},
            )
        )

        # Store pending
        self.pending_messages[message.id] = message

        # Deliver message
        await self._deliver_message(message)

        # Store in history
        self.message_history.append(message)
        if len(self.message_history) > self.max_history_size:
            self.message_history = self.message_history[-self.max_history_size:]

        return message

    async def _deliver_message(self, message: AgentMessage) -> None:
        """Deliver message to recipient"""
        if message.recipient:
            await self._deliver_direct_message(message)
        elif message.recipient_roles:
            await self._deliver_role_broadcast(message)
        else:
            await self._deliver_global_broadcast(message)

        # Mark as delivered
        message.status = "delivered"
        message.delivered_at = _utcnow()

    async def wait_for_response(
        self,
        message_id: str,
        timeout_seconds: float = 30.0,
    ) -> AgentMessage | None:
        """Wait for response to a sent message"""
        original_message = self.pending_messages.get(message_id)
        if not original_message:
            return None

        start_time = _utcnow()

        while (_utcnow() - start_time).total_seconds() < timeout_seconds:
            # Check for response in history
            for msg in reversed(self.message_history):
                if (
                    msg.metadata.reply_to == message_id
                    and msg.sender != original_message.sender
                ):
                    return msg

            await asyncio.sleep(0.1)

        return None

    def get_pending_count(self, agent_id: str) -> int:
        """Get count of pending messages for agent"""
        return sum(
            1 for msg in self.pending_messages.values()
            if msg.recipient == agent_id and msg.status == "pending"
        )


class TaskRouter:
    """
    Routes tasks to appropriate agents based on task type and requirements.
    """

    def __init__(
        self,
        router: AgentRouter,
        communication: AgentCommunicationProtocol,
    ):
        self.router = router
        self.communication = communication

        # Task type to role mapping
        self.task_role_mapping = {
            "chat": AgentRole.COORDINATOR,
            "research": AgentRole.RESEARCHER,
            "code_generation": AgentRole.GENERATOR,
            "planning": AgentRole.PLANNER,
            "execution": AgentRole.EXECUTOR,
            "critique": AgentRole.CRITIC,
            "verification": AgentRole.VERIFIER,
            "data_analysis": AgentRole.RESEARCHER,
            "creative": AgentRole.GENERATOR,
        }

    async def route_task_to_agent(
        self,
        task_type: str,
        task_id: str,
        requirements: dict[str, Any],
        payload: dict[str, Any],
    ) -> str | None:
        """
        Route a task to an appropriate agent.

        Args:
            task_type: Type of task to route
            task_id: Task identifier
            requirements: Task requirements
            payload: Task payload

        Returns:
            agent_id of selected agent or None
        """
        # Route to agent
        agent = self.router.route_task(task_type, requirements)
        if not agent:
            logger.warning(f"No agent available for task type {task_type}")
            return None

        # Send task message to agent
        message_type = self._get_message_type_for_task(task_type)

        await self.communication.send_message(
            sender="task_router",
            recipient=agent.agent_id,
            message_type=message_type,
            payload=payload,
            task_id=task_id,
            priority=MessagePriority(requirements.get("priority", 2)),
        )

        return agent.agent_id

    def _get_message_type_for_task(self, task_type: str) -> AgentMessageType:
        """Map task type to agent message type"""
        mapping = {
            "planning": AgentMessageType.PLAN,
            "research": AgentMessageType.QUERY,
            "execution": AgentMessageType.ACTION,
            "critique": AgentMessageType.CRITIQUE,
            "verification": AgentMessageType.VERIFY,
            "chat": AgentMessageType.ACTION,
            "code_generation": AgentMessageType.ACTION,
        }
        return mapping.get(task_type, AgentMessageType.ACTION)


# Global instances
communication_protocol = AgentCommunicationProtocol()
task_router = TaskRouter(router, communication_protocol)


class AgentRegistry:
    """
    Registry for managing agent lifecycle and state.
    """

    def __init__(self):
        self.agents: dict[str, dict[str, Any]] = {}
        self.agent_heartbeats: dict[str, datetime] = {}
        self.heartbeat_timeout_seconds = 60

    def register(
        self,
        agent_id: str,
        agent_type: str,
        role: AgentRole,
        capabilities: list[str],
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Register a new agent"""
        self.agents[agent_id] = {
            "agent_id": agent_id,
            "agent_type": agent_type,
            "role": role.value,
            "capabilities": capabilities,
            "status": "offline",
            "registered_at": _utcnow().isoformat(),
            "metadata": metadata or {},
        }
        logger.info(f"Registered agent {agent_id} of type {agent_type}")

    def unregister(self, agent_id: str) -> None:
        """Unregister an agent"""
        if agent_id in self.agents:
            del self.agents[agent_id]
            self.agent_heartbeats.pop(agent_id, None)
            logger.info(f"Unregistered agent {agent_id}")

    def update_heartbeat(self, agent_id: str) -> None:
        """Update agent heartbeat timestamp"""
        self.agent_heartbeats[agent_id] = _utcnow()

        if agent_id in self.agents:
            self.agents[agent_id]["last_heartbeat"] = _utcnow().isoformat()

    def get_stale_agents(self) -> list[str]:
        """Get IDs of agents that have stale heartbeats"""
        stale = []
        now = _utcnow()

        for agent_id, last_heartbeat in self.agent_heartbeats.items():
            if (now - last_heartbeat).total_seconds() > self.heartbeat_timeout_seconds:
                stale.append(agent_id)

        return stale

    def update_status(self, agent_id: str, status: str) -> None:
        """Update agent status"""
        if agent_id in self.agents:
            self.agents[agent_id]["status"] = status

    def get_agent(self, agent_id: str) -> dict[str, Any] | None:
        """Get agent info"""
        return self.agents.get(agent_id)

    def get_all_agents(self) -> list[dict[str, Any]]:
        """Get all registered agents"""
        return list(self.agents.values())

    def get_agents_by_role(self, role: AgentRole) -> list[dict[str, Any]]:
        """Get agents by role"""
        return [
            agent for agent in self.agents.values()
            if agent["role"] == role.value
        ]


# Global registry
agent_registry = AgentRegistry()


__all__ = [
    "AgentCommunicationProtocol",
    "AgentRegistry",
    "TaskRouter",
    "communication_protocol",
    "task_router",
    "agent_registry",
]