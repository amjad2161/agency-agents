"""
Knowledge Agent - Knowledge Management Agent
Handles knowledge retrieval and management
"""
from typing import Any, Optional

from ..base_agent import BaseAgent, AgentRole
from packages.schemas.src import AgentMessage, AgentMessageType


class KnowledgeAgent(BaseAgent):
    """Agent responsible for knowledge management"""

    def __init__(
        self,
        agent_id: str = "knowledge_01",
        name: str = "Knowledge Agent",
        description: str = "Handles knowledge retrieval and management",
        **kwargs,
    ):
        super().__init__(
            agent_id=agent_id,
            role=AgentRole.RESEARCHER,
            name=name,
            description=description,
            **kwargs,
        )

    async def process(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Process knowledge request"""
        if message.message_type not in [AgentMessageType.QUERY, AgentMessageType.ACTION]:
            return None

        action = message.payload.get("action", "retrieve")

        if action == "retrieve":
            return await self._handle_knowledge_retrieval(message)
        elif action == "store":
            return await self._handle_knowledge_storage(message)
        elif action == "synthesize":
            return await self._handle_knowledge_synthesis(message)

        return None

    async def _handle_knowledge_retrieval(self, message: AgentMessage) -> AgentMessage:
        """Handle knowledge retrieval"""
        query = message.payload.get("query", "")
        sources = message.payload.get("sources", ["knowledge_graph", "documents"])
        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload={
                "intent": "knowledge_retrieval_result",
                "knowledge": [
                    {"content": f"Knowledge about: {query}", "source": s, "relevance": 0.9}
                    for s in sources
                ],
                "query": query,
            },
            metadata=message.metadata,
        )

    async def _handle_knowledge_storage(self, message: AgentMessage) -> AgentMessage:
        """Handle knowledge storage"""
        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload={
                "intent": "knowledge_storage_result",
                "stored": True,
            },
            metadata=message.metadata,
        )

    async def _handle_knowledge_synthesis(self, message: AgentMessage) -> AgentMessage:
        """Handle knowledge synthesis"""
        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload={
                "intent": "knowledge_synthesis_result",
                "synthesized": True,
                "summary": "Knowledge synthesis complete",
            },
            metadata=message.metadata,
        )
