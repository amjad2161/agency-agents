"""
Code Agent - Code Generation Agent
Handles code generation and execution
"""
import asyncio
from typing import Any, Optional

from ..base_agent import BaseAgent, AgentRole
from packages.schemas.src import AgentMessage, AgentMessageType, MessagePayload


class CodeAgent(BaseAgent):
    """Agent responsible for code generation and execution"""

    def __init__(
        self,
        agent_id: str = "code_01",
        name: str = "Code Agent",
        description: str = "Handles code generation and execution",
        **kwargs,
    ):
        super().__init__(
            agent_id=agent_id,
            role=AgentRole.GENERATOR,
            name=name,
            description=description,
            **kwargs,
        )

    async def process(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Process code request"""
        if message.message_type not in [AgentMessageType.ACTION, AgentMessageType.QUERY]:
            return None

        action = message.payload.action or "generate"

        if action == "generate":
            return await self._handle_code_generation(message)
        elif action == "execute":
            return await self._handle_code_execution(message)
        elif action == "review":
            return await self._handle_code_review(message)

        return None

    async def _handle_code_generation(self, message: AgentMessage) -> AgentMessage:
        """Handle code generation"""
        await asyncio.sleep(0)
        language = str(message.payload.parameters.get("language", "python"))
        prompt = str(message.payload.parameters.get("prompt", ""))
        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload=MessagePayload(
                intent="code_generation_result",
                content=f"# Generated {language} code for: {prompt}",
                parameters={"language": language},
            ),
            metadata=message.metadata,
        )

    async def _handle_code_execution(self, message: AgentMessage) -> AgentMessage:
        """Handle code execution"""
        await asyncio.sleep(0)
        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload=MessagePayload(
                intent="code_execution_result",
                result={"executed": True, "output": "Code executed successfully"},
            ),
            metadata=message.metadata,
        )

    async def _handle_code_review(self, message: AgentMessage) -> AgentMessage:
        """Handle code review"""
        await asyncio.sleep(0)
        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload=MessagePayload(
                intent="code_review_result",
                result={"issues": [], "score": 0.95},
            ),
            metadata=message.metadata,
        )
