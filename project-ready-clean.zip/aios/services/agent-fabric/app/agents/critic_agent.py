"""
Critic Agent - Quality Assessment Agent
Evaluates and critiques outputs for quality and accuracy
"""
from typing import Any, Optional
from datetime import datetime

from .base_agent import BaseAgent, AgentConfig, AgentMessage, AgentMessageType


class CriticAgent(BaseAgent):
    """Agent responsible for critiquing outputs"""

    def __init__(self, config: AgentConfig | None = None):
        super().__init__(
            agent_id="critic-agent",
            name="Critic Agent",
            description="Evaluates and critiques outputs for quality and accuracy",
            config=config or AgentConfig(max_execution_steps=20),
        )

    async def process(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Process critique request"""
        if message.message_type != AgentMessageType.CRITIQUE:
            return None

        content = message.payload.get("content_to_review")
        criteria = message.payload.get("criteria", ["accuracy", "completeness", "clarity"])

        critique = await self._critique_content(content, criteria)

        return AgentMessage(
            message_id=f"msg-{datetime.utcnow().timestamp()}",
            trace_id=message.trace_id,
            task_id=message.task_id,
            tenant_id=message.tenant_id,
            session_id=message.session_id,
            sender=self.agent_id,
            recipient="planner-agent",
            message_type=AgentMessageType.RESULT,
            priority=message.priority,
            payload={"critique": critique},
            tool_permissions=message.tool_permissions,
        )

    async def _critique_content(self, content: Any, criteria: list[str]) -> dict[str, Any]:
        """Perform critique of content"""
        critique = {
            "approved": True,
            "issues": [],
            "scores": {},
            "suggestions": [],
        }

        for criterion in criteria:
            critique["scores"][criterion] = 0.8

        return critique