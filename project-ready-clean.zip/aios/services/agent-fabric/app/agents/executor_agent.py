"""
Executor Agent - Action Execution Agent
Executes planned actions through tool invocations
"""
from typing import Any, Optional
from datetime import datetime

from .base_agent import BaseAgent, AgentConfig, AgentMessage, AgentMessageType


class ExecutorAgent(BaseAgent):
    """Agent responsible for executing planned actions"""

    def __init__(self, config: AgentConfig | None = None):
        super().__init__(
            agent_id="executor-agent",
            name="Executor Agent",
            description="Executes planned actions through tool invocations",
            config=config or AgentConfig(
                max_execution_steps=50,
                timeout_seconds=300,
            ),
        )
        self.execution_history: list[dict[str, Any]] = []

    async def process(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Process action execution request"""
        if message.message_type != AgentMessageType.ACTION:
            return None

        action_plan = message.payload.get("action_plan", {})
        context = message.payload.get("context", {})

        results = []
        for step in action_plan.get("steps", []):
            result = await self._execute_step(step, context)
            results.append(result)

            if not result.get("success"):
                break

        return AgentMessage(
            message_id=f"msg-{datetime.utcnow().timestamp()}",
            trace_id=message.trace_id,
            task_id=message.task_id,
            tenant_id=message.tenant_id,
            session_id=message.session_id,
            sender=self.agent_id,
            recipient="planner-agent",
            message_type=AgentMessageType.RESULT,
            priority=message.priority,
            payload={
                "results": results,
                "success": all(r.get("success", False) for r in results),
            },
            tool_permissions=message.tool_permissions,
        )

    async def _execute_step(self, step: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Execute a single action step"""
        return {
            "step_id": step.get("id"),
            "action": step.get("action"),
            "params": step.get("params"),
            "success": True,
            "output": {},
        }