"""
AI-OS Agent Fabric - Agent Implementations
All 15 specialized agents for the multi-agent system
"""

# Core orchestration agents (from planner_agent.py - includes base 6)
from .planner_agent import (
    PlannerAgent,
    ExecutorAgent,
    CriticAgent,
    VerifierAgent,
    ResearcherAgent,
    GeneratorAgent,
)

# Additional specialized agents
from .decomposer_agent import DecomposerAgent
from .executive_agent import ExecutiveAgent
from .memory_agent import MemoryAgent
from .security_agent import SecurityAgent
from .data_agent import DataAgent
from .code_agent import CodeAgent
from .multimodal_agent import MultimodalAgent
from .ui_agent import UIAgent
from .automation_agent import AutomationAgent
from .knowledge_agent import KnowledgeAgent

__all__ = [
    # Core orchestration (6)
    "PlannerAgent",
    "ExecutorAgent",
    "CriticAgent",
    "VerifierAgent",
    "ResearcherAgent",
    "GeneratorAgent",

    # Strategic (2)
    "DecomposerAgent",
    "ExecutiveAgent",

    # Specialized (7)
    "MemoryAgent",
    "SecurityAgent",
    "DataAgent",
    "CodeAgent",
    "MultimodalAgent",
    "UIAgent",
    "AutomationAgent",
    "KnowledgeAgent",
]
