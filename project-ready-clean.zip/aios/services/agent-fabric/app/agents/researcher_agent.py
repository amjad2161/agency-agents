"""
Researcher Agent - Information Gathering Agent
Gathers information from various sources
"""
from typing import Any, Optional
from datetime import datetime

from .base_agent import BaseAgent, AgentConfig, AgentMessage, AgentMessageType


class ResearcherAgent(BaseAgent):
    """Agent responsible for research and information gathering"""

    def __init__(self, config: AgentConfig | None = None):
        super().__init__(
            agent_id="researcher-agent",
            name="Researcher Agent",
            description="Gathers information from various sources",
            config=config or AgentConfig(max_execution_steps=30),
        )

    async def process(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Process research request"""
        if message.message_type != AgentMessageType.ACTION:
            return None

        query = message.payload.get("query")
        sources = message.payload.get("sources", ["web", "knowledge"])

        findings = await self._conduct_research(query, sources)

        return AgentMessage(
            message_id=f"msg-{datetime.utcnow().timestamp()}",
            trace_id=message.trace_id,
            task_id=message.task_id,
            tenant_id=message.tenant_id,
            session_id=message.session_id,
            sender=self.agent_id,
            recipient="planner-agent",
            message_type=AgentMessageType.RESULT,
            priority=message.priority,
            payload={"findings": findings},
            tool_permissions=message.tool_permissions,
        )

    async def _conduct_research(self, query: str, sources: list[str]) -> list[dict[str, Any]]:
        """Conduct research on a query"""
        return [{"source": "web", "content": f"Research on: {query}", "relevance": 0.8}]