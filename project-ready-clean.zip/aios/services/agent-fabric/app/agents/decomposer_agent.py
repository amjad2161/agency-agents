"""
Decomposer Agent - Task Decomposition Agent
Breaks down complex tasks into subtasks
"""
from typing import Any, Optional
from datetime import datetime

from ..base_agent import BaseAgent, AgentRole
from packages.schemas.src import AgentMessage, AgentMessageType


class DecomposerAgent(BaseAgent):
    """Agent responsible for task decomposition"""

    def __init__(
        self,
        agent_id: str = "decomposer_01",
        name: str = "Decomposer Agent",
        description: str = "Breaks down complex tasks into subtasks",
        **kwargs,
    ):
        super().__init__(
            agent_id=agent_id,
            role=AgentRole.PLANNER,
            name=name,
            description=description,
            **kwargs,
        )

    async def process(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Process task decomposition request"""
        if message.message_type not in [AgentMessageType.PLAN, AgentMessageType.ACTION]:
            return None

        task_description = message.payload.get("task_description", "")
        constraints = message.payload.get("constraints", {})

        decomposition = await self._decompose_task(task_description, constraints)

        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload={
                "intent": "decomposition_result",
                "subtasks": decomposition.get("subtasks", []),
                "dependencies": decomposition.get("dependencies", {}),
            },
            metadata=message.metadata,
        )

    async def _decompose_task(
        self,
        task_description: str,
        constraints: dict[str, Any],
    ) -> dict[str, Any]:
        """Decompose task into subtasks"""
        # Simulate decomposition
        return {
            "subtasks": [
                {
                    "id": "sub-1",
                    "description": "Analyze requirements",
                    "dependencies": [],
                    "estimated_duration_ms": 1000,
                },
                {
                    "id": "sub-2",
                    "description": "Retrieve context",
                    "dependencies": ["sub-1"],
                    "estimated_duration_ms": 2000,
                },
                {
                    "id": "sub-3",
                    "description": "Execute core task",
                    "dependencies": ["sub-2"],
                    "estimated_duration_ms": 5000,
                },
            ],
            "dependencies": {"sub-2": ["sub-1"], "sub-3": ["sub-2"]},
        }
