"""
UI Agent - Interface Generation Agent
Generates user interface components
"""
from typing import Any, Optional

from ..base_agent import BaseAgent, AgentRole
from packages.schemas.src import AgentMessage, AgentMessageType


class UIAgent(BaseAgent):
    """Agent responsible for UI generation"""

    def __init__(
        self,
        agent_id: str = "ui_01",
        name: str = "UI Agent",
        description: str = "Generates user interface components",
        **kwargs,
    ):
        super().__init__(
            agent_id=agent_id,
            role=AgentRole.GENERATOR,
            name=name,
            description=description,
            **kwargs,
        )

    async def process(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Process UI generation request"""
        if message.message_type not in [AgentMessageType.ACTION, AgentMessageType.QUERY]:
            return None

        component_type = message.payload.get("component_type", "component")

        if component_type == "component":
            return await self._handle_component_generation(message)
        elif component_type == "layout":
            return await self._handle_layout_generation(message)
        elif component_type == "dashboard":
            return await self._handle_dashboard_generation(message)

        return None

    async def _handle_component_generation(self, message: AgentMessage) -> AgentMessage:
        """Handle component generation"""
        specification = message.payload.get("specification", {})
        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload={
                "intent": "ui_generation_result",
                "code": "<!-- Generated component -->",
                "component_type": "component",
            },
            metadata=message.metadata,
        )

    async def _handle_layout_generation(self, message: AgentMessage) -> AgentMessage:
        """Handle layout generation"""
        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload={
                "intent": "layout_generation_result",
                "code": "<!-- Generated layout -->",
                "component_type": "layout",
            },
            metadata=message.metadata,
        )

    async def _handle_dashboard_generation(self, message: AgentMessage) -> AgentMessage:
        """Handle dashboard generation"""
        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload={
                "intent": "dashboard_generation_result",
                "code": "<!-- Generated dashboard -->",
                "component_type": "dashboard",
            },
            metadata=message.metadata,
        )
