"""
Memory Agent - Memory Operations Agent
Handles memory read/write operations
"""
from typing import Any, Optional

from ..base_agent import BaseAgent, AgentRole
from packages.schemas.src import AgentMessage, AgentMessageType


class MemoryAgent(BaseAgent):
    """Agent responsible for memory operations"""

    def __init__(
        self,
        agent_id: str = "memory_01",
        name: str = "Memory Agent",
        description: str = "Handles memory read/write operations",
        **kwargs,
    ):
        super().__init__(
            agent_id=agent_id,
            role=AgentRole.COORDINATOR,
            name=name,
            description=description,
            **kwargs,
        )

    async def process(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Process memory request"""
        if message.message_type not in [AgentMessageType.ACTION, AgentMessageType.QUERY]:
            return None

        memory_op = message.payload.get("operation", "read")

        if memory_op == "read":
            return await self._handle_memory_read(message)
        elif memory_op == "write":
            return await self._handle_memory_write(message)
        elif memory_op == "search":
            return await self._handle_memory_search(message)
        elif memory_op == "consolidate":
            return await self._handle_memory_consolidate(message)

        return None

    async def _handle_memory_read(self, message: AgentMessage) -> AgentMessage:
        """Handle memory read operation"""
        memory_id = message.payload.get("memory_id")
        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload={
                "intent": "memory_read_result",
                "memory_id": memory_id,
                "content": "Retrieved memory content",
            },
            metadata=message.metadata,
        )

    async def _handle_memory_write(self, message: AgentMessage) -> AgentMessage:
        """Handle memory write operation"""
        content = message.payload.get("content", "")
        memory_type = message.payload.get("memory_type", "semantic")
        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload={
                "intent": "memory_write_result",
                "stored": True,
                "memory_type": memory_type,
            },
            metadata=message.metadata,
        )

    async def _handle_memory_search(self, message: AgentMessage) -> AgentMessage:
        """Handle memory search operation"""
        query = message.payload.get("query", "")
        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload={
                "intent": "memory_search_result",
                "results": [],
                "query": query,
            },
            metadata=message.metadata,
        )

    async def _handle_memory_consolidate(self, message: AgentMessage) -> AgentMessage:
        """Handle memory consolidation operation"""
        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload={
                "intent": "memory_consolidate_result",
                "consolidated": True,
            },
            metadata=message.metadata,
        )
