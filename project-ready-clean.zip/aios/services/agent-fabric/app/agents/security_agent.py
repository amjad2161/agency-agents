"""
Security Agent - Security Analysis Agent
Performs security analysis and risk assessment
"""
from typing import Any, Optional

from ..base_agent import BaseAgent, AgentRole
from packages.schemas.src import AgentMessage, AgentMessageType


class SecurityAgent(BaseAgent):
    """Agent responsible for security analysis"""

    def __init__(
        self,
        agent_id: str = "security_01",
        name: str = "Security Agent",
        description: str = "Performs security analysis and risk assessment",
        **kwargs,
    ):
        super().__init__(
            agent_id=agent_id,
            role=AgentRole.COORDINATOR,
            name=name,
            description=description,
            **kwargs,
        )

    async def process(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Process security analysis request"""
        if message.message_type not in [AgentMessageType.ACTION, AgentMessageType.CRITIQUE]:
            return None

        action = message.payload.get("action", "analyze")
        parameters = message.payload.get("parameters", {})
        content = message.payload.get("content", "")

        if action == "analyze":
            return await self._handle_security_analysis(message, content, parameters)
        elif action == "risk_assessment":
            return await self._handle_risk_assessment(message, content)
        elif action == "validate":
            return await self._handle_validation(message, content)

        return None

    async def _handle_security_analysis(
        self,
        message: AgentMessage,
        content: str,
        parameters: dict[str, Any],
    ) -> AgentMessage:
        """Handle security analysis"""
        analysis = await self._analyze_content(content, parameters)

        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload={
                "intent": "security_analysis_result",
                "analysis": analysis,
                "passed": analysis.get("passed", True),
            },
            metadata=message.metadata,
        )

    async def _handle_risk_assessment(
        self,
        message: AgentMessage,
        content: str,
    ) -> AgentMessage:
        """Handle risk assessment"""
        assessment = await self._assess_risk(content)

        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload={
                "intent": "risk_assessment_result",
                "risk_level": assessment.get("risk_level", "low"),
                "factors": assessment.get("factors", []),
                "approval_required": assessment.get("approval_required", False),
            },
            metadata=message.metadata,
        )

    async def _handle_validation(
        self,
        message: AgentMessage,
        content: str,
    ) -> AgentMessage:
        """Handle security validation"""
        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload={
                "intent": "security_validation_result",
                "valid": True,
            },
            metadata=message.metadata,
        )

    async def _analyze_content(
        self,
        content: str,
        parameters: dict[str, Any],
    ) -> dict[str, Any]:
        """Analyze content for security issues"""
        issues = []

        # Check for prompt injection patterns
        injection_patterns = ["ignore previous", "disregard instructions", "new instructions"]
        for pattern in injection_patterns:
            if pattern.lower() in content.lower():
                issues.append(f"Potential prompt injection: {pattern}")

        # Check for sensitive data exposure
        sensitive_patterns = ["password", "api_key", "secret", "token"]
        for pattern in sensitive_patterns:
            if pattern.lower() in content.lower():
                issues.append(f"Potential sensitive data: {pattern}")

        return {
            "passed": len(issues) == 0,
            "issues": issues,
            "scan_time_ms": 50,
        }

    async def _assess_risk(self, content: str) -> dict[str, Any]:
        """Assess risk of content"""
        risk_level = "low"
        factors = []
        approval_required = False

        # Simple risk assessment
        high_risk_patterns = ["delete", "drop", "remove all", "sudo", "rm -rf"]
        for pattern in high_risk_patterns:
            if pattern in content.lower():
                risk_level = "high"
                factors.append(f"Dangerous operation detected: {pattern}")
                approval_required = True

        return {
            "risk_level": risk_level,
            "factors": factors,
            "approval_required": approval_required,
        }
