"""
Multimodal Agent - Multimodal Processing Agent
Handles image, audio, and video processing
"""
from typing import Any, Optional

from ..base_agent import BaseAgent, AgentRole
from packages.schemas.src import AgentMessage, AgentMessageType


class MultimodalAgent(BaseAgent):
    """Agent responsible for multimodal processing"""

    def __init__(
        self,
        agent_id: str = "multimodal_01",
        name: str = "Multimodal Agent",
        description: str = "Handles image, audio, and video processing",
        **kwargs,
    ):
        super().__init__(
            agent_id=agent_id,
            role=AgentRole.GENERATOR,
            name=name,
            description=description,
            **kwargs,
        )

    async def process(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Process multimodal request"""
        if message.message_type not in [AgentMessageType.ACTION, AgentMessageType.QUERY]:
            return None

        modality = message.payload.get("modality", "image")

        if modality == "image":
            return await self._handle_image_processing(message)
        elif modality == "audio":
            return await self._handle_audio_processing(message)
        elif modality == "video":
            return await self._handle_video_processing(message)

        return None

    async def _handle_image_processing(self, message: AgentMessage) -> AgentMessage:
        """Handle image processing"""
        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload={
                "intent": "image_processing_result",
                "processed": True,
                "modality": "image",
            },
            metadata=message.metadata,
        )

    async def _handle_audio_processing(self, message: AgentMessage) -> AgentMessage:
        """Handle audio processing"""
        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload={
                "intent": "audio_processing_result",
                "processed": True,
                "modality": "audio",
            },
            metadata=message.metadata,
        )

    async def _handle_video_processing(self, message: AgentMessage) -> AgentMessage:
        """Handle video processing"""
        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload={
                "intent": "video_processing_result",
                "processed": True,
                "modality": "video",
            },
            metadata=message.metadata,
        )
