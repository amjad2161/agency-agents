"""
AI-OS Agent Fabric - Specialized Agents
Implementation of Planner, Executor, Critic, Verifier, Researcher, and Generator agents
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from ..base_agent import BaseAgent, AgentCapability, AgentRole
from packages.schemas.src import AgentMessage, AgentMessageType

logger = logging.getLogger(__name__)


class PlannerAgent(BaseAgent):
    """
    Strategic planning agent that decomposes complex tasks into executable steps.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.system_prompt = self.system_prompt or (
            "You are a strategic planner that breaks down complex tasks into "
            "manageable steps. You analyze requirements, identify dependencies, "
            "and create optimal execution plans."
        )

    async def process(self, message: AgentMessage) -> AgentMessage | None:
        """Process planning request"""
        if message.message_type != AgentMessageType.PLAN:
            return None

        self.status = "busy"
        self.active_tasks.add(message.task_id)

        try:
            # Extract planning context
            task_description = message.payload.content or message.payload.parameters.get("task")
            constraints = message.payload.parameters.get("constraints", {})
            context = message.payload.context or {}

            # Create plan
            plan = await self.create_plan(task_description, constraints, context)

            # Return plan response
            response = AgentMessage(
                trace_id=message.trace_id,
                task_id=message.task_id,
                sender=self.agent_id,
                recipient=message.sender,
                sender_role=self.role,
                message_type=AgentMessageType.RESULT,
                priority=message.priority,
                payload={
                    "intent": "plan_response",
                    "plan": plan,
                    "steps": plan.get("steps", []),
                    "estimated_duration_ms": plan.get("estimated_duration_ms", 0),
                },
                metadata={
                    "correlation_id": message.metadata.correlation_id,
                    "reply_to": message.id,
                }
            )

            return response

        except Exception as e:
            logger.error(f"Planning error: {e}")
            raise

        finally:
            self.status = "idle"
            self.active_tasks.discard(message.task_id)
            self.tasks_processed += 1

    async def create_plan(
        self,
        task_description: str,
        constraints: dict[str, Any],
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """Create execution plan for task"""
        # Simulate planning logic
        steps = [
            {"step_id": "1", "action": "analyze", "description": "Analyze task requirements"},
            {"step_id": "2", "action": "retrieve", "description": "Retrieve relevant context"},
            {"step_id": "3", "action": "execute", "description": "Execute main task"},
            {"step_id": "4", "action": "validate", "description": "Validate output"},
            {"step_id": "5", "action": "finalize", "description": "Finalize and format"},
        ]

        return {
            "plan_id": f"plan_{context.get('task_id', 'unknown')}",
            "task_type": context.get("task_type", "general"),
            "steps": steps,
            "estimated_duration_ms": 5000,
            "dependencies": {},
            "fallback_strategy": "simplify" if constraints.get("limited_resources") else None,
        }


class ExecutorAgent(BaseAgent):
    """
    Task execution agent that coordinates tool usage and step execution.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.system_prompt = self.system_prompt or (
            "You are an execution agent that coordinates tool usage and task completion. "
            "You execute planned steps, handle tool invocations, and manage execution flow."
        )

    async def process(self, message: AgentMessage) -> AgentMessage | None:
        """Process execution request"""
        if message.message_type != AgentMessageType.ACTION:
            return None

        self.status = "busy"
        self.active_tasks.add(message.task_id)

        try:
            action = message.payload.action
            parameters = message.payload.parameters
            context = message.payload.context or {}

            # Execute action
            result = await self.execute_action(action, parameters, context)

            # Return result
            response = AgentMessage(
                trace_id=message.trace_id,
                task_id=message.task_id,
                sender=self.agent_id,
                recipient=message.sender,
                sender_role=self.role,
                message_type=AgentMessageType.RESULT,
                payload={
                    "intent": "action_result",
                    "action": action,
                    "result": result,
                },
                metadata={
                    "correlation_id": message.metadata.correlation_id,
                    "reply_to": message.id,
                }
            )

            self.tasks_succeeded += 1
            return response

        except Exception as e:
            logger.error(f"Execution error: {e}")
            self.tasks_failed += 1
            raise

        finally:
            self.status = "idle"
            self.active_tasks.discard(message.task_id)
            self.tasks_processed += 1

    async def execute_action(
        self,
        action: str,
        parameters: dict[str, Any],
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """Execute a single action"""
        # Route to appropriate tool handler
        if action == "invoke_tool":
            return await self._invoke_tool(parameters)
        elif action == "generate_response":
            return await self._generate_response(parameters)
        elif action == "analyze_data":
            return await self._analyze_data(parameters)
        else:
            return {"status": "executed", "action": action}

    async def _invoke_tool(self, parameters: dict[str, Any]) -> dict[str, Any]:
        """Invoke a tool"""
        tool_id = parameters.get("tool_id")
        tool_params = parameters.get("parameters", {})

        # In production, would invoke via tool-runtime
        return {
            "tool_id": tool_id,
            "status": "executed",
            "result": {"output": "Tool execution result"},
        }

    async def _generate_response(self, parameters: dict[str, Any]) -> dict[str, Any]:
        """Generate a response"""
        prompt = parameters.get("prompt", "")
        return {
            "status": "generated",
            "response": f"Generated response for: {prompt[:50]}...",
        }

    async def _analyze_data(self, parameters: dict[str, Any]) -> dict[str, Any]:
        """Analyze data"""
        data = parameters.get("data", [])
        analysis_type = parameters.get("type", "summary")

        return {
            "status": "analyzed",
            "analysis_type": analysis_type,
            "results": {"count": len(data), "summary": "Data analyzed"},
        }


class CriticAgent(BaseAgent):
    """
    Quality assurance agent that evaluates outputs and suggests improvements.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.system_prompt = self.system_prompt or (
            "You are a critic agent that evaluates outputs and suggests improvements. "
            "You provide constructive feedback, identify issues, and recommend refinements."
        )

    async def process(self, message: AgentMessage) -> AgentMessage | None:
        """Process critique request"""
        if message.message_type != AgentMessageType.CRITIQUE:
            return None

        self.status = "busy"
        self.active_tasks.add(message.task_id)

        try:
            content_to_critique = message.payload.content
            criteria = message.payload.parameters.get("criteria", {})
            context = message.payload.context or {}

            # Perform critique
            critique = await self.critique(content_to_critique, criteria, context)

            response = AgentMessage(
                trace_id=message.trace_id,
                task_id=message.task_id,
                sender=self.agent_id,
                recipient=message.sender,
                sender_role=self.role,
                message_type=AgentMessageType.RESULT,
                payload={
                    "intent": "critique_response",
                    "critique": critique,
                    "issues": critique.get("issues", []),
                    "suggestions": critique.get("suggestions", []),
                    "score": critique.get("score", 0.0),
                },
                metadata={
                    "correlation_id": message.metadata.correlation_id,
                    "reply_to": message.id,
                }
            )

            return response

        finally:
            self.status = "idle"
            self.active_tasks.discard(message.task_id)
            self.tasks_processed += 1

    async def critique(
        self,
        content: str,
        criteria: dict[str, Any],
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """Perform critique of content"""
        # Simulate critique logic
        issues = []
        suggestions = []

        # Check for length
        if len(content) < 50:
            issues.append("Content is too short")
            suggestions.append("Provide more detailed content")

        # Check for clarity
        if "..." in content or "???" in content:
            issues.append("Contains unclear elements")
            suggestions.append("Rewrite ambiguous sections")

        # Calculate score
        score = 1.0 - (len(issues) * 0.2)
        score = max(0.0, min(1.0, score))

        return {
            "overall_score": score,
            "issues": issues,
            "suggestions": suggestions,
            "aspects": {
                "clarity": score * 0.3,
                "completeness": score * 0.3,
                "accuracy": score * 0.4,
            },
        }


class VerifierAgent(BaseAgent):
    """
    Verification agent that validates outputs against requirements.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.system_prompt = self.system_prompt or (
            "You are a verifier agent that validates outputs against requirements. "
            "You check correctness, completeness, and compliance with specifications."
        )

    async def process(self, message: AgentMessage) -> AgentMessage | None:
        """Process verification request"""
        if message.message_type != AgentMessageType.VERIFY:
            return None

        self.status = "busy"
        self.active_tasks.add(message.task_id)

        try:
            output_to_verify = message.payload.content
            requirements = message.payload.parameters.get("requirements", {})
            verification_type = message.payload.parameters.get("type", "standard")

            # Perform verification
            verification = await self.verify(output_to_verify, requirements, verification_type)

            response = AgentMessage(
                trace_id=message.trace_id,
                task_id=message.task_id,
                sender=self.agent_id,
                recipient=message.sender,
                sender_role=self.role,
                message_type=AgentMessageType.RESULT,
                payload={
                    "intent": "verification_response",
                    "verification": verification,
                    "passed": verification.get("passed", False),
                    "details": verification.get("details", []),
                },
                metadata={
                    "correlation_id": message.metadata.correlation_id,
                    "reply_to": message.id,
                }
            )

            return response

        finally:
            self.status = "idle"
            self.active_tasks.discard(message.task_id)
            self.tasks_processed += 1

    async def verify(
        self,
        output: str,
        requirements: dict[str, Any],
        verification_type: str,
    ) -> dict[str, Any]:
        """Verify output against requirements"""
        # Simulate verification
        checks = []

        # Check format
        if verification_type == "json" and not output.strip().startswith("{"):
            checks.append({"check": "format", "passed": False, "message": "Not valid JSON"})
        else:
            checks.append({"check": "format", "passed": True})

        # Check required elements
        required_elements = requirements.get("required_elements", [])
        for element in required_elements:
            if element not in output:
                checks.append({
                    "check": f"contains_{element}",
                    "passed": False,
                    "message": f"Missing required element: {element}",
                })

        # Overall pass/fail
        passed = all(c.get("passed", False) for c in checks)

        return {
            "passed": passed,
            "checks": checks,
            "verification_type": verification_type,
        }


class ResearcherAgent(BaseAgent):
    """
    Research agent that gathers and analyzes information.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.system_prompt = self.system_prompt or (
            "You are a researcher agent that gathers and analyzes information. "
            "You search knowledge bases, analyze data, and provide insights."
        )

    async def process(self, message: AgentMessage) -> AgentMessage | None:
        """Process research request"""
        if message.message_type != AgentMessageType.QUERY:
            return None

        self.status = "busy"
        self.active_tasks.add(message.task_id)

        try:
            query = message.payload.content
            search_params = message.payload.parameters or {}

            # Perform research
            results = await self.research(query, search_params)

            response = AgentMessage(
                trace_id=message.trace_id,
                task_id=message.task_id,
                sender=self.agent_id,
                recipient=message.sender,
                sender_role=self.role,
                message_type=AgentMessageType.RESPONSE,
                payload={
                    "intent": "research_response",
                    "results": results,
                    "sources": results.get("sources", []),
                    "summary": results.get("summary", ""),
                },
                metadata={
                    "correlation_id": message.metadata.correlation_id,
                    "reply_to": message.id,
                }
            )

            return response

        finally:
            self.status = "idle"
            self.active_tasks.discard(message.task_id)
            self.tasks_processed += 1

    async def research(
        self,
        query: str,
        search_params: dict[str, Any],
    ) -> dict[str, Any]:
        """Perform research on query"""
        # Simulate research
        return {
            "query": query,
            "results": [
                {"title": "Result 1", "relevance": 0.9, "source": "knowledge_base"},
                {"title": "Result 2", "relevance": 0.7, "source": "web_search"},
            ],
            "sources": ["knowledge_base", "web_search"],
            "summary": f"Research results for: {query}",
            "cited_count": 2,
        }


class GeneratorAgent(BaseAgent):
    """
    Content generation agent that creates text, code, and other content.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.system_prompt = self.system_prompt or (
            "You are a generator agent that creates content and code. "
            "You produce high-quality outputs based on prompts and specifications."
        )

    async def process(self, message: AgentMessage) -> AgentMessage | None:
        """Process generation request"""
        if message.message_type != AgentMessageType.ACTION:
            return None

        action = message.payload.action
        if action != "generate":
            return None

        self.status = "busy"
        self.active_tasks.add(message.task_id)

        try:
            prompt = message.payload.parameters.get("prompt", "")
            generation_type = message.payload.parameters.get("type", "text")
            options = message.payload.parameters.get("options", {})

            # Generate content
            content = await self.generate(prompt, generation_type, options)

            response = AgentMessage(
                trace_id=message.trace_id,
                task_id=message.task_id,
                sender=self.agent_id,
                recipient=message.sender,
                sender_role=self.role,
                message_type=AgentMessageType.RESULT,
                payload={
                    "intent": "generation_response",
                    "content": content,
                    "type": generation_type,
                    "metadata": content.get("metadata", {}),
                },
                metadata={
                    "correlation_id": message.metadata.correlation_id,
                    "reply_to": message.id,
                }
            )

            self.tasks_succeeded += 1
            return response

        except Exception as e:
            logger.error(f"Generation error: {e}")
            self.tasks_failed += 1
            raise

        finally:
            self.status = "idle"
            self.active_tasks.discard(message.task_id)
            self.tasks_processed += 1

    async def generate(
        self,
        prompt: str,
        generation_type: str,
        options: dict[str, Any],
    ) -> dict[str, Any]:
        """Generate content based on prompt"""
        # Simulate generation
        if generation_type == "text":
            content = f"Generated text for: {prompt[:50]}..."
        elif generation_type == "code":
            content = {
                "language": options.get("language", "python"),
                "code": f"# Generated code for: {prompt[:50]}...\ndef main():\n    pass",
            }
        elif generation_type == "json":
            content = {"generated": True, "data": {"sample": "value"}}
        else:
            content = f"Generated content for: {prompt[:50]}..."

        return {
            "content": content,
            "type": generation_type,
            "metadata": {
                "tokens_used": len(prompt) * 2,
                "generation_time_ms": 150,
            },
        }