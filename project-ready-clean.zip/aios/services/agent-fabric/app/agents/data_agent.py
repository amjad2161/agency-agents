"""
Data Agent - Data Processing Agent
Handles data processing and transformation
"""
from typing import Any, Optional

from ..base_agent import BaseAgent, AgentRole
from packages.schemas.src import AgentMessage, AgentMessageType


class DataAgent(BaseAgent):
    """Agent responsible for data processing"""

    def __init__(
        self,
        agent_id: str = "data_01",
        name: str = "Data Agent",
        description: str = "Handles data processing and transformation",
        **kwargs,
    ):
        super().__init__(
            agent_id=agent_id,
            role=AgentRole.GENERATOR,
            name=name,
            description=description,
            **kwargs,
        )

    async def process(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Process data request"""
        if message.message_type not in [AgentMessageType.ACTION, AgentMessageType.QUERY]:
            return None

        action = message.payload.get("action", "process")

        if action == "process":
            return await self._handle_data_processing(message)
        elif action == "transform":
            return await self._handle_data_transform(message)
        elif action == "analyze":
            return await self._handle_data_analysis(message)

        return None

    async def _handle_data_processing(self, message: AgentMessage) -> AgentMessage:
        """Handle data processing"""
        data = message.payload.get("data", [])
        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload={
                "intent": "data_processing_result",
                "processed": True,
                "record_count": len(data),
            },
            metadata=message.metadata,
        )

    async def _handle_data_transform(self, message: AgentMessage) -> AgentMessage:
        """Handle data transformation"""
        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload={
                "intent": "data_transform_result",
                "transformed": True,
            },
            metadata=message.metadata,
        )

    async def _handle_data_analysis(self, message: AgentMessage) -> AgentMessage:
        """Handle data analysis"""
        return AgentMessage(
            trace_id=message.trace_id,
            task_id=message.task_id,
            sender=self.agent_id,
            recipient=message.sender,
            sender_role=self.role,
            message_type=AgentMessageType.RESULT,
            payload={
                "intent": "data_analysis_result",
                "analysis": {"summary": "Data analysis complete"},
            },
            metadata=message.metadata,
        )
