"""Agent fabric service application package."""
