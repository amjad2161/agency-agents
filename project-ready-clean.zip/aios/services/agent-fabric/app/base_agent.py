"""
AI-OS Agent Fabric - Base Agent and Router
Multi-agent runtime with specialized agent implementations
"""
from __future__ import annotations

import asyncio
from contextlib import suppress
import logging
import uuid
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, cast

from packages.schemas.src import (
    AgentMessage,
    AgentMessageType,
    AgentRole,
    MessageMetadata,
    MessagePayload,
    MessagePriority,
)

logger = logging.getLogger(__name__)


def _utcnow() -> datetime:
    """Return a naive UTC timestamp for compatibility with existing schema fields."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


PlannerAgent: Any = None
ExecutorAgent: Any = None
CriticAgent: Any = None
VerifierAgent: Any = None
ResearcherAgent: Any = None
GeneratorAgent: Any = None


def _load_agent_classes() -> tuple[Any, Any, Any, Any, Any, Any]:
    """Load specialized agent classes lazily to avoid import-cycle and layout issues."""
    from .agents import (
        CriticAgent as LoadedCriticAgent,
        ExecutorAgent as LoadedExecutorAgent,
        GeneratorAgent as LoadedGeneratorAgent,
        PlannerAgent as LoadedPlannerAgent,
        ResearcherAgent as LoadedResearcherAgent,
        VerifierAgent as LoadedVerifierAgent,
    )

    return (
        LoadedPlannerAgent,
        LoadedExecutorAgent,
        LoadedCriticAgent,
        LoadedVerifierAgent,
        LoadedResearcherAgent,
        LoadedGeneratorAgent,
    )


class AgentCapability(str, Enum):
    """Agent capabilities"""
    REASONING = "reasoning"
    PLANNING = "planning"
    EXECUTION = "execution"
    CRITIQUE = "critique"
    VERIFICATION = "verification"
    RESEARCH = "research"
    GENERATION = "generation"
    COORDINATION = "coordination"


class BaseAgent(ABC):
    """
    Base class for all agents in the AI-OS system.
    Provides common functionality for message handling, state management, and tool usage.
    """

    def __init__(
        self,
        agent_id: str,
        role: AgentRole,
        name: str | None = None,
        description: str | None = None,
        system_prompt: str | None = None,
        capabilities: list[AgentCapability] | None = None,
        max_concurrent_tasks: int = 5,
        tool_ids: list[str] | None = None,
        timeout_seconds: int = 300,
    ):
        self.agent_id = agent_id
        self.role = role
        self.name = name or agent_id
        self.description = description
        self.system_prompt = system_prompt

        self.capabilities = capabilities or []
        self.max_concurrent_tasks = max_concurrent_tasks
        self.tool_ids = tool_ids or []
        self.timeout_seconds = timeout_seconds

        # State
        self.status = "idle"  # idle, busy, error, offline
        self.active_tasks: set[str] = set()
        self.message_queue: asyncio.Queue = asyncio.Queue()
        self.current_task_id: str | None = None

        # Metrics
        self.tasks_processed = 0
        self.tasks_succeeded = 0
        self.tasks_failed = 0
        self.messages_sent = 0
        self.messages_received = 0

        # Last heartbeat
        self.last_heartbeat = _utcnow()

        # Event handlers
        self._event_handlers: dict[str, list[Callable]] = {}

        # Background task
        self._message_processor: asyncio.Task | None = None
        self._running = False

    async def start(self) -> None:
        """Start the agent"""
        if self._running:
            return

        await asyncio.sleep(0)
        self._running = True
        self._message_processor = asyncio.create_task(self._process_messages())
        logger.info(f"Agent {self.agent_id} ({self.role.value}) started")

    async def stop(self) -> None:
        """Stop the agent"""
        self._running = False

        if self._message_processor:
            self._message_processor.cancel()
            with suppress(asyncio.CancelledError):
                await self._message_processor

        logger.info(f"Agent {self.agent_id} stopped")

    async def _process_messages(self) -> None:
        """Process incoming messages"""
        while self._running:
            try:
                message = await asyncio.wait_for(
                    self.message_queue.get(),
                    timeout=1.0
                )
                await self.handle_message(message)
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Error processing message: {e}")

    async def handle_message(self, message: AgentMessage) -> None:
        """Handle incoming agent message"""
        self.messages_received += 1
        self.last_heartbeat = _utcnow()

        try:
            response = await asyncio.wait_for(
                self.process(message),
                timeout=float(self.timeout_seconds),
            )

            if response:
                await self.send_response(response)

        except Exception as e:
            logger.error(f"Error handling message: {e}")
            await self.send_error(message, str(e))

    @abstractmethod
    async def process(self, message: AgentMessage) -> AgentMessage | None:
        """
        Process incoming message and optionally return response.

        Must be implemented by subclasses.
        """
        await asyncio.sleep(0)
        raise NotImplementedError

    async def send_response(self, response: AgentMessage) -> None:
        """Send response message"""
        await asyncio.sleep(0)
        response.recipient = response.recipient or response.metadata.reply_to
        self.messages_sent += 1
        # Would send via message bus in production

    async def send_error(self, original: AgentMessage, error: str) -> None:
        """Send error response"""
        error_message = AgentMessage(
            trace_id=original.trace_id,
            task_id=original.task_id,
            sender=self.agent_id,
            recipient=original.sender,
            sender_role=self.role,
            message_type=AgentMessageType.ERROR,
            payload=MessagePayload(
                intent="error_response",
                error=error,
                context={"original_message_id": original.id},
            ),
            metadata=MessageMetadata(
                correlation_id=original.metadata.correlation_id,
            ),
        )
        await self.send_response(error_message)

    def can_accept_task(self) -> bool:
        """Check if agent can accept new task"""
        return (
            len(self.active_tasks) < self.max_concurrent_tasks
            and self.status != "offline"
        )

    async def send_heartbeat(self) -> None:
        """Send heartbeat to coordinator"""
        await asyncio.sleep(0)
        self.last_heartbeat = _utcnow()
        # Would send heartbeat via message bus

    def get_state(self) -> dict[str, Any]:
        """Get agent state for monitoring"""
        return {
            "agent_id": self.agent_id,
            "role": self.role.value,
            "status": self.status,
            "active_tasks": len(self.active_tasks),
            "max_concurrent_tasks": self.max_concurrent_tasks,
            "capabilities": [c.value for c in self.capabilities],
            "last_heartbeat": self.last_heartbeat.isoformat(),
            "metrics": {
                "tasks_processed": self.tasks_processed,
                "tasks_succeeded": self.tasks_succeeded,
                "tasks_failed": self.tasks_failed,
                "messages_sent": self.messages_sent,
                "messages_received": self.messages_received,
            },
        }


class AgentRouter:
    """
    Routes tasks to appropriate agents based on task type, requirements, and agent availability.
    """

    def __init__(self):
        self.registry = {}
        self.agents: dict[str, BaseAgent] = {}
        self.agents_by_role: dict[AgentRole, list[str]] = {role: [] for role in AgentRole}
        self.agents_by_capability: dict[AgentCapability, list[str]] = {}

        # Routing rules
        self.role_routing: dict[str, AgentRole] = {
            "chat": AgentRole.COORDINATOR,
            "research": AgentRole.RESEARCHER,
            "code_generation": AgentRole.GENERATOR,
            "planning": AgentRole.PLANNER,
            "execution": AgentRole.EXECUTOR,
            "critique": AgentRole.CRITIC,
            "verification": AgentRole.VERIFIER,
        }

    def register_agent(self, agent: BaseAgent) -> None:
        """Register an agent with the router"""
        self.agents[agent.agent_id] = agent
        self.agents_by_role[agent.role].append(agent.agent_id)

        for capability in agent.capabilities:
            if capability not in self.agents_by_capability:
                self.agents_by_capability[capability] = []
            self.agents_by_capability[capability].append(agent.agent_id)

        logger.info(f"Registered agent {agent.agent_id} with role {agent.role.value}")

    def unregister_agent(self, agent_id: str) -> None:
        """Unregister an agent"""
        if agent_id not in self.agents:
            return

        agent = self.agents[agent_id]

        # Remove from role index
        self.agents_by_role[agent.role].remove(agent_id)

        # Remove from capability index
        for capability in agent.capabilities:
            if capability in self.agents_by_capability:
                self.agents_by_capability[capability].remove(agent_id)

        del self.agents[agent_id]
        logger.info(f"Unregistered agent {agent_id}")

    def get_available_agents(
        self,
        role: AgentRole | None = None,
        capability: AgentCapability | None = None,
    ) -> list[BaseAgent]:
        """Get list of available agents matching criteria"""
        candidates = []

        if role:
            agent_ids = self.agents_by_role.get(role, [])
            candidates = [self.agents[aid] for aid in agent_ids]
        elif capability:
            agent_ids = self.agents_by_capability.get(capability, [])
            candidates = [self.agents[aid] for aid in agent_ids]
        else:
            candidates = list(self.agents.values())

        # Filter by availability
        return [a for a in candidates if a.can_accept_task()]

    def route_task(
        self,
        task_type: str,
        requirements: dict[str, Any] | None = None,
    ) -> BaseAgent | None:
        """
        Route task to appropriate agent.

        Args:
            task_type: Type of task to route
            requirements: Additional requirements (capabilities, etc.)

        Returns:
            Selected agent or None if no agent available
        """
        requirements = requirements or {}

        # Determine required role
        required_role = self.role_routing.get(task_type, AgentRole.EXECUTOR)

        # Check for specific capability requirements
        required_capabilities = requirements.get("capabilities", [])
        required_capability_enums = [
            AgentCapability(c) for c in required_capabilities
        ] if required_capabilities else []

        # Find available agents
        available = self.get_available_agents(role=required_role)

        # Enforce capability requirements when provided.
        if required_capability_enums:
            available = [
                agent for agent in available
                if all(capability in agent.capabilities for capability in required_capability_enums)
            ]

        if not available:
            # Fallback to any available agent
            available = self.get_available_agents()
            if required_capability_enums:
                available = [
                    agent for agent in available
                    if all(capability in agent.capabilities for capability in required_capability_enums)
                ]

        if not available:
            logger.warning(f"No available agent for task type {task_type}")
            return None

        # Select agent (simple round-robin, would be more sophisticated in production)
        selected = available[0]

        logger.info(f"Routed task {task_type} to agent {selected.agent_id}")

        return selected

    def get_agent(self, agent_id: str) -> BaseAgent | None:
        """Get agent by ID"""
        return self.agents.get(agent_id)

    def get_all_agents(self) -> list[dict[str, Any]]:
        """Get state of all registered agents"""
        return [agent.get_state() for agent in self.agents.values()]

    def get_agents_by_role(self, role: AgentRole) -> list[dict[str, Any]]:
        """Get agents by role"""
        agent_ids = self.agents_by_role.get(role, [])
        return [self.agents[aid].get_state() for aid in agent_ids if aid in self.agents]


# Global router instance
router = AgentRouter()


async def initialize_agents() -> list[BaseAgent]:
    """Initialize default set of agents"""
    agents: list[BaseAgent] = []
    (
        planner_agent_cls,
        executor_agent_cls,
        critic_agent_cls,
        verifier_agent_cls,
        researcher_agent_cls,
        generator_agent_cls,
    ) = _load_agent_classes()

    # Create planner agent
    planner = cast(BaseAgent, planner_agent_cls(
        agent_id="planner_01",
        role=AgentRole.PLANNER,
        name="Planner Agent",
        description="Strategic task planning and decomposition",
        capabilities=[
            AgentCapability.PLANNING,
            AgentCapability.REASONING,
        ],
    ))
    agents.append(planner)

    # Create executor agent
    executor = cast(BaseAgent, executor_agent_cls(
        agent_id="executor_01",
        role=AgentRole.EXECUTOR,
        name="Executor Agent",
        description="Task execution and tool coordination",
        capabilities=[
            AgentCapability.EXECUTION,
            AgentCapability.REASONING,
        ],
        max_concurrent_tasks=10,
    ))
    agents.append(executor)

    # Create critic agent
    critic = cast(BaseAgent, critic_agent_cls(
        agent_id="critic_01",
        role=AgentRole.CRITIC,
        name="Critic Agent",
        description="Quality assurance and self-critique",
        capabilities=[
            AgentCapability.CRITIQUE,
            AgentCapability.REASONING,
        ],
    ))
    agents.append(critic)

    # Create verifier agent
    verifier = cast(BaseAgent, verifier_agent_cls(
        agent_id="verifier_01",
        role=AgentRole.VERIFIER,
        name="Verifier Agent",
        description="Verification and validation",
        capabilities=[
            AgentCapability.VERIFICATION,
        ],
    ))
    agents.append(verifier)

    # Create researcher agent
    researcher = cast(BaseAgent, researcher_agent_cls(
        agent_id="researcher_01",
        role=AgentRole.RESEARCHER,
        name="Researcher Agent",
        description="Information retrieval and analysis",
        capabilities=[
            AgentCapability.RESEARCH,
            AgentCapability.REASONING,
        ],
    ))
    agents.append(researcher)

    # Create generator agent
    generator = cast(BaseAgent, generator_agent_cls(
        agent_id="generator_01",
        role=AgentRole.GENERATOR,
        name="Generator Agent",
        description="Content and code generation",
        capabilities=[
            AgentCapability.GENERATION,
            AgentCapability.REASONING,
        ],
    ))
    agents.append(generator)

    # Register all agents
    for agent in agents:
        router.register_agent(agent)
        await agent.start()

    logger.info(f"Initialized {len(agents)} agents")

    return agents


__all__ = [
    "BaseAgent",
    "AgentRouter",
    "AgentCapability",
    "router",
    "initialize_agents",
]