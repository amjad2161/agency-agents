"""
Approval Service - Human-in-the-Loop Approval Workflow
Handles approval requests and decisions
"""
from typing import Any, Optional
from datetime import datetime, timedelta
from enum import Enum
from uuid import uuid4

from pydantic import BaseModel, Field


class ApprovalStatus(str, Enum):
    """Approval request status"""
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"
    CANCELLED = "cancelled"


class ApprovalPriority(str, Enum):
    """Approval priority levels"""
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    URGENT = "urgent"


class ApprovalRequest(BaseModel):
    """Approval request model"""
    approval_id: str = Field(default_factory=lambda: str(uuid4()))
    task_id: str
    tenant_id: str
    requested_by: str
    action_description: str
    risk_level: str
    affected_resources: list[dict[str, Any]] = Field(default_factory=list)
    priority: ApprovalPriority = ApprovalPriority.NORMAL
    status: ApprovalStatus = ApprovalStatus.PENDING
    created_at: datetime = Field(default_factory=datetime.utcnow)
    expires_at: datetime
    responded_at: Optional[datetime] = None
    responded_by: Optional[str] = None
    decision_reason: Optional[str] = None
    conditions: Optional[dict[str, Any]] = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class ApprovalDecision(BaseModel):
    """Approval decision model"""
    approval_id: str
    decision: str  # approve, reject
    decided_by: str
    reason: Optional[str] = None
    conditions: Optional[dict[str, Any]] = None


class ApprovalService:
    """Service for managing approval workflows"""

    def __init__(self, config: dict[str, Any] | None = None):
        self.config = config or {}
        self._requests: dict[str, ApprovalRequest] = {}
        self._default_expiry_hours = 24

    async def initialize(self) -> None:
        """Initialize approval service"""
        pass

    async def create_request(
        self,
        task_id: str,
        tenant_id: str,
        requested_by: str,
        action_description: str,
        risk_level: str,
        affected_resources: list[dict[str, Any]] | None = None,
        priority: ApprovalPriority = ApprovalPriority.NORMAL,
        expiry_hours: int | None = None,
    ) -> str:
        """Create a new approval request"""
        expiry = datetime.utcnow() + timedelta(hours=expiry_hours or self._default_expiry_hours)

        request = ApprovalRequest(
            task_id=task_id,
            tenant_id=tenant_id,
            requested_by=requested_by,
            action_description=action_description,
            risk_level=risk_level,
            affected_resources=affected_resources or [],
            priority=priority,
            expires_at=expiry,
        )

        self._requests[request.approval_id] = request
        return request.approval_id

    async def get_request(self, approval_id: str) -> Optional[ApprovalRequest]:
        """Get approval request by ID"""
        request = self._requests.get(approval_id)
        if request and request.status == ApprovalStatus.PENDING:
            if datetime.utcnow() > request.expires_at:
                request.status = ApprovalStatus.EXPIRED
        return request

    async def list_pending(self, tenant_id: str) -> list[ApprovalRequest]:
        """List pending approval requests for tenant"""
        pending = []
        for request in self._requests.values():
            if request.tenant_id == tenant_id and request.status == ApprovalStatus.PENDING:
                if datetime.utcnow() <= request.expires_at:
                    pending.append(request)
        return sorted(pending, key=lambda r: (r.priority.value, r.created_at))

    async def approve(
        self,
        approval_id: str,
        decided_by: str,
        reason: str | None = None,
        conditions: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Approve an approval request"""
        request = self._requests.get(approval_id)
        if not request:
            return {"success": False, "error": "Request not found"}

        if request.status != ApprovalStatus.PENDING:
            return {"success": False, "error": f"Request is {request.status.value}"}

        if datetime.utcnow() > request.expires_at:
            request.status = ApprovalStatus.EXPIRED
            return {"success": False, "error": "Request has expired"}

        request.status = ApprovalStatus.APPROVED
        request.responded_at = datetime.utcnow()
        request.responded_by = decided_by
        request.decision_reason = reason
        request.conditions = conditions

        return {
            "success": True,
            "status": "approved",
            "approval_id": approval_id,
            "conditions": conditions,
        }

    async def reject(
        self,
        approval_id: str,
        decided_by: str,
        reason: str,
    ) -> dict[str, Any]:
        """Reject an approval request"""
        request = self._requests.get(approval_id)
        if not request:
            return {"success": False, "error": "Request not found"}

        if request.status != ApprovalStatus.PENDING:
            return {"success": False, "error": f"Request is {request.status.value}"}

        request.status = ApprovalStatus.REJECTED
        request.responded_at = datetime.utcnow()
        request.responded_by = decided_by
        request.decision_reason = reason

        return {
            "success": True,
            "status": "rejected",
            "approval_id": approval_id,
        }

    async def cancel(self, approval_id: str, cancelled_by: str) -> dict[str, Any]:
        """Cancel an approval request"""
        request = self._requests.get(approval_id)
        if not request:
            return {"success": False, "error": "Request not found"}

        if request.status != ApprovalStatus.PENDING:
            return {"success": False, "error": f"Request is {request.status.value}"}

        request.status = ApprovalStatus.CANCELLED
        request.responded_at = datetime.utcnow()
        request.responded_by = cancelled_by

        return {
            "success": True,
            "status": "cancelled",
            "approval_id": approval_id,
        }

    async def check_approval_status(self, task_id: str) -> dict[str, Any]:
        """Check approval status for a task"""
        for request in self._requests.values():
            if request.task_id == task_id:
                return {
                    "approval_required": True,
                    "approval_id": request.approval_id,
                    "status": request.status.value,
                    "is_approved": request.status == ApprovalStatus.APPROVED,
                }

        return {
            "approval_required": False,
        }

    async def cleanup_expired(self) -> int:
        """Clean up expired requests"""
        expired_count = 0
        for request in self._requests.values():
            if request.status == ApprovalStatus.PENDING and datetime.utcnow() > request.expires_at:
                request.status = ApprovalStatus.EXPIRED
                expired_count += 1
        return expired_count

    async def get_statistics(self, tenant_id: str) -> dict[str, Any]:
        """Get approval statistics for tenant"""
        stats = {
            "total": 0,
            "pending": 0,
            "approved": 0,
            "rejected": 0,
            "expired": 0,
            "avg_response_time_hours": 0,
        }

        tenant_requests = [r for r in self._requests.values() if r.tenant_id == tenant_id]
        stats["total"] = len(tenant_requests)

        for request in tenant_requests:
            if request.status == ApprovalStatus.PENDING:
                stats["pending"] += 1
            elif request.status == ApprovalStatus.APPROVED:
                stats["approved"] += 1
            elif request.status == ApprovalStatus.REJECTED:
                stats["rejected"] += 1
            elif request.status == ApprovalStatus.EXPIRED:
                stats["expired"] += 1

        responded = [r for r in tenant_requests if r.responded_at and r.status in [ApprovalStatus.APPROVED, ApprovalStatus.REJECTED]]
        if responded:
            total_hours = sum((r.responded_at - r.created_at).total_seconds() / 3600 for r in responded)
            stats["avg_response_time_hours"] = round(total_hours / len(responded), 2)

        return stats