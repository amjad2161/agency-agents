"""
AI-OS Advanced Memory Systems
Production-grade memory management with episodic, semantic, procedural, and working memory
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


# ============= ENUMS =============
class MemoryType(str, Enum):
    """Memory types"""
    EPISODIC = "episodic"  # Experience-based memories
    SEMANTIC = "semantic"  # Factual knowledge
    PROCEDURAL = "procedural"  # Skills and procedures
    WORKING = "working"  # Short-term active memory
    LONG_TERM = "long_term"  # Persistent storage
    CONTEXT = "context"  # Current context


class MemoryImportance(str, Enum):
    """Memory importance levels"""
    CRITICAL = "critical"  # Must remember
    HIGH = "high"  # Important
    MEDIUM = "medium"  # Normal
    LOW = "low"  # Minor


class ConsolidationStatus(str, Enum):
    """Memory consolidation status"""
    ACTIVE = "active"
    CONSOLIDATING = "consolidating"
    CONSOLIDATED = "consolidated"
    FORGOTTEN = "forgotten"


class RetrievalMode(str, Enum):
    """Memory retrieval modes"""
    EXACT = "exact"  # Exact match
    SEMANTIC = "semantic"  # Meaning-based
    ASSOCIATIVE = "associative"  # Related concepts
    SPIRAL = "spiral"  # Expanding search
    SPARSE = "sparse"  # Broad retrieval


# ============= DATA CLASSES =============
@dataclass
class MemoryNode:
    """Core memory node"""
    node_id: str
    memory_type: MemoryType
    content: str
    embedding: list[float] = field(default_factory=list)
    importance: MemoryImportance = MemoryImportance.MEDIUM
    created_at: datetime = field(default_factory=datetime.utcnow)
    last_accessed: datetime = field(default_factory=datetime.utcnow)
    access_count: int = 0
    consolidation_status: ConsolidationStatus = ConsolidationStatus.ACTIVE
    source: str = ""  # Where this memory came from
    language: str = "en"
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class EpisodicMemory(MemoryNode):
    """Episodic memory - experiences and events"""
    episode_id: str = ""
    duration_ms: float = 0.0
    participants: list[str] = field(default_factory=list)
    location: str = ""
    emotions: list[str] = field(default_factory=list)
    context: dict[str, Any] = field(default_factory=dict)


@dataclass
class SemanticMemory(MemoryNode):
    """Semantic memory - facts and knowledge"""
    concept_id: str = ""
    category: str = ""
    related_concepts: list[str] = field(default_factory=list)
    confidence: float = 1.0
    sources: list[str] = field(default_factory=list)


@dataclass
class ProceduralMemory(MemoryNode):
    """Procedural memory - skills and procedures"""
    procedure_id: str = ""
    procedure_type: str = ""
    steps: list[dict[str, Any]] = field(default_factory=list)
    prerequisites: list[str] = field(default_factory=list)
    success_rate: float = 1.0
    usage_count: int = 0


@dataclass
class WorkingMemoryEntry:
    """Working memory entry - active processing"""
    entry_id: str
    key: str
    value: Any
    created_at: datetime = field(default_factory=datetime.utcnow)
    expires_at: datetime | None = None
    ttl_seconds: int = 300  # 5 minutes default
    priority: int = 0


@dataclass
class MemoryAssociation:
    """Association between memories"""
    association_id: str
    source_node_id: str
    target_node_id: str
    association_type: str  # causal, temporal, semantic, spatial
    strength: float = 1.0
    bidirectional: bool = False


@dataclass
class MemoryConsolidationTask:
    """Memory consolidation task"""
    task_id: str
    source_nodes: list[str]
    status: ConsolidationStatus
    started_at: datetime | None = None
    completed_at: datetime | None = None
    consolidated_node_id: str | None = None
    retention_score: float = 0.0


@dataclass
class MemoryRetrievalResult:
    """Memory retrieval result"""
    memories: list[MemoryNode]
    relevance_scores: list[float]
    total_score: float
    retrieval_mode: RetrievalMode
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class MemoryStats:
    """Memory statistics"""
    total_memories: int = 0
    by_type: dict[str, int] = field(default_factory=dict)
    by_importance: dict[str, int] = field(default_factory=dict)
    consolidation_rate: float = 0.0
    forgetting_rate: float = 0.0
    avg_access_count: float = 0.0


# ============= MEMORY STORES =============
class WorkingMemoryStore:
    """Working memory - short-term active storage"""

    def __init__(self, max_entries: int = 100, default_ttl: int = 300):
        self.max_entries = max_entries
        self.default_ttl = default_ttl
        self.entries: dict[str, WorkingMemoryEntry] = {}

    async def store(
        self,
        key: str,
        value: Any,
        ttl_seconds: int | None = None,
        priority: int = 0,
    ) -> WorkingMemoryEntry:
        """Store in working memory"""
        entry_id = hashlib.md5(f"{key}_{time.time()}".encode()).hexdigest()[:12]
        ttl = ttl_seconds or self.default_ttl

        entry = WorkingMemoryEntry(
            entry_id=entry_id,
            key=key,
            value=value,
            ttl_seconds=ttl,
            priority=priority,
            expires_at=datetime.utcnow() + timedelta(seconds=ttl),
        )

        self.entries[key] = entry

        # Evict if too many
        if len(self.entries) > self.max_entries:
            await self._evict_low_priority()

        return entry

    async def retrieve(self, key: str) -> Any | None:
        """Retrieve from working memory"""
        if key not in self.entries:
            return None

        entry = self.entries[key]

        # Check expiration
        if entry.expires_at and datetime.utcnow() > entry.expires_at:
            del self.entries[key]
            return None

        entry.access_count = getattr(entry, "access_count", 0) + 1
        return entry.value

    async def update(self, key: str, value: Any):
        """Update existing entry"""
        if key in self.entries:
            entry = self.entries[key]
            entry.value = value
            entry.created_at = datetime.utcnow()

    async def clear(self):
        """Clear all working memory"""
        self.entries.clear()

    async def _evict_low_priority(self):
        """Evict lowest priority entries"""
        sorted_entries = sorted(
            self.entries.values(),
            key=lambda e: e.priority
        )
        to_remove = len(self.entries) - self.max_entries
        for entry in sorted_entries[:to_remove]:
            del self.entries[entry.key]

    def get_stats(self) -> dict[str, Any]:
        """Get working memory stats"""
        return {
            "entries": len(self.entries),
            "max_entries": self.max_entries,
        }


class EpisodicMemoryStore:
    """Episodic memory - experiences and events"""

    def __init__(self, max_memories: int = 10000, retention_days: int = 90):
        self.max_memories = max_memories
        self.retention_days = retention_days
        self.memories: dict[str, EpisodicMemory] = {}
        self.by_episode: dict[str, list[str]] = {}

    async def store(
        self,
        content: str,
        episode_id: str | None = None,
        importance: MemoryImportance = MemoryImportance.MEDIUM,
        context: dict[str, Any] | None = None,
    ) -> EpisodicMemory:
        """Store episodic memory"""
        node_id = hashlib.md5(f"{content[:100]}_{time.time()}".encode()).hexdigest()[:12]

        memory = EpisodicMemory(
            node_id=node_id,
            memory_type=MemoryType.EPISODIC,
            content=content,
            importance=importance,
            episode_id=episode_id or f"ep_{node_id}",
            context=context or {},
        )

        self.memories[node_id] = memory

        # Index by episode
        if episode_id:
            if episode_id not in self.by_episode:
                self.by_episode[episode_id] = []
            self.by_episode[episode_id].append(node_id)

        return memory

    async def retrieve_by_episode(
        self,
        episode_id: str,
    ) -> list[EpisodicMemory]:
        """Retrieve memories by episode"""
        node_ids = self.by_episode.get(episode_id, [])
        return [self.memories[nid] for nid in node_ids if nid in self.memories]

    async def retrieve_recent(
        self,
        limit: int = 10,
    ) -> list[EpisodicMemory]:
        """Retrieve recent memories"""
        sorted_memories = sorted(
            self.memories.values(),
            key=lambda m: m.last_accessed,
            reverse=True
        )
        return sorted_memories[:limit]

    async def forget_old(self) -> int:
        """Forget old memories based on retention policy"""
        cutoff = datetime.utcnow() - timedelta(days=self.retention_days)
        to_forget = [
            node_id for node_id, memory in self.memories.items()
            if memory.created_at < cutoff
        ]
        for node_id in to_forget:
            del self.memories[node_id]
        return len(to_forget)

    def get_stats(self) -> dict[str, Any]:
        """Get episodic memory stats"""
        return {
            "total": len(self.memories),
            "episodes": len(self.by_episode),
        }


class SemanticMemoryStore:
    """Semantic memory - facts and knowledge"""

    def __init__(self, max_memories: int = 50000):
        self.max_memories = max_memories
        self.memories: dict[str, SemanticMemory] = {}
        self.by_category: dict[str, list[str]] = {}
        self.concept_index: dict[str, list[str]] = {}

    async def store(
        self,
        content: str,
        concept_id: str | None = None,
        category: str = "",
        related_concepts: list[str] | None = None,
        importance: MemoryImportance = MemoryImportance.MEDIUM,
        confidence: float = 1.0,
    ) -> SemanticMemory:
        """Store semantic memory"""
        node_id = hashlib.md5(f"{content[:100]}_{time.time()}".encode()).hexdigest()[:12]

        memory = SemanticMemory(
            node_id=node_id,
            memory_type=MemoryType.SEMANTIC,
            content=content,
            concept_id=concept_id or f"concept_{node_id}",
            category=category,
            related_concepts=related_concepts or [],
            importance=importance,
            confidence=confidence,
        )

        self.memories[node_id] = memory

        # Index by category
        if category:
            if category not in self.by_category:
                self.by_category[category] = []
            self.by_category[category].append(node_id)

        # Index concepts
        for concept in memory.related_concepts:
            if concept not in self.concept_index:
                self.concept_index[concept] = []
            self.concept_index[concept].append(node_id)

        return memory

    async def retrieve_by_category(
        self,
        category: str,
    ) -> list[SemanticMemory]:
        """Retrieve memories by category"""
        node_ids = self.by_category.get(category, [])
        return [self.memories[nid] for nid in node_ids if nid in self.memories]

    async def retrieve_related(
        self,
        concept: str,
    ) -> list[SemanticMemory]:
        """Retrieve related memories"""
        node_ids = self.concept_index.get(concept, [])
        return [self.memories[nid] for nid in node_ids if nid in self.memories]

    async def search(
        self,
        query: str,
        limit: int = 10,
    ) -> list[SemanticMemory]:
        """Search semantic memories"""
        query_lower = query.lower()
        results = []

        for memory in self.memories.values():
            if query_lower in memory.content.lower():
                results.append(memory)

        return results[:limit]

    def get_stats(self) -> dict[str, Any]:
        """Get semantic memory stats"""
        return {
            "total": len(self.memories),
            "categories": len(self.by_category),
            "concepts": len(self.concept_index),
        }


class ProceduralMemoryStore:
    """Procedural memory - skills and procedures"""

    def __init__(self):
        self.memories: dict[str, ProceduralMemory] = {}
        self.by_type: dict[str, list[str]] = {}

    async def store(
        self,
        content: str,
        procedure_type: str,
        steps: list[dict[str, Any]],
        prerequisites: list[str] | None = None,
        importance: MemoryImportance = MemoryImportance.HIGH,
    ) -> ProceduralMemory:
        """Store procedural memory"""
        node_id = hashlib.md5(f"{content[:100]}_{time.time()}".encode()).hexdigest()[:12]

        memory = ProceduralMemory(
            node_id=node_id,
            memory_type=MemoryType.PROCEDURAL,
            content=content,
            procedure_id=f"proc_{node_id}",
            procedure_type=procedure_type,
            steps=steps,
            prerequisites=prerequisites or [],
        )

        self.memories[node_id] = memory

        # Index by type
        if procedure_type:
            if procedure_type not in self.by_type:
                self.by_type[procedure_type] = []
            self.by_type[procedure_type].append(node_id)

        return memory

    async def retrieve_by_type(
        self,
        procedure_type: str,
    ) -> list[ProceduralMemory]:
        """Retrieve procedures by type"""
        node_ids = self.by_type.get(procedure_type, [])
        return [self.memories[nid] for nid in node_ids if nid in self.memories]

    async def update_success_rate(
        self,
        node_id: str,
        success: bool,
    ):
        """Update procedure success rate"""
        if node_id in self.memories:
            memory = self.memories[node_id]
            memory.usage_count += 1
            current_rate = memory.success_rate
            # Exponential moving average
            memory.success_rate = 0.9 * current_rate + 0.1 * (1.0 if success else 0.0)

    def get_stats(self) -> dict[str, Any]:
        """Get procedural memory stats"""
        return {
            "total": len(self.memories),
            "types": len(self.by_type),
        }


class AssociationStore:
    """Memory associations store"""

    def __init__(self):
        self.associations: dict[str, MemoryAssociation] = {}
        self.by_source: dict[str, list[str]] = {}
        self.by_target: dict[str, list[str]] = {}

    async def create_association(
        self,
        source_node_id: str,
        target_node_id: str,
        association_type: str = "semantic",
        strength: float = 1.0,
        bidirectional: bool = True,
    ) -> MemoryAssociation:
        """Create memory association"""
        assoc_id = hashlib.md5(
            f"{source_node_id}_{target_node_id}_{time.time()}".encode()
        ).hexdigest()[:12]

        association = MemoryAssociation(
            association_id=assoc_id,
            source_node_id=source_node_id,
            target_node_id=target_node_id,
            association_type=association_type,
            strength=strength,
            bidirectional=bidirectional,
        )

        self.associations[assoc_id] = association

        # Index
        if source_node_id not in self.by_source:
            self.by_source[source_node_id] = []
        self.by_source[source_node_id].append(assoc_id)

        if bidirectional:
            if target_node_id not in self.by_source:
                self.by_source[target_node_id] = []
            self.by_source[target_node_id].append(assoc_id)

        return association

    async def get_associations(self, node_id: str) -> list[MemoryAssociation]:
        """Get all associations for a node"""
        assoc_ids = self.by_source.get(node_id, [])
        return [self.associations[aid] for aid in assoc_ids if aid in self.associations]

    def get_stats(self) -> dict[str, Any]:
        """Get association stats"""
        return {
            "total": len(self.associations),
        }


class ContextMemoryManager:
    """Context memory for current conversation/session"""

    def __init__(self, max_context_length: int = 10):
        self.max_context_length = max_context_length
        self.context_history: list[dict[str, Any]] = []
        self.summary: str = ""

    async def add_context(
        self,
        role: str,
        content: str,
        metadata: dict[str, Any] | None = None,
    ):
        """Add to context history"""
        entry = {
            "role": role,
            "content": content,
            "timestamp": datetime.utcnow().isoformat(),
            "metadata": metadata or {},
        }

        self.context_history.append(entry)

        # Evict oldest if too long
        if len(self.context_history) > self.max_context_length:
            self.context_history.pop(0)

    async def get_recent_context(
        self,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Get recent context"""
        limit = limit or self.max_context_length
        return self.context_history[-limit:]

    async def clear_context(self):
        """Clear context"""
        self.context_history.clear()
        self.summary = ""

    async def summarize(self, summary: str):
        """Update context summary"""
        self.summary = summary

    def get_stats(self) -> dict[str, Any]:
        """Get context stats"""
        return {
            "entries": len(self.context_history),
            "has_summary": bool(self.summary),
        }


# ============= UNIFIED MEMORY SYSTEM =============
class UnifiedMemory:
    """
    Unified Memory System for AI-OS.
    Integrates episodic, semantic, procedural, and working memory.
    """

    def __init__(
        self,
        config: dict[str, Any] | None = None,
    ):
        config = config or {}

        # Initialize stores
        self.working_memory = WorkingMemoryStore(
            max_entries=config.get("working_memory_max", 100),
            default_ttl=config.get("working_memory_ttl", 300),
        )
        self.episodic_memory = EpisodicMemoryStore(
            max_memories=config.get("episodic_max", 10000),
            retention_days=config.get("episodic_retention", 90),
        )
        self.semantic_memory = SemanticMemoryStore(
            max_memories=config.get("semantic_max", 50000),
        )
        self.procedural_memory = ProceduralMemoryStore()
        self.association_store = AssociationStore()
        self.context_memory = ContextMemoryManager(
            max_context_length=config.get("context_length", 10),
        )

        # Consolidation tasks
        self.consolidation_queue: list[MemoryConsolidationTask] = []

        # Statistics
        self.stats = MemoryStats()

    # ============= STORE OPERATIONS =============
    async def remember(
        self,
        content: str,
        memory_type: MemoryType,
        importance: MemoryImportance = MemoryImportance.MEDIUM,
        context: dict[str, Any] | None = None,
        **kwargs,
    ) -> MemoryNode:
        """Store a new memory"""
        memory = None

        if memory_type == MemoryType.EPISODIC:
            memory = await self.episodic_memory.store(
                content=content,
                importance=importance,
                context=context,
                **kwargs,
            )
        elif memory_type == MemoryType.SEMANTIC:
            memory = await self.semantic_memory.store(
                content=content,
                importance=importance,
                **kwargs,
            )
        elif memory_type == MemoryType.PROCEDURAL:
            memory = await self.procedural_memory.store(
                content=content,
                importance=importance,
                **kwargs,
            )
        elif memory_type == MemoryType.WORKING:
            entry = await self.working_memory.store(
                key=kwargs.get("key", content[:50]),
                value=content,
                priority=kwargs.get("priority", 0),
            )
            # Convert to node for consistency
            memory = MemoryNode(
                node_id=entry.entry_id,
                memory_type=MemoryType.WORKING,
                content=str(entry.value),
            )

        # Update stats
        if memory:
            self.stats.total_memories += 1
            type_key = memory_type.value
            if type_key not in self.stats.by_type:
                self.stats.by_type[type_key] = 0
            self.stats.by_type[type_key] += 1

            imp_key = importance.value
            if imp_key not in self.stats.by_importance:
                self.stats.by_importance[imp_key] = 0
            self.stats.by_importance[imp_key] += 1

        return memory

    async def recall(
        self,
        query: str,
        memory_type: MemoryType | None = None,
        mode: RetrievalMode = RetrievalMode.SEMANTIC,
        limit: int = 10,
    ) -> MemoryRetrievalResult:
        """Recall memories"""
        memories = []
        relevance_scores = []

        if memory_type:
            # Retrieve from specific store
            if memory_type == MemoryType.EPISODIC:
                memories = await self.episodic_memory.retrieve_recent(limit)
            elif memory_type == MemoryType.SEMANTIC:
                memories = await self.semantic_memory.search(query, limit)
            elif memory_type == MemoryType.PROCEDURAL:
                proc_memories = await self.procedural_memory.retrieve_by_type(query)
                memories = proc_memories[:limit]
            elif memory_type == MemoryType.WORKING:
                value = await self.working_memory.retrieve(query)
                if value:
                    memories = [MemoryNode(
                        node_id=query,
                        memory_type=MemoryType.WORKING,
                        content=str(value),
                    )]
        else:
            # Multi-store retrieval based on mode
            if mode == RetrievalMode.SEMANTIC:
                semantic_results = await self.semantic_memory.search(query, limit // 2)
                memories.extend(semantic_results)
                episodic_results = await self.episodic_memory.retrieve_recent(limit // 2)
                memories.extend(episodic_results)
            elif mode == RetrievalMode.ASSOCIATIVE:
                # Get associated memories
                associations = await self.association_store.get_associations(query)
                for assoc in associations[:limit]:
                    # Simplified - would resolve node IDs to actual memories
                    pass
            elif mode == RetrievalMode.SPIRAL:
                # Expanding search
                initial = await self.semantic_memory.search(query, 5)
                memories.extend(initial)
                for mem in initial[:3]:
                    related = await self.semantic_memory.retrieve_related(mem.concept_id if hasattr(mem, "concept_id") else "")
                    memories.extend(related[:3])
            else:
                # Default to recent episodic
                memories = await self.episodic_memory.retrieve_recent(limit)

        # Calculate scores
        query_lower = query.lower()
        total_score = 0.0
        for memory in memories:
            score = 0.5  # Base score
            if query_lower in memory.content.lower():
                score += 0.3
            score += min(memory.access_count * 0.01, 0.2)  # Access bonus
            relevance_scores.append(score)
            total_score += score

        return MemoryRetrievalResult(
            memories=memories[:limit],
            relevance_scores=relevance_scores[:limit],
            total_score=total_score,
            retrieval_mode=mode,
        )

    async def learn_association(
        self,
        source_node_id: str,
        target_node_id: str,
        association_type: str = "semantic",
    ):
        """Create memory association"""
        await self.association_store.create_association(
            source_node_id=source_node_id,
            target_node_id=target_node_id,
            association_type=association_type,
        )

    # ============= CONTEXT OPERATIONS =============
    async def add_to_context(
        self,
        role: str,
        content: str,
        metadata: dict[str, Any] | None = None,
    ):
        """Add to current context"""
        await self.context_memory.add_context(role, content, metadata)

    async def get_context(self, limit: int | None = None) -> list[dict[str, Any]]:
        """Get current context"""
        return await self.context_memory.get_recent_context(limit)

    async def clear_context(self):
        """Clear current context"""
        await self.context_memory.clear_context()

    # ============= CONSOLIDATION =============
    async def consolidate(
        self,
        source_node_ids: list[str],
    ) -> str:
        """Consolidate multiple memories into one"""
        task_id = hashlib.md5(f"{'_'.join(source_node_ids)}_{time.time()}".encode()).hexdigest()[:12]

        task = MemoryConsolidationTask(
            task_id=task_id,
            source_nodes=source_node_ids,
            status=ConsolidationStatus.CONSOLIDATING,
            started_at=datetime.utcnow(),
        )

        self.consolidation_queue.append(task)

        # Simulate consolidation
        await asyncio.sleep(0.01)  # In production would do actual work

        task.status = ConsolidationStatus.CONSOLIDATED
        task.completed_at = datetime.utcnow()
        task.consolidated_node_id = f"consolidated_{task_id}"

        return task.consolidated_node_id

    # ============= MAINTENANCE =============
    async def cleanup(self) -> dict[str, int]:
        """Run memory cleanup"""
        results = {}

        # Forget old episodic memories
        forgotten = await self.episodic_memory.forget_old()
        results["episodic_forgotten"] = forgotten
        self.stats.forgetting_rate = forgotten / max(self.stats.total_memories, 1)

        # Clear old working memory
        # (This is automatic via TTL)

        return results

    # ============= STATISTICS =============
    def get_stats(self) -> dict[str, Any]:
        """Get comprehensive memory statistics"""
        return {
            "unified_memory": {
                "total_memories": self.stats.total_memories,
                "by_type": self.stats.by_type,
                "by_importance": self.stats.by_importance,
            },
            "working_memory": self.working_memory.get_stats(),
            "episodic_memory": self.episodic_memory.get_stats(),
            "semantic_memory": self.semantic_memory.get_stats(),
            "procedural_memory": self.procedural_memory.get_stats(),
            "associations": self.association_store.get_stats(),
            "context": self.context_memory.get_stats(),
        }


async def example():
    """Example memory system usage"""

    memory = UnifiedMemory()

    print("=" * 60)
    print("AI-OS Advanced Memory Systems Example")
    print("=" * 60)

    # Store different memory types
    print("\n[Test 1] Storing Memories")

    # Episodic memory - experience
    await memory.remember(
        content="User asked about neural networks and seemed satisfied with the explanation",
        memory_type=MemoryType.EPISODIC,
        importance=MemoryImportance.HIGH,
        context={"topic": "neural networks", "satisfaction": "high"},
    )
    print("Stored episodic memory: User interaction")

    # Semantic memory - knowledge
    await memory.remember(
        content="Neural networks are computing systems inspired by biological neural networks",
        memory_type=MemoryType.SEMANTIC,
        importance=MemoryImportance.MEDIUM,
        category="machine_learning",
        concept_id="neural_network",
        related_concepts=["deep_learning", "backpropagation"],
    )
    print("Stored semantic memory: Neural network definition")

    # Procedural memory - skill
    await memory.remember(
        content="How to explain complex concepts simply",
        memory_type=MemoryType.PROCEDURAL,
        importance=MemoryImportance.HIGH,
        procedure_type="explanation",
        steps=[
            {"step": 1, "action": "Identify core concept"},
            {"step": 2, "action": "Use analogy"},
            {"step": 3, "action": "Provide examples"},
        ],
    )
    print("Stored procedural memory: Explanation skill")

    # Working memory - short term
    await memory.remember(
        content="User currently discussing: transformer architectures",
        memory_type=MemoryType.WORKING,
        key="current_topic",
        priority=10,
    )
    print("Stored working memory: Current topic")

    # Context memory
    print("\n[Test 2] Context Management")
    await memory.add_to_context(
        role="user",
        content="Explain how transformers work",
    )
    await memory.add_to_context(
        role="assistant",
        content="Transformers use self-attention mechanism...",
    )
    await memory.add_to_context(
        role="user",
        content="What about attention heads?",
    )

    context = await memory.get_context()
    print(f"Context entries: {len(context)}")
    for entry in context:
        print(f"  [{entry['role']}] {entry['content'][:40]}...")

    # Recall memories
    print("\n[Test 3] Memory Recall")
    results = await memory.recall(
        query="neural",
        mode=RetrievalMode.SEMANTIC,
        limit=5,
    )
    print(f"Found {len(results.memories)} memories")
    print(f"Total relevance score: {results.total_score:.2f}")

    # Cross-store recall
    results = await memory.recall(
        query="explanation",
        mode=RetrievalMode.SPIRAL,
        limit=5,
    )
    print(f"\nSpiral retrieval found {len(results.memories)} memories")

    # Retrieve working memory
    working_value = await memory.working_memory.retrieve("current_topic")
    print(f"\nWorking memory retrieval: {working_value}")

    # Consolidation
    print("\n[Test 4] Memory Consolidation")
    consolidated_id = await memory.consolidate(
        source_node_ids=["node1", "node2", "node3"]
    )
    print(f"Consolidated into: {consolidated_id}")

    # Cleanup
    print("\n[Test 5] Memory Cleanup")
    cleanup_results = await memory.cleanup()
    print(f"Cleanup results: {cleanup_results}")

    # Memory statistics
    print("\n" + "=" * 60)
    print("Memory Statistics")
    print("=" * 60)
    stats = memory.get_stats()

    for section, data in stats.items():
        print(f"\n{section}:")
        if isinstance(data, dict):
            for key, value in data.items():
                print(f"  {key}: {value}")


if __name__ == "__main__":
    asyncio.run(example())
