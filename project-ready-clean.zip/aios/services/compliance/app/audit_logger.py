"""
Compliance Module - Audit Logging
Tracks all system actions for compliance and security
"""
from datetime import datetime
from typing import Any, Optional
from enum import Enum
from uuid import uuid4

from pydantic import BaseModel, Field


class AuditEventType(str, Enum):
    """Types of auditable events"""
    USER_LOGIN = "user.login"
    USER_LOGOUT = "user.logout"
    API_REQUEST = "api.request"
    DATA_ACCESS = "data.access"
    DATA_MODIFICATION = "data.modification"
    PERMISSION_CHANGE = "permission.change"
    CONFIG_CHANGE = "config.change"
    SECURITY_EVENT = "security.event"
    AGENT_ACTION = "agent.action"
    TOOL_EXECUTION = "tool.execution"
    APPROVAL_REQUEST = "approval.request"
    APPROVAL_GRANTED = "approval.granted"
    APPROVAL_REJECTED = "approval.rejected"


class AuditSeverity(str, Enum):
    """Event severity levels"""
    INFO = "info"
    WARNING = "warning"
    HIGH = "high"
    CRITICAL = "critical"


class AuditEvent(BaseModel):
    """Audit event structure"""
    event_id: str = Field(default_factory=lambda: str(uuid4()))
    event_type: AuditEventType
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    tenant_id: str
    user_id: str
    actor_type: str = "user"  # user, system, agent, service
    action: str
    resource_type: str
    resource_id: str
    outcome: str = "success"  # success, failure, partial
    severity: AuditSeverity = AuditSeverity.INFO
    details: dict[str, Any] = Field(default_factory=dict)
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    request_id: Optional[str] = None
    trace_id: Optional[str] = None
    session_id: Optional[str] = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class AuditLogger:
    """Audit logging service for compliance"""

    def __init__(self, tenant_id: str):
        self.tenant_id = tenant_id
        self._events: list[AuditEvent] = []

    async def log(
        self,
        event_type: AuditEventType,
        user_id: str,
        action: str,
        resource_type: str,
        resource_id: str,
        **kwargs,
    ) -> str:
        """Log an audit event"""
        event = AuditEvent(
            event_type=event_type,
            tenant_id=self.tenant_id,
            user_id=user_id,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            **kwargs,
        )
        self._events.append(event)
        return event.event_id

    async def log_login(self, user_id: str, success: bool, ip_address: str | None = None) -> str:
        """Log user login attempt"""
        return await self.log(
            event_type=AuditEventType.USER_LOGIN,
            user_id=user_id,
            action="login",
            resource_type="session",
            resource_id=user_id,
            outcome="success" if success else "failure",
            ip_address=ip_address,
        )

    async def log_api_request(
        self,
        user_id: str,
        endpoint: str,
        method: str,
        status_code: int,
        request_id: str,
    ) -> str:
        """Log API request"""
        return await self.log(
            event_type=AuditEventType.API_REQUEST,
            user_id=user_id,
            action=f"{method} {endpoint}",
            resource_type="api",
            resource_id=request_id,
            outcome="success" if status_code < 400 else "failure",
            details={"status_code": status_code},
            request_id=request_id,
        )

    async def log_data_access(
        self,
        user_id: str,
        data_type: str,
        data_id: str,
        action: str = "read",
    ) -> str:
        """Log data access"""
        return await self.log(
            event_type=AuditEventType.DATA_ACCESS,
            user_id=user_id,
            action=action,
            resource_type=data_type,
            resource_id=data_id,
        )

    async def log_tool_execution(
        self,
        user_id: str,
        tool_id: str,
        tool_name: str,
        success: bool,
        parameters: dict[str, Any],
    ) -> str:
        """Log tool execution"""
        return await self.log(
            event_type=AuditEventType.TOOL_EXECUTION,
            user_id=user_id,
            action=f"execute:{tool_name}",
            resource_type="tool",
            resource_id=tool_id,
            outcome="success" if success else "failure",
            details={"parameters": parameters},
        )

    async def log_agent_action(
        self,
        agent_id: str,
        agent_type: str,
        action: str,
        outcome: str,
        details: dict[str, Any],
    ) -> str:
        """Log agent action"""
        return await self.log(
            event_type=AuditEventType.AGENT_ACTION,
            user_id=agent_id,
            action=action,
            resource_type=f"agent:{agent_type}",
            resource_id=agent_id,
            outcome=outcome,
            details=details,
            actor_type="agent",
        )

    async def log_approval_request(
        self,
        requester_id: str,
        approver_id: str,
        risk_level: str,
        action: str,
    ) -> str:
        """Log approval request"""
        return await self.log(
            event_type=AuditEventType.APPROVAL_REQUEST,
            user_id=requester_id,
            action=action,
            resource_type="approval",
            resource_id=f"approval-{uuid4()}",
            severity=AuditSeverity.WARNING,
            details={"risk_level": risk_level, "approver_id": approver_id},
        )

    async def log_approval_decision(
        self,
        approver_id: str,
        approved: bool,
        approval_id: str,
        reason: str | None = None,
    ) -> str:
        """Log approval decision"""
        return await self.log(
            event_type=AuditEventType.APPROVAL_GRANTED if approved else AuditEventType.APPROVAL_REJECTED,
            user_id=approver_id,
            action="approve" if approved else "reject",
            resource_type="approval",
            resource_id=approval_id,
            outcome="success",
            details={"reason": reason} if reason else {},
        )

    async def log_security_event(
        self,
        user_id: str,
        event_type: str,
        severity: AuditSeverity,
        details: dict[str, Any],
        ip_address: str | None = None,
    ) -> str:
        """Log security event"""
        return await self.log(
            event_type=AuditEventType.SECURITY_EVENT,
            user_id=user_id,
            action=event_type,
            resource_type="security",
            resource_id=str(uuid4()),
            severity=severity,
            details=details,
            ip_address=ip_address,
        )

    async def query_events(
        self,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
        event_types: list[AuditEventType] | None = None,
        user_id: str | None = None,
        resource_type: str | None = None,
        limit: int = 100,
    ) -> list[AuditEvent]:
        """Query audit events"""
        results = self._events

        if start_time:
            results = [e for e in results if e.timestamp >= start_time]
        if end_time:
            results = [e for e in results if e.timestamp <= end_time]
        if event_types:
            results = [e for e in results if e.event_type in event_types]
        if user_id:
            results = [e for e in results if e.user_id == user_id]
        if resource_type:
            results = [e for e in results if e.resource_type == resource_type]

        return results[:limit]

    async def export_for_compliance(
        self, start_date: datetime, end_date: datetime, format: str = "json"
    ) -> dict[str, Any]:
        """Export audit log for compliance reporting"""
        events = await self.query_events(
            start_time=start_date, end_time=end_date, limit=10000
        )

        return {
            "export_date": datetime.utcnow().isoformat(),
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
            "total_events": len(events),
            "events": [e.model_dump() for e in events],
            "format": format,
        }


class ComplianceReporter:
    """Generate compliance reports"""

    def __init__(self, audit_logger: AuditLogger):
        self.audit_logger = audit_logger

    async def generate_user_activity_report(
        self, user_id: str, start_date: datetime, end_date: datetime
    ) -> dict[str, Any]:
        """Generate user activity report"""
        events = await self.audit_logger.query_events(
            start_time=start_date,
            end_time=end_date,
            user_id=user_id,
        )

        return {
            "user_id": user_id,
            "period": {"start": start_date.isoformat(), "end": end_date.isoformat()},
            "total_actions": len(events),
            "action_breakdown": self._aggregate_by_type(events),
            "security_events": sum(1 for e in events if e.severity in [AuditSeverity.HIGH, AuditSeverity.CRITICAL]),
        }

    async def generate_data_access_report(
        self, resource_type: str, start_date: datetime, end_date: datetime
    ) -> dict[str, Any]:
        """Generate data access report"""
        events = await self.audit_logger.query_events(
            start_time=start_date,
            end_time=end_date,
            resource_type=resource_type,
        )

        return {
            "resource_type": resource_type,
            "period": {"start": start_date.isoformat(), "end": end_date.isoformat()},
            "total_accesses": len(events),
            "unique_users": len(set(e.user_id for e in events)),
            "access_breakdown": self._aggregate_by_action(events),
        }

    def _aggregate_by_type(self, events: list[AuditEvent]) -> dict[str, int]:
        """Aggregate events by type"""
        result = {}
        for event in events:
            event_type = event.event_type.value
            result[event_type] = result.get(event_type, 0) + 1
        return result

    def _aggregate_by_action(self, events: list[AuditEvent]) -> dict[str, int]:
        """Aggregate events by action"""
        result = {}
        for event in events:
            result[event.action] = result.get(event.action, 0) + 1
        return result