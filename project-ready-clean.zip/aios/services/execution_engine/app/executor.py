from __future__ import annotations

from pathlib import Path
from typing import Any

from services._legacy_loader import export_legacy_module


globals().update(
    export_legacy_module(
        __name__,
        Path(__file__).resolve().parents[2] / "execution-engine" / "app" / "executor.py",
    )
)

execution_engine: Any = globals().get("execution_engine")

__all__ = ["execution_engine"]
