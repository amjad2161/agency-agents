"""
AI-OS Enterprise Features
RBAC, Billing, Multi-Tenancy, and Enterprise Security
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


# ============= ENUMS =============
class BillingCycle(str, Enum):
    """Billing cycle options"""
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"
    ANNUAL = "annual"


class BillingStatus(str, Enum):
    """Billing status"""
    ACTIVE = "active"
    PAST_DUE = "past_due"
    CANCELLED = "cancelled"
    SUSPENDED = "suspended"


class TenantStatus(str, Enum):
    """Tenant status"""
    ACTIVE = "active"
    SUSPENDED = "suspended"
    PENDING = "pending"


class PlanTier(str, Enum):
    """Subscription plan tiers"""
    FREE = "free"
    STARTER = "starter"
    PROFESSIONAL = "professional"
    ENTERPRISE = "enterprise"


class UsageMetric(str, Enum):
    """Usage metrics"""
    API_CALLS = "api_calls"
    AGENT_RUNS = "agent_runs"
    TOKENS_USED = "tokens_used"
    STORAGE_GB = "storage_gb"
    BANDWIDTH_GB = "bandwidth_gb"


class ResourceQuota(str, Enum):
    """Resource quota types"""
    API_RATE_LIMIT = "api_rate_limit"
    CONCURRENT_AGENTS = "concurrent_agents"
    MAX_USERS = "max_users"
    STORAGE_LIMIT = "storage_limit"
    API_CALLS_PER_MONTH = "api_calls_per_month"


# ============= DATA CLASSES =============
@dataclass
class User:
    """User account"""
    user_id: str
    email: str
    name: str
    tenant_id: str
    role_ids: list[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.utcnow)
    last_login: datetime = field(default_factory=datetime.utcnow)
    is_active: bool = True
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Tenant:
    """Multi-tenant organization"""
    tenant_id: str
    name: str
    plan: PlanTier = PlanTier.FREE
    status: TenantStatus = TenantStatus.ACTIVE
    created_at: datetime = field(default_factory=datetime.utcnow)
    owner_id: str = ""
    settings: dict[str, Any] = field(default_factory=dict)
    custom_branding: dict[str, Any] = field(default_factory=dict)
    sso_config: dict[str, Any] = field(default_factory=dict)
    quotas: dict[str, int] = field(default_factory=dict)


@dataclass
class Subscription:
    """Subscription details"""
    subscription_id: str
    tenant_id: str
    plan: PlanTier
    billing_cycle: BillingCycle = BillingCycle.MONTHLY
    status: BillingStatus = BillingStatus.ACTIVE
    started_at: datetime = field(default_factory=datetime.utcnow)
    current_period_start: datetime = field(default_factory=datetime.utcnow)
    current_period_end: datetime = field(default_factory=lambda: datetime.utcnow() + timedelta(days=30))
    cancelled_at: datetime | None = None
    trial_ends_at: datetime | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class UsageRecord:
    """Usage record"""
    record_id: str
    tenant_id: str
    user_id: str
    metric: UsageMetric
    value: float
    timestamp: datetime = field(default_factory=datetime.utcnow)
    period: str = ""  # e.g., "2024-01"
    cost: float = 0.0


@dataclass
class Invoice:
    """Invoice"""
    invoice_id: str
    tenant_id: str
    subscription_id: str
    amount: float
    currency: str = "USD"
    status: str = "pending"
    items: list[dict[str, Any]] = field(default_factory=list)
    issued_at: datetime = field(default_factory=datetime.utcnow)
    due_at: datetime = field(default_factory=lambda: datetime.utcnow() + timedelta(days=30))
    paid_at: datetime | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ResourceQuotaConfig:
    """Resource quota configuration"""
    quota_type: ResourceQuota
    plan_tier: PlanTier
    limit: int
    soft_limit: int | None = None
    unit: str = "count"


@dataclass
class APIKey:
    """API Key for programmatic access"""
    key_id: str
    tenant_id: str
    user_id: str
    key_prefix: str  # First 8 chars for identification
    key_hash: str
    name: str
    created_at: datetime = field(default_factory=datetime.utcnow)
    last_used: datetime | None = None
    expires_at: datetime | None = None
    is_active: bool = True
    scopes: list[str] = field(default_factory=list)
    rate_limit: int = 100


@dataclass
class AuditEntry:
    """Enterprise audit entry"""
    entry_id: str
    timestamp: datetime
    tenant_id: str
    user_id: str
    action: str
    resource_type: str
    resource_id: str
    result: str
    ip_address: str
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class SSOConfig:
    """SSO Configuration"""
    config_id: str
    tenant_id: str
    provider: str  # okta, azure-ad, google, saml
    client_id: str = ""
    client_secret_hash: str = ""
    metadata_url: str = ""
    enabled: bool = False
    domains: list[str] = field(default_factory=list)
    default_role: str = "user"


# ============= PLAN CONFIGURATIONS =============
PLAN_CONFIGS = {
    PlanTier.FREE: {
        "price_monthly": 0,
        "price_annual": 0,
        "api_calls_per_month": 1000,
        "agents": 2,
        "users": 1,
        "storage_gb": 1,
        "concurrent_requests": 1,
        "support": "community",
        "features": ["basic_agents", "basic_knowledge"],
    },
    PlanTier.STARTER: {
        "price_monthly": 29,
        "price_annual": 290,
        "api_calls_per_month": 50000,
        "agents": 5,
        "users": 5,
        "storage_gb": 10,
        "concurrent_requests": 5,
        "support": "email",
        "features": ["advanced_agents", "knowledge_base", "api_access"],
    },
    PlanTier.PROFESSIONAL: {
        "price_monthly": 99,
        "price_annual": 990,
        "api_calls_per_month": 500000,
        "agents": 20,
        "users": 25,
        "storage_gb": 100,
        "concurrent_requests": 20,
        "support": "priority",
        "features": [
            "all_agents", "knowledge_base", "api_access",
            "custom_branding", "advanced_analytics",
        ],
    },
    PlanTier.ENTERPRISE: {
        "price_monthly": 499,
        "price_annual": 4990,
        "api_calls_per_month": -1,  # Unlimited
        "agents": -1,
        "users": -1,
        "storage_gb": -1,
        "concurrent_requests": -1,
        "support": "dedicated",
        "features": [
            "all_agents", "knowledge_base", "api_access",
            "custom_branding", "advanced_analytics",
            "sso", "audit_logs", "sla", "custom_development",
        ],
    },
}


# ============= ENTERPRISE MANAGER =============
class EnterpriseManager:
    """
    Enterprise features manager.
    Handles multi-tenancy, RBAC, billing, and enterprise security.
    """

    def __init__(self):
        # Data stores
        self.tenants: dict[str, Tenant] = {}
        self.users: dict[str, User] = {}
        self.subscriptions: dict[str, Subscription] = {}
        self.usage_records: list[UsageRecord] = []
        self.invoices: dict[str, Invoice] = {}
        self.api_keys: dict[str, APIKey] = {}
        self.audit_entries: list[AuditEntry] = []
        self.sso_configs: dict[str, SSOConfig] = {}

        # Role definitions
        self.roles: dict[str, dict[str, Any]] = {}
        self._initialize_roles()

        # Statistics
        self.stats = {
            "total_tenants": 0,
            "total_users": 0,
            "active_subscriptions": 0,
            "monthly_recurring_revenue": 0.0,
        }

    def _initialize_roles(self):
        """Initialize default roles"""
        self.roles = {
            "owner": {
                "name": "Tenant Owner",
                "permissions": [
                    "tenant:*", "user:*", "subscription:*",
                    "billing:*", "api_key:*", "audit:*",
                ],
                "is_system": True,
            },
            "admin": {
                "name": "Administrator",
                "permissions": [
                    "user:*", "api_key:*",
                ],
                "is_system": True,
            },
            "developer": {
                "name": "Developer",
                "permissions": [
                    "api_key:read", "api_key:write",
                    "user:read",
                ],
                "is_system": False,
            },
            "viewer": {
                "name": "Viewer",
                "permissions": [
                    "user:read",
                ],
                "is_system": False,
            },
        }

    # ============= TENANT MANAGEMENT =============
    async def create_tenant(
        self,
        name: str,
        owner_id: str,
        plan: PlanTier = PlanTier.FREE,
    ) -> Tenant:
        """Create a new tenant"""
        tenant_id = hashlib.md5(f"{name}_{time.time()}".encode()).hexdigest()[:12]

        tenant = Tenant(
            tenant_id=tenant_id,
            name=name,
            plan=plan,
            owner_id=owner_id,
            quotas=self._get_plan_quotas(plan),
        )

        self.tenants[tenant_id] = tenant
        self.stats["total_tenants"] += 1

        await self._audit_log(
            tenant_id=tenant_id,
            user_id=owner_id,
            action="create_tenant",
            resource_type="tenant",
            resource_id=tenant_id,
            result="success",
            details={"name": name, "plan": plan.value},
        )

        return tenant

    def _get_plan_quotas(self, plan: PlanTier) -> dict[str, int]:
        """Get quotas for a plan"""
        config = PLAN_CONFIGS.get(plan, PLAN_CONFIGS[PlanTier.FREE])
        return {
            "api_calls_per_month": config.get("api_calls_per_month", 0),
            "agents": config.get("agents", 0),
            "users": config.get("users", 0),
            "storage_gb": config.get("storage_gb", 0),
            "concurrent_requests": config.get("concurrent_requests", 0),
        }

    async def update_tenant_plan(
        self,
        tenant_id: str,
        new_plan: PlanTier,
    ) -> Tenant:
        """Update tenant plan"""
        if tenant_id not in self.tenants:
            raise ValueError(f"Tenant {tenant_id} not found")

        tenant = self.tenants[tenant_id]
        old_plan = tenant.plan
        tenant.plan = new_plan
        tenant.quotas = self._get_plan_quotas(new_plan)

        await self._audit_log(
            tenant_id=tenant_id,
            user_id=tenant.owner_id,
            action="update_plan",
            resource_type="subscription",
            resource_id=tenant_id,
            result="success",
            details={"old_plan": old_plan.value, "new_plan": new_plan.value},
        )

        return tenant

    # ============= USER MANAGEMENT =============
    async def create_user(
        self,
        email: str,
        name: str,
        tenant_id: str,
        role_ids: list[str] | None = None,
    ) -> User:
        """Create a new user"""
        user_id = hashlib.md5(f"{email}_{time.time()}".encode()).hexdigest()[:12]

        user = User(
            user_id=user_id,
            email=email,
            name=name,
            tenant_id=tenant_id,
            role_ids=role_ids or ["viewer"],
        )

        self.users[user_id] = user
        self.stats["total_users"] += 1

        await self._audit_log(
            tenant_id=tenant_id,
            user_id=user_id,
            action="create_user",
            resource_type="user",
            resource_id=user_id,
            result="success",
            details={"email": email, "name": name},
        )

        return user

    async def assign_role(
        self,
        user_id: str,
        role_id: str,
    ) -> User:
        """Assign role to user"""
        if user_id not in self.users:
            raise ValueError(f"User {user_id} not found")

        user = self.users[user_id]
        if role_id not in user.role_ids:
            user.role_ids.append(role_id)

        await self._audit_log(
            tenant_id=user.tenant_id,
            user_id=user_id,
            action="assign_role",
            resource_type="user",
            resource_id=user_id,
            result="success",
            details={"role": role_id},
        )

        return user

    def get_user_permissions(self, user_id: str) -> list[str]:
        """Get all permissions for a user"""
        if user_id not in self.users:
            return []

        user = self.users[user_id]
        permissions = set()

        for role_id in user.role_ids:
            if role_id in self.roles:
                permissions.update(self.roles[role_id]["permissions"])

        return list(permissions)

    def check_permission(self, user_id: str, permission: str) -> bool:
        """Check if user has permission"""
        user_permissions = self.get_user_permissions(user_id)

        # Check for wildcard permissions
        for user_perm in user_permissions:
            if user_perm.endswith("*"):
                prefix = user_perm.rsplit(":", 1)[0]
                if permission.startswith(prefix):
                    return True
            elif user_perm == permission:
                return True

        return False

    # ============= SUBSCRIPTION MANAGEMENT =============
    async def create_subscription(
        self,
        tenant_id: str,
        plan: PlanTier,
        billing_cycle: BillingCycle = BillingCycle.MONTHLY,
        trial_days: int = 0,
    ) -> Subscription:
        """Create subscription"""
        subscription_id = hashlib.md5(
            f"{tenant_id}_{time.time()}".encode()
        ).hexdigest()[:12]

        now = datetime.utcnow()
        period_days = 30 if billing_cycle == BillingCycle.MONTHLY else 90 if billing_cycle == BillingCycle.QUARTERLY else 365

        subscription = Subscription(
            subscription_id=subscription_id,
            tenant_id=tenant_id,
            plan=plan,
            billing_cycle=billing_cycle,
            current_period_start=now,
            current_period_end=now + timedelta(days=period_days),
            trial_ends_at=now + timedelta(days=trial_days) if trial_days > 0 else None,
        )

        self.subscriptions[subscription_id] = subscription
        self.stats["active_subscriptions"] += 1

        # Update MRR
        plan_config = PLAN_CONFIGS[plan]
        if billing_cycle == BillingCycle.MONTHLY:
            self.stats["monthly_recurring_revenue"] += plan_config["price_monthly"]
        elif billing_cycle == BillingCycle.ANNUAL:
            self.stats["monthly_recurring_revenue"] += plan_config["price_annual"] / 12

        return subscription

    async def update_subscription(
        self,
        subscription_id: str,
        new_plan: PlanTier,
    ) -> Subscription:
        """Update subscription plan"""
        if subscription_id not in self.subscriptions:
            raise ValueError(f"Subscription {subscription_id} not found")

        sub = self.subscriptions[subscription_id]
        old_plan = sub.plan

        sub.plan = new_plan
        sub.current_period_start = datetime.utcnow()
        sub.current_period_end = sub.current_period_start + timedelta(days=30)

        await self._audit_log(
            tenant_id=sub.tenant_id,
            user_id="system",
            action="update_subscription",
            resource_type="subscription",
            resource_id=subscription_id,
            result="success",
            details={"old_plan": old_plan.value, "new_plan": new_plan.value},
        )

        return sub

    # ============= USAGE TRACKING =============
    async def record_usage(
        self,
        tenant_id: str,
        user_id: str,
        metric: UsageMetric,
        value: float,
    ) -> UsageRecord:
        """Record usage"""
        record_id = hashlib.md5(
            f"{tenant_id}_{metric.value}_{time.time()}".encode()
        ).hexdigest()[:12]

        period = datetime.utcnow().strftime("%Y-%m")
        cost = self._calculate_usage_cost(metric, value)

        record = UsageRecord(
            record_id=record_id,
            tenant_id=tenant_id,
            user_id=user_id,
            metric=metric,
            value=value,
            period=period,
            cost=cost,
        )

        self.usage_records.append(record)
        return record

    def _calculate_usage_cost(
        self,
        metric: UsageMetric,
        value: float,
    ) -> float:
        """Calculate cost for usage"""
        rates = {
            UsageMetric.API_CALLS: 0.001,  # $0.001 per call
            UsageMetric.AGENT_RUNS: 0.01,   # $0.01 per agent run
            UsageMetric.TOKENS_USED: 0.00001,  # $0.00001 per token
            UsageMetric.STORAGE_GB: 0.10,   # $0.10 per GB per month
            UsageMetric.BANDWIDTH_GB: 0.05,  # $0.05 per GB
        }
        return value * rates.get(metric, 0)

    async def get_usage_summary(
        self,
        tenant_id: str,
        period: str | None = None,
    ) -> dict[str, Any]:
        """Get usage summary for tenant"""
        period = period or datetime.utcnow().strftime("%Y-%m")

        records = [
            r for r in self.usage_records
            if r.tenant_id == tenant_id and r.period == period
        ]

        summary = {
            "period": period,
            "total_cost": sum(r.cost for r in records),
            "by_metric": {},
        }

        for metric in UsageMetric:
            metric_records = [r for r in records if r.metric == metric]
            summary["by_metric"][metric.value] = {
                "count": len(metric_records),
                "total_value": sum(r.value for r in metric_records),
                "total_cost": sum(r.cost for r in metric_records),
            }

        return summary

    # ============= INVOICE MANAGEMENT =============
    async def create_invoice(
        self,
        tenant_id: str,
        subscription_id: str,
        amount: float,
        items: list[dict[str, Any]] | None = None,
    ) -> Invoice:
        """Create invoice"""
        invoice_id = hashlib.md5(
            f"{tenant_id}_{subscription_id}_{time.time()}".encode()
        ).hexdigest()[:12]

        invoice = Invoice(
            invoice_id=invoice_id,
            tenant_id=tenant_id,
            subscription_id=subscription_id,
            amount=amount,
            items=items or [],
        )

        self.invoices[invoice_id] = invoice
        return invoice

    async def generate_monthly_invoices(self) -> list[Invoice]:
        """Generate invoices for all active subscriptions"""
        invoices = []

        for sub in self.subscriptions.values():
            if sub.status != BillingStatus.ACTIVE:
                continue

            plan_config = PLAN_CONFIGS[sub.plan]
            base_amount = plan_config["price_monthly"]

            # Get usage costs
            usage_summary = await self.get_usage_summary(sub.tenant_id)
            usage_cost = usage_summary["total_cost"]

            total_amount = base_amount + usage_cost

            items = [
                {"description": f"{sub.plan.value.title()} Plan", "amount": base_amount},
            ]

            if usage_cost > 0:
                items.append({"description": "Additional Usage", "amount": usage_cost})

            invoice = await self.create_invoice(
                sub.tenant_id,
                sub.subscription_id,
                total_amount,
                items,
            )
            invoices.append(invoice)

        return invoices

    # ============= API KEY MANAGEMENT =============
    async def create_api_key(
        self,
        tenant_id: str,
        user_id: str,
        name: str,
        scopes: list[str] | None = None,
        expires_in_days: int | None = None,
    ) -> tuple[str, APIKey]:
        """Create API key"""
        key_id = hashlib.md5(f"{tenant_id}_{time.time()}".encode()).hexdigest()[:12]
        raw_key = f"aios_{hashlib.sha256(f'{key_id}_{time.time()}'.encode()).hexdigest()[:32]}"
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()

        api_key = APIKey(
            key_id=key_id,
            tenant_id=tenant_id,
            user_id=user_id,
            key_prefix=raw_key[:12],
            key_hash=key_hash,
            name=name,
            scopes=scopes or [],
            expires_at=datetime.utcnow() + timedelta(days=expires_in_days) if expires_in_days else None,
        )

        self.api_keys[key_id] = api_key

        await self._audit_log(
            tenant_id=tenant_id,
            user_id=user_id,
            action="create_api_key",
            resource_type="api_key",
            resource_id=key_id,
            result="success",
            details={"name": name},
        )

        return raw_key, api_key

    def verify_api_key(self, raw_key: str) -> APIKey | None:
        """Verify API key"""
        if not raw_key.startswith("aios_"):
            return None

        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()

        for api_key in self.api_keys.values():
            if api_key.key_hash == key_hash and api_key.is_active:
                # Check expiration
                if api_key.expires_at and datetime.utcnow() > api_key.expires_at:
                    return None

                api_key.last_used = datetime.utcnow()
                return api_key

        return None

    # ============= SSO MANAGEMENT =============
    async def configure_sso(
        self,
        tenant_id: str,
        provider: str,
        config: dict[str, Any],
    ) -> SSOConfig:
        """Configure SSO for tenant"""
        config_id = hashlib.md5(
            f"{tenant_id}_{provider}_{time.time()}".encode()
        ).hexdigest()[:12]

        sso_config = SSOConfig(
            config_id=config_id,
            tenant_id=tenant_id,
            provider=provider,
            client_id=config.get("client_id", ""),
            metadata_url=config.get("metadata_url", ""),
            enabled=config.get("enabled", False),
            domains=config.get("domains", []),
            default_role=config.get("default_role", "viewer"),
        )

        self.sso_configs[config_id] = sso_config
        return sso_config

    # ============= AUDIT LOGGING =============
    async def _audit_log(
        self,
        tenant_id: str,
        user_id: str,
        action: str,
        resource_type: str,
        resource_id: str,
        result: str,
        ip_address: str = "unknown",
        details: dict[str, Any] | None = None,
    ):
        """Create audit log entry"""
        entry = AuditEntry(
            entry_id=hashlib.md5(
                f"{tenant_id}_{action}_{time.time()}".encode()
            ).hexdigest()[:16],
            timestamp=datetime.utcnow(),
            tenant_id=tenant_id,
            user_id=user_id,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            result=result,
            ip_address=ip_address,
            details=details or {},
        )

        self.audit_entries.append(entry)

        # Keep only last 10000 entries
        if len(self.audit_entries) > 10000:
            self.audit_entries = self.audit_entries[-10000:]

    async def query_audit_logs(
        self,
        tenant_id: str,
        user_id: str | None = None,
        action: str | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
        limit: int = 100,
    ) -> list[AuditEntry]:
        """Query audit logs"""
        results = [
            entry for entry in self.audit_entries
            if entry.tenant_id == tenant_id
        ]

        if user_id:
            results = [e for e in results if e.user_id == user_id]
        if action:
            results = [e for e in results if e.action == action]
        if start_time:
            results = [e for e in results if e.timestamp >= start_time]
        if end_time:
            results = [e for e in results if e.timestamp <= end_time]

        return results[-limit:]

    # ============= QUOTA ENFORCEMENT =============
    async def check_quota(
        self,
        tenant_id: str,
        quota_type: ResourceQuota,
    ) -> tuple[bool, dict[str, Any]]:
        """Check if tenant is within quota"""
        if tenant_id not in self.tenants:
            return True, {"status": "unknown", "limit": 0, "used": 0}

        tenant = self.tenants[tenant_id]
        quota_map = {
            ResourceQuota.API_RATE_LIMIT: "concurrent_requests",
            ResourceQuota.MAX_USERS: "users",
            ResourceQuota.STORAGE_LIMIT: "storage_gb",
            ResourceQuota.API_CALLS_PER_MONTH: "api_calls_per_month",
        }

        quota_key = quota_map.get(quota_type, "")
        limit = tenant.quotas.get(quota_key, -1)  # -1 = unlimited

        if limit == -1:
            return True, {"status": "ok", "limit": "unlimited", "used": 0}

        # Get current usage
        if quota_type == ResourceQuota.MAX_USERS:
            used = len([u for u in self.users.values() if u.tenant_id == tenant_id])
        else:
            used = 0  # Simplified

        return used < limit, {
            "status": "ok" if used < limit else "exceeded",
            "limit": limit,
            "used": used,
            "remaining": limit - used,
        }

    # ============= STATISTICS =============
    def get_stats(self) -> dict[str, Any]:
        """Get enterprise statistics"""
        return {
            **self.stats,
            "active_tenants": len([t for t in self.tenants.values() if t.status == TenantStatus.ACTIVE]),
            "total_users": len(self.users),
            "active_subscriptions": len([s for s in self.subscriptions.values() if s.status == BillingStatus.ACTIVE]),
            "usage_records": len(self.usage_records),
            "invoices": len(self.invoices),
            "api_keys": len(self.api_keys),
            "audit_entries": len(self.audit_entries),
        }


async def example():
    """Example enterprise features usage"""

    enterprise = EnterpriseManager()

    print("=" * 60)
    print("AI-OS Enterprise Features Example")
    print("=" * 60)

    # Create tenant
    print("\n[Test 1] Tenant Management")
    tenant = await enterprise.create_tenant(
        name="Acme Corporation",
        owner_id="owner_001",
        plan=PlanTier.PROFESSIONAL,
    )
    print(f"Created Tenant: {tenant.tenant_id}")
    print(f"Plan: {tenant.plan.value}")
    print(f"Quotas: {tenant.quotas}")

    # Create subscription
    print("\n[Test 2] Subscription Management")
    subscription = await enterprise.create_subscription(
        tenant_id=tenant.tenant_id,
        plan=PlanTier.PROFESSIONAL,
        billing_cycle=BillingCycle.MONTHLY,
        trial_days=14,
    )
    print(f"Subscription: {subscription.subscription_id}")
    print(f"Plan: {subscription.plan.value}")
    print(f"Status: {subscription.status.value}")

    # Create users
    print("\n[Test 3] User Management")
    admin = await enterprise.create_user(
        email="admin@acme.com",
        name="Admin User",
        tenant_id=tenant.tenant_id,
        role_ids=["admin"],
    )
    print(f"Created Admin: {admin.user_id}")

    developer = await enterprise.create_user(
        email="dev@acme.com",
        name="Developer",
        tenant_id=tenant.tenant_id,
        role_ids=["developer"],
    )
    print(f"Created Developer: {developer.user_id}")

    # Check permissions
    print("\n[Test 4] Permission System")
    print(f"Admin Permissions: {enterprise.get_user_permissions(admin.user_id)}")
    print(f"Developer Permissions: {enterprise.get_user_permissions(developer.user_id)}")
    print(f"Can admin manage api keys: {enterprise.check_permission(admin.user_id, 'api_key:write')}")
    print(f"Can developer manage api keys: {enterprise.check_permission(developer.user_id, 'api_key:write')}")

    # API Keys
    print("\n[Test 5] API Key Management")
    raw_key, api_key = await enterprise.create_api_key(
        tenant_id=tenant.tenant_id,
        user_id=admin.user_id,
        name="Production API Key",
        scopes=["read", "write"],
        expires_in_days=90,
    )
    print(f"API Key Created: {api_key.key_prefix}...")
    print(f"Full Key: {raw_key}")

    # Verify API key
    verified = enterprise.verify_api_key(raw_key)
    print(f"Verification: {'Success' if verified else 'Failed'}")

    # Usage tracking
    print("\n[Test 6] Usage Tracking")
    for i in range(5):
        await enterprise.record_usage(
            tenant_id=tenant.tenant_id,
            user_id=developer.user_id,
            metric=UsageMetric.API_CALLS,
            value=100,
        )

    usage_summary = await enterprise.get_usage_summary(tenant.tenant_id)
    print(f"Period: {usage_summary['period']}")
    print(f"Total Cost: ${usage_summary['total_cost']:.4f}")

    # Quota enforcement
    print("\n[Test 7] Quota Enforcement")
    can_proceed, quota_info = await enterprise.check_quota(
        tenant.tenant_id,
        ResourceQuota.MAX_USERS,
    )
    print(f"User Quota Check: {quota_info}")

    # Plan upgrade
    print("\n[Test 8] Plan Upgrade")
    updated_tenant = await enterprise.update_tenant_plan(tenant.tenant_id, PlanTier.ENTERPRISE)
    print(f"New Plan: {updated_tenant.plan.value}")
    print(f"New Quotas: {updated_tenant.quotas}")

    # SSO Configuration
    print("\n[Test 9] SSO Configuration")
    sso = await enterprise.configure_sso(
        tenant_id=tenant.tenant_id,
        provider="okta",
        config={
            "client_id": "okta_client_id",
            "metadata_url": "https://acme.okta.com/metadata",
            "domains": ["acme.com"],
            "default_role": "viewer",
        },
    )
    print(f"SSO Provider: {sso.provider}")
    print(f"Domains: {sso.domains}")

    # Audit logs
    print("\n[Test 10] Audit Logging")
    logs = await enterprise.query_audit_logs(tenant.tenant_id)
    print(f"Total Audit Entries: {len(logs)}")

    # Enterprise statistics
    print("\n" + "=" * 60)
    print("Enterprise Statistics")
    print("=" * 60)
    stats = enterprise.get_stats()
    for key, value in stats.items():
        if isinstance(value, float):
            print(f"{key}: ${value:.2f}")
        else:
            print(f"{key}: {value}")


if __name__ == "__main__":
    asyncio.run(example())
