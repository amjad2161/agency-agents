"""
AI-OS Multi-Agent Crew Framework
Integrated from CrewAI architecture with advanced features
"""
from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable

logger = logging.getLogger(__name__)


class ProcessType(str, Enum):
    """Agent coordination process types"""
    SEQUENTIAL = "sequential"
    HIERARCHICAL = "hierarchical"
    ASYNC = "async"


@dataclass
class AgentConfig:
    """Agent configuration"""
    role: str
    goal: str
    backstory: str
    verbose: bool = False
    tools: list[Any] = field(default_factory=list)
    llm_config: dict[str, Any] = field(default_factory=dict)


@dataclass
class TaskConfig:
    """Task configuration"""
    description: str
    expected_output: str
    agent: str | None = None
    tools: list[Any] = field(default_factory=list)
    async_execution: bool = False


@dataclass
class CrewExecutionResult:
    """Result from crew execution"""
    task_results: list[dict[str, Any]]
    final_output: str
    token_usage: int
    duration_seconds: float
    success: bool


class BaseAgent(ABC):
    """
    CrewAI-style agent with role, goal, and backstory.
    """

    def __init__(
        self,
        agent_id: str,
        role: str,
        goal: str,
        backstory: str,
        verbose: bool = False,
        tools: list[Any] | None = None,
        llm_config: dict[str, Any] | None = None,
    ):
        self.agent_id = agent_id
        self.role = role
        self.goal = goal
        self.backstory = backstory
        self.verbose = verbose
        self.tools = tools or []
        self.llm_config = llm_config or {}
        self._history: list[dict[str, Any]] = []

    @property
    def system_prompt(self) -> str:
        """Generate system prompt from role, goal, backstory"""
        return f"""You are a {self.role}.

Your goal: {self.goal}

Your backstory: {self.backstory}

You have access to the following tools:
{self._format_tools()}

Always work towards your goal and use your tools appropriately.
"""

    def _format_tools(self) -> str:
        """Format tools for prompt"""
        if not self.tools:
            return "No tools available."
        return "\n".join([f"- {tool.name}: {tool.description}" for tool in self.tools])

    async def execute_task(self, task: TaskConfig) -> dict[str, Any]:
        """Execute a task"""
        if self.verbose:
            logger.info(f"{self.role} executing task: {task.description}")

        start_time = datetime.utcnow()

        try:
            result = await self._execute_with_llm(task)
            duration = (datetime.utcnow() - start_time).total_seconds()

            self._history.append({
                "task": task.description,
                "result": result,
                "timestamp": datetime.utcnow().isoformat(),
                "duration": duration,
            })

            return {
                "success": True,
                "output": result.get("output", ""),
                "tokens": result.get("tokens", 0),
                "duration": duration,
            }
        except Exception as e:
            logger.error(f"Task execution failed: {e}")
            return {
                "success": False,
                "error": str(e),
                "output": "",
                "tokens": 0,
                "duration": 0,
            }

    @abstractmethod
    async def _execute_with_llm(self, task: TaskConfig) -> dict[str, Any]:
        """Execute task with LLM - implement in subclass"""
        pass

    def get_memory(self) -> list[dict[str, Any]]:
        """Get agent memory/history"""
        return self._history


class Tool:
    """Base tool for agents"""

    def __init__(self, name: str, description: str, func: Callable):
        self.name = name
        self.description = description
        self.func = func

    async def run(self, *args, **kwargs) -> Any:
        """Execute tool"""
        return await self.func(*args, **kwargs)


class Task:
    """Task that can be assigned to agents"""

    def __init__(
        self,
        task_id: str,
        description: str,
        expected_output: str,
        agent: BaseAgent | None = None,
        tools: list[Tool] | None = None,
        async_execution: bool = False,
    ):
        self.task_id = task_id
        self.description = description
        self.expected_output = expected_output
        self.agent = agent
        self.tools = tools or []
        self.async_execution = async_execution
        self.output: str | None = None


class Crew:
    """
    Crew of agents working together on tasks.
    Inspired by CrewAI architecture.
    """

    def __init__(
        self,
        agents: list[BaseAgent],
        tasks: list[Task],
        process: ProcessType = ProcessType.SEQUENTIAL,
        verbose: bool = True,
    ):
        self.agents = agents
        self.tasks = tasks
        self.process = process
        self.verbose = verbose
        self._assign_tasks()

    def _assign_tasks(self):
        """Assign tasks to agents based on config"""
        for task in self.tasks:
            if task.agent is None and self.agents:
                task.agent = self.agents[0]

    async def kickoff(self, inputs: dict[str, Any] | None = None) -> CrewExecutionResult:
        """Execute all tasks"""
        inputs = inputs or {}
        start_time = datetime.utcnow()
        task_results = []

        if self.verbose:
            logger.info(f"Starting crew with {len(self.agents)} agents, {len(self.tasks)} tasks")

        if self.process == ProcessType.SEQUENTIAL:
            task_results = await self._execute_sequential(inputs)
        elif self.process == ProcessType.HIERARCHICAL:
            task_results = await self._execute_hierarchical(inputs)
        elif self.process == ProcessType.ASYNC:
            task_results = await self._execute_async(inputs)

        duration = (datetime.utcnow() - start_time).total_seconds()

        return CrewExecutionResult(
            task_results=task_results,
            final_output=task_results[-1]["output"] if task_results else "",
            token_usage=sum(r.get("tokens", 0) for r in task_results),
            duration_seconds=duration,
            success=all(r.get("success", False) for r in task_results),
        )

    async def _execute_sequential(self, inputs: dict[str, Any]) -> list[dict[str, Any]]:
        """Execute tasks sequentially"""
        results = []
        context = inputs.copy()

        for i, task in enumerate(self.tasks):
            if self.verbose:
                logger.info(f"Task {i+1}/{len(self.tasks)}: {task.description[:50]}...")

            prompt = self._build_task_prompt(task, context)

            result = await task.agent.execute_task(TaskConfig(
                description=prompt,
                expected_output=task.expected_output,
            ))

            task.output = result.get("output", "")
            results.append(result)
            context[task.description[:50]] = task.output

        return results

    async def _execute_hierarchical(self, inputs: dict[str, Any]) -> list[dict[str, Any]]:
        """Execute with manager agent coordinating"""
        manager = self.agents[0] if self.agents else None
        workers = self.agents[1:] if len(self.agents) > 1 else []

        if not manager or not workers:
            return await self._execute_sequential(inputs)

        results = []

        # Manager plans task distribution
        plan_prompt = f"""Plan execution of tasks:
{chr(10).join([f"- {t.description}" for t in self.tasks])}
Assign to workers: {[w.role for w in workers]}"""

        plan_result = await manager.execute_task(TaskConfig(
            description=plan_prompt,
            expected_output="Assignment plan",
        ))
        results.append(plan_result)

        for task in self.tasks:
            worker = workers[0]
            result = await worker.execute_task(TaskConfig(
                description=task.description,
                expected_output=task.expected_output,
            ))
            task.output = result.get("output", "")
            results.append(result)

        return results

    async def _execute_async(self, inputs: dict[str, Any]) -> list[dict[str, Any]]:
        """Execute tasks in parallel"""
        results = []

        async_results = await asyncio.gather(*[
            task.agent.execute_task(TaskConfig(
                description=task.description,
                expected_output=task.expected_output,
            ))
            for task in self.tasks if task.agent
        ])

        for task, result in zip(self.tasks, async_results):
            task.output = result.get("output", "")
            results.append(result)

        return results

    def _build_task_prompt(self, task: Task, context: dict[str, Any]) -> str:
        """Build task prompt with context"""
        context_str = "\n\nContext:\n" + "\n".join([f"- {k}: {v}" for k, v in context.items()]) if context else ""
        return f"{task.description}{context_str}\n\nExpected: {task.expected_output}"


# Decorator-based Flow
class Flow:
    """Event-driven workflow framework"""

    def __init__(self):
        self._start_handlers: list[Callable] = []
        self._listen_handlers: dict[str, list[Callable]] = {}
        self._router_handlers: list[Callable] = []

    def start(self, func: Callable) -> Callable:
        """Decorator for starting flow"""
        self._start_handlers.append(func)
        return func

    def listen(self, event: str) -> Callable:
        """Decorator for listening to events"""
        def decorator(func: Callable) -> Callable:
            if event not in self._listen_handlers:
                self._listen_handlers[event] = []
            self._listen_handlers[event].append(func)
            return func
        return decorator

    def router(self, func: Callable) -> Callable:
        """Decorator for routing"""
        self._router_handlers.append(func)
        return func

    async def run(self, initial_data: dict[str, Any]) -> dict[str, Any]:
        """Run the flow"""
        current_data = initial_data.copy()

        for handler in self._start_handlers:
            result = await handler(current_data)
            if result:
                current_data.update(result if isinstance(result, dict) else {"result": result})

        while True:
            event = current_data.get("event")
            if not event or event not in self._listen_handlers:
                break

            for handler in self._listen_handlers[event]:
                result = await handler(current_data)
                if result:
                    current_data.update(result if isinstance(result, dict) else {"result": result})

            routed = False
            for router in self._router_handlers:
                route_result = router(current_data)
                if route_result:
                    current_data["event"] = route_result
                    routed = True
                    break
            if not routed:
                break

        return current_data


# Example usage
async def example():
    """Example crew execution"""

    class SimpleAgent(BaseAgent):
        async def _execute_with_llm(self, task: TaskConfig) -> dict[str, Any]:
            # Simulate LLM execution
            return {"output": f"Result for: {task.description[:30]}...", "tokens": 100}

    # Create agents
    researcher = SimpleAgent(
        agent_id="researcher_01",
        role="Senior Data Researcher",
        goal="Find cutting-edge developments in AI",
        backstory="Expert researcher with years of experience",
        verbose=True
    )

    analyst = SimpleAgent(
        agent_id="analyst_01",
        role="Data Analyst",
        goal="Analyze and synthesize research findings",
        backstory="Expert analyst specializing in AI trends",
        verbose=True
    )

    # Create tasks
    tasks = [
        Task("t1", "Research latest AI agent frameworks on GitHub", "10 key findings"),
        Task("t2", "Analyze research findings and create summary", "Executive summary"),
    ]
    tasks[1].agent = analyst

    # Create crew
    crew = Crew(
        agents=[researcher, analyst],
        tasks=tasks,
        process=ProcessType.SEQUENTIAL,
        verbose=True
    )

    # Execute
    result = await crew.kickoff({"topic": "AI Agents"})

    print(f"Success: {result.success}")
    print(f"Output: {result.final_output}")


if __name__ == "__main__":
    asyncio.run(example())
