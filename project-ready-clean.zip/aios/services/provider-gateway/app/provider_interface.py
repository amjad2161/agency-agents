"""
Provider Gateway Service - Model Provider Abstraction
Provides unified interface for multiple model providers
"""
from typing import Any, Optional, Protocol
from abc import ABC, abstractmethod
from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field


class ProviderType(str, Enum):
    """Supported model providers"""
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    LOCAL = "local"
    AZURE = "azure"
    GOOGLE = "google"


class ModelCapability(str, Enum):
    """Model capabilities"""
    TEXT = "text"
    VISION = "vision"
    CODE = "code"
    EMBEDDING = "embedding"
    REASONING = "reasoning"


class ProviderConfig(BaseModel):
    """Provider configuration"""
    provider_type: ProviderType
    api_key: str
    base_url: Optional[str] = None
    model: str
    max_tokens: int = 4096
    timeout_seconds: int = 60
    retry_attempts: int = 3


class ModelRequest(BaseModel):
    """Unified model request"""
    model: str
    messages: list[dict[str, str]]
    temperature: float = 0.7
    max_tokens: Optional[int] = None
    top_p: Optional[float] = None
    stream: bool = False
    stop: Optional[list[str]] = None


class ModelResponse(BaseModel):
    """Unified model response"""
    id: str
    model: str
    content: str
    finish_reason: str
    usage: dict[str, int]
    latency_ms: int
    provider: ProviderType


class ProviderAdapter(ABC):
    """Abstract base class for provider adapters"""

    @abstractmethod
    async def initialize(self) -> None:
        """Initialize the provider"""
        pass

    @abstractmethod
    async def complete(self, request: ModelRequest) -> ModelResponse:
        """Generate completion"""
        pass

    @abstractmethod
    async def embed(self, text: str) -> list[float]:
        """Generate embeddings"""
        pass

    @abstractmethod
    async def health_check(self) -> dict[str, Any]:
        """Check provider health"""
        pass

    @abstractmethod
    def get_capabilities(self) -> list[ModelCapability]:
        """Get model capabilities"""
        pass


class OpenAIAdapter(ProviderAdapter):
    """OpenAI provider adapter"""

    def __init__(self, config: ProviderConfig):
        self.config = config
        self._client = None

    async def initialize(self) -> None:
        """Initialize OpenAI client"""
        self._client = {"initialized": True}

    async def complete(self, request: ModelRequest) -> ModelResponse:
        """Generate OpenAI completion"""
        return ModelResponse(
            id=f"openai-{datetime.utcnow().timestamp()}",
            model=request.model,
            content="Generated response",
            finish_reason="stop",
            usage={"prompt_tokens": 100, "completion_tokens": 50, "total_tokens": 150},
            latency_ms=500,
            provider=ProviderType.OPENAI,
        )

    async def embed(self, text: str) -> list[float]:
        """Generate OpenAI embeddings"""
        return [0.1] * 1536

    async def health_check(self) -> dict[str, Any]:
        """Check OpenAI health"""
        return {"status": "healthy", "latency_ms": 100}

    def get_capabilities(self) -> list[ModelCapability]:
        """Get OpenAI capabilities"""
        return [ModelCapability.TEXT, ModelCapability.VISION, ModelCapability.CODE, ModelCapability.EMBEDDING]


class AnthropicAdapter(ProviderAdapter):
    """Anthropic provider adapter"""

    def __init__(self, config: ProviderConfig):
        self.config = config
        self._client = None

    async def initialize(self) -> None:
        """Initialize Anthropic client"""
        self._client = {"initialized": True}

    async def complete(self, request: ModelRequest) -> ModelResponse:
        """Generate Anthropic completion"""
        return ModelResponse(
            id=f"anthropic-{datetime.utcnow().timestamp()}",
            model=request.model,
            content="Generated response",
            finish_reason="stop",
            usage={"input_tokens": 100, "output_tokens": 50},
            latency_ms=600,
            provider=ProviderType.ANTHROPIC,
        )

    async def embed(self, text: str) -> list[float]:
        """Anthropic doesn't support embeddings natively"""
        return []

    async def health_check(self) -> dict[str, Any]:
        """Check Anthropic health"""
        return {"status": "healthy", "latency_ms": 120}

    def get_capabilities(self) -> list[ModelCapability]:
        """Get Anthropic capabilities"""
        return [ModelCapability.TEXT, ModelCapability.VISION, ModelCapability.REASONING]


class LocalAdapter(ProviderAdapter):
    """Local/self-hosted model adapter"""

    def __init__(self, config: ProviderConfig):
        self.config = config
        self._client = None

    async def initialize(self) -> None:
        """Initialize local client"""
        self._client = {"initialized": True}

    async def complete(self, request: ModelRequest) -> ModelResponse:
        """Generate local completion"""
        return ModelResponse(
            id=f"local-{datetime.utcnow().timestamp()}",
            model=request.model,
            content="Local model response",
            finish_reason="stop",
            usage={"tokens": 150},
            latency_ms=1000,
            provider=ProviderType.LOCAL,
        )

    async def embed(self, text: str) -> list[float]:
        """Generate local embeddings"""
        return [0.1] * 768

    async def health_check(self) -> dict[str, Any]:
        """Check local model health"""
        return {"status": "healthy", "latency_ms": 50}

    def get_capabilities(self) -> list[ModelCapability]:
        """Get local capabilities"""
        return [ModelCapability.TEXT, ModelCapability.CODE, ModelCapability.EMBEDDING]


class ProviderRouter:
    """Routes requests to appropriate provider"""

    def __init__(self):
        self._providers: dict[ProviderType, ProviderAdapter] = {}
        self._fallback_order: list[ProviderType] = []

    def register_provider(self, provider_type: ProviderType, adapter: ProviderAdapter) -> None:
        """Register a provider adapter"""
        self._providers[provider_type] = adapter
        self._fallback_order.append(provider_type)

    async def route(self, request: ModelRequest, preferred_provider: ProviderType | None = None) -> ModelResponse:
        """Route request to provider with fallback"""
        providers_to_try = []

        if preferred_provider and preferred_provider in self._providers:
            providers_to_try = [preferred_provider] + [p for p in self._fallback_order if p != preferred_provider]
        else:
            providers_to_try = self._fallback_order

        last_error = None
        for provider_type in providers_to_try:
            adapter = self._providers.get(provider_type)
            if not adapter:
                continue

            try:
                response = await adapter.complete(request)
                return response
            except Exception as e:
                last_error = e
                continue

        raise RuntimeError(f"All providers failed. Last error: {last_error}")


class ProviderGateway:
    """Main provider gateway service"""

    def __init__(self):
        self.router = ProviderRouter()
        self._initialized = False

    async def initialize(self, configs: list[ProviderConfig]) -> None:
        """Initialize all providers"""
        for config in configs:
            adapter = self._create_adapter(config)
            await adapter.initialize()
            self.router.register_provider(config.provider_type, adapter)

        self._initialized = True

    def _create_adapter(self, config: ProviderConfig) -> ProviderAdapter:
        """Create adapter based on provider type"""
        if config.provider_type == ProviderType.OPENAI:
            return OpenAIAdapter(config)
        elif config.provider_type == ProviderType.ANTHROPIC:
            return AnthropicAdapter(config)
        elif config.provider_type == ProviderType.LOCAL:
            return LocalAdapter(config)
        else:
            raise ValueError(f"Unknown provider type: {config.provider_type}")

    async def complete(self, request: ModelRequest, preferred_provider: ProviderType | None = None) -> ModelResponse:
        """Generate completion with automatic routing"""
        return await self.router.route(request, preferred_provider)

    async def embed(self, text: str, provider: ProviderType = ProviderType.OPENAI) -> list[float]:
        """Generate embeddings"""
        adapter = self._providers.get(provider)
        if not adapter:
            raise ValueError(f"Provider {provider} not registered")
        return await adapter.embed(text)

    async def get_health_status(self) -> dict[str, Any]:
        """Get health status of all providers"""
        health = {}
        for provider_type, adapter in self._providers.items():
            health[provider_type.value] = await adapter.health_check()
        return health