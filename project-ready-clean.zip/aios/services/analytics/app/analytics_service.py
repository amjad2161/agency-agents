"""
Analytics Service - Advanced metrics and reporting
Provides comprehensive analytics, insights, and reporting
"""
from datetime import datetime, timedelta
from typing import Any, Optional
from enum import Enum
from uuid import uuid4
import statistics

from pydantic import BaseModel, Field


class MetricType(str, Enum):
    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"
    RATE = "rate"
    PERCENTILE = "percentile"


class TimeRange(str, Enum):
    HOUR = "1h"
    DAY = "24h"
    WEEK = "7d"
    MONTH = "30d"
    QUARTER = "90d"


class AggregationPeriod(str, Enum):
    MINUTE = "1m"
    FIVE_MINUTES = "5m"
    FIFTEEN_MINUTES = "15m"
    HOUR = "1h"
    DAY = "1d"


class MetricValue(BaseModel):
    """Single metric value"""
    timestamp: datetime
    value: float
    labels: dict[str, str] = Field(default_factory=dict)


class MetricSeries(BaseModel):
    """Time series metric data"""
    metric_name: str
    unit: str
    values: list[MetricValue]
    aggregation: AggregationPeriod


class DashboardWidget(BaseModel):
    """Dashboard widget configuration"""
    widget_id: str = Field(default_factory=lambda: str(uuid4()))
    title: str
    widget_type: str  # line, bar, pie, gauge, table, heatmap
    metrics: list[str]
    filters: dict[str, Any] = Field(default_factory=dict)
    visualization_options: dict[str, Any] = Field(default_factory=dict)
    position: dict[str, int] = Field(default_factory=dict)  # x, y, width, height


class Dashboard(BaseModel):
    """Analytics dashboard"""
    dashboard_id: str = Field(default_factory=lambda: str(uuid4()))
    name: str
    description: str
    widgets: list[DashboardWidget]
    refresh_interval: int = 30  # seconds
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class AlertRule(BaseModel):
    """Alert rule configuration"""
    rule_id: str = Field(default_factory=lambda: str(uuid4()))
    name: str
    description: str
    metric: str
    condition: str  # e.g., "greater_than", "less_than", "equals"
    threshold: float
    severity: str  # info, warning, critical
    duration_seconds: int = 60
    notification_channels: list[str] = Field(default_factory=list)
    enabled: bool = True


class AlertEvent(BaseModel):
    """Alert event"""
    alert_id: str = Field(default_factory=lambda: str(uuid4()))
    rule_id: str
    rule_name: str
    severity: str
    triggered_at: datetime
    resolved_at: Optional[datetime] = None
    value: float
    threshold: float
    status: str  # firing, resolved, acknowledged


class AnalyticsService:
    """Advanced analytics and reporting service"""

    def __init__(self):
        self._metrics_store: dict[str, list[MetricValue]] = {}
        self._dashboards: dict[str, Dashboard] = {}
        self._alert_rules: dict[str, AlertRule] = {}

    async def initialize(self) -> None:
        """Initialize analytics service"""
        pass

    # === Metric Collection ===

    async def record_metric(
        self,
        metric_name: str,
        value: float,
        labels: dict[str, str] | None = None,
        timestamp: datetime | None = None,
    ) -> str:
        """Record a metric value"""
        if metric_name not in self._metrics_store:
            self._metrics_store[metric_name] = []

        metric_value = MetricValue(
            timestamp=timestamp or datetime.utcnow(),
            value=value,
            labels=labels or {},
        )
        self._metrics_store[metric_name].append(metric_value)
        return str(uuid4())

    async def record_counter(
        self, name: str, increment: float = 1, labels: dict[str, str] | None = None
    ) -> str:
        """Record counter metric"""
        return await self.record_metric(f"counter.{name}", increment, labels)

    async def record_gauge(
        self, name: str, value: float, labels: dict[str, str] | None = None
    ) -> str:
        """Record gauge metric"""
        return await self.record_metric(f"gauge.{name}", value, labels)

    async def record_histogram(
        self,
        name: str,
        value: float,
        labels: dict[str, str] | None = None,
        buckets: list[float] | None = None,
    ) -> str:
        """Record histogram metric"""
        return await self.record_metric(f"histogram.{name}", value, labels)

    # === Metric Query ===

    async def query_metric(
        self,
        metric_name: str,
        start_time: datetime,
        end_time: datetime,
        aggregation: AggregationPeriod = AggregationPeriod.HOUR,
    ) -> MetricSeries:
        """Query metric time series"""
        values = self._metrics_store.get(metric_name, [])
        filtered = [v for v in values if start_time <= v.timestamp <= end_time]

        return MetricSeries(
            metric_name=metric_name,
            unit="",
            values=filtered,
            aggregation=aggregation,
        )

    async def get_metric_aggregates(
        self,
        metric_name: str,
        start_time: datetime,
        end_time: datetime,
    ) -> dict[str, float]:
        """Get aggregated statistics for metric"""
        values = self._metrics_store.get(metric_name, [])
        filtered = [v.value for v in values if start_time <= v.timestamp <= end_time]

        if not filtered:
            return {"count": 0, "sum": 0, "avg": 0, "min": 0, "max": 0}

        return {
            "count": len(filtered),
            "sum": sum(filtered),
            "avg": statistics.mean(filtered),
            "min": min(filtered),
            "max": max(filtered),
            "p50": statistics.median(filtered),
            "p90": self._percentile(filtered, 90),
            "p95": self._percentile(filtered, 95),
            "p99": self._percentile(filtered, 99),
        }

    def _percentile(self, data: list[float], percentile: float) -> float:
        """Calculate percentile"""
        sorted_data = sorted(data)
        index = int(len(sorted_data) * percentile / 100)
        return sorted_data[min(index, len(sorted_data) - 1)]

    # === Pre-built Metrics ===

    async def get_request_metrics(
        self, time_range: TimeRange
    ) -> dict[str, Any]:
        """Get request metrics"""
        start_time = datetime.utcnow() - self._parse_time_range(time_range)
        return await self.get_metric_aggregates(
            "counter.requests", start_time, datetime.utcnow()
        )

    async def get_latency_metrics(
        self, time_range: TimeRange
    ) -> dict[str, Any]:
        """Get latency metrics"""
        start_time = datetime.utcnow() - self._parse_time_range(time_range)
        return await self.get_metric_aggregates(
            "histogram.latency", start_time, datetime.utcnow()
        )

    async def get_error_rate(
        self, time_range: TimeRange
    ) -> dict[str, Any]:
        """Get error rate metrics"""
        start_time = datetime.utcnow() - self._parse_time_range(time_range)
        request_count = await self.get_metric_aggregates(
            "counter.requests", start_time, datetime.utcnow()
        )
        error_count = await self.get_metric_aggregates(
            "counter.errors", start_time, datetime.utcnow()
        )

        if request_count.get("count", 0) == 0:
            return {"error_rate": 0, "total_requests": 0, "total_errors": 0}

        return {
            "error_rate": error_count.get("count", 0) / request_count.get("count", 1),
            "total_requests": request_count.get("count", 0),
            "total_errors": error_count.get("count", 0),
        }

    def _parse_time_range(self, time_range: TimeRange) -> timedelta:
        """Parse time range to timedelta"""
        mapping = {
            TimeRange.HOUR: timedelta(hours=1),
            TimeRange.DAY: timedelta(days=1),
            TimeRange.WEEK: timedelta(days=7),
            TimeRange.MONTH: timedelta(days=30),
            TimeRange.QUARTER: timedelta(days=90),
        }
        return mapping.get(time_range, timedelta(days=1))

    # === Dashboards ===

    async def create_dashboard(
        self, name: str, description: str, widgets: list[DashboardWidget]
    ) -> Dashboard:
        """Create new dashboard"""
        dashboard = Dashboard(
            name=name,
            description=description,
            widgets=widgets,
        )
        self._dashboards[dashboard.dashboard_id] = dashboard
        return dashboard

    async def get_dashboard(self, dashboard_id: str) -> Dashboard | None:
        """Get dashboard by ID"""
        return self._dashboards.get(dashboard_id)

    async def update_dashboard(
        self, dashboard_id: str, updates: dict[str, Any]
    ) -> Dashboard | None:
        """Update dashboard"""
        if dashboard_id not in self._dashboards:
            return None

        dashboard = self._dashboards[dashboard_id]
        for key, value in updates.items():
            setattr(dashboard, key, value)
        dashboard.updated_at = datetime.utcnow()
        return dashboard

    async def list_dashboards(self) -> list[Dashboard]:
        """List all dashboards"""
        return list(self._dashboards.values())

    async def delete_dashboard(self, dashboard_id: str) -> bool:
        """Delete dashboard"""
        if dashboard_id in self._dashboards:
            del self._dashboards[dashboard_id]
            return True
        return False

    # === Alerts ===

    async def create_alert_rule(self, rule: AlertRule) -> str:
        """Create alert rule"""
        self._alert_rules[rule.rule_id] = rule
        return rule.rule_id

    async def get_alert_rule(self, rule_id: str) -> AlertRule | None:
        """Get alert rule"""
        return self._alert_rules.get(rule_id)

    async def list_alert_rules(self) -> list[AlertRule]:
        """List all alert rules"""
        return list(self._alert_rules.values())

    async def update_alert_rule(
        self, rule_id: str, updates: dict[str, Any]
    ) -> AlertRule | None:
        """Update alert rule"""
        if rule_id not in self._alert_rules:
            return None

        rule = self._alert_rules[rule_id]
        for key, value in updates.items():
            setattr(rule, key, value)
        return rule

    async def delete_alert_rule(self, rule_id: str) -> bool:
        """Delete alert rule"""
        if rule_id in self._alert_rules:
            del self._alert_rules[rule_id]
            return True
        return False

    async def evaluate_alerts(self) -> list[AlertEvent]:
        """Evaluate all alert rules"""
        triggered_alerts = []
        for rule in self._alert_rules.values():
            if not rule.enabled:
                continue

            metric_data = await self.get_metric_aggregates(
                rule.metric,
                datetime.utcnow() - timedelta(seconds=rule.duration_seconds),
                datetime.utcnow(),
            )

            current_value = metric_data.get("avg", 0)
            should_trigger = False

            if rule.condition == "greater_than" and current_value > rule.threshold:
                should_trigger = True
            elif rule.condition == "less_than" and current_value < rule.threshold:
                should_trigger = True
            elif rule.condition == "equals" and abs(current_value - rule.threshold) < 0.01:
                should_trigger = True

            if should_trigger:
                alert = AlertEvent(
                    rule_id=rule.rule_id,
                    rule_name=rule.name,
                    severity=rule.severity,
                    triggered_at=datetime.utcnow(),
                    value=current_value,
                    threshold=rule.threshold,
                    status="firing",
                )
                triggered_alerts.append(alert)

        return triggered_alerts

    # === Reporting ===

    async def generate_report(
        self,
        report_type: str,
        start_time: datetime,
        end_time: datetime,
        filters: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Generate analytics report"""
        metrics = {}

        if report_type == "overview":
            metrics = {
                "requests": await self.get_metric_aggregates(
                    "counter.requests", start_time, end_time
                ),
                "latency": await self.get_metric_aggregates(
                    "histogram.latency", start_time, end_time
                ),
                "errors": await self.get_metric_aggregates(
                    "counter.errors", start_time, end_time
                ),
            }
        elif report_type == "performance":
            metrics = {
                "latency": await self.get_metric_aggregates(
                    "histogram.latency", start_time, end_time
                ),
                "throughput": await self.get_metric_aggregates(
                    "rate.requests", start_time, end_time
                ),
            }

        return {
            "report_type": report_type,
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "generated_at": datetime.utcnow().isoformat(),
            "metrics": metrics,
            "filters": filters or {},
        }

    async def export_data(
        self,
        metric_names: list[str],
        start_time: datetime,
        end_time: datetime,
        format: str = "json",
    ) -> dict[str, Any]:
        """Export metric data"""
        data = {}
        for metric_name in metric_names:
            series = await self.query_metric(metric_name, start_time, end_time)
            data[metric_name] = {
                "metric_name": series.metric_name,
                "values": [
                    {"timestamp": v.timestamp.isoformat(), "value": v.value}
                    for v in series.values
                ],
            }

        return {
            "export_time": datetime.utcnow().isoformat(),
            "start_time": start_time.isoformat(),
            "end_time": end_time.isoformat(),
            "format": format,
            "data": data,
        }


class UsageAnalytics:
    """Tenant usage analytics"""

    def __init__(self, analytics_service: AnalyticsService):
        self.analytics = analytics_service

    async def track_api_usage(
        self, tenant_id: str, endpoint: str, tokens_used: int
    ) -> None:
        """Track API usage for tenant"""
        await self.analytics.record_counter(
            f"usage.api.{endpoint}",
            increment=1,
            labels={"tenant_id": tenant_id},
        )
        await self.analytics.record_counter(
            "usage.tokens",
            increment=tokens_used,
            labels={"tenant_id": tenant_id},
        )

    async def get_tenant_usage(
        self, tenant_id: str, time_range: TimeRange
    ) -> dict[str, Any]:
        """Get usage metrics for tenant"""
        start_time = datetime.utcnow() - self.analytics._parse_time_range(time_range)

        api_calls = await self.analytics.get_metric_aggregates(
            "usage.api.*", start_time, datetime.utcnow()
        )
        tokens = await self.analytics.get_metric_aggregates(
            "usage.tokens", start_time, datetime.utcnow()
        )

        return {
            "tenant_id": tenant_id,
            "time_range": time_range.value,
            "api_calls": api_calls.get("count", 0),
            "total_tokens": int(tokens.get("sum", 0)),
            "avg_daily_calls": api_calls.get("count", 0)
            / self._days_in_range(time_range),
        }

    def _days_in_range(self, time_range: TimeRange) -> float:
        """Get days in time range"""
        mapping = {
            TimeRange.HOUR: 1 / 24,
            TimeRange.DAY: 1,
            TimeRange.WEEK: 7,
            TimeRange.MONTH: 30,
            TimeRange.QUARTER: 90,
        }
        return mapping.get(time_range, 1)


class CostAnalytics:
    """Cost and budget analytics"""

    def __init__(self, analytics_service: AnalyticsService):
        self.analytics = analytics_service

    async def track_cost(
        self, tenant_id: str, cost_type: str, amount: float, metadata: dict[str, Any] | None = None
    ) -> None:
        """Track cost for tenant"""
        await self.analytics.record_gauge(
            f"cost.{cost_type}",
            value=amount,
            labels={"tenant_id": tenant_id, **(metadata or {})},
        )

    async def get_tenant_costs(
        self, tenant_id: str, time_range: TimeRange
    ) -> dict[str, Any]:
        """Get cost breakdown for tenant"""
        cost_types = ["compute", "storage", "api_calls", "storage_transfer"]
        total_cost = 0.0
        breakdown = {}

        for cost_type in cost_types:
            aggregates = await self.analytics.get_metric_aggregates(
                f"cost.{cost_type}",
                datetime.utcnow() - self.analytics._parse_time_range(time_range),
                datetime.utcnow(),
            )
            cost = aggregates.get("sum", 0)
            breakdown[cost_type] = cost
            total_cost += cost

        return {
            "tenant_id": tenant_id,
            "time_range": time_range.value,
            "total_cost": total_cost,
            "breakdown": breakdown,
            "currency": "USD",
        }