"""
AI-OS Memory Service - Memory Manager
Multi-tier memory system with retrieval pipeline
"""
from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from packages.schemas.src import (
    MemoryRecord,
    MemoryType,
    MemorySearchRequest,
    MemorySearchResult,
    SemanticMemoryRecord,
    EpisodicMemoryRecord,
    WorkingMemoryRecord,
    ProceduralMemoryRecord,
)

logger = logging.getLogger(__name__)


class MemoryManager:
    """
    Multi-tier memory system manager.
    Coordinates working, semantic, episodic, and procedural memory.
    """

    def __init__(self):
        # Memory stores
        self.stores: dict[MemoryType, Any] = {
            MemoryType.WORKING: {},
            MemoryType.SEMANTIC: {},
            MemoryType.EPISODIC: {},
            MemoryType.PROCEDURAL: {},
        }

        # Vector index for semantic memory
        self.vector_index: dict[str, list[float]] = {}

        # Configuration
        self.config = {
            MemoryType.WORKING: {"ttl_seconds": 3600, "max_entries": 1000},
            MemoryType.SEMANTIC: {"ttl_seconds": None, "max_entries": None},
            MemoryType.EPISODIC: {"ttl_seconds": 86400 * 30, "max_entries": 10000},
            MemoryType.PROCEDURAL: {"ttl_seconds": None, "max_entries": 5000},
        }

    async def initialize(self) -> None:
        """Initialize memory manager resources."""
        await asyncio.sleep(0)
        return None

    async def shutdown(self) -> None:
        """Release memory manager resources."""
        await asyncio.sleep(0)
        return None

    async def store(
        self,
        memory_type: MemoryType,
        content: str,
        tenant_id: str,
        user_id: str | None = None,
        session_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        embedding: list[float] | None = None,
        tags: list[str] | None = None,
    ) -> str:
        """
        Store a memory record.

        Args:
            memory_type: Type of memory
            content: Content to store
            tenant_id: Tenant identifier
            user_id: Optional user identifier
            session_id: Optional session identifier
            metadata: Additional metadata
            embedding: Optional vector embedding
            tags: Optional tags

        Returns:
            memory_id: Unique identifier for stored memory
        """
        await asyncio.sleep(0)
        memory_id = str(uuid.uuid4())

        record = {
            "memory_id": memory_id,
            "memory_type": memory_type.value,
            "content": content,
            "tenant_id": tenant_id,
            "user_id": user_id,
            "session_id": session_id,
            "metadata": metadata or {},
            "embedding": embedding,
            "tags": tags or [],
            "created_at": datetime.now(timezone.utc).replace(tzinfo=None),
            "updated_at": datetime.now(timezone.utc).replace(tzinfo=None),
            "access_count": 0,
            "last_accessed_at": None,
        }

        if memory_type == MemoryType.WORKING and metadata:
            record.update({
                "key": metadata.get("key"),
                "value": metadata.get("value"),
                "scope": metadata.get("scope", "session"),
                "ttl_seconds": metadata.get("ttl_seconds"),
            })

        # Store in appropriate memory store
        self.stores[memory_type][memory_id] = record

        # Index in vector store if semantic memory
        if memory_type == MemoryType.SEMANTIC and embedding:
            self.vector_index[memory_id] = embedding

        logger.info(f"Stored {memory_type.value} memory {memory_id}")

        return memory_id

    async def retrieve(
        self,
        request: MemorySearchRequest,
        tenant_id: str,
        user_id: str | None = None,
    ) -> list[MemorySearchResult]:
        """
        Retrieve memories using the full retrieval pipeline.

        Pipeline stages:
        1. Query normalization
        2. Embedding generation
        3. Vector recall
        4. Semantic reranking
        5. Symbolic lookup
        6. Recency weighting
        7. Tenant filter
        8. Privacy filter
        9. Relevance threshold
        10. Context compression
        """
        start_time = datetime.now(timezone.utc).replace(tzinfo=None)

        # Stage 1: Query normalization
        normalized_query = self._normalize_query(request.query)
        logger.debug(f"Normalized query: {normalized_query}")

        # Stage 2-3: Embedding and vector recall
        query_embedding = await self._generate_embedding(normalized_query)
        vector_results = await self._vector_recall(
            query_embedding,
            request.top_k * 2,  # Get more for reranking
            request.memory_types,
            tenant_id,
        )

        # Stage 4: Semantic reranking
        if request.rerank:
            vector_results = await self._rerank_results(
                vector_results,
                request.query,
            )

        # Stage 5: Symbolic lookup (keyword matching)
        symbolic_results = await self._symbolic_lookup(
            normalized_query,
            request.memory_types,
            tenant_id,
        )

        # Stage 6: Merge and recency weighting
        merged_results = self._merge_results(
            vector_results,
            symbolic_results,
            weight_vector=0.7,
            weight_symbolic=0.3,
        )

        # Apply recency weighting
        for result in merged_results:
            result.recency_weight = self._calculate_recency_weight(result)
            result.combined_score = self._combine_scores(
                result.relevance_score,
                result.recency_weight,
            )

        # Stage 7-8: Tenant and privacy filter
        filtered_results = self._apply_filters(
            merged_results,
            tenant_id,
            user_id,
        )

        # Stage 9: Relevance threshold
        filtered_results = [
            r for r in filtered_results
            if r.combined_score >= request.min_relevance
        ]

        # Stage 10: Context compression
        if request.compress:
            filtered_results = await self._compress_context(
                filtered_results,
                request.max_context_tokens,
            )

        # Limit to top_k
        filtered_results = filtered_results[:request.top_k]

        # Calculate processing time
        processing_time = (datetime.now(timezone.utc).replace(tzinfo=None) - start_time).total_seconds() * 1000

        logger.info(
            f"Memory retrieval completed in {processing_time:.0f}ms, "
            f"returned {len(filtered_results)} results"
        )

        return filtered_results

    def _normalize_query(self, query: str) -> str:
        """Normalize search query"""
        # Simple normalization - lowercase and strip
        return query.lower().strip()

    async def _generate_embedding(self, query: str) -> list[float]:
        """Generate embedding for query"""
        # In production, would call embedding service
        # Return fake embedding for now
        await asyncio.sleep(0)
        return [0.1] * 1536  # Assuming 1536-dim embeddings

    async def _vector_recall(
        self,
        query_embedding: list[float],
        top_k: int,
        memory_types: list[MemoryType] | None,
        tenant_id: str,
    ) -> list[MemorySearchResult]:
        """Perform vector similarity search"""
        await asyncio.sleep(0)
        if memory_types is not None and MemoryType.SEMANTIC not in memory_types:
            return []
        results = []

        for memory_id, embedding in self.vector_index.items():
            # Calculate cosine similarity
            similarity = self._cosine_similarity(query_embedding, embedding)

            if similarity > 0.3:  # Threshold
                record = self.stores[MemoryType.SEMANTIC].get(memory_id)
                if record and record.get("tenant_id") == tenant_id:
                    results.append(MemorySearchResult(
                        memory_id=memory_id,
                        memory_type=MemoryType.SEMANTIC,
                        content=record["content"],
                        relevance_score=similarity,
                        created_at=record["created_at"],
                    ))

        # Sort by similarity
        results.sort(key=lambda x: x.relevance_score, reverse=True)

        return results[:top_k]

    def _cosine_similarity(self, vec1: list[float], vec2: list[float]) -> float:
        """Calculate cosine similarity between two vectors"""
        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        magnitude1 = sum(a * a for a in vec1) ** 0.5
        magnitude2 = sum(b * b for b in vec2) ** 0.5

        if magnitude1 == 0 or magnitude2 == 0:
            return 0.0

        return dot_product / (magnitude1 * magnitude2)

    async def _rerank_results(
        self,
        results: list[MemorySearchResult],
        query: str,
    ) -> list[MemorySearchResult]:
        """Rerank results using cross-encoder"""
        await asyncio.sleep(0)
        query_lower = query.lower()

        for result in results:
            # Simple reranking based on keyword matches
            content_lower = result.content.lower()

            # Exact match bonus
            if query_lower in content_lower:
                result.relevance_score = min(result.relevance_score * 1.2, 1.0)

            # Partial match bonus
            query_words = query_lower.split()
            matches = sum(1 for word in query_words if word in content_lower)
            if matches > 0:
                result.relevance_score = min(result.relevance_score * (1 + 0.1 * matches), 1.0)

        results.sort(key=lambda x: x.relevance_score, reverse=True)

        return results

    async def _symbolic_lookup(
        self,
        query: str,
        memory_types: list[MemoryType] | None,
        tenant_id: str,
    ) -> list[MemorySearchResult]:
        """Perform keyword-based symbolic lookup"""
        await asyncio.sleep(0)
        results = []

        for memory_type in (memory_types or [MemoryType.SEMANTIC]):
            store = self.stores.get(memory_type, {})

            for memory_id, record in store.items():
                if record.get("tenant_id") != tenant_id:
                    continue

                # Simple keyword matching
                content_lower = record["content"].lower()
                if query in content_lower:
                    results.append(MemorySearchResult(
                        memory_id=memory_id,
                        memory_type=memory_type,
                        content=record["content"],
                        relevance_score=0.5,  # Symbolic results get fixed score
                        created_at=record["created_at"],
                    ))

        return results

    def _merge_results(
        self,
        vector_results: list[MemorySearchResult],
        symbolic_results: list[MemorySearchResult],
        weight_vector: float = 0.7,
        weight_symbolic: float = 0.3,
    ) -> list[MemorySearchResult]:
        """Merge vector and symbolic results"""
        # Combine results, avoiding duplicates
        merged = {}

        for result in vector_results:
            result.vector_score = result.relevance_score
            result.symbolic_score = 0.0
            result.combined_score = min(result.relevance_score * weight_vector, 1.0)
            merged[result.memory_id] = result

        for result in symbolic_results:
            if result.memory_id in merged:
                # Update existing
                merged[result.memory_id].symbolic_score = result.relevance_score
                vector_score = merged[result.memory_id].vector_score
                if vector_score is None:
                    vector_score = 0.0
                merged[result.memory_id].combined_score = (
                    vector_score * weight_vector +
                    result.relevance_score * weight_symbolic
                )
                merged[result.memory_id].combined_score = min(merged[result.memory_id].combined_score, 1.0)
            else:
                result.vector_score = 0.0
                result.symbolic_score = result.relevance_score
                result.combined_score = min(result.relevance_score * weight_symbolic, 1.0)
                merged[result.memory_id] = result

        # Sort by combined score
        results = list(merged.values())
        results.sort(key=lambda x: x.combined_score, reverse=True)

        return results

    def _calculate_recency_weight(self, result: MemorySearchResult) -> float:
        """Calculate recency weighting factor"""
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        age_days = (now - result.created_at).total_seconds() / 86400

        # Exponential decay with half-life of 7 days
        import math
        return math.exp(-0.1 * age_days)

    def _combine_scores(
        self,
        relevance: float,
        recency: float,
        relevance_weight: float = 0.7,
        recency_weight: float = 0.3,
    ) -> float:
        """Combine relevance and recency scores"""
        return min(relevance * relevance_weight + recency * recency_weight, 1.0)

    def _apply_filters(
        self,
        results: list[MemorySearchResult],
        tenant_id: str,
        user_id: str | None,
    ) -> list[MemorySearchResult]:
        """Apply tenant and privacy filters"""
        filtered = []

        for result in results:
            record = self._get_record(result.memory_id, result.memory_type)
            if not record:
                continue

            # Tenant filter
            if record.get("tenant_id") != tenant_id:
                continue

            # Privacy filter - check access level
            access_level = record.get("metadata", {}).get("access_level", "private")

            if access_level == "private" and user_id != record.get("user_id"):
                continue

            filtered.append(result)

        return filtered

    async def _compress_context(
        self,
        results: list[MemorySearchResult],
        max_tokens: int = 4000,
    ) -> list[MemorySearchResult]:
        """Compress context to fit token budget"""
        await asyncio.sleep(0)
        # Simple implementation - would use summarization in production
        total_chars = sum(len(r.content) for r in results)
        target_chars = max_tokens * 4  # Rough estimate: 4 chars per token

        if total_chars > target_chars:
            # Keep top results, truncate content
            compressed = []
            chars_used = 0

            for result in results:
                available = target_chars - chars_used
                if available <= 0:
                    break

                truncated_content = result.content[:available]
                result.content = truncated_content
                chars_used += len(truncated_content)

                compressed.append(result)

            return compressed

        return results

    def _get_record(self, memory_id: str, memory_type: MemoryType) -> dict | None:
        """Get memory record by ID and type"""
        store = self.stores.get(memory_type, {})
        return store.get(memory_id)

    async def get_working_memory(
        self,
        tenant_id: str,
        session_id: str,
        key: str | None = None,
    ) -> list[dict[str, Any]]:
        """Get working memory entries for session"""
        await asyncio.sleep(0)
        store = self.stores.get(MemoryType.WORKING, {})
        results = []

        for record in store.values():
            if record.get("tenant_id") != tenant_id:
                continue
            if record.get("session_id") != session_id:
                continue

            if key and record.get("key") != key:
                continue

            results.append(record)

        return results

    async def store_working_memory(
        self,
        tenant_id: str,
        session_id: str,
        key: str,
        value: Any,
        ttl_seconds: int = 3600,
    ) -> str:
        """Store a working memory entry"""
        content = f"{key}: {str(value)}"

        return await self.store(
            memory_type=MemoryType.WORKING,
            content=content,
            tenant_id=tenant_id,
            session_id=session_id,
            metadata={
                "key": key,
                "value": value,
                "scope": "session",
                "ttl_seconds": ttl_seconds,
            },
            tags=[key],
        )

    async def clear_expired(self) -> int:
        """Clear expired memory entries"""
        await asyncio.sleep(0)
        cleared = 0
        now = datetime.now(timezone.utc).replace(tzinfo=None)

        for memory_type, config in self.config.items():
            ttl = config.get("ttl_seconds")
            if not ttl:
                continue

            store = self.stores.get(memory_type, {})
            expired_keys = []

            for memory_id, record in store.items():
                age = (now - record["created_at"]).total_seconds()
                if age > ttl:
                    expired_keys.append(memory_id)

            for key in expired_keys:
                del store[key]
                if key in self.vector_index:
                    del self.vector_index[key]
                cleared += 1

        logger.info(f"Cleared {cleared} expired memory entries")

        return cleared


# Global memory manager instance
memory_manager = MemoryManager()


__all__ = [
    "MemoryManager",
    "memory_manager",
]