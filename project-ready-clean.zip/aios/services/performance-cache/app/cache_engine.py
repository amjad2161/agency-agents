"""
AI-OS Semantic Cache & Speculative Execution Engine
Production-grade performance optimization with semantic caching and prediction
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class CacheStrategy(str, Enum):
    """Caching strategies"""
    LRU = "lru"  # Least Recently Used
    LFU = "lfu"  # Least Frequently Used
    SEMANTIC = "semantic"  # Semantic similarity matching
    TTL = "ttl"  # Time-based expiration
    HYBRID = "hybrid"  # Combined strategy


class PredictionType(str, Enum):
    """Speculative execution prediction types"""
    NEXT_TOKEN = "next_token"
    NEXT_ACTION = "next_action"
    NEXT_QUERY = "next_query"
    RESPONSE_PREFIX = "response_prefix"
    CONTEXT_EXTENSION = "context_extension"


class ExecutionStrategy(str, Enum):
    """Execution strategies"""
    EAGER = "eager"  # Execute immediately
    LAZY = "lazy"  # Execute on demand
    SPECULATIVE = "speculative"  # Execute in background
    PARALLEL = "parallel"  # Execute in parallel


@dataclass
class CacheEntry:
    """Cache entry with semantic metadata"""
    entry_id: str
    key_hash: str
    key_semantic_hash: str
    value: Any
    query: str
    response: str
    created_at: datetime
    last_accessed: datetime
    access_count: int = 0
    hit_count: int = 0
    ttl_seconds: int = 3600
    language: str = "en"
    embeddings: list[float] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class SemanticQuery:
    """Semantic query representation"""
    query_id: str
    original_text: str
    normalized_text: str
    language: str
    intent: str
    entities: list[str] = field(default_factory=list)
    embeddings: list[float] = field(default_factory=list)
    timestamp: datetime = field(default_factory=datetime.utcnow)


@dataclass
class CacheHit:
    """Cache hit result"""
    is_hit: bool
    entry: CacheEntry | None = None
    similarity_score: float = 0.0
    match_type: str = "exact"  # exact, semantic, partial
    confidence: float = 0.0


@dataclass
class Prediction:
    """Speculative execution prediction"""
    prediction_id: str
    prediction_type: PredictionType
    predicted_value: Any
    confidence: float
    reasoning: str
    created_at: datetime
    ttl_seconds: int = 60
    execution_strategy: ExecutionStrategy = ExecutionStrategy.LAZY
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class SpeculativeTask:
    """Speculative execution task"""
    task_id: str
    prediction: Prediction
    input_context: dict[str, Any]
    status: str = "pending"
    result: Any = None
    error: str | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    execution_time_ms: float = 0.0


@dataclass
class CacheStats:
    """Cache statistics"""
    total_entries: int = 0
    hits: int = 0
    misses: int = 0
    evictions: int = 0
    hit_rate: float = 0.0
    avg_latency_ms: float = 0.0
    total_requests: int = 0
    semantic_hits: int = 0
    exact_hits: int = 0


@dataclass
class PredictionStats:
    """Prediction statistics"""
    total_predictions: int = 0
    correct_predictions: int = 0
    accuracy: float = 0.0
    avg_confidence: float = 0.0
    predictions_by_type: dict[str, int] = field(default_factory=dict)


class SemanticCache:
    """
    Semantic caching system with embedding-based similarity matching.
    Supports multiple languages including Arabic and Hebrew RTL.
    """

    def __init__(
        self,
        max_entries: int = 10000,
        default_ttl: int = 3600,
        similarity_threshold: float = 0.92,
        strategy: CacheStrategy = CacheStrategy.SEMANTIC,
    ):
        self.max_entries = max_entries
        self.default_ttl = default_ttl
        self.similarity_threshold = similarity_threshold
        self.strategy = strategy

        self.entries: dict[str, CacheEntry] = {}
        self.access_order: list[str] = []  # For LRU
        self.query_index: dict[str, str] = {}  # text -> entry_id

        self.stats = CacheStats()

        # Performance tracking
        self._latencies: list[float] = []
        self._max_latencies = 1000

    async def get(
        self,
        query: str,
        language: str = "en",
        intent: str | None = None,
    ) -> CacheHit:
        """Get entry from cache"""
        start_time = time.time()
        self.stats.total_requests += 1

        # Normalize query
        normalized = self._normalize_query(query, language)

        # Create key hash
        key_hash = self._hash_key(normalized)

        # Exact match
        if key_hash in self.entries:
            entry = self.entries[key_hash]
            entry.last_accessed = datetime.utcnow()
            entry.hit_count += 1
            entry.access_count += 1
            self.stats.hits += 1
            self.stats.exact_hits += 1

            self._update_latency(start_time)
            return CacheHit(
                is_hit=True,
                entry=entry,
                match_type="exact",
                similarity_score=1.0,
                confidence=1.0,
            )

        # Semantic match (for SEMANTIC and HYBRID strategies)
        if self.strategy in [CacheStrategy.SEMANTIC, CacheStrategy.HYBRID]:
            semantic_hit = await self._find_semantic_match(normalized, language)
            if semantic_hit:
                self.stats.hits += 1
                self.stats.semantic_hits += 1

                self._update_latency(start_time)
                return semantic_hit

        # Partial match
        partial_hit = await self._find_partial_match(normalized)
        if partial_hit:
            self.stats.hits += 1
            self._update_latency(start_time)
            return partial_hit

        # Cache miss
        self.stats.misses += 1
        self._update_latency(start_time)
        return CacheHit(is_hit=False)

    async def put(
        self,
        query: str,
        response: str,
        language: str = "en",
        intent: str | None = None,
        ttl_seconds: int | None = None,
        embeddings: list[float] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> CacheEntry:
        """Put entry in cache"""
        normalized = self._normalize_query(query, language)
        key_hash = self._hash_key(normalized)

        # Check if entry exists
        if key_hash in self.entries:
            entry = self.entries[key_hash]
            entry.value = response
            entry.response = response
            entry.last_accessed = datetime.utcnow()
            entry.access_count += 1
            return entry

        # Evict if necessary
        if len(self.entries) >= self.max_entries:
            await self._evict()

        # Create new entry
        entry_id = hashlib.md5(f"{key_hash}_{time.time()}".encode()).hexdigest()[:16]
        entry = CacheEntry(
            entry_id=entry_id,
            key_hash=key_hash,
            key_semantic_hash=key_hash,  # Simplified
            value=response,
            query=query,
            response=response,
            created_at=datetime.utcnow(),
            last_accessed=datetime.utcnow(),
            ttl_seconds=ttl_seconds or self.default_ttl,
            language=language,
            embeddings=embeddings or [],
            metadata=metadata or {},
        )

        self.entries[key_hash] = entry
        self.query_index[normalized] = entry_id
        self.access_order.append(key_hash)
        self.stats.total_entries += 1

        return entry

    async def _find_semantic_match(
        self,
        normalized_query: str,
        language: str,
    ) -> CacheHit | None:
        """Find semantically similar entry using embeddings"""
        # Simplified semantic matching
        # In production, would use vector similarity (cosine, dot product)

        query_words = set(normalized_query.lower().split())
        best_match = None
        best_score = 0.0

        for key_hash, entry in self.entries.items():
            if entry.language != language:
                continue

            # Skip if expired
            age = (datetime.utcnow() - entry.created_at).total_seconds()
            if age > entry.ttl_seconds:
                continue

            # Simple word overlap scoring
            entry_words = set(entry.query.lower().split())
            if not entry_words:
                continue

            # Jaccard similarity
            intersection = query_words & entry_words
            union = query_words | entry_words
            score = len(intersection) / len(union) if union else 0

            if score > best_score and score >= self.similarity_threshold:
                best_score = score
                best_match = entry

        if best_match:
            best_match.last_accessed = datetime.utcnow()
            best_match.hit_count += 1
            best_match.access_count += 1

            return CacheHit(
                is_hit=True,
                entry=best_match,
                similarity_score=best_score,
                match_type="semantic",
                confidence=best_score,
            )

        return None

    async def _find_partial_match(
        self,
        normalized_query: str,
    ) -> CacheHit | None:
        """Find partial match (substring)"""
        query_lower = normalized_query.lower()

        for key_hash, entry in self.entries.items():
            entry_lower = entry.query.lower()
            if query_lower in entry_lower or entry_lower in query_lower:
                # Check length ratio
                if len(entry.query) > 5 and len(normalized_query) > 5:
                    ratio = min(len(entry.query), len(normalized_query)) / max(
                        len(entry.query), len(normalized_query)
                    )
                    if ratio >= 0.6:
                        entry.last_accessed = datetime.utcnow()
                        entry.hit_count += 1
                        entry.access_count += 1

                        return CacheHit(
                            is_hit=True,
                            entry=entry,
                            similarity_score=ratio,
                            match_type="partial",
                            confidence=ratio * 0.8,
                        )

        return None

    async def _evict(self):
        """Evict entries based on strategy"""
        if not self.entries:
            return

        if self.strategy == CacheStrategy.LRU:
            # Evict least recently used
            while len(self.entries) >= self.max_entries and self.access_order:
                key = self.access_order.pop(0)
                if key in self.entries:
                    del self.entries[key]
                    self.stats.evictions += 1

        elif self.strategy == CacheStrategy.LFU:
            # Evict least frequently used
            entries_by_freq = sorted(
                self.entries.values(),
                key=lambda e: e.access_count
            )
            if entries_by_freq:
                entry_to_evict = entries_by_freq[0]
                key_to_evict = entry_to_evict.key_hash
                del self.entries[key_to_evict]
                self.stats.evictions += 1

        elif self.strategy == CacheStrategy.TTL:
            # Evict expired entries
            now = datetime.utcnow()
            expired = [
                key for key, entry in self.entries.items()
                if (now - entry.created_at).total_seconds() > entry.ttl_seconds
            ]
            for key in expired[:10]:
                del self.entries[key]
                self.stats.evictions += 1

        else:
            # HYBRID: Combination of LRU and TTL
            now = datetime.utcnow()
            expired = [
                key for key, entry in self.entries.items()
                if (now - entry.created_at).total_seconds() > entry.ttl_seconds
            ]
            for key in expired:
                del self.entries[key]
                self.stats.evictions += 1

            while len(self.entries) >= self.max_entries and self.access_order:
                key = self.access_order.pop(0)
                if key in self.entries:
                    del self.entries[key]
                    self.stats.evictions += 1

    async def invalidate(
        self,
        query: str | None = None,
        pattern: str | None = None,
    ):
        """Invalidate cache entries"""
        if query:
            normalized = self._normalize_query(query, "en")
            key_hash = self._hash_key(normalized)
            if key_hash in self.entries:
                del self.entries[key_hash]

        if pattern:
            import re
            try:
                regex = re.compile(pattern)
                to_delete = [
                    key for key, entry in self.entries.items()
                    if regex.search(entry.query)
                ]
                for key in to_delete:
                    del self.entries[key]
            except re.error:
                pass

    async def cleanup_expired(self):
        """Remove all expired entries"""
        now = datetime.utcnow()
        expired = [
            key for key, entry in self.entries.items()
            if (now - entry.created_at).total_seconds() > entry.ttl_seconds
        ]
        for key in expired:
            del self.entries[key]
        return len(expired)

    def _normalize_query(self, query: str, language: str = "en") -> str:
        """Normalize query for consistent caching"""
        # Basic normalization
        normalized = query.lower().strip()

        # Language-specific normalization
        if language == "ar":
            # Arabic normalization
            normalized = normalized.replace("َ", "")  # Fatha
            normalized = normalized.replace("ً", "")  # Tanwin fath
            normalized = normalized.replace("ُ", "")  # Damma
            normalized = normalized.replace("ٌ", "")  # Tanwin damm
            normalized = normalized.replace("ِ", "")  # Kasra
            normalized = normalized.replace("ٍ", "")  # Tanwin kasr
            normalized = normalized.replace("ْ", "")  # Sukun
            normalized = normalized.replace("ّ", "")  # Shadda
        elif language == "he":
            # Hebrew normalization
            normalized = normalized.replace("ׂ", "")  # Shin
            normalized = normalized.replace("׃", "")  # Sin
            normalized = normalized.replace("׀", "")  # Geresh
            normalized = normalized.replace("׳", "")  # Geresh
            normalized = normalized.replace("״", "")  # Gershayim

        # Remove extra whitespace
        normalized = " ".join(normalized.split())

        return normalized

    def _hash_key(self, normalized: str) -> str:
        """Create hash key for normalized query"""
        return hashlib.sha256(normalized.encode()).hexdigest()[:32]

    def _update_latency(self, start_time: float):
        """Update latency statistics"""
        latency_ms = (time.time() - start_time) * 1000
        self._latencies.append(latency_ms)
        if len(self._latencies) > self._max_latencies:
            self._latencies = self._latencies[-self._max_latencies:]

        if self._latencies:
            self.stats.avg_latency_ms = sum(self._latencies) / len(self._latencies)

    def get_stats(self) -> dict[str, Any]:
        """Get cache statistics"""
        total = self.stats.hits + self.stats.misses
        if total > 0:
            self.stats.hit_rate = self.stats.hits / total

        return {
            "total_entries": len(self.entries),
            "max_entries": self.max_entries,
            "total_requests": self.stats.total_requests,
            "hits": self.stats.hits,
            "misses": self.stats.misses,
            "hit_rate": self.stats.hit_rate,
            "exact_hits": self.stats.exact_hits,
            "semantic_hits": self.stats.semantic_hits,
            "evictions": self.stats.evictions,
            "avg_latency_ms": self.stats.avg_latency_ms,
            "strategy": self.strategy.value,
        }


class SpeculativeExecutor:
    """
    Speculative execution engine for AI-OS.
    Predicts and pre-executes likely operations.
    """

    def __init__(
        self,
        max_predictions: int = 100,
        confidence_threshold: float = 0.7,
        enable_pre_execution: bool = True,
    ):
        self.max_predictions = max_predictions
        self.confidence_threshold = confidence_threshold
        self.enable_pre_execution = enable_pre_execution

        self.predictions: dict[str, Prediction] = {}
        self.tasks: dict[str, SpeculativeTask] = {}
        self.history: list[dict[str, Any]] = []

        self.stats = PredictionStats()

        # Context tracking
        self.context_window: list[dict[str, Any]] = []
        self.max_context_window = 10

    async def predict(
        self,
        prediction_type: PredictionType,
        context: dict[str, Any],
        based_on: str | None = None,
    ) -> Prediction:
        """Generate prediction based on context"""
        prediction_id = hashlib.md5(
            f"{prediction_type.value}_{time.time()}".encode()
        ).hexdigest()[:16]

        predicted_value = None
        confidence = 0.5
        reasoning = ""

        # Simple prediction logic (in production would use ML)
        if prediction_type == PredictionType.NEXT_TOKEN:
            predicted_value, confidence, reasoning = await self._predict_next_token(context)
        elif prediction_type == PredictionType.NEXT_ACTION:
            predicted_value, confidence, reasoning = await self._predict_next_action(context)
        elif prediction_type == PredictionType.NEXT_QUERY:
            predicted_value, confidence, reasoning = await self._predict_next_query(context)
        elif prediction_type == PredictionType.RESPONSE_PREFIX:
            predicted_value, confidence, reasoning = await self._predict_response_prefix(context)

        prediction = Prediction(
            prediction_id=prediction_id,
            prediction_type=prediction_type,
            predicted_value=predicted_value,
            confidence=confidence,
            reasoning=reasoning,
            created_at=datetime.utcnow(),
            execution_strategy=ExecutionStrategy.LAZY if confidence < self.confidence_threshold else ExecutionStrategy.SPECULATIVE,
        )

        self.predictions[prediction_id] = prediction

        # Update stats
        self.stats.total_predictions += 1
        if prediction_type.value not in self.stats.predictions_by_type:
            self.stats.predictions_by_type[prediction_type.value] = 0
        self.stats.predictions_by_type[prediction_type.value] += 1

        return prediction

    async def _predict_next_token(
        self,
        context: dict[str, Any],
    ) -> tuple[Any, float, str]:
        """Predict next token"""
        prompt = context.get("prompt", "")
        tokens = prompt.split()

        if not tokens:
            return "hello", 0.5, "Default greeting"

        # Simple n-gram based prediction
        last_token = tokens[-1] if tokens else ""

        # Common patterns
        if last_token.endswith("?"):
            predicted = "I think" if context.get("language") != "ar" else "أعتقد أن"
            return predicted, 0.6, "Question prediction"
        elif last_token.endswith("."):
            predicted = "Additionally" if context.get("language") != "ar" else "بالإضافة"
            return predicted, 0.5, "Sentence continuation"

        return last_token, 0.5, "Token repetition"

    async def _predict_next_action(
        self,
        context: dict[str, Any],
    ) -> tuple[Any, float, str]:
        """Predict next action"""
        history = context.get("history", [])

        if not history:
            return "query_knowledge", 0.5, "Default first action"

        # Pattern detection
        actions = [h.get("action") for h in history if h.get("action")]
        if actions:
            if "search" in actions:
                return "refine_search", 0.7, "Search refinement pattern"
            elif "generate" in actions:
                return "improve_generation", 0.6, "Generation improvement pattern"

        return "analyze", 0.5, "Default analysis"

    async def _predict_next_query(
        self,
        context: dict[str, Any],
    ) -> tuple[Any, float, str]:
        """Predict next user query"""
        current_query = context.get("current_query", "")
        query_lower = current_query.lower()

        # Query patterns
        if "how" in query_lower:
            return "why", 0.4, "How-to question follow-up"
        elif "what" in query_lower:
            return "where", 0.4, "What question follow-up"
        elif any(word in query_lower for word in ["who", "who's"]):
            return "when", 0.4, "Who question follow-up"

        # Arabic patterns
        if any(word in query_lower for word in ["كيف", "ما", "من"]):
            return "متى", 0.4, "Arabic question follow-up"

        return "explain more", 0.3, "Default follow-up"

    async def _predict_response_prefix(
        self,
        context: dict[str, Any],
    ) -> tuple[Any, float, str]:
        """Predict response prefix"""
        language = context.get("language", "en")

        prefixes = {
            "en": "Based on the provided information",
            "ar": "بناءً على المعلومات المقدمة",
            "he": "בהתבסס על המידע שניתן",
        }

        return prefixes.get(language, prefixes["en"]), 0.6, "Language-appropriate prefix"

    async def execute_speculative(
        self,
        prediction: Prediction,
        context: dict[str, Any],
    ) -> SpeculativeTask:
        """Execute speculative task based on prediction"""
        task_id = hashlib.md5(
            f"{prediction.prediction_id}_{time.time()}".encode()
        ).hexdigest()[:16]

        task = SpeculativeTask(
            task_id=task_id,
            prediction=prediction,
            input_context=context,
            status="running",
            started_at=datetime.utcnow(),
        )

        self.tasks[task_id] = task

        try:
            # Simulate execution
            # In production, would actually execute the predicted operation
            if prediction.prediction_type == PredictionType.NEXT_TOKEN:
                await asyncio.sleep(0.01)  # Simulate work
                task.result = prediction.predicted_value
            elif prediction.prediction_type == PredictionType.NEXT_ACTION:
                await asyncio.sleep(0.02)
                task.result = {"action": prediction.predicted_value, "params": {}}
            elif prediction.prediction_type == PredictionType.NEXT_QUERY:
                await asyncio.sleep(0.01)
                task.result = prediction.predicted_value

            task.status = "completed"
            task.completed_at = datetime.utcnow()

            if task.started_at:
                task.execution_time_ms = (
                    task.completed_at - task.started_at
                ).total_seconds() * 1000

        except Exception as e:
            task.status = "failed"
            task.error = str(e)

        return task

    async def verify_prediction(
        self,
        prediction: Prediction,
        actual_value: Any,
    ) -> bool:
        """Verify prediction accuracy"""
        is_correct = prediction.predicted_value == actual_value

        if is_correct:
            self.stats.correct_predictions += 1

        if self.stats.total_predictions > 0:
            self.stats.accuracy = (
                self.stats.correct_predictions / self.stats.total_predictions
            )

        # Update confidence based on correctness
        if is_correct and prediction.confidence < 1.0:
            prediction.metadata["adjusted_confidence"] = min(
                prediction.confidence + 0.1, 1.0
            )

        # Record in history
        self.history.append({
            "prediction_id": prediction.prediction_id,
            "predicted": prediction.predicted_value,
            "actual": actual_value,
            "correct": is_correct,
            "timestamp": datetime.utcnow().isoformat(),
        })

        # Limit history
        if len(self.history) > 1000:
            self.history = self.history[-1000:]

        return is_correct

    def update_context(self, context_entry: dict[str, Any]):
        """Update context window for better predictions"""
        self.context_window.append(context_entry)
        if len(self.context_window) > self.max_context_window:
            self.context_window.pop(0)

    def get_stats(self) -> dict[str, Any]:
        """Get prediction statistics"""
        return {
            "total_predictions": self.stats.total_predictions,
            "correct_predictions": self.stats.correct_predictions,
            "accuracy": self.stats.accuracy,
            "active_predictions": len(self.predictions),
            "active_tasks": len(self.tasks),
            "predictions_by_type": self.stats.predictions_by_type,
        }


class PerformanceOptimizer:
    """
    Performance optimization orchestrator.
    Combines semantic caching with speculative execution.
    """

    def __init__(
        self,
        cache_config: dict[str, Any] | None = None,
        speculative_config: dict[str, Any] | None = None,
    ):
        cache_config = cache_config or {}
        speculative_config = speculative_config or {}

        self.cache = SemanticCache(
            max_entries=cache_config.get("max_entries", 10000),
            default_ttl=cache_config.get("default_ttl", 3600),
            similarity_threshold=cache_config.get("similarity_threshold", 0.92),
        )

        self.speculative = SpeculativeExecutor(
            max_predictions=cache_config.get("max_predictions", 100),
            confidence_threshold=speculative_config.get("confidence_threshold", 0.7),
        )

        self.enabled = True

        # Metrics
        self.metrics = {
            "total_requests": 0,
            "cache_hits": 0,
            "speculative_hits": 0,
            "latency_saved_ms": 0.0,
        }

    async def optimize_request(
        self,
        query: str,
        language: str = "en",
        intent: str | None = None,
    ) -> dict[str, Any]:
        """Optimize request using cache and prediction"""
        self.metrics["total_requests"] += 1

        result = {
            "from_cache": False,
            "from_speculative": False,
            "response": None,
            "cache_hit": None,
            "prediction": None,
            "latency_ms": 0.0,
        }

        start_time = time.time()

        # Check cache first
        cache_hit = await self.cache.get(query, language, intent)
        result["cache_hit"] = cache_hit

        if cache_hit.is_hit:
            result["from_cache"] = True
            result["response"] = cache_hit.entry.response
            self.metrics["cache_hits"] += 1
            result["latency_ms"] = (time.time() - start_time) * 1000

            # Update speculative context
            self.speculative.update_context({
                "query": query,
                "language": language,
                "from_cache": True,
            })

            return result

        # Generate speculative predictions
        if self.speculative.enable_pre_execution:
            context = {
                "prompt": query,
                "language": language,
                "history": self.speculative.context_window,
            }

            prediction = await self.speculative.predict(
                PredictionType.NEXT_ACTION,
                context,
            )

            result["prediction"] = prediction

            # Execute if confidence is high enough
            if prediction.confidence >= self.speculative.confidence_threshold:
                task = await self.speculative.execute_speculative(
                    prediction, context
                )
                if task.status == "completed":
                    result["from_speculative"] = True
                    result["speculative_result"] = task.result
                    self.metrics["speculative_hits"] += 1

        result["latency_ms"] = (time.time() - start_time) * 1000
        return result

    async def cache_response(
        self,
        query: str,
        response: str,
        language: str = "en",
        intent: str | None = None,
    ):
        """Cache response for future requests"""
        await self.cache.put(query, response, language, intent)

    async def run_cleanup(self):
        """Run periodic cleanup tasks"""
        await self.cache.cleanup_expired()

    def get_stats(self) -> dict[str, Any]:
        """Get comprehensive performance statistics"""
        return {
            "cache": self.cache.get_stats(),
            "speculative": self.speculative.get_stats(),
            "metrics": {
                **self.metrics,
                "cache_hit_rate": (
                    self.metrics["cache_hits"] / self.metrics["total_requests"]
                    if self.metrics["total_requests"] > 0 else 0
                ),
            },
        }


async def example():
    """Example performance optimization usage"""

    optimizer = PerformanceOptimizer()

    print("=" * 60)
    print("Semantic Cache & Speculative Execution Example")
    print("=" * 60)

    # Test cache operations
    print("\n[Test 1] Cache Operations")
    queries = [
        "Explain neural networks",
        "What is machine learning?",
        "How do transformers work?",
        "Explain neural networks",  # Duplicate - should hit cache
    ]

    for query in queries:
        result = await optimizer.optimize_request(query, "en")
        print(f"\nQuery: {query[:40]}...")
        print(f"  From Cache: {result['from_cache']}")
        print(f"  Match Type: {result['cache_hit'].match_type if result['cache_hit'] else 'N/A'}")
        print(f"  Similarity: {result['cache_hit'].similarity_score:.2f}" if result['cache_hit'] else "")

    # Cache some responses
    print("\n[Test 2] Caching Responses")
    await optimizer.cache_response(
        "What is deep learning?",
        "Deep learning is a subset of machine learning that uses neural networks with multiple layers.",
        "en"
    )
    print("Cached: What is deep learning?")

    await optimizer.cache_response(
        "ما هو التعلم العميق؟",
        "التعلم العميق هو فرع من فروع تعلم الآلة يستخدم الشبكات العصبية ذات الطبقات المتعددة.",
        "ar"
    )
    print("Cached: ما هو التعلم العميق؟ (Arabic)")

    # Test Arabic cache
    print("\n[Test 3] Arabic Cache Test")
    result = await optimizer.optimize_request("ما هو التعلم العميق؟", "ar")
    print(f"Query: ما هو التعلم العميق؟")
    print(f"  From Cache: {result['from_cache']}")

    # Test speculative execution
    print("\n[Test 4] Speculative Execution")
    context = {
        "prompt": "How does",
        "language": "en",
        "history": [
            {"action": "search", "query": "machine learning"},
            {"action": "generate", "content": "ML explanation"},
        ],
    }

    prediction = await optimizer.speculative.predict(
        PredictionType.NEXT_TOKEN,
        context
    )
    print(f"\nNext Token Prediction:")
    print(f"  Predicted: {prediction.predicted_value}")
    print(f"  Confidence: {prediction.confidence:.2f}")
    print(f"  Reasoning: {prediction.reasoning}")

    next_action = await optimizer.speculative.predict(
        PredictionType.NEXT_ACTION,
        context
    )
    print(f"\nNext Action Prediction:")
    print(f"  Predicted: {next_action.predicted_value}")
    print(f"  Confidence: {next_action.confidence:.2f}")

    # Verify prediction
    await optimizer.speculative.verify_prediction(prediction, "neural networks")
    print(f"\nPrediction Verified: {prediction.predicted_value} == neural networks")

    # Performance statistics
    print("\n" + "=" * 60)
    print("Performance Statistics")
    print("=" * 60)
    stats = optimizer.get_stats()
    for section, data in stats.items():
        print(f"\n{section}:")
        for key, value in data.items():
            if isinstance(value, float):
                print(f"  {key}: {value:.4f}")
            else:
                print(f"  {key}: {value}")


if __name__ == "__main__":
    asyncio.run(example())
