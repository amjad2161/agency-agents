"""
AI-OS Task Graph - DAG-based Execution Model
"""
from __future__ import annotations

import asyncio
import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable

logger = logging.getLogger(__name__)


def _utcnow() -> datetime:
    """Return a naive UTC timestamp for compatibility with existing graph fields."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


class NodeType(str, Enum):
    """Task graph node types"""
    PLAN = "plan"
    REASON = "reason"
    RETRIEVE_MEMORY = "retrieve_memory"
    RETRIEVE_KNOWLEDGE = "retrieve_knowledge"
    INVOKE_TOOL = "invoke_tool"
    VALIDATE = "validate"
    CRITIQUE = "critique"
    SYNTHESIZE = "synthesize"
    FINALIZE = "finalize"
    AGENT = "agent"
    CONDITION = "condition"
    LOOP = "loop"


class NodeStatus(str, Enum):
    """Task graph node status"""
    PENDING = "pending"
    READY = "ready"
    RUNNING = "running"
    BLOCKED = "blocked"
    FAILED = "failed"
    COMPLETED = "completed"
    SKIPPED = "skipped"


@dataclass
class TaskNode:
    """Node in task graph"""
    node_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    node_type: NodeType = NodeType.REASON
    label: str = ""
    description: str | None = None

    status: NodeStatus = NodeStatus.PENDING
    config: dict[str, Any] = field(default_factory=dict)

    input_mappings: dict[str, str] = field(default_factory=dict)
    output_mapping: str | None = None

    depends_on: list[str] = field(default_factory=list)
    retry_count: int = 0
    max_retries: int = 3
    timeout_seconds: int = 300

    agent_id: str | None = None
    tool_id: str | None = None

    result: Any = None
    error: str | None = None

    started_at: datetime | None = None
    completed_at: datetime | None = None

    metadata: dict[str, Any] = field(default_factory=dict)

    def can_retry(self) -> bool:
        """Check if node can be retried"""
        return self.retry_count < self.max_retries and self.status == NodeStatus.FAILED

    @property
    def execution_time_ms(self) -> int | None:
        """Calculate execution time in milliseconds"""
        if self.started_at and self.completed_at:
            return int((self.completed_at - self.started_at).total_seconds() * 1000)
        return None


@dataclass
class TaskEdge:
    """Edge connecting nodes in task graph"""
    source_node_id: str
    target_node_id: str
    edge_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    condition: str | None = None
    priority: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class TaskGraph:
    """Task execution graph (DAG)"""
    graph_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str | None = None

    nodes: list[TaskNode] = field(default_factory=list)
    edges: list[TaskEdge] = field(default_factory=list)

    entry_node_id: str | None = None
    exit_node_id: str | None = None

    variables: dict[str, Any] = field(default_factory=dict)
    config: dict[str, Any] = field(default_factory=dict)

    # Execution state
    current_node_id: str | None = None
    completed_nodes: list[str] = field(default_factory=list)

    def get_node(self, node_id: str) -> TaskNode | None:
        """Get node by ID"""
        for node in self.nodes:
            if node.node_id == node_id:
                return node
        return None

    def get_dependencies(self, node_id: str) -> list[TaskNode]:
        """Get all nodes that the given node depends on"""
        deps = []
        for edge in self.edges:
            if edge.target_node_id == node_id:
                if node := self.get_node(edge.source_node_id):
                    deps.append(node)
        return deps

    def get_dependents(self, node_id: str) -> list[TaskNode]:
        """Get all nodes that depend on the given node"""
        deps = []
        for edge in self.edges:
            if edge.source_node_id == node_id:
                if node := self.get_node(edge.target_node_id):
                    deps.append(node)
        return deps

    def topological_sort(self) -> list[TaskNode]:
        """Return nodes in topological order for execution."""
        in_degree = {n.node_id: 0 for n in self.nodes}
        for edge in self.edges:
            if edge.source_node_id not in in_degree or edge.target_node_id not in in_degree:
                raise ValueError("Task graph edge references an unknown node")
            in_degree[edge.target_node_id] += 1

        queue = [n for n in self.nodes if in_degree[n.node_id] == 0]
        sorted_nodes = []

        while queue:
            node = queue.pop(0)
            sorted_nodes.append(node)
            for dep in self.get_dependents(node.node_id):
                in_degree[dep.node_id] -= 1
                if in_degree[dep.node_id] == 0:
                    queue.append(dep)

        if len(sorted_nodes) != len(self.nodes):
            raise ValueError("Task graph contains a circular dependency")

        return sorted_nodes

    def get_ready_nodes(self) -> list[TaskNode]:
        """Get nodes that are ready to execute (all dependencies completed)"""
        ready = []
        for node in self.nodes:
            if node.status != NodeStatus.PENDING:
                continue
            deps = self.get_dependencies(node.node_id)
            if all(d.status == NodeStatus.COMPLETED for d in deps):
                ready.append(node)
        return ready

    def get_failed_dependencies(self, node_id: str) -> list[TaskNode]:
        """Get dependencies that have failed"""
        deps = self.get_dependencies(node_id)
        return [d for d in deps if d.status == NodeStatus.FAILED]

    def is_complete(self) -> bool:
        """Check if graph execution is complete"""
        return all(
            n.status in {NodeStatus.COMPLETED, NodeStatus.SKIPPED, NodeStatus.FAILED}
            for n in self.nodes
        )

    @property
    def progress(self) -> float:
        """Calculate execution progress as percentage"""
        if not self.nodes:
            return 0.0
        completed = sum(1 for n in self.nodes if n.status == NodeStatus.COMPLETED)
        return round((completed / len(self.nodes)) * 100, 2)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation"""
        return {
            "graph_id": self.graph_id,
            "name": self.name,
            "description": self.description,
            "nodes": [
                {
                    "node_id": n.node_id,
                    "node_type": n.node_type.value,
                    "label": n.label,
                    "status": n.status.value,
                    "result": n.result,
                    "error": n.error,
                    "started_at": n.started_at.isoformat() if n.started_at else None,
                    "completed_at": n.completed_at.isoformat() if n.completed_at else None,
                }
                for n in self.nodes
            ],
            "edges": [
                {
                    "edge_id": e.edge_id,
                    "source": e.source_node_id,
                    "target": e.target_node_id,
                    "condition": e.condition,
                }
                for e in self.edges
            ],
            "progress": self.progress,
            "current_node_id": self.current_node_id,
            "completed_nodes": self.completed_nodes,
        }


class TaskGraphExecutor:
    """
    Executes task graphs with proper node ordering and dependencies.
    """

    def __init__(
        self,
        orchestrator: Any,
        max_concurrent_nodes: int = 5,
        enable_parallel_execution: bool = True,
    ):
        self.orchestrator = orchestrator
        self.max_concurrent_nodes = max_concurrent_nodes
        self.enable_parallel_execution = enable_parallel_execution

        # Node type handlers
        self.node_handlers: dict[NodeType, Callable] = {
            NodeType.PLAN: self._handle_plan,
            NodeType.REASON: self._handle_reason,
            NodeType.RETRIEVE_MEMORY: self._handle_retrieve_memory,
            NodeType.RETRIEVE_KNOWLEDGE: self._handle_retrieve_knowledge,
            NodeType.INVOKE_TOOL: self._handle_invoke_tool,
            NodeType.VALIDATE: self._handle_validate,
            NodeType.CRITIQUE: self._handle_critique,
            NodeType.SYNTHESIZE: self._handle_synthesize,
            NodeType.FINALIZE: self._handle_finalize,
            NodeType.AGENT: self._handle_agent,
        }

    async def execute(self, task: dict[str, Any]) -> dict[str, Any]:
        """
        Execute a task graph.

        Args:
            task: Task dictionary containing execution_graph

        Returns:
            Execution result
        """
        graph = task.get("execution_graph")
        if not graph:
            raise ValueError("Task has no execution graph")

        logger.info(f"Executing task graph {graph.graph_id}")

        # Create execution context
        context = {
            "task_id": task["task_id"],
            "tenant_id": task["tenant_id"],
            "user_id": task.get("user_id"),
            "input_data": task.get("input_data", {}),
            "variables": dict(graph.variables),
            "node_results": {},
            "intermediate_outputs": {},
        }

        # Execute nodes in topological order
        sorted_nodes = graph.topological_sort()

        for node in sorted_nodes:
            if node.status == NodeStatus.SKIPPED:
                continue

            # Check if all dependencies are satisfied
            failed_deps = graph.get_failed_dependencies(node.node_id)
            if failed_deps:
                logger.warning(f"Node {node.node_id} has failed dependencies")
                node.status = NodeStatus.BLOCKED
                continue

            # Execute node
            try:
                result = await self._execute_node(node, context)
                node.result = result
                node.status = NodeStatus.COMPLETED
                node.completed_at = _utcnow()

                # Store result for dependent nodes
                context["node_results"][node.node_id] = result
                context["intermediate_outputs"][node.label] = result

                logger.info(f"Node {node.node_id} ({node.label}) completed")

            except Exception as e:
                logger.error(f"Node {node.node_id} failed: {e}")
                node.error = str(e)
                node.status = NodeStatus.FAILED
                node.completed_at = _utcnow()

                # Check if we should continue
                if node.config.get("critical", False):
                    raise

        # Gather final output
        output = self._gather_output(graph, context)

        return {
            "graph_id": graph.graph_id,
            "status": "completed" if graph.is_complete() else "partial",
            "output": output,
            "node_results": context["node_results"],
            "execution_time_ms": self._calculate_execution_time(graph),
        }

    async def _execute_node(self, node: TaskNode, context: dict[str, Any]) -> Any:
        """Execute a single node with timeout"""
        node.status = NodeStatus.RUNNING
        node.started_at = _utcnow()

        handler = self.node_handlers.get(node.node_type)
        if not handler:
            raise ValueError(f"No handler for node type {node.node_type}")

        try:
            # Execute with timeout
            result = await asyncio.wait_for(
                handler(node, context),
                timeout=node.timeout_seconds
            )
            return result

        except asyncio.TimeoutError:
            node.error = f"Node execution timed out after {node.timeout_seconds}s"
            node.status = NodeStatus.FAILED
            raise TimeoutError(node.error)

    async def _handle_plan(self, node: TaskNode, context: dict[str, Any]) -> dict[str, Any]:
        """Handle plan node - create execution plan"""
        await asyncio.sleep(0)
        # In production, would invoke planner agent
        return {
            "plan": "Execute nodes in sequence",
            "estimated_steps": len(context.get("node_results", {})) + 1,
        }

    async def _handle_reason(self, node: TaskNode, context: dict[str, Any]) -> dict[str, Any]:
        """Handle reason node - generate response/content"""
        await asyncio.sleep(0)
        # Get inputs from dependencies
        inputs = {}
        for dep_id in node.depends_on:
            if dep_result := context["node_results"].get(dep_id):
                inputs[dep_id] = dep_result

        # Generate response using model
        return {
            "reasoning": "Generated response based on context",
            "inputs_used": list(inputs.keys()),
        }

    async def _handle_retrieve_memory(self, node: TaskNode, context: dict[str, Any]) -> dict[str, Any]:
        """Handle memory retrieval node"""
        await asyncio.sleep(0)
        # In production, would call memory service
        return {
            "retrieved_memories": [],
            "relevance_scores": [],
        }

    async def _handle_retrieve_knowledge(self, node: TaskNode, context: dict[str, Any]) -> dict[str, Any]:
        """Handle knowledge retrieval node"""
        await asyncio.sleep(0)
        # In production, would call knowledge service with RAG
        return {
            "retrieved_documents": [],
            "citations": [],
        }

    async def _handle_invoke_tool(self, node: TaskNode, context: dict[str, Any]) -> dict[str, Any]:
        """Handle tool invocation node"""
        await asyncio.sleep(0)
        tool_id = node.tool_id or node.config.get("tool_id")

        if not tool_id:
            raise ValueError("No tool_id specified for INVOKE_TOOL node")

        # In production, would invoke tool via tool-runtime
        return {
            "tool_id": tool_id,
            "status": "executed",
            "result": {"items": []},
            "citations": [] if tool_id != "web_search" else [
                {
                    "title": "Web search placeholder citation",
                    "url": "https://example.com",
                }
            ],
        }

    async def _handle_validate(self, node: TaskNode, context: dict[str, Any]) -> dict[str, Any]:
        """Handle validation node"""
        await asyncio.sleep(0)
        # Validate previous outputs
        previous_nodes = list(context["node_results"].keys())

        return {
            "valid": True,
            "validated_nodes": previous_nodes,
        }

    async def _handle_critique(self, node: TaskNode, context: dict[str, Any]) -> dict[str, Any]:
        """Handle critique node - self-critique output"""
        await asyncio.sleep(0)
        return {
            "critique": "No issues identified",
            "suggestions": [],
        }

    async def _handle_synthesize(self, node: TaskNode, context: dict[str, Any]) -> dict[str, Any]:
        """Handle synthesis node - combine outputs"""
        await asyncio.sleep(0)
        return {
            "synthesized": True,
            "sources": list(context["node_results"].keys()),
        }

    async def _handle_finalize(self, node: TaskNode, context: dict[str, Any]) -> dict[str, Any]:
        """Handle finalize node - format output"""
        await asyncio.sleep(0)
        citations = []
        memory_hits = 0

        for result in context["node_results"].values():
            if isinstance(result, dict):
                citations.extend(result.get("citations", []))
                retrieved_memories = result.get("retrieved_memories", [])
                memory_hits += len(retrieved_memories)

        return {
            "finalized": True,
            "format": node.config.get("output_format", "text"),
            "citations": citations,
            "memory_hits": memory_hits,
        }

    async def _handle_agent(self, node: TaskNode, context: dict[str, Any]) -> dict[str, Any]:
        """Handle agent node - delegate to agent"""
        await asyncio.sleep(0)
        agent_id = node.agent_id or node.config.get("agent_id")

        if not agent_id:
            raise ValueError("No agent_id specified for AGENT node")

        return {
            "agent_id": agent_id,
            "status": "delegated",
        }

    def _gather_output(self, graph: TaskGraph, context: dict[str, Any]) -> dict[str, Any]:
        """Gather final output from graph execution"""
        # Find finalize node output
        finalize_node = None
        for node in graph.nodes:
            if node.node_type == NodeType.FINALIZE and node.status == NodeStatus.COMPLETED:
                finalize_node = node
                break

        if finalize_node and finalize_node.result:
            return finalize_node.result

        # Fall back to last completed node
        for node in reversed(graph.nodes):
            if node.status == NodeStatus.COMPLETED and node.result:
                return node.result

        return {"status": "completed", "message": "Task completed"}

    def _calculate_execution_time(self, graph: TaskGraph) -> int | None:
        """Calculate total execution time in milliseconds"""
        start_times = [n.started_at for n in graph.nodes if n.started_at]
        end_times = [n.completed_at for n in graph.nodes if n.completed_at]

        if not start_times or not end_times:
            return None

        start = min(start_times)
        end = max(end_times)

        return int((end - start).total_seconds() * 1000)


# Factory function to create graphs from task type
def create_graph_for_task_type(
    task_type: str,
    task_id: str,
    config: dict[str, Any] | None = None
) -> TaskGraph:
    """Create appropriate task graph based on task type"""

    templates = {
        "chat": [
            (NodeType.PLAN, "Plan response"),
            (NodeType.RETRIEVE_MEMORY, "Fetch context"),
            (NodeType.REASON, "Generate response"),
            (NodeType.CRITIQUE, "Self-critique"),
            (NodeType.FINALIZE, "Format output"),
        ],
        "research": [
            (NodeType.PLAN, "Plan research"),
            (NodeType.RETRIEVE_MEMORY, "Fetch prior context"),
            (NodeType.RETRIEVE_KNOWLEDGE, "Search knowledge"),
            (NodeType.INVOKE_TOOL, "Web search"),
            (NodeType.SYNTHESIZE, "Compile findings"),
            (NodeType.CRITIQUE, "Verify accuracy"),
            (NodeType.FINALIZE, "Format citations"),
        ],
        "code_generation": [
            (NodeType.PLAN, "Plan code"),
            (NodeType.RETRIEVE_MEMORY, "Fetch examples"),
            (NodeType.REASON, "Generate code"),
            (NodeType.VALIDATE, "Validate syntax"),
            (NodeType.INVOKE_TOOL, "Execute tests"),
            (NodeType.CRITIQUE, "Review code"),
            (NodeType.FINALIZE, "Format output"),
        ],
    }

    node_types = templates.get(task_type, [
        (NodeType.PLAN, "Plan"),
        (NodeType.REASON, "Execute"),
        (NodeType.FINALIZE, "Finalize"),
    ])

    nodes = []
    edges = []
    prev_node_id = None

    for i, (node_type, label) in enumerate(node_types):
        node_id = str(uuid.uuid4())
        node_config = dict(config or {})
        tool_id = None

        if node_type == NodeType.INVOKE_TOOL:
            tool_id = "web_search" if "web" in label.lower() else node_config.get("tool_id")

        nodes.append(TaskNode(
            node_id=node_id,
            node_type=node_type,
            label=label,
            config=node_config,
            tool_id=tool_id,
        ))

        if prev_node_id:
            edges.append(TaskEdge(
                source_node_id=prev_node_id,
                target_node_id=node_id,
            ))

        prev_node_id = node_id

    return TaskGraph(
        graph_id=str(uuid.uuid4()),
        name=f"{task_type}_{task_id}",
        nodes=nodes,
        edges=edges,
        entry_node_id=nodes[0].node_id if nodes else None,
        exit_node_id=nodes[-1].node_id if nodes else None,
        variables={"task_id": task_id, "task_type": task_type},
    )