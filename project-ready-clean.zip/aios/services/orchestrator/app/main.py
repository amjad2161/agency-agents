"""
AI-OS Orchestrator Service - Main Application
Task orchestration and DAG execution engine
"""

import logging
import asyncio
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from opentelemetry import trace
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

from .orchestrator import OrchestratorService
from .task_graph import TaskGraphExecutor
from .state_machine import TaskStateMachine

# Initialize tracer
tracer = trace.get_tracer(__name__)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler"""
    logger.info("Starting AI-OS Orchestrator Service")

    # Initialize services
    orchestrator = OrchestratorService()
    await orchestrator.initialize()

    app.state.orchestrator = orchestrator

    yield

    # Cleanup
    logger.info("Shutting down AI-OS Orchestrator Service")
    await orchestrator.shutdown()


# Create FastAPI application
app = FastAPI(
    title="AI-OS Orchestrator",
    description="Task orchestration and DAG execution engine",
    version="1.0.0",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Tracing
FastAPIInstrumentor.instrument_app(app)


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Global exception handler"""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "error": "internal_error",
            "message": str(exc),
            "path": str(request.url),
        }
    )


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "orchestrator",
        "version": "1.0.0",
        "timestamp": datetime.utcnow().isoformat(),
    }


@app.get("/health/ready")
async def readiness_check():
    """Readiness check - verify all dependencies"""
    orchestrator = app.state.orchestrator

    checks = {
        "database": await orchestrator.check_database(),
        "redis": await orchestrator.check_redis(),
        "agent_fabric": await orchestrator.check_agent_fabric(),
    }

    all_healthy = all(c["healthy"] for c in checks.values())

    return {
        "status": "ready" if all_healthy else "not_ready",
        "checks": checks,
        "timestamp": datetime.utcnow().isoformat(),
    }


@app.get("/api/v1/status")
async def get_status():
    """Get orchestrator status and metrics"""
    orchestrator = app.state.orchestrator

    return {
        "status": "running",
        "active_tasks": await orchestrator.get_active_task_count(),
        "queued_tasks": await orchestrator.get_queued_task_count(),
        "completed_tasks_today": await orchestrator.get_completed_today(),
        "failed_tasks_today": await orchestrator.get_failed_today(),
        "avg_execution_time_ms": await orchestrator.get_avg_execution_time(),
        "timestamp": datetime.utcnow().isoformat(),
    }


@app.post("/api/v1/tasks")
async def create_task(request: Request):
    """Create a new task for orchestration"""
    with tracer.start_as_current_span("create_task") as span:
        body = await request.json()
        orchestrator = app.state.orchestrator

        task_id = await orchestrator.create_task(
            task_type=body.get("task_type"),
            tenant_id=body.get("tenant_id"),
            user_id=body.get("user_id"),
            input_data=body.get("input_data", {}),
            priority=body.get("priority", "normal"),
            metadata=body.get("metadata", {}),
        )

        span.set_attribute("task_id", task_id)

        return {
            "task_id": task_id,
            "status": "queued",
            "created_at": datetime.utcnow().isoformat(),
        }


@app.get("/api/v1/tasks/{task_id}")
async def get_task(task_id: str):
    """Get task status and details"""
    orchestrator = app.state.orchestrator
    task = await orchestrator.get_task(task_id)

    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    return task


@app.post("/api/v1/tasks/{task_id}/execute")
async def execute_task(task_id: str):
    """Start task execution"""
    with tracer.start_as_current_span("execute_task") as span:
        span.set_attribute("task_id", task_id)

        orchestrator = app.state.orchestrator
        result = await orchestrator.execute_task(task_id)

        return {
            "task_id": task_id,
            "status": "running",
            "execution_id": result.get("execution_id"),
        }


@app.post("/api/v1/tasks/{task_id}/cancel")
async def cancel_task(task_id: str):
    """Cancel a running task"""
    orchestrator = app.state.orchestrator
    success = await orchestrator.cancel_task(task_id)

    if not success:
        raise HTTPException(status_code=400, detail="Task cannot be cancelled")

    return {"task_id": task_id, "status": "cancelled"}


@app.post("/api/v1/tasks/{task_id}/retry")
async def retry_task(task_id: str):
    """Retry a failed task"""
    orchestrator = app.state.orchestrator
    new_task_id = await orchestrator.retry_task(task_id)

    return {
        "original_task_id": task_id,
        "new_task_id": new_task_id,
        "status": "queued",
    }


@app.get("/api/v1/tasks/{task_id}/graph")
async def get_task_graph(task_id: str):
    """Get task execution graph"""
    orchestrator = app.state.orchestrator
    graph = await orchestrator.get_task_graph(task_id)

    if not graph:
        raise HTTPException(status_code=404, detail="Task graph not found")

    return graph


@app.post("/api/v1/tasks/{task_id}/approve")
async def approve_task(task_id: str, request: Request):
    """Approve a task requiring human approval"""
    body = await request.json()

    orchestrator = app.state.orchestrator
    result = await orchestrator.approve_task(
        task_id=task_id,
        approved_by=body.get("approved_by"),
        reason=body.get("reason"),
        conditions=body.get("conditions"),
    )

    return result


@app.get("/api/v1/graphs/{graph_id}")
async def get_graph(graph_id: str):
    """Get task graph by ID"""
    orchestrator = app.state.orchestrator
    graph = await orchestrator.get_graph(graph_id)

    if not graph:
        raise HTTPException(status_code=404, detail="Graph not found")

    return graph


@app.post("/api/v1/graphs/{graph_id}/execute")
async def execute_graph(graph_id: str):
    """Execute a task graph"""
    with tracer.start_as_current_span("execute_graph") as span:
        span.set_attribute("graph_id", graph_id)

        orchestrator = app.state.orchestrator
        executor = TaskGraphExecutor(orchestrator)
        result = await executor.execute_graph(graph_id)

        return result


@app.get("/api/v1/metrics")
async def get_metrics():
    """Get orchestrator metrics"""
    orchestrator = app.state.orchestrator

    return await orchestrator.get_metrics()


# WebSocket endpoint for real-time task updates
@app.websocket("/ws/tasks/{task_id}")
async def task_websocket(websocket, task_id: str):
    """WebSocket for real-time task updates"""
    await websocket.accept()

    orchestrator = app.state.orchestrator

    try:
        async for update in orchestrator.task_updates(task_id):
            await websocket.send_json(update)
    except Exception as e:
        logger.error(f"WebSocket error for task {task_id}: {e}")
    finally:
        await websocket.close()