"""
AI-OS Task State Machine - State Transitions and Validation
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Callable

logger = logging.getLogger(__name__)


class TaskStatus(str, Enum):
    """Task status states"""
    PENDING = "pending"       # Created, not yet queued
    QUEUED = "queued"         # In queue, waiting for execution
    RUNNING = "running"       # Currently executing
    BLOCKED = "blocked"       # Waiting for dependencies or resources
    COMPLETED = "completed"   # Successfully completed
    FAILED = "failed"         # Execution failed
    CANCELLED = "cancelled"    # Manually cancelled
    TIMED_OUT = "timed_out"    # Execution timed out


class TaskStateMachine:
    """
    State machine for task lifecycle management.
    Handles state transitions, validation, and side effects.
    """

    # Valid state transitions
    TRANSITIONS: dict[TaskStatus, list[TaskStatus]] = {
        TaskStatus.PENDING: [TaskStatus.QUEUED, TaskStatus.CANCELLED],
        TaskStatus.QUEUED: [TaskStatus.RUNNING, TaskStatus.BLOCKED, TaskStatus.CANCELLED],
        TaskStatus.RUNNING: [
            TaskStatus.COMPLETED,
            TaskStatus.FAILED,
            TaskStatus.BLOCKED,
            TaskStatus.CANCELLED,
            TaskStatus.TIMED_OUT,
        ],
        TaskStatus.BLOCKED: [TaskStatus.QUEUED, TaskStatus.RUNNING, TaskStatus.CANCELLED],
        TaskStatus.COMPLETED: [],  # Terminal state
        TaskStatus.FAILED: [TaskStatus.QUEUED],  # Can retry
        TaskStatus.CANCELLED: [],  # Terminal state
        TaskStatus.TIMED_OUT: [TaskStatus.QUEUED],  # Can retry
    }

    def __init__(self):
        self._state_history: dict[str, list[dict[str, Any]]] = {}

    def can_transition(self, from_state: TaskStatus, to_state: TaskStatus) -> bool:
        """Check if transition is valid"""
        return to_state in self.TRANSITIONS.get(from_state, [])

    def transition(
        self,
        task_id: str,
        from_state: TaskStatus,
        to_state: TaskStatus,
        metadata: dict[str, Any] | None = None,
    ) -> tuple[bool, str]:
        """
        Attempt state transition.

        Returns:
            tuple: (success, message)
        """
        # Validate transition
        if not self.can_transition(from_state, to_state):
            return False, f"Invalid transition from {from_state.value} to {to_state.value}"

        # Record transition
        self._record_transition(
            task_id=task_id,
            from_state=from_state,
            to_state=to_state,
            metadata=metadata,
        )

        logger.info(f"Task {task_id} transitioned from {from_state.value} to {to_state.value}")

        return True, "Transition successful"

    def _record_transition(
        self,
        task_id: str,
        from_state: TaskStatus,
        to_state: TaskStatus,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Record state transition in history"""
        if task_id not in self._state_history:
            self._state_history[task_id] = []

        self._state_history[task_id].append({
            "from_state": from_state.value,
            "to_state": to_state.value,
            "timestamp": datetime.utcnow().isoformat(),
            "metadata": metadata or {},
        })

    def get_history(self, task_id: str) -> list[dict[str, Any]]:
        """Get state transition history for task"""
        return self._state_history.get(task_id, [])

    def validate_task_state(self, task: dict[str, Any]) -> tuple[bool, str | None]:
        """
        Validate task state consistency.

        Returns:
            tuple: (is_valid, error_message)
        """
        status = TaskStatus(task.get("status", "pending"))

        # Check for orphaned running tasks
        if status == TaskStatus.RUNNING:
            started_at = task.get("started_at")
            if not started_at:
                return False, "Running task missing started_at timestamp"

            # Check timeout
            timeout = task.get("timeout_seconds", 300)
            if datetime.utcnow() - started_at > timedelta(seconds=timeout):
                return False, "Task has exceeded timeout"

        # Check for invalid completed state
        if status == TaskStatus.COMPLETED:
            if not task.get("completed_at"):
                return False, "Completed task missing completed_at timestamp"

        # Check retry consistency
        retry_count = task.get("retry_count", 0)
        max_retries = task.get("max_retries", 3)

        if retry_count > max_retries and status == TaskStatus.FAILED:
            return False, f"Task exceeded max retries ({max_retries})"

        return True, None

    def get_available_transitions(self, current_state: TaskStatus) -> list[TaskStatus]:
        """Get list of valid transitions from current state"""
        return self.TRANSITIONS.get(current_state, [])


class TaskStateHandler:
    """
    Handler for task state-specific logic and side effects.
    """

    def __init__(self):
        self._handlers: dict[TaskStatus, Callable] = {}

    def on_enter(self, status: TaskStatus, handler: Callable) -> None:
        """Register handler for entering a state"""
        self._handlers[status] = handler

    async def handle_state_change(
        self,
        task_id: str,
        old_status: TaskStatus,
        new_status: TaskStatus,
        task: dict[str, Any],
    ) -> None:
        """Handle state change with side effects"""

        # Execute state handler if registered
        if new_status in self._handlers:
            try:
                await self._handlers[new_status](task_id, task)
            except Exception as e:
                logger.error(f"State handler error for {new_status.value}: {e}")

        # Log state change
        logger.info(f"Task {task_id} state change: {old_status.value} -> {new_status.value}")

        # Emit events based on state
        await self._emit_state_events(task_id, old_status, new_status, task)

    async def _emit_state_events(
        self,
        task_id: str,
        old_status: TaskStatus,
        new_status: TaskStatus,
        task: dict[str, Any],
    ) -> None:
        """Emit events for state changes"""
        # Terminal states
        if new_status == TaskStatus.COMPLETED:
            logger.info(f"Task {task_id} completed successfully")
            # Would emit task.completed event here

        elif new_status == TaskStatus.FAILED:
            logger.warning(f"Task {task_id} failed: {task.get('error')}")
            # Would emit task.failed event here

        elif new_status == TaskStatus.TIMED_OUT:
            logger.warning(f"Task {task_id} timed out")
            # Would emit task.timeout event here

        # State changes requiring notification
        if new_status == TaskStatus.BLOCKED:
            logger.info(f"Task {task_id} is blocked: {task.get('block_reason')}")
            # Would emit task.blocked event here


# Default state handlers
async def handle_running_entry(task_id: str, task: dict[str, Any]) -> None:
    """Handle task entering running state"""
    task["started_at"] = datetime.utcnow()
    logger.debug(f"Task {task_id} started execution")


async def handle_completed_entry(task_id: str, task: dict[str, Any]) -> None:
    """Handle task entering completed state"""
    task["completed_at"] = datetime.utcnow()

    execution_time_ms = None
    if task.get("started_at"):
        execution_time_ms = int(
            (task["completed_at"] - task["started_at"]).total_seconds() * 1000
        )

    task["execution_time_ms"] = execution_time_ms
    logger.info(f"Task {task_id} completed in {execution_time_ms}ms")


async def handle_failed_entry(task_id: str, task: dict[str, Any]) -> None:
    """Handle task entering failed state"""
    task["failed_at"] = datetime.utcnow()

    if task.get("retry_count", 0) < task.get("max_retries", 3):
        logger.info(f"Task {task_id} eligible for retry")
    else:
        logger.warning(f"Task {task_id} exceeded max retries")


async def handle_blocked_entry(task_id: str, task: dict[str, Any]) -> None:
    """Handle task entering blocked state"""
    task["blocked_at"] = datetime.utcnow()
    logger.info(f"Task {task_id} is now blocked")


# Initialize default handlers
state_handler = TaskStateHandler()
state_handler.on_enter(TaskStatus.RUNNING, handle_running_entry)
state_handler.on_enter(TaskStatus.COMPLETED, handle_completed_entry)
state_handler.on_enter(TaskStatus.FAILED, handle_failed_entry)
state_handler.on_enter(TaskStatus.BLOCKED, handle_blocked_entry)