"""
AI-OS Orchestrator Service - Core Orchestration Logic
"""
from __future__ import annotations

import asyncio
from contextlib import suppress
import logging
import uuid
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Callable

from services.execution_engine.app.executor import execution_engine

from .task_graph import TaskGraph, TaskGraphExecutor, create_graph_for_task_type
from .state_machine import TaskStateMachine, TaskStatus

logger = logging.getLogger(__name__)


class AsyncTaskRecord(dict):
    """Dict-like task record with awaitable update for backward-compatible tests."""

    async def update(self, **kwargs):  # type: ignore[override]
        super().update(**kwargs)
        return self


class OrchestratorConfig:
    """Orchestrator configuration"""
    def __init__(
        self,
        max_concurrent_tasks: int = 100,
        task_timeout_seconds: int = 300,
        enable_auto_retry: bool = True,
        max_retry_attempts: int = 3,
        queue_poll_interval_ms: int = 100,
        enable_task_graph_caching: bool = True,
    ):
        self.max_concurrent_tasks = max_concurrent_tasks
        self.task_timeout_seconds = task_timeout_seconds
        self.enable_auto_retry = enable_auto_retry
        self.max_retry_attempts = max_retry_attempts
        self.queue_poll_interval_ms = queue_poll_interval_ms
        self.enable_task_graph_caching = enable_task_graph_caching


class OrchestratorService:
    """
    Core orchestration service for AI-OS.
    Handles task intake, planning, execution, and coordination.
    """

    def __init__(self, config: OrchestratorConfig | None = None):
        self.config = config or OrchestratorConfig()
        self.state_machine = TaskStateMachine()

        # Task storage
        self.tasks: dict[str, dict[str, Any]] = {}
        self._tasks = self.tasks
        self.task_queues: dict[str, asyncio.PriorityQueue] = {}
        self.task_events: dict[str, asyncio.Event] = {}

        # Task graph executor
        self.graph_executor = TaskGraphExecutor(self)

        # Agent coordination
        self.active_agents: dict[str, set[str]] = {}  # agent_id -> set of task_ids
        self.agent_queues: dict[str, asyncio.Queue] = {}

        # Dependencies
        self._redis = None
        self._database = None
        self._agent_fabric = None

        # Background tasks
        self._task_processor: asyncio.Task | None = None
        self._background_tasks: set[asyncio.Task[Any]] = set()
        self._running = False

    def _utcnow(self) -> datetime:
        """Return naive UTC timestamps compatible with existing task records."""
        return datetime.now(timezone.utc).replace(tzinfo=None)

    async def initialize(self) -> None:
        """Initialize orchestrator and dependencies"""
        await asyncio.sleep(0)
        logger.info("Initializing OrchestratorService")

        # Initialize dependencies (would connect to actual services in production)
        # self._redis = await Redis.connect(...)
        # self._database = await Database.connect(...)
        # self._agent_fabric = await AgentFabric.connect(...)

        # Start task processor
        self._running = True
        self._task_processor = asyncio.create_task(self._process_tasks())

        logger.info("OrchestratorService initialized")

    async def shutdown(self) -> None:
        """Shutdown orchestrator"""
        logger.info("Shutting down OrchestratorService")

        self._running = False

        if self._task_processor:
            self._task_processor.cancel()
            with suppress(asyncio.CancelledError):
                await self._task_processor
            logger.info("Task processor cancelled during shutdown")

        if self._background_tasks:
            for background_task in self._background_tasks:
                background_task.cancel()
            await asyncio.gather(*self._background_tasks, return_exceptions=True)
            self._background_tasks.clear()

        logger.info("OrchestratorService shutdown complete")

    # =========================================================================
    # Task Lifecycle Management
    # =========================================================================

    async def create_task(
        self,
        task_type: str,
        tenant_id: str,
        user_id: str | None = None,
        input_data: dict[str, Any] | None = None,
        priority: str = "normal",
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """
        Create a new task for orchestration.

        Args:
            task_type: Type of task (chat, research, code_generation, etc.)
            tenant_id: Tenant identifier
            user_id: Optional user identifier
            input_data: Task input parameters
            priority: Task priority (critical, high, normal, low, background)
            metadata: Additional task metadata

        Returns:
            task_id: Unique identifier for the created task
        """
        task_id = str(uuid.uuid4())

        task: AsyncTaskRecord = AsyncTaskRecord({
            "task_id": task_id,
            "task_type": task_type,
            "tenant_id": tenant_id,
            "user_id": user_id,
            "status": TaskStatus.PENDING.value,
            "priority": priority,
            "input_data": input_data or {},
            "metadata": metadata or {},
            "created_at": self._utcnow(),
            "updated_at": self._utcnow(),
            "retry_count": 0,
            "execution_graph": None,
        })

        self.tasks[task_id] = task

        # Create task graph based on task type
        graph = await self._create_task_graph(task)
        task["execution_graph"] = graph

        # Add to priority queue
        await self._enqueue_task(task)

        logger.info(f"Created task {task_id} of type {task_type}")

        return task_id

    async def execute_task(self, task_id: str) -> dict[str, Any]:
        """
        Execute a task using the task graph.

        Args:
            task_id: Task identifier

        Returns:
            Execution result
        """
        task = self.tasks.get(task_id)
        if not task:
            raise ValueError(f"Task {task_id} not found")

        if task["status"] not in {
            TaskStatus.PENDING.value,
            TaskStatus.QUEUED.value,
            TaskStatus.BLOCKED.value,
        }:
            raise ValueError(f"Task {task_id} is not in executable state")

        # Update status
        task["status"] = TaskStatus.RUNNING.value
        task["started_at"] = self._utcnow()

        # Create event for tracking
        self.task_events[task_id] = asyncio.Event()

        try:
            # Execute task graph
            result = await self.graph_executor.execute(task)
            output = result.get("output", {}) if isinstance(result, dict) else {}
            citations = output.get("citations", []) if isinstance(output, dict) else []
            response_metadata: dict[str, Any] = {}
            if isinstance(output, dict) and "memory_hits" in output:
                response_metadata["memory_hits"] = output["memory_hits"]

            # Update task with result
            task["output_data"] = result.get("output")
            task["status"] = TaskStatus.COMPLETED.value
            task["completed_at"] = self._utcnow()

            logger.info(f"Task {task_id} completed successfully")

            return {
                "execution_id": str(uuid.uuid4()),
                "status": "completed",
                "result": {
                    **result,
                    "citations": citations,
                },
                "metadata": response_metadata,
            }

        except Exception as e:
            logger.error(f"Task {task_id} execution failed: {e}")

            task["error"] = str(e)
            task["status"] = TaskStatus.FAILED.value

            # Handle retry
            if self.config.enable_auto_retry and task["retry_count"] < self.config.max_retry_attempts:
                task["retry_count"] += 1
                await self._requeue_task(task)
                return {
                    "execution_id": str(uuid.uuid4()),
                    "status": "retry_scheduled",
                    "retry_count": task["retry_count"],
                }

            return {
                "execution_id": str(uuid.uuid4()),
                "status": "failed",
                "error": str(e),
            }

        finally:
            # Signal completion
            if task_id in self.task_events:
                self.task_events[task_id].set()

    async def cancel_task(self, task_id: str) -> bool:
        """Cancel a running or queued task"""
        await asyncio.sleep(0)
        task = self.tasks.get(task_id)
        if not task:
            return False

        if task["status"] in {TaskStatus.COMPLETED.value, TaskStatus.CANCELLED.value}:
            return False

        task["status"] = TaskStatus.CANCELLED.value
        task["cancelled_at"] = self._utcnow()

        logger.info(f"Task {task_id} cancelled")

        return True

    async def retry_task(self, task_id: str) -> str:
        """Create a retry of a failed task"""
        original_task = self.tasks.get(task_id)
        if not original_task:
            raise ValueError(f"Task {task_id} not found")

        # Create new task with same parameters
        new_task_id = await self.create_task(
            task_type=original_task["task_type"],
            tenant_id=original_task["tenant_id"],
            user_id=original_task["user_id"],
            input_data=original_task["input_data"],
            priority=original_task["priority"],
            metadata={**original_task["metadata"], "original_task_id": task_id},
        )

        logger.info(f"Created retry task {new_task_id} for failed task {task_id}")

        return new_task_id

    async def request_approval(
        self,
        task_id: str,
        tenant_id: str,
        requested_by: str,
        risk_level: Any,
        action_description: str,
        affected_resources: list[dict[str, str]],
    ) -> str:
        """Forward approval requests to the execution engine."""
        return await execution_engine.request_approval(
            task_id=task_id,
            tenant_id=tenant_id,
            requested_by=requested_by,
            risk_level=risk_level,
            action_description=action_description,
            affected_resources=affected_resources,
        )

    async def process_approval(
        self,
        approval_id: str,
        decision: str,
        decided_by: str,
        reason: str | None = None,
        conditions: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Forward approval decisions to the execution engine."""
        return await execution_engine.process_approval(
            approval_id=approval_id,
            decision=decision,
            decided_by=decided_by,
            reason=reason,
            conditions=conditions,
        )

    # =========================================================================
    # Task Graph Management
    # =========================================================================

    async def _create_task_graph(self, task: dict[str, Any]) -> TaskGraph:
        """Create appropriate task graph based on task type"""
        await asyncio.sleep(0)
        return create_graph_for_task_type(
            task_type=task["task_type"],
            task_id=task["task_id"],
            config=task.get("metadata") or {},
        )

    async def get_task_graph(self, task_id: str) -> dict[str, Any] | None:
        """Get task execution graph"""
        await asyncio.sleep(0)
        task = self.tasks.get(task_id)
        if not task or not task.get("execution_graph"):
            return None

        return task["execution_graph"].to_dict()

    async def get_graph(self, graph_id: str) -> dict[str, Any] | None:
        """Get graph by ID"""
        await asyncio.sleep(0)
        for task in self.tasks.values():
            if task.get("execution_graph", {}).get("graph_id") == graph_id:
                return task["execution_graph"].to_dict()
        return None

    # =========================================================================
    # Task Queue Management
    # =========================================================================

    async def _enqueue_task(self, task: dict[str, Any]) -> None:
        """Add task to priority queue"""
        priority_map = {"critical": 0, "high": 1, "normal": 2, "low": 3, "background": 4}
        priority = priority_map.get(task["priority"], 2)

        queue_key = f"priority_{priority}"
        if queue_key not in self.task_queues:
            self.task_queues[queue_key] = asyncio.PriorityQueue()

        await self.task_queues[queue_key].put((priority, task["task_id"]))
        # Keep initial status as pending; queue placement is tracked separately.

    async def _requeue_task(self, task: dict[str, Any]) -> None:
        """Re-queue a task for retry"""
        task["status"] = TaskStatus.PENDING.value
        await self._enqueue_task(task)

    async def _process_tasks(self) -> None:
        """Background task processor"""
        while self._running:
            try:
                did_work = await self._dispatch_queued_tasks()

                # Always yield to avoid starving the event loop when queues are empty.
                if not did_work:
                    await asyncio.sleep(self.config.queue_poll_interval_ms / 1000)

            except Exception as e:
                logger.error(f"Error in task processor: {e}")
                await asyncio.sleep(1)

    async def _dispatch_queued_tasks(self) -> bool:
        """Dispatch ready queued tasks while respecting concurrency limits."""
        did_work = False
        for queue in self.task_queues.values():
            if queue.empty():
                continue

            if self._active_running_count() >= self.config.max_concurrent_tasks:
                await asyncio.sleep(self.config.queue_poll_interval_ms / 1000)
                continue

            try:
                _, task_id = queue.get_nowait()
            except asyncio.QueueEmpty:
                continue

            if self._schedule_queued_task(task_id):
                did_work = True

        return did_work

    def _active_running_count(self) -> int:
        """Count currently running tasks."""
        return sum(1 for task in self.tasks.values() if task["status"] == TaskStatus.RUNNING.value)

    def _schedule_queued_task(self, task_id: str) -> bool:
        """Schedule a queued task if it is still executable."""
        queued_task = self.tasks.get(task_id)
        if not queued_task or queued_task["status"] not in {
            TaskStatus.PENDING.value,
            TaskStatus.QUEUED.value,
            TaskStatus.BLOCKED.value,
        }:
            return False

        background_task = asyncio.create_task(self.execute_task(task_id))
        self._background_tasks.add(background_task)
        background_task.add_done_callback(self._background_tasks.discard)
        return True

    # =========================================================================
    # Agent Coordination
    # =========================================================================

    async def register_agent(self, agent_id: str, agent_type: str) -> None:
        """Register an agent with the orchestrator"""
        await asyncio.sleep(0)
        if agent_type not in self.active_agents:
            self.active_agents[agent_type] = set()
        self.active_agents[agent_type].add(agent_id)

        logger.info(f"Registered agent {agent_id} of type {agent_type}")

    async def unregister_agent(self, agent_id: str) -> None:
        """Unregister an agent"""
        await asyncio.sleep(0)
        for agents in self.active_agents.values():
            agents.discard(agent_id)

        logger.info(f"Unregistered agent {agent_id}")

    async def assign_task_to_agent(
        self,
        task_id: str,
        agent_type: str,
        node_id: str | None = None
    ) -> str | None:
        """Assign a task node to an available agent"""
        await asyncio.sleep(0)
        available_agents = self.active_agents.get(agent_type, set())
        if not available_agents:
            return None

        # Select first available agent (round-robin in production)
        agent_id = next(iter(available_agents))

        # Record assignment
        if agent_id not in [t.get("assigned_agent") for t in self.tasks.values()]:
            task = self.tasks.get(task_id)
            if task:
                task["assigned_agent"] = agent_id
                task["assigned_node"] = node_id

            return agent_id

        return None

    # =========================================================================
    # Status and Metrics
    # =========================================================================

    async def get_task(self, task_id: str) -> dict[str, Any] | None:
        """Get task details"""
        await asyncio.sleep(0)
        return self.tasks.get(task_id)

    async def get_active_task_count(self) -> int:
        """Get number of active (running) tasks"""
        await asyncio.sleep(0)
        return sum(1 for t in self.tasks.values() if t["status"] == TaskStatus.RUNNING.value)

    async def get_queued_task_count(self) -> int:
        """Get number of queued tasks"""
        await asyncio.sleep(0)
        return sum(q.qsize() for q in self.task_queues.values())

    async def get_completed_today(self) -> int:
        """Get completed task count for today"""
        await asyncio.sleep(0)
        today = self._utcnow().date()
        return sum(
            1 for t in self.tasks.values()
            if t.get("completed_at", datetime.min).date() == today
            and t["status"] == TaskStatus.COMPLETED.value
        )

    async def get_failed_today(self) -> int:
        """Get failed task count for today"""
        await asyncio.sleep(0)
        today = self._utcnow().date()
        return sum(
            1 for t in self.tasks.values()
            if t.get("updated_at", datetime.min).date() == today
            and t["status"] == TaskStatus.FAILED.value
        )

    async def get_avg_execution_time(self) -> float | None:
        """Get average task execution time in ms"""
        await asyncio.sleep(0)
        completed = [
            t for t in self.tasks.values()
            if t["status"] == TaskStatus.COMPLETED.value
            and t.get("started_at") and t.get("completed_at")
        ]

        if not completed:
            return None

        total_ms = sum(
            (t["completed_at"] - t["started_at"]).total_seconds() * 1000
            for t in completed
        )

        return total_ms / len(completed)

    async def get_metrics(self) -> dict[str, Any]:
        """Get orchestrator metrics"""
        return {
            "active_tasks": await self.get_active_task_count(),
            "queued_tasks": await self.get_queued_task_count(),
            "total_tasks": len(self.tasks),
            "completed_today": await self.get_completed_today(),
            "failed_today": await self.get_failed_today(),
            "avg_execution_time_ms": await self.get_avg_execution_time(),
            "registered_agents": {
                agent_type: len(agents)
                for agent_type, agents in self.active_agents.items()
            },
            "timestamp": self._utcnow().isoformat(),
        }

    # =========================================================================
    # Dependency Checks
    # =========================================================================

    async def check_database(self) -> dict[str, Any]:
        """Check database connectivity"""
        await asyncio.sleep(0)
        # In production, would ping database
        return {"healthy": True, "latency_ms": 5}

    async def check_redis(self) -> dict[str, Any]:
        """Check Redis connectivity"""
        await asyncio.sleep(0)
        # In production, would ping Redis
        return {"healthy": True, "latency_ms": 2}

    async def check_agent_fabric(self) -> dict[str, Any]:
        """Check agent fabric connectivity"""
        await asyncio.sleep(0)
        return {
            "healthy": True,
            "available_agents": len(self.active_agents),
        }

    # =========================================================================
    # Real-time Updates
    # =========================================================================

    async def task_updates(self, task_id: str):
        """Generate real-time task updates"""
        task = self.tasks.get(task_id)
        if not task:
            return

        last_status = None

        while True:
            current_task = self.tasks.get(task_id)
            if not current_task:
                break

            current_status = current_task["status"]

            if current_status != last_status:
                yield {
                    "task_id": task_id,
                    "status": current_status,
                    "progress": current_task.get("progress", 0),
                    "updated_at": self._utcnow().isoformat(),
                }
                last_status = current_status

            if current_status in {
                TaskStatus.COMPLETED.value,
                TaskStatus.FAILED.value,
                TaskStatus.CANCELLED.value,
            }:
                break

            await asyncio.sleep(0.5)

    # =========================================================================
    # Approval Handling
    # =========================================================================

    async def approve_task(
        self,
        task_id: str,
        approved_by: str,
        reason: str | None = None,
        conditions: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Handle task approval"""
        await asyncio.sleep(0)
        task = self.tasks.get(task_id)
        if not task:
            raise ValueError(f"Task {task_id} not found")

        # Store approval
        task["approval"] = {
            "approved_by": approved_by,
            "reason": reason,
            "conditions": conditions,
            "approved_at": self._utcnow().isoformat(),
        }
        task["status"] = TaskStatus.PENDING.value

        # Continue execution
        background_task = asyncio.create_task(self.execute_task(task_id))
        self._background_tasks.add(background_task)
        background_task.add_done_callback(self._background_tasks.discard)

        return {
            "task_id": task_id,
            "status": "approved",
            "approved_by": approved_by,
        }