from __future__ import annotations

import re
from typing import Any


class InjectionDetector:
    """Minimal encoding-focused detector used by the security tests."""

    _base64_pattern = re.compile(r"(?:[A-Za-z0-9+/]{8,}={0,2})")
    _hex_pattern = re.compile(r"(?:0x)?[0-9a-fA-F]{8,}")
    _escape_pattern = re.compile(r"(?:\\x[0-9a-fA-F]{2}|%[0-9a-fA-F]{2}|&#\d+;)")

    async def detect_encoding_attack(self, text: str) -> dict[str, Any]:
        encoding_detected = any(
            pattern.search(text)
            for pattern in (self._base64_pattern, self._hex_pattern, self._escape_pattern)
        )
        return {
            "encoding_detected": encoding_detected,
            "suspicious": encoding_detected,
        }