from __future__ import annotations

from pathlib import Path

from services._legacy_loader import export_legacy_module


globals().update(
    export_legacy_module(
        __name__,
        Path(__file__).resolve().parents[2] / "security-gateway" / "app" / "policy.py",
    )
)