"""
AI-OS Security Gateway - Policy, Injection Detection, Redaction
"""
from __future__ import annotations

import logging
import re
import uuid
import asyncio
from datetime import datetime, timezone
from enum import Enum
from typing import Any

from packages.schemas.src import (
    RiskPolicy,
    ExecutionRiskLevel,
)

logger = logging.getLogger(__name__)


def _utcnow() -> datetime:
    """Return a naive UTC timestamp for compatibility with existing audit payloads."""
    return datetime.now(timezone.utc).replace(tzinfo=None)

# Backward-compatible alias expected by existing integration tests and callers.
RiskLevel = ExecutionRiskLevel


class PromptInjectionPattern:
    """Pattern definitions for prompt injection detection"""

    # Direct injection attempts
    DIRECT_PATTERNS = [
        r"ignore\s+(?:(?:your|all)\s+)?(?:previous|all|above)\s+(instructions?|commands?|rules?)",
        r"(system|prompt|instruct):",
        r"<\|system\|>",
        r"\[\s*system\s*\]",
        r"{{SYS|BOT|ASSISTANT}}",
        r"\[INST\]",
        r"<\/INST\]",
        r"def\s+system\s*\(",
        r"you\s+are\s+now\s+(?:a\s+)?",
        r"forget\s+(?:everything|all|previous)",
        r"new\s+(?:system|prompt|instructions?)",
        r"override\s+(?:system|instructions?)",
        r"override\s*:\s*admin\s+mode",
        r"disregard\s+(?:previous|all)",
        r"you\s+(?:only|just)\s+have\s+to",
        r"show\s+me\s+your\s+system\s+prompt",
        r"reveal\s+(?:your|all)\s+(?:configuration|secrets?|instructions?)",
        r"what\s+is\s+your\s+(?:api\s+key|token|configuration)",
        r"what\s+instructions?\s+(?:were|are)\s+you\s+(?:given|using)",
    ]

    # Manipulation patterns
    MANIPULATION_PATTERNS = [
        r"(?:please|could you|would you|kindly)\s+(?:ignore|disregard)",
        r"(?:as an?)\s+(?:AI|language model)",
        r"(?:for educational|research) purposes?",
        r"(?:hypothetically|imagine|suppose)",
        r"(?:in the context of|in a fictional)",
        r"(?:jailbreak|bypass|circumvent)",
        r"(?:roleplay|act as|pretend to be)",
        r"pretend\s+you(?:'re|\s+are)",
        r"roleplay\s+as",
        r"(?:urgent|emergency|critical|immediate action required)",
        r"(?:as the ceo|admin override|security clearance)",
        r"(?:all user records|all transactions|all logs|everything)",
    ]

    # Encoding/obsfuscation
    ENCODING_PATTERNS = [
        r"base64",
        r"hex\s*:",
        r"\\x[0-9a-f]{2}",
        r"\bu\d{4}\b",  # Unicode escape
        r"&#\d+;",  # HTML entity
        r"%[0-9a-f]{2}",  # URL encoding
    ]

    # Special characters abuse
    SPECIAL_CHAR_PATTERNS = [
        r"[\x00-\x1f]",  # Control characters
        r"\x7f",  # DEL character
        r"[\ufeff]",  # BOM
    ]


class SecurityGateway:
    """
    Security gateway for policy enforcement, injection detection, and output sanitization.
    """

    def __init__(self):
        self.policies: dict[str, RiskPolicy] = {}
        self.audit_log: list[dict[str, Any]] = []

        # Compile patterns
        self.direct_patterns = [
            re.compile(p, re.IGNORECASE) for p in PromptInjectionPattern.DIRECT_PATTERNS
        ]
        self.manipulation_patterns = [
            re.compile(p, re.IGNORECASE) for p in PromptInjectionPattern.MANIPULATION_PATTERNS
        ]
        self.encoding_patterns = [
            re.compile(p, re.IGNORECASE) for p in PromptInjectionPattern.ENCODING_PATTERNS
        ]

        # Secret patterns for redaction
        self.secret_patterns = {
            "api_key": re.compile(r"api[_-]?key\s*[:=]\s*['\"]?([-a-z0-9_]{20,})['\"]?", re.IGNORECASE),
            "password": re.compile(r"(?:password|passwd|pwd)\s*[:=]\s*['\"]?([^\s'\"]{8,})['\"]?", re.IGNORECASE),
            "token": re.compile(r"(?:token|auth[_-]?token)\s*[:=]\s*['\"]?([-a-z0-9._]{20,})['\"]?", re.IGNORECASE),
            "secret": re.compile(r"(?:secret|private[_-]?key)\s*[:=]\s*['\"]?([-a-z0-9_/+=]{20,})['\"]?", re.IGNORECASE),
            "aws_access_key": re.compile(r"aws[_-]?access[_-]?key[_-]?id\s*[:=]\s*['\"]?([A-Z0-9]{20,})['\"]?", re.IGNORECASE),
            "aws_secret_key": re.compile(r"aws[_-]?secret[_-]?access[_-]?key\s*[:=]\s*['\"]?([A-Z0-9]{20,})['\"]?", re.IGNORECASE),
        }

        # Allowlist for external requests
        self.domain_allowlist = {
            "api.openai.com",
            "api.anthropic.com",
            "api.google.com",
            "api.github.com",
        }

    def register_policy(self, policy: RiskPolicy) -> None:
        """Register a risk policy"""
        self.policies[policy.policy_id] = policy
        logger.info(f"Registered policy: {policy.policy_id}")

    def _record_keyword_findings(self, text_lower: str, findings: list[dict[str, Any]]) -> tuple[float, bool, bool]:
        """Record keyword-driven prompt-injection findings."""
        risk_score = 0.0
        urgency_detected = False
        bulk_extraction_suspected = False

        keyword_hits = [
            "ignore your previous instructions",
            "ignore previous instructions",
            "system prompt",
            "what instructions were you given",
            "pretend you're",
            "roleplay as",
            "act as if",
        ]
        if any(hit in text_lower for hit in keyword_hits):
            risk_score += 0.45
            findings.append({"type": "keyword_jailbreak", "severity": "high"})

        urgency_terms = ["urgent", "emergency", "critical", "immediate"]
        if any(word in text_lower for word in urgency_terms):
            urgency_detected = True
            risk_score += 0.35
            findings.append({"type": "urgency_manipulation", "severity": "medium"})

        bulk_terms = ["all user records", "all transactions", "all logs", "everything"]
        if any(phrase in text_lower for phrase in bulk_terms):
            bulk_extraction_suspected = True
            risk_score += 0.55
            findings.append({"type": "bulk_extraction", "severity": "high"})

        return risk_score, urgency_detected, bulk_extraction_suspected

    def _record_context_findings(self, context: dict[str, Any], findings: list[dict[str, Any]]) -> tuple[float, bool, bool]:
        """Record context-specific injection and access findings."""
        risk_score = 0.0
        context_checked = False
        cross_tenant_access = False

        if context.get("requesting_access_to") and context.get("requesting_access_to") != context.get("tenant_id"):
            cross_tenant_access = True
            risk_score += 0.9
            findings.append({"type": "cross_tenant_access", "severity": "critical"})

        retrieved_context = context.get("retrieved_context")
        if isinstance(retrieved_context, str):
            context_checked = True
            ctx = retrieved_context.lower()
            markers = [
                "ignore",
                "reveal secrets",
                "override",
                "new instruction",
                "disregard",
                "system prompt",
                "jailbreak",
            ]
            if any(marker in ctx for marker in markers):
                findings.append({"type": "indirect_context_injection", "severity": "high"})
                risk_score += 0.45

        return risk_score, context_checked, cross_tenant_access

    def _scan_compiled_patterns(
        self,
        text: str,
        patterns: list[re.Pattern[str]],
        finding_type: str,
        severity: str,
        score_delta: float,
        limit_matches: bool = False,
    ) -> tuple[list[dict[str, Any]], float]:
        """Scan text with compiled regex patterns and return findings plus score contribution."""
        findings: list[dict[str, Any]] = []
        risk_score = 0.0

        for pattern in patterns:
            matches = pattern.findall(text)
            if not matches:
                continue
            findings.append({
                "type": finding_type,
                "pattern": pattern.pattern,
                "matches": matches[:5] if limit_matches else matches,
                "severity": severity,
            })
            risk_score += score_delta

        return findings, risk_score

    def _severity_for_score(self, risk_score: float) -> str:
        """Translate a numeric risk score into a severity label."""
        if risk_score >= 0.7:
            return "critical"
        if risk_score >= 0.5:
            return "high"
        if risk_score >= 0.3:
            return "medium"
        if risk_score >= 0.1:
            return "low"
        return "none"

    async def scan_prompt_injection(
        self,
        text: str,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Scan text for prompt injection attempts.

        Returns:
            scan_result: Detection result with severity and matched patterns
        """
        await asyncio.sleep(0)
        findings: list[dict[str, Any]] = []
        risk_score = 0.0
        context = context or {}

        text_lower = text.lower()

        keyword_score, urgency_detected, bulk_extraction_suspected = self._record_keyword_findings(text_lower, findings)
        context_score, context_checked, cross_tenant_access = self._record_context_findings(context, findings)
        direct_findings, direct_score = self._scan_compiled_patterns(text, self.direct_patterns, "direct_injection", "high", 0.4)
        manipulation_findings, manipulation_score = self._scan_compiled_patterns(text, self.manipulation_patterns, "manipulation", "medium", 0.25)
        encoding_findings, encoding_score = self._scan_compiled_patterns(text, self.encoding_patterns, "encoding", "medium", 0.3, limit_matches=True)

        findings.extend(direct_findings)
        findings.extend(manipulation_findings)
        findings.extend(encoding_findings)
        risk_score += keyword_score + context_score + direct_score + manipulation_score + encoding_score
        severity = self._severity_for_score(risk_score)

        result = {
            "detected": len(findings) > 0,
            "severity": severity,
            "risk_score": min(risk_score, 1.0),
            "findings": findings,
            "context_checked": context_checked,
            "urgency_detected": urgency_detected,
            "bulk_extraction_suspected": bulk_extraction_suspected,
            "cross_tenant_access": cross_tenant_access,
            "scanned_at": _utcnow().isoformat(),
        }

        # Log scan
        self._log_audit(
            action="prompt_injection_scan",
            details={"text_length": len(text), "result": result},
            context=context,
        )

        return result

    async def scan_tool_output(
        self,
        output: Any,
        tool_id: str,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Scan tool output for malicious content.

        Returns:
            scan_result: Detection result
        """
        await asyncio.sleep(0)
        findings = []
        output_str = str(output)
        redacted = False
        pii_detected = False

        # Check for malicious URLs
        url_pattern = re.compile(r"https?://[^\s]+")
        urls = url_pattern.findall(output_str)

        for url in urls:
            domain = self._extract_domain(url)
            if domain and domain not in self.domain_allowlist:
                findings.append({
                    "type": "unauthorized_url",
                    "domain": domain,
                    "url": url,
                })

        # Check for embedded executables
        if "ELF" in output_str or "MZ" in output_str:
            findings.append({
                "type": "executable_content",
                "severity": "high",
            })

        # Check for SQL injection patterns
        sql_patterns = [
            r"(?:union|select|insert|update|delete|drop)\s+",
            r"(?:'\s*or\s*'1'\s*=\s*'1)",
            r"--\s*$",
        ]
        for pattern in sql_patterns:
            if re.search(pattern, output_str, re.IGNORECASE):
                findings.append({
                    "type": "sql_injection_pattern",
                    "pattern": pattern,
                })

        pii_patterns = [
            r"\b\d{3}-\d{2}-\d{4}\b",
            r"\b(?:\d[ -]*?){13,16}\b",
        ]
        for pattern in pii_patterns:
            if re.search(pattern, output_str):
                pii_detected = True
                redacted = True
                findings.append({"type": "pii_detected", "pattern": pattern})
                break

        result = {
            "clean": len(findings) == 0,
            "safe": len(findings) == 0,
            "findings": findings,
            "pii_detected": pii_detected,
            "redacted": redacted,
            "scanned_at": _utcnow().isoformat(),
        }

        self._log_audit(
            action="tool_output_scan",
            details={"tool_id": tool_id, "result": result},
            context=context,
        )

        return result

    async def redact_secrets(self, text: str) -> str:
        """
        Redact secrets from text.

        Returns:
            redacted_text: Text with secrets replaced
        """
        await asyncio.sleep(0)
        redacted = text

        # Handle natural language secret disclosures.
        redacted = re.sub(r"(?i)(password\s+is\s+)(\S+)", r"\1[REDACTED_PASSWORD]", redacted)
        redacted = re.sub(r"(?i)(api\s*key\s+is\s+)(\S+)", r"\1[REDACTED_API_KEY]", redacted)
        redacted = re.sub(r"\bsk-[A-Za-z0-9_-]+\b", "[REDACTED_API_KEY]", redacted)

        for secret_type, pattern in self.secret_patterns.items():
            redacted = pattern.sub(f"[REDACTED_{secret_type.upper()}]", redacted)

        return redacted

    async def check_outbound_url(self, url: str) -> dict[str, Any]:
        """Check whether outbound URL is allowed."""
        allowed, reason = await self.validate_domain(url)
        risk_score = 0.05 if allowed else 0.9
        return {
            "allowed": allowed,
            "reason": reason,
            "risk_score": risk_score,
        }

    async def validate_domain(
        self,
        url: str,
        context: dict[str, Any] | None = None,
    ) -> tuple[bool, str | None]:
        """
        Validate if domain is allowed for external requests.

        Returns:
            (is_allowed, reason)
        """
        await asyncio.sleep(0)
        domain = self._extract_domain(url)

        if not domain:
            return False, "Invalid URL"

        if domain in self.domain_allowlist:
            return True, None

        # Check subdomain
        parts = domain.split(".")
        if len(parts) > 2:
            parent_domain = ".".join(parts[1:])
            if parent_domain in self.domain_allowlist:
                return True, None

        return False, f"Domain not in allowlist: {domain}"

    async def enforce_policy(
        self,
        tenant_id: str,
        action: str,
        risk_level: ExecutionRiskLevel,
        context: dict[str, Any] | None = None,
    ) -> tuple[bool, str | None]:
        """
        Enforce risk policies for an action.

        Returns:
            (allowed, reason)
        """
        await asyncio.sleep(0)

        # Get tenant policies
        tenant_policies = [
            p for p in self.policies.values()
            if p.tenant_id == tenant_id or p.tenant_id is None
        ]

        # Sort by priority
        tenant_policies.sort(key=lambda p: p.priority, reverse=True)

        for policy in tenant_policies:
            if not policy.is_active:
                continue

            # Check if action matches policy
            if policy.tool_ids and action not in policy.tool_ids:
                continue

            # Check risk level against policy
            if risk_level == policy.block_risk_level:
                self._log_audit(
                    action="policy_block",
                    details={
                        "tenant_id": tenant_id,
                        "action": action,
                        "risk_level": risk_level.value,
                        "policy_id": policy.policy_id,
                    },
                    context=context,
                )
                return False, f"Blocked by policy: {policy.name}"

        return True, None

    def _extract_domain(self, url: str) -> str | None:
        """Extract domain from URL"""
        match = re.search(r"https?://([^/]+)", url)
        return match.group(1) if match else None

    def _log_audit(
        self,
        action: str,
        details: dict[str, Any],
        context: dict[str, Any] | None = None,
    ) -> None:
        """Log audit event"""
        event = {
            "event_id": str(uuid.uuid4()),
            "action": action,
            "details": details,
            "tenant_id": context.get("tenant_id") if context else None,
            "user_id": context.get("user_id") if context else None,
            "timestamp": _utcnow().isoformat(),
        }

        self.audit_log.append(event)

        # Keep only last 10000 events
        if len(self.audit_log) > 10000:
            self.audit_log = self.audit_log[-10000:]

        logger.debug(f"Audit event: {action}")

    def get_audit_log(
        self,
        tenant_id: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Get audit log entries"""
        events = self.audit_log

        if tenant_id:
            events = [e for e in events if e.get("tenant_id") == tenant_id]

        return events[-limit:]


# Global security gateway
security_gateway = SecurityGateway()


__all__ = [
    "SecurityGateway",
    "security_gateway",
    "PromptInjectionPattern",
    "RiskLevel",
    "ExecutionRiskLevel",
]