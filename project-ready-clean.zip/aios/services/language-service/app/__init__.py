"""
AI-OS Language Service
Comprehensive Arabic & Hebrew Language Support
Supports RTL text, image generation, video generation, TTS, STT
"""
from .service import LanguageService
from .arabic.processor import ArabicProcessor
from .hebrew.processor import HebrewProcessor
from .shared.tokenizer import MultilingualTokenizer
from .shared.embedding import MultilingualEmbedding
from .rtl.alignment import RTLTextAlignment
from .rtl.font_manager import FontManager

__all__ = [
    "LanguageService",
    "ArabicProcessor",
    "HebrewProcessor",
    "MultilingualTokenizer",
    "MultilingualEmbedding",
    "RTLTextAlignment",
    "FontManager",
]
