"""
AI-OS Language Service
Arabic & Hebrew NLP with RTL Support for Text, Image, Video Generation
"""
from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class Language(str, Enum):
    """Supported languages for generation"""
    ARABIC = "ar"
    HEBREW = "he"
    ENGLISH = "en"
    FRENCH = "fr"
    SPANISH = "es"
    GERMAN = "de"
    CHINESE = "zh"
    JAPANESE = "ja"
    KOREAN = "ko"
    RUSSIAN = "ru"


class TextDirection(str, Enum):
    """Text direction"""
    LTR = "ltr"
    RTL = "rtl"
    AUTO = "auto"


class Dialect(str, Enum):
    """Arabic dialects"""
    MSA = "msa"  # Modern Standard Arabic
    EGYPTIAN = "egyptian"
    GULF = "gulf"
    LEVANTINE = "levantine"
    MAGHREBI = "maghrebi"


@dataclass
class LanguageConfig:
    """Language-specific configuration"""
    language: Language
    direction: TextDirection
    dialect: Dialect | None = None
    font_family: str = "Arial"
    font_size: int = 16
    text_align: str = "right"  # right for RTL, left for LTR
    tokenizer_class: str = "DefaultTokenizer"
    embedding_model: str = "multilingual-embedding"


@dataclass
class ProcessedText:
    """Processed text result"""
    original: str
    normalized: str
    language: Language
    tokens: list[str]
    entities: list[dict[str, Any]]
    sentiment: float
    morphology: dict[str, Any]
    embeddings: list[float]


@dataclass
class GeneratedContent:
    """Generated content specification"""
    text: str
    language: Language
    direction: TextDirection
    style: str  # formal, casual, poetic
    dialect: str | None
    prompt_enhancement: str  # Additional prompt for image/video
    font_config: dict[str, Any]
    tts_voice: str
    translation_key: str  # For UI localization


class ArabicProcessor:
    """Arabic language processing"""

    # Arabic character ranges
    ARABIC_CHARS = range(0x0600, 0x06FF)
    ARABIC_EXTENDED = range(0x0750, 0x077F)
    ARABIC_PRESENTATION = range(0xFB50, 0xFDFF)

    # Arabic diacritics (tashkeel)
    DIACRITICS = [
        '\u064B', '\u064C', '\u064D', '\u064E', '\u064F', '\u0650', '\u0651', '\u0652'
    ]

    # Arabic font mappings
    ARABIC_FONTS = {
        "formal": "Traditional Arabic",
        "casual": "Segoe UI",
        "modern": "Arial",
        "calligraphy": "Amiri",
        "heading": "Scheherazade New",
    }

    def __init__(self):
        self.name = "Arabic Processor"
        self.config = LanguageConfig(
            language=Language.ARABIC,
            direction=TextDirection.RTL,
            dialect=Dialect.MSA,
            text_align="right",
        )

    def normalize(self, text: str) -> str:
        """Normalize Arabic text"""
        # Remove diacritics
        for diacritic in self.DIACRITICS:
            text = text.replace(diacritic, "")

        # Normalize alef variants
        text = text.replace('\u0622', '\u0627')  # Alef with madda -> bare alef
        text = text.replace('\u0623', '\u0627')  # Alef with hamza above -> bare alef
        text = text.replace('\u0625', '\u0627')  # Alef with hamza below -> bare alef

        # Normalize taa marbuta
        text = text.replace('\u0629', '\u0647')  # Ta marbuta -> Ha

        # Normalize yeh
        text = text.replace('\u064A', '\u0649')  # Yeh with dots -> Yeh barree

        # Remove tatweel (kashida)
        text = text.replace('\u0640', '')

        # Normalize whitespace
        text = re.sub(r'\s+', ' ', text)
        text = text.strip()

        return text

    def analyze_morphology(self, text: str) -> dict[str, Any]:
        """Analyze Arabic morphology"""
        # Simplified morphological analysis
        words = text.split()
        patterns = []

        for word in words:
            # Check for common patterns
            if word.startswith('ال'):  # definite article
                patterns.append({"pattern": "definite_article", "root": word[2:]})
            elif len(word) >= 4:
                patterns.append({"pattern": "possible_root", "root": word[:3]})

        return {
            "words": len(words),
            "patterns": patterns,
            "has_tashkeel": any(c in text for c in self.DIACRITICS),
        }

    def analyze_sentiment(self, text: str) -> float:
        """Analyze sentiment in Arabic"""
        # Simplified sentiment
        positive_words = ["جيد", "ممتاز", "رائع", "مفيد", "ناجح"]
        negative_words = ["سيئ", "فظيع", "فاشل", "سلبي", "ضعيف"]

        score = 0.5
        for word in positive_words:
            if word in text:
                score += 0.1
        for word in negative_words:
            if word in text:
                score -= 0.1

        return max(0.0, min(1.0, score))

    def extract_entities(self, text: str) -> list[dict[str, Any]]:
        """Extract named entities from Arabic text"""
        entities = []

        # Simple pattern-based entity extraction
        # Names typically follow definite article or are capitalized
        words = text.split()

        for i, word in enumerate(words):
            # Check for person names (simplified)
            if word in ["محمد", "أحمد", "عمر", "علي", "فاطمة", "زينب"]:
                entities.append({
                    "text": word,
                    "type": "PERSON",
                    "confidence": 0.9,
                })
            # Check for locations
            elif word in ["مصر", "السعودية", "الإمارات", "الأردن", "لبنان"]:
                entities.append({
                    "text": word,
                    "type": "LOCATION",
                    "confidence": 0.9,
                })
            # Check for organizations
            elif word in ["جامعة", "شركة", "مستشفى", "وزارة"]:
                if i + 1 < len(words):
                    entities.append({
                        "text": f"{word} {words[i+1]}",
                        "type": "ORGANIZATION",
                        "confidence": 0.8,
                    })

        return entities

    async def text_to_speech(
        self,
        text: str,
        voice: str = "default",
        speed: float = 1.0,
    ) -> bytes:
        """Convert Arabic text to speech"""
        # Normalize for TTS
        normalized = self.normalize(text)
        return f"Arabic TTS: {normalized}".encode()

    async def speech_to_text(self, audio: bytes) -> str:
        """Convert Arabic speech to text"""
        return "[Arabic speech transcribed]"


class HebrewProcessor:
    """Hebrew language processing"""

    # Hebrew character range
    HEBREW_CHARS = range(0x0590, 0x05FF)
    HEBREW_EXTENDED = range(0xFB1D, 0xFB4F)

    # Hebrew fonts
    HEBREW_FONTS = {
        "formal": "David",
        "casual": "Arial",
        "modern": "Frank Ruehl",
        "heading": "Gisha",
    }

    def __init__(self):
        self.name = "Hebrew Processor"
        self.config = LanguageConfig(
            language=Language.HEBREW,
            direction=TextDirection.RTL,
            text_align="right",
        )

    def normalize(self, text: str) -> str:
        """Normalize Hebrew text"""
        # Remove niqqud (vowel points)
        niqqud = [
            '\u05B0', '\u05B1', '\u05B2', '\u05B3', '\u05B4', '\u05B5',
            '\u05B6', '\u05B7', '\u05B8', '\u05B9', '\u05BB', '\u05BC',
            '\u05BD', '\u05BF', '\u05C1', '\u05C2', '\u05C3', '\u05C4',
            '\u05C5', '\u05C6', '\u05C7', '\u05C8', '\u05C9', '\u05CA',
        ]

        for point in niqqud:
            text = text.replace(point, '')

        # Normalize shin/sin
        text = text.replace('\u05C1', '')  # Shin dot
        text = text.replace('\u05C2', '')  # Sin dot

        # Normalize dagesh
        text = text.replace('\u05BC', '')

        # Remove maqaf
        text = text.replace('\u05BE', ' ')

        # Remove sof-pasuq (period)
        text = text.replace('\u05C3', '')

        # Normalize whitespace
        text = re.sub(r'\s+', ' ', text)
        text = text.strip()

        return text

    def analyze_morphology(self, text: str) -> dict[str, Any]:
        """Analyze Hebrew morphology"""
        words = text.split()
        patterns = []

        for word in words:
            # Check for prefixes
            if word.startswith('ה') or word.startswith('ב') or word.startswith('ל'):
                if len(word) > 2:
                    patterns.append({"pattern": "prefixed", "root": word[1:]})

        return {
            "words": len(words),
            "patterns": patterns,
            "has_niqqud": any(c in text for c in '\u05B0\u05B1\u05B2'),
        }

    def analyze_sentiment(self, text: str) -> float:
        """Analyze sentiment in Hebrew"""
        positive_words = ["טוב", "מצוין", "נהדר", "חיובי", "מוצלח"]
        negative_words = ["רע", "נורא", "כושל", "שלילי", "חלש"]

        score = 0.5
        for word in positive_words:
            if word in text:
                score += 0.1
        for word in negative_words:
            if word in text:
                score -= 0.1

        return max(0.0, min(1.0, score))

    def extract_entities(self, text: str) -> list[dict[str, Any]]:
        """Extract named entities from Hebrew text"""
        entities = []

        words = text.split()

        for i, word in enumerate(words):
            # Person names
            if word in ["יוסי", "דוד", "משה", "אברהם", "שרה", "רחל"]:
                entities.append({
                    "text": word,
                    "type": "PERSON",
                    "confidence": 0.9,
                })
            # Locations
            elif word in ["תל אביב", "ירושלים", "חיפה", "באר שבע"]:
                entities.append({
                    "text": word,
                    "type": "LOCATION",
                    "confidence": 0.9,
                })

        return entities

    async def text_to_speech(self, text: str, voice: str = "default", speed: float = 1.0) -> bytes:
        """Convert Hebrew text to speech"""
        normalized = self.normalize(text)
        return f"Hebrew TTS: {normalized}".encode()

    async def speech_to_text(self, audio: bytes) -> str:
        """Convert Hebrew speech to text"""
        return "[Hebrew speech transcribed]"


class RTLTextAlignment:
    """RTL text alignment for UI rendering"""

    def __init__(self):
        self.rtl_chars = set()
        self.ltr_chars = set()

        # Build character sets
        for cp in range(0x0600, 0x06FF):
            self.rtl_chars.add(chr(cp))
        for cp in range(0x0750, 0x077F):
            self.rtl_chars.add(chr(cp))
        for cp in range(0xFB50, 0xFDFF):
            self.rtl_chars.add(chr(cp))
        for cp in range(0x0590, 0x05FF):
            self.rtl_chars.add(chr(cp))

        # Latin and other LTR
        for cp in range(0x0041, 0x005A):
            self.ltr_chars.add(chr(cp))
        for cp in range(0x0061, 0x007A):
            self.ltr_chars.add(chr(cp))

    def detect_direction(self, text: str) -> TextDirection:
        """Detect text direction"""
        rtl_count = sum(1 for c in text if c in self.rtl_chars)
        ltr_count = sum(1 for c in text if c in self.ltr_chars)

        if rtl_count > ltr_count:
            return TextDirection.RTL
        return TextDirection.LTR

    def align_text(self, text: str, direction: TextDirection) -> str:
        """Align text for proper RTL/LTR display"""
        if direction == TextDirection.RTL:
            # Reverse the logical order for visual display
            # This is a simplified implementation
            return f"\u202E{text}\u202C"  # RTL embedding marks
        return text

    def get_css_direction(self, direction: TextDirection) -> str:
        """Get CSS direction property"""
        return "rtl" if direction == TextDirection.RTL else "ltr"


class MultilingualTokenizer:
    """Cross-lingual tokenizer"""

    def __init__(self):
        self.processors = {
            Language.ARABIC: ArabicProcessor(),
            Language.HEBREW: HebrewProcessor(),
        }

    async def tokenize(self, text: str, language: Language) -> list[str]:
        """Tokenize text in specified language"""
        if language in self.processors:
            processor = self.processors[language]
            normalized = processor.normalize(text)
            return normalized.split()
        return text.split()

    async def get_embeddings(self, text: str, language: Language) -> list[float]:
        """Get multilingual embeddings for text"""
        # Simplified - would use actual embedding model
        # Return random embedding for demonstration
        import random
        return [random.random() for _ in range(768)]


class LanguageService:
    """
    Unified language service supporting Arabic, Hebrew, and more.
    Expert in RTL languages for text, image, and video generation.
    """

    def __init__(self):
        self.arabic = ArabicProcessor()
        self.hebrew = HebrewProcessor()
        self.tokenizer = MultilingualTokenizer()
        self.rtl_aligner = RTLTextAlignment()

        self.language_configs = {
            Language.ARABIC: LanguageConfig(
                language=Language.ARABIC,
                direction=TextDirection.RTL,
                dialect=Dialect.MSA,
                font_family="Arial",
                text_align="right",
            ),
            Language.HEBREW: LanguageConfig(
                language=Language.HEBREW,
                direction=TextDirection.RTL,
                font_family="David",
                text_align="right",
            ),
            Language.ENGLISH: LanguageConfig(
                language=Language.ENGLISH,
                direction=TextDirection.LTR,
                font_family="Arial",
                text_align="left",
            ),
        }

        logger.info("Language service initialized with Arabic and Hebrew support")

    async def detect_language(self, text: str) -> tuple[Language, TextDirection]:
        """Detect language and direction"""
        # Count character types
        rtl_count = sum(1 for c in text if ord(c) in range(0x0600, 0x06FF) or ord(c) in range(0x0590, 0x05FF))
        ltr_count = sum(1 for c in text if c.isalpha() and c.isascii())

        if rtl_count > ltr_count:
            if any(ord(c) in range(0x0600, 0x06FF) for c in text):
                return Language.ARABIC, TextDirection.RTL
            return Language.HEBREW, TextDirection.RTL

        return Language.ENGLISH, TextDirection.LTR

    async def process_text(
        self,
        text: str,
        language: Language | None = None,
    ) -> ProcessedText:
        """Process text with language-specific handling"""
        if language is None:
            language, _ = await self.detect_language(text)

        if language == Language.ARABIC:
            processor = self.arabic
        elif language == Language.HEBREW:
            processor = self.hebrew
        else:
            return ProcessedText(
                original=text,
                normalized=text,
                language=language,
                tokens=text.split(),
                entities=[],
                sentiment=0.5,
                morphology={},
                embeddings=[],
            )

        normalized = processor.normalize(text)
        tokens = normalized.split()
        entities = processor.extract_entities(text)
        sentiment = processor.analyze_sentiment(text)
        morphology = processor.analyze_morphology(text)
        embeddings = await self.tokenizer.get_embeddings(normalized, language)

        return ProcessedText(
            original=text,
            normalized=normalized,
            language=language,
            tokens=tokens,
            entities=entities,
            sentiment=sentiment,
            morphology=morphology,
            embeddings=embeddings,
        )

    async def prepare_image_prompt(
        self,
        prompt: str,
        language: Language,
        style: str = "natural",
    ) -> dict[str, Any]:
        """Prepare image generation prompt with RTL language support"""
        if language == Language.ARABIC:
            return {
                "prompt": prompt,
                "text_direction": "RTL",
                "text_overlay": {
                    "language": "Arabic",
                    "script": "العربية",
                    "font_family": "Traditional Arabic",
                    "direction": "right-to-left",
                },
                "style_guidance": {
                    "calligraphy_style": True,
                    "include_arabic_in_image": True,
                },
                "negative_prompt": "incorrect text, gibberish Arabic, spelling errors",
            }
        elif language == Language.HEBREW:
            return {
                "prompt": prompt,
                "text_direction": "RTL",
                "text_overlay": {
                    "language": "Hebrew",
                    "script": "עברית",
                    "font_family": "David",
                    "direction": "right-to-left",
                },
                "style_guidance": {
                    "script_style": "modern Hebrew",
                    "include_hebrew_in_image": True,
                },
                "negative_prompt": "incorrect text, backwards Hebrew, spelling errors",
            }
        else:
            return {
                "prompt": prompt,
                "text_direction": "LTR",
                "style_guidance": {},
            }

    async def prepare_video_prompt(
        self,
        prompt: str,
        language: Language,
        duration: float = 10.0,
    ) -> dict[str, Any]:
        """Prepare video generation prompt with RTL language support"""
        base_prompt = await self.prepare_image_prompt(prompt, language)

        if language == Language.ARABIC:
            base_prompt.update({
                "video_config": {
                    "duration": duration,
                    "text_animation": "fade_in_right",
                    "text_reading_direction": "right-to-left",
                    "audio_language": "ar-SA",
                    "voiceover_style": "formal MSA",
                },
                "scene_transitions": {
                    "direction": "right-to-left",
                    "text_flow": "right-aligned",
                },
            })
        elif language == Language.HEBREW:
            base_prompt.update({
                "video_config": {
                    "duration": duration,
                    "text_animation": "fade_in_right",
                    "text_reading_direction": "right-to-left",
                    "audio_language": "he-IL",
                    "voiceover_style": "modern Hebrew",
                },
                "scene_transitions": {
                    "direction": "right-to-left",
                    "text_flow": "right-aligned",
                },
            })

        return base_prompt

    async def translate_text(
        self,
        text: str,
        source_language: Language,
        target_language: Language,
    ) -> str:
        """Translate text between languages"""
        translations = {
            (Language.ENGLISH, Language.ARABIC): f"[عربي] {text}",
            (Language.ENGLISH, Language.HEBREW): f"[עברית] {text}",
            (Language.ARABIC, Language.ENGLISH): f"[English] {text}",
            (Language.HEBREW, Language.ENGLISH): f"[English] {text}",
            (Language.ARABIC, Language.HEBREW): f"[עברית] {text}",
            (Language.HEBREW, Language.ARABIC): f"[عربي] {text}",
        }

        key = (source_language, target_language)
        return translations.get(key, text)

    def get_ui_translations(self, language: Language) -> dict[str, str]:
        """Get UI translations for a language"""
        translations = {
            Language.ARABIC: {
                "welcome": "مرحباً",
                "search": "بحث",
                "submit": "إرسال",
                "cancel": "إلغاء",
                "settings": "الإعدادات",
                "loading": "جاري التحميل...",
                "error": "خطأ",
                "success": "نجاح",
                "generate": "إنشاء",
                "analyze": "تحليل",
                "result": "النتيجة",
            },
            Language.HEBREW: {
                "welcome": "ברוך הבא",
                "search": "חיפוש",
                "submit": "שלח",
                "cancel": "ביטול",
                "settings": "הגדרות",
                "loading": "טוען...",
                "error": "שגיאה",
                "success": "הצלחה",
                "generate": "צור",
                "analyze": "נתח",
                "result": "תוצאה",
            },
            Language.ENGLISH: {
                "welcome": "Welcome",
                "search": "Search",
                "submit": "Submit",
                "cancel": "Cancel",
                "settings": "Settings",
                "loading": "Loading...",
                "error": "Error",
                "success": "Success",
                "generate": "Generate",
                "analyze": "Analyze",
                "result": "Result",
            },
        }

        return translations.get(language, translations[Language.ENGLISH])


async def example():
    """Example language service usage"""
    service = LanguageService()

    # Arabic text processing
    arabic_text = "مرحباً بالعالم! هذا نص باللغة العربية."
    processed = await service.process_text(arabic_text, Language.ARABIC)

    print(f"Original: {arabic_text}")
    print(f"Normalized: {processed.normalized}")
    print(f"Direction: RTL")
    print(f"Entities: {processed.entities}")

    # Image prompt preparation
    image_prompt = await service.prepare_image_prompt(
        "A futuristic city with Arabic text",
        Language.ARABIC
    )
    print(f"\nImage Prompt: {image_prompt}")

    # Video prompt preparation
    video_prompt = await service.prepare_video_prompt(
        "Documentary about ancient Egypt",
        Language.ARABIC,
        duration=15.0
    )
    print(f"\nVideo Prompt: {video_prompt}")

    # UI translations
    translations = service.get_ui_translations(Language.ARABIC)
    print(f"\nUI Translations: {translations}")


if __name__ == "__main__":
    asyncio.run(example())
