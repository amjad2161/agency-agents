from __future__ import annotations

import importlib.util
from pathlib import Path


def export_legacy_module(module_name: str, file_path: Path) -> dict[str, object]:
    spec = importlib.util.spec_from_file_location(f"_legacy_{module_name.replace('.', '_')}", file_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Unable to load legacy module from {file_path}")

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    exported: dict[str, object] = {}
    for name, value in vars(module).items():
        if name.startswith("__") and name not in {"__doc__", "__all__"}:
            continue
        exported[name] = value
    return exported