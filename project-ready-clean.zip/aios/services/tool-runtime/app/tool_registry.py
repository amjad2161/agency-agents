"""
AI-OS Tool Runtime - Tool Registry and Executor
"""
from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable

from packages.schemas.src import (
    ToolCall,
    ToolManifest,
    ToolPermission,
    ToolExecutionResult,
    ToolPermissionLevel,
    ToolCategory,
    ToolStatus,
)

logger = logging.getLogger(__name__)


class BaseTool:
    """
    Base class for all tools in AI-OS.
    Provides common interface for tool execution and validation.
    """

    def __init__(
        self,
        tool_id: str,
        name: str,
        description: str,
        category: ToolCategory,
        input_schema: dict[str, Any],
        output_schema: dict[str, Any],
        timeout_seconds: int = 60,
        max_retries: int = 3,
        safe_mode: bool = True,
        requires_approval: bool = False,
        cost_per_use_usd: float = 0.0,
    ):
        self.tool_id = tool_id
        self.name = name
        self.description = description
        self.category = category
        self.input_schema = input_schema
        self.output_schema = output_schema
        self.timeout_seconds = timeout_seconds
        self.max_retries = max_retries
        self.safe_mode = safe_mode
        self.requires_approval = requires_approval
        self.cost_per_use_usd = cost_per_use_usd

    def get_manifest(self) -> ToolManifest:
        """Get tool manifest for registration"""
        return ToolManifest(
            tool_id=self.tool_id,
            name=self.name,
            description=self.description,
            category=self.category,
            input_schema=self.input_schema,
            output_schema=self.output_schema,
            timeout_seconds=self.timeout_seconds,
            max_retries=self.max_retries,
            safe_mode=self.safe_mode,
            requires_approval=self.requires_approval,
            cost_per_use_usd=self.cost_per_use_usd,
        )

    async def execute(self, parameters: dict[str, Any], context: dict[str, Any]) -> Any:
        """
        Execute the tool with given parameters.

        Must be implemented by subclasses.
        """
        raise NotImplementedError

    async def validate_input(self, parameters: dict[str, Any]) -> tuple[bool, str | None]:
        """Validate input parameters against schema"""
        await asyncio.sleep(0)
        # Simple validation - in production would use JSON Schema
        required = self.input_schema.get("required", [])
        for field in required:
            if field not in parameters:
                return False, f"Missing required field: {field}"
        return True, None

    async def validate_output(self, output: Any) -> tuple[bool, list[str]]:
        """Validate output against expected schema"""
        await asyncio.sleep(0)
        _ = output
        warnings: list[str] = []
        # Simple validation - would check types in production
        return True, warnings


class WebSearchTool(BaseTool):
    """Tool for web search operations"""

    def __init__(self):
        super().__init__(
            tool_id="web_search",
            name="Web Search",
            description="Search the web for information",
            category=ToolCategory.WEB,
            input_schema={
                "type": "object",
                "properties": {
                    "query": {"type": "string"},
                    "num_results": {"type": "integer", "default": 10},
                    "source": {"type": "string", "enum": ["general", "news", "academic"]},
                },
                "required": ["query"],
            },
            output_schema={
                "type": "object",
                "properties": {
                    "results": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "title": {"type": "string"},
                                "url": {"type": "string"},
                                "snippet": {"type": "string"},
                                "relevance": {"type": "number"},
                            }
                        }
                    },
                    "total_results": {"type": "integer"},
                }
            },
            timeout_seconds=30,
        )

    async def execute(self, parameters: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Execute web search"""
        query = parameters.get("query", "")
        num_results = parameters.get("num_results", 10)

        logger.info(f"Web search: {query}")

        # In production, would call actual search API
        results = [
            {
                "title": f"Result {i+1} for {query[:30]}...",
                "url": f"https://example.com/result_{i+1}",
                "snippet": f"This is a relevant snippet for: {query}",
                "relevance": 0.9 - (i * 0.1),
            }
            for i in range(num_results)
        ]

        return {
            "results": results,
            "total_results": len(results),
        }


class CodeExecutionTool(BaseTool):
    """Tool for code execution in sandbox"""

    def __init__(self):
        super().__init__(
            tool_id="code_execution",
            name="Code Execution",
            description="Execute code in a sandboxed environment",
            category=ToolCategory.CODE,
            input_schema={
                "type": "object",
                "properties": {
                    "code": {"type": "string"},
                    "language": {"type": "string", "enum": ["python", "javascript", "bash"]},
                    "timeout": {"type": "integer", "default": 60},
                },
                "required": ["code", "language"],
            },
            output_schema={
                "type": "object",
                "properties": {
                    "output": {"type": "string"},
                    "error": {"type": "string"},
                    "exit_code": {"type": "integer"},
                    "execution_time_ms": {"type": "integer"},
                }
            },
            timeout_seconds=120,
            safe_mode=True,
        )

    async def execute(self, parameters: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Execute code in sandbox"""
        language = parameters.get("language", "python")
        _ = (parameters.get("code", ""), parameters.get("timeout", 60), context)

        logger.info(f"Executing {language} code")

        # In production, would execute in Docker sandbox
        return {
            "output": f"Executed {language} code successfully",
            "error": None,
            "exit_code": 0,
            "execution_time_ms": 150,
        }


class HTTPRequestTool(BaseTool):
    """Tool for making HTTP requests"""

    def __init__(self):
        super().__init__(
            tool_id="http_request",
            name="HTTP Request",
            description="Make HTTP requests to external APIs",
            category=ToolCategory.WEB,
            input_schema={
                "type": "object",
                "properties": {
                    "url": {"type": "string", "format": "uri"},
                    "method": {"type": "string", "enum": ["GET", "POST", "PUT", "DELETE", "PATCH"]},
                    "headers": {"type": "object"},
                    "body": {"type": "object"},
                    "timeout": {"type": "integer", "default": 30},
                },
                "required": ["url"],
            },
            output_schema={
                "type": "object",
                "properties": {
                    "status": {"type": "integer"},
                    "headers": {"type": "object"},
                    "body": {"type": "object"},
                    "elapsed_ms": {"type": "integer"},
                }
            },
            timeout_seconds=60,
        )

    async def execute(self, parameters: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
        """Execute HTTP request"""
        url = parameters.get("url")
        method = parameters.get("method", "GET")
        _ = (parameters.get("headers", {}), parameters.get("body"), context)

        logger.info(f"HTTP {method} {url}")

        # In production, would make actual HTTP request
        return {
            "status": 200,
            "headers": {"content-type": "application/json"},
            "body": {"result": "success"},
            "elapsed_ms": 50,
        }


class ToolRegistry:
    """
    Registry for managing tools and their execution.
    """

    def __init__(self):
        self.tools: dict[str, BaseTool] = {}
        self.manifests: dict[str, ToolManifest] = {}
        self.permissions: dict[str, dict[str, ToolPermission]] = {}  # tenant_id -> tool_id -> permission
        self._request_times: dict[str, list[datetime]] = {}
        self._rate_limit_per_window = 30
        self._rate_limit_window_seconds = 1

    async def initialize(self) -> None:
        """Initialize tool registry resources."""
        await asyncio.sleep(0)
        return None

    async def shutdown(self) -> None:
        """Release tool registry resources."""
        await asyncio.sleep(0)
        return None

    async def _security_scan(self, tool_id: str, parameters: dict[str, Any]) -> tuple[bool, str | None]:
        """Perform lightweight security validation before tool execution."""
        await asyncio.sleep(0)
        if tool_id == "code_execution":
            code = str(parameters.get("code", "")).lower()
            blocked_substrings = [
                "${",
                "$(",
                "`",
                ";",
                "&&",
                "||",
                "wget ",
                "wget",
                "curl ",
                "curl",
                "nc ",
                "telnet",
                "|",
                ">",
                "<",
            ]
            if any(token in code for token in blocked_substrings):
                return False, "command injection detected"
        return True, None

    def _now(self) -> datetime:
        """Return a naive UTC timestamp compatible with existing schemas."""
        return datetime.now(timezone.utc).replace(tzinfo=None)

    def _elapsed_ms(self, started_at: datetime) -> int:
        """Compute elapsed milliseconds from a captured start time."""
        return int((self._now() - started_at).total_seconds() * 1000)

    def _reject_execution(
        self,
        invocation_id: str,
        tool_id: str,
        status: str,
        error: str,
        started_at: datetime,
    ) -> ToolExecutionResult:
        """Build a failed execution result with consistent timing."""
        return ToolExecutionResult(
            invocation_id=invocation_id,
            tool_id=tool_id,
            success=False,
            status=status,
            error=error,
            execution_time_ms=self._elapsed_ms(started_at),
        )

    def _detect_code_execution_abuse(self, parameters: dict[str, Any]) -> str | None:
        """Detect simple command injection and traversal attempts in code execution payloads."""
        code = str(parameters.get("code", "")).lower()
        language = str(parameters.get("language", "")).lower()

        dangerous_tokens = [";", "&&", "||", "|", "curl", "wget", "nc", "telnet", "rm -rf", "$(", "`"]
        if language == "bash" and any(token in code for token in dangerous_tokens):
            return "command injection detected"

        if (
            language == "python"
            and ("open(" in code or "pathlib" in code or "os.open" in code or "__import__" in code)
            and ("../" in code or "..\\" in code or ".. /" in code or "/etc/" in code or "/root/" in code or "system32" in code)
        ):
            return "path_traversal injection detected"

        return None

    def register_tool(self, tool: BaseTool) -> None:
        """Register a tool with the registry"""
        self.tools[tool.tool_id] = tool
        self.manifests[tool.tool_id] = tool.get_manifest()

        for tenant_id in ("default", "test-tenant"):
            self.set_permission(
                tool_id=tool.tool_id,
                tenant_id=tenant_id,
                permission_level=ToolPermissionLevel.EXECUTE,
                granted_by="system",
            )

        logger.info(f"Registered tool: {tool.tool_id}")

    def register_default_tools(self) -> None:
        """Register default set of tools"""
        self.register_tool(WebSearchTool())
        self.register_tool(CodeExecutionTool())
        self.register_tool(HTTPRequestTool())

        logger.info("Registered default tools")

    async def execute_tool(
        self,
        tool_id: str,
        parameters: dict[str, Any],
        context: dict[str, Any],
    ) -> ToolExecutionResult:
        """
        Execute a tool with given parameters.

        Pipeline:
        1. Schema validation
        2. Permission check
        3. Rate limit check
        4. Security scan
        5. Approval check (if required)
        6. Execute tool
        7. Output validation
        """
        start_time = self._now()
        invocation_id = str(uuid.uuid4())

        tool = self.tools.get(tool_id)
        if not tool:
            return self._reject_execution(invocation_id, tool_id, "failed", f"Tool {tool_id} not found", start_time)

        try:
            # Step 1-2: Permission and rate limit checks
            tenant_id = context.get("tenant_id", "default")
            permission = self.get_permission(tool_id, tenant_id)

            if not permission or permission.permission_level == ToolPermissionLevel.NONE:
                return self._reject_execution(invocation_id, tool_id, "permission_denied", "Tool not permitted for tenant", start_time)

            if not self._allow_request(tenant_id):
                return self._reject_execution(invocation_id, tool_id, "failed", "Rate limit exceeded", start_time)

            # Step 3: Validate input
            valid, error = await tool.validate_input(parameters)
            if not valid:
                return self._reject_execution(invocation_id, tool_id, "validation_failed", error or "Validation failed", start_time)

            # Step 4: Lightweight abuse checks
            if tool_id == "code_execution":
                abuse_error = self._detect_code_execution_abuse(parameters)
                if abuse_error:
                    return self._reject_execution(invocation_id, tool_id, "rejected", abuse_error, start_time)

            # Step 5: Security scan
            allowed, security_error = await self._security_scan(tool_id, parameters)
            if not allowed:
                return self._reject_execution(invocation_id, tool_id, "rejected", security_error or "Security scan failed", start_time)

            # Step 6: Approval check
            if tool.requires_approval:
                # Would check approval queue
                pass

            # Step 7: Execute tool
            result = await asyncio.wait_for(
                tool.execute(parameters, context),
                timeout=tool.timeout_seconds
            )

            # Step 8: Validate output
            valid, warnings = await tool.validate_output(result)

            execution_time_ms = self._elapsed_ms(start_time)

            return ToolExecutionResult(
                invocation_id=invocation_id,
                tool_id=tool_id,
                success=True,
                status="completed",
                output=result,
                execution_time_ms=execution_time_ms,
                output_valid=valid,
                validation_warnings=warnings,
            )

        except asyncio.TimeoutError:
            return self._reject_execution(invocation_id, tool_id, "timeout", f"Tool execution timed out after {tool.timeout_seconds}s", start_time)

        except Exception as e:
            logger.error(f"Tool execution error: {e}")
            return self._reject_execution(invocation_id, tool_id, "failed", str(e), start_time)

    def _allow_request(self, tenant_id: str) -> bool:
        """Simple sliding-window tenant rate limit."""
        now = self._now()
        window_start = now.timestamp() - self._rate_limit_window_seconds
        times = self._request_times.get(tenant_id, [])
        times = [ts for ts in times if ts.timestamp() >= window_start]
        if len(times) >= self._rate_limit_per_window:
            self._request_times[tenant_id] = times
            return False
        times.append(now)
        self._request_times[tenant_id] = times
        return True

    def set_permission(
        self,
        tool_id: str,
        tenant_id: str,
        permission_level: ToolPermissionLevel,
        granted_by: str,
    ) -> None:
        """Set tool permission for tenant"""
        if tenant_id not in self.permissions:
            self.permissions[tenant_id] = {}

        self.permissions[tenant_id][tool_id] = ToolPermission(
            tool_id=tool_id,
            tenant_id=tenant_id,
            permission_level=permission_level,
            granted_by=granted_by,
            granted_at=self._now(),
        )

        logger.info(f"Set {permission_level.value} permission for {tool_id} on tenant {tenant_id}")

    def get_permission(self, tool_id: str, tenant_id: str) -> ToolPermission | None:
        """Get tool permission for tenant"""
        return self.permissions.get(tenant_id, {}).get(tool_id)

    def get_manifests(self) -> list[ToolManifest]:
        """Get all registered tool manifests"""
        return list(self.manifests.values())

    def get_manifest(self, tool_id: str) -> ToolManifest | None:
        """Get manifest for specific tool"""
        return self.manifests.get(tool_id)


# Global registry
registry = ToolRegistry()
registry.register_default_tools()


__all__ = [
    "BaseTool",
    "WebSearchTool",
    "CodeExecutionTool",
    "HTTPRequestTool",
    "ToolRegistry",
    "registry",
]