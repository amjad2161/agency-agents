"""
Knowledge Service - Citations, Trust, and RAG Pipeline
Implements citation generation, trust scoring, and contradiction detection
"""
from typing import Any, Optional
from enum import Enum
from datetime import datetime
from uuid import uuid4

from pydantic import BaseModel, Field


class SourceType(str, Enum):
    """Types of knowledge sources"""
    WEB = "web"
    DOCUMENT = "document"
    DATABASE = "database"
    API = "api"
    USER_UPLOAD = "user_upload"
    AGENT_GENERATED = "agent_generated"
    KNOWLEDGE_GRAPH = "knowledge_graph"
    MEMORY = "memory"


class TrustLevel(str, Enum):
    """Trust levels for sources"""
    VERIFIED = "verified"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    UNVERIFIED = "unverified"


class FactType(str, Enum):
    """Classification of fact types"""
    FACT = "fact"
    INFERENCE = "inference"
    ASSUMPTION = "assumption"
    CONJECTURE = "conjecture"
    PERSONAL_OPINION = "personal_opinion"


class Citation(BaseModel):
    """Citation data model"""
    citation_id: str = Field(default_factory=lambda: str(uuid4()))
    source_type: SourceType
    source_id: str
    source_url: Optional[str] = None
    source_title: Optional[str] = None
    source_author: Optional[str] = None
    source_date: Optional[datetime] = None
    accessed_at: datetime = Field(default_factory=datetime.utcnow)
    trust_level: TrustLevel = TrustLevel.MEDIUM
    relevance_score: float = 1.0
    excerpt: Optional[str] = None
    page_number: Optional[int] = None
    line_number: Optional[int] = None


class TrustScore(BaseModel):
    """Trust score for knowledge"""
    score: float = Field(..., ge=0, le=1)
    trust_level: TrustLevel
    factors: dict[str, float] = Field(default_factory=dict)
    source_age_days: Optional[int] = None
    citation_count: int = 0
    verification_status: str = "unverified"
    last_verified: Optional[datetime] = None
    warnings: list[str] = Field(default_factory=list)


class KnowledgeClaim(BaseModel):
    """A knowledge claim with metadata"""
    claim_id: str = Field(default_factory=lambda: str(uuid4()))
    content: str
    fact_type: FactType
    citations: list[Citation] = Field(default_factory=list)
    trust_score: Optional[TrustScore] = None
    confidence: float = Field(default=0.5, ge=0, le=1)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    contradicted_by: list[str] = Field(default_factory=list)  # claim_ids
    supported_by: list[str] = Field(default_factory=list)  # claim_ids


class CitationService:
    """Citation generation and management"""

    def __init__(self):
        self._citations: dict[str, Citation] = {}

    async def create_citation(
        self,
        source_type: SourceType,
        source_id: str,
        source_url: str | None = None,
        source_title: str | None = None,
        excerpt: str | None = None,
        **kwargs,
    ) -> Citation:
        """Create a new citation"""
        citation = Citation(
            source_type=source_type,
            source_id=source_id,
            source_url=source_url,
            source_title=source_title,
            excerpt=excerpt,
            **kwargs,
        )
        self._citations[citation.citation_id] = citation
        return citation

    async def get_citation(self, citation_id: str) -> Citation | None:
        """Get citation by ID"""
        return self._citations.get(citation_id)

    async def format_citation(
        self,
        citation: Citation,
        format_style: str = "academic",
    ) -> str:
        """Format citation in specified style"""
        if format_style == "academic":
            parts = []
            if citation.source_author:
                parts.append(citation.source_author)
            if citation.source_date:
                parts.append(f"({citation.source_date.year})")
            if citation.source_title:
                parts.append(f'"{citation.source_title}"')
            if citation.source_url:
                parts.append(f"Retrieved from {citation.source_url}")
            return ". ".join(parts) if parts else "Unknown source"

        elif format_style == "chicago":
            parts = []
            if citation.source_author:
                parts.append(citation.source_author)
            if citation.source_title:
                parts.append(f'"{citation.source_title}"')
            if citation.source_url:
                parts.append(citation.source_url)
            return ", ".join(parts) if parts else "Unknown source"

        elif format_style == "mla":
            parts = []
            if citation.source_author:
                parts.append(citation.source_author)
            if citation.source_title:
                parts.append(f'"{citation.source_title}"')
            if citation.source_url:
                parts.append(citation.source_url)
            return " ".join(parts) if parts else "Unknown source"

        return f"[{citation.source_type.value}] {citation.source_title or citation.source_id}"

    async def generate_citation_chain(
        self,
        retrieved_context: list[dict[str, Any]],
        format_style: str = "academic",
    ) -> tuple[list[str], list[Citation]]:
        """Generate citation chain for retrieved context"""
        formatted_citations = []
        all_citations = []

        for i, context_item in enumerate(retrieved_context):
            citation_data = context_item.get("citation")
            if citation_data:
                citation = Citation(**citation_data) if isinstance(citation_data, dict) else citation_data
                formatted = await self.format_citation(citation, format_style)
                formatted_citations.append(f"[{i + 1}] {formatted}")
                all_citations.append(citation)

        return formatted_citations, all_citations


class TrustScoringService:
    """Trust scoring for knowledge sources"""

    def __init__(self):
        self._source_weights = {
            SourceType.WEB: 0.5,
            SourceType.DOCUMENT: 0.7,
            SourceType.DATABASE: 0.8,
            SourceType.API: 0.75,
            SourceType.USER_UPLOAD: 0.4,
            SourceType.AGENT_GENERATED: 0.3,
            SourceType.KNOWLEDGE_GRAPH: 0.85,
            SourceType.MEMORY: 0.6,
        }

    async def compute_trust_score(
        self,
        source_type: SourceType,
        source_url: str | None = None,
        source_date: datetime | None = None,
        citation_count: int = 0,
        verification_status: str = "unverified",
        user_relevance_score: float | None = None,
    ) -> TrustScore:
        """Compute trust score for a knowledge source"""
        base_score = self._source_weights.get(source_type, 0.5)
        factors = {"base_source_trust": base_score}

        # Age factor (newer sources score higher)
        if source_date:
            age_days = (datetime.utcnow() - source_date).days
            if age_days < 30:
                age_factor = 1.0
            elif age_days < 180:
                age_factor = 0.9
            elif age_days < 365:
                age_factor = 0.8
            else:
                age_factor = max(0.5, 1.0 - (age_days / 3650))  # Decay over 10 years
            factors["source_freshness"] = age_factor
        else:
            age_days = None
            factors["source_freshness"] = 0.6

        # Citation factor (well-cited sources score higher)
        if citation_count > 10:
            citation_factor = 1.0
        elif citation_count > 5:
            citation_factor = 0.9
        elif citation_count > 0:
            citation_factor = 0.8
        else:
            citation_factor = 0.6
        factors["citation_count_factor"] = citation_factor

        # Verification factor
        verification_map = {
            "verified": 1.0,
            "cross_checked": 0.95,
            "partially_verified": 0.7,
            "unverified": 0.5,
        }
        verification_factor = verification_map.get(verification_status, 0.5)
        factors["verification_status"] = verification_factor

        # URL/domain factor (authoritative domains score higher)
        if source_url:
            authoritative_domains = ["gov", "edu", "wikipedia.org", "arxiv.org", "nature.com"]
            url_factor = 0.7
            for domain in authoritative_domains:
                if domain in source_url:
                    url_factor = 1.0
                    break
            factors["domain_authority"] = url_factor
        else:
            factors["domain_authority"] = 0.5

        # Compute weighted score
        weights = {
            "base_source_trust": 0.35,
            "source_freshness": 0.2,
            "citation_count_factor": 0.15,
            "verification_status": 0.2,
            "domain_authority": 0.1,
        }

        final_score = sum(factors.get(k, 0) * w for k, w in weights.items())

        # Determine trust level
        if final_score >= 0.85:
            trust_level = TrustLevel.VERIFIED
        elif final_score >= 0.75:
            trust_level = TrustLevel.HIGH
        elif final_score >= 0.6:
            trust_level = TrustLevel.MEDIUM
        elif final_score >= 0.4:
            trust_level = TrustLevel.LOW
        else:
            trust_level = TrustLevel.UNVERIFIED

        return TrustScore(
            score=final_score,
            trust_level=trust_level,
            factors=factors,
            source_age_days=age_days,
            citation_count=citation_count,
            verification_status=verification_status,
        )

    async def adjust_trust_for_claim_age(
        self,
        trust_score: TrustScore,
        claim_date: datetime,
    ) -> TrustScore:
        """Adjust trust score based on claim age"""
        age_days = (datetime.utcnow() - claim_date).days

        if age_days > 365:
            # Decay score for old claims
            decay = min(0.2, age_days / 365 * 0.05)
            trust_score.score -= decay

        return trust_score


class ContradictionDetector:
    """Detect contradictions in knowledge"""

    def __init__(self):
        self._claims: dict[str, KnowledgeClaim] = {}

    async def register_claim(
        self,
        content: str,
        fact_type: FactType,
        citations: list[Citation] | None = None,
    ) -> str:
        """Register a knowledge claim"""
        claim = KnowledgeClaim(
            content=content,
            fact_type=fact_type,
            citations=citations or [],
        )
        self._claims[claim.claim_id] = claim
        return claim.claim_id

    async def check_contradiction(
        self,
        new_claim_id: str,
    ) -> list[dict[str, Any]]:
        """Check if a claim contradicts existing claims"""
        if new_claim_id not in self._claims:
            return []

        new_claim = self._claims[new_claim_id]
        contradictions = []

        for claim_id, existing_claim in self._claims.items():
            if claim_id == new_claim_id:
                continue

            # Check for semantic contradiction
            if self._are_contradictory(new_claim.content, existing_claim.content):
                contradictions.append({
                    "type": "semantic",
                    "contradicts_claim_id": claim_id,
                    "existing_claim": existing_claim.content,
                    "new_claim": new_claim.content,
                    "confidence": 0.85,
                })

                # Update claim metadata
                new_claim.contradicted_by.append(claim_id)
                existing_claim.contradicted_by.append(new_claim_id)

        return contradictions

    def _are_contradictory(self, claim1: str, claim2: str) -> bool:
        """Simple contradiction detection based on negation patterns"""
        negation_indicators = [
            ("is not", "is"),
            ("doesn't", "does"),
            ("cannot", "can"),
            ("never", "always"),
            ("none", "all"),
            ("false", "true"),
            ("wrong", "right"),
        ]

        claim1_lower = claim1.lower()
        claim2_lower = claim2.lower()

        for neg1, pos1 in negation_indicators:
            for neg2, pos2 in negation_indicators:
                if (neg1 in claim1_lower and pos2 in claim2_lower) or \
                   (neg2 in claim2_lower and pos1 in claim1_lower):
                    # Check if they talk about similar topics
                    words1 = set(claim1_lower.split())
                    words2 = set(claim2_lower.split())
                    overlap = words1 & words2
                    if len(overlap) > 5:  # Significant overlap suggests contradiction
                        return True

        return False

    async def get_claim_confidence(
        self,
        claim_id: str,
    ) -> float:
        """Compute confidence for a claim based on support and contradiction"""
        if claim_id not in self._claims:
            return 0.0

        claim = self._claims[claim_id]

        # Base confidence from fact type
        type_confidence = {
            FactType.FACT: 0.9,
            FactType.INFERENCE: 0.7,
            FactType.ASSUMPTION: 0.5,
            FactType.CONJECTURE: 0.3,
            FactType.PERSONAL_OPINION: 0.4,
        }
        confidence = type_confidence.get(claim.fact_type, 0.5)

        # Reduce for contradictions
        if claim.contradicted_by:
            confidence *= (1.0 - min(0.4, len(claim.contradicted_by) * 0.1))

        # Increase for citations
        if claim.citations:
            citation_boost = min(0.2, len(claim.citations) * 0.05)
            confidence = min(1.0, confidence + citation_boost)

        # Reduce for being contradicted
        if claim.contradicted_by:
            confidence *= 0.7

        return confidence


class RAGPipeline:
    """Complete RAG pipeline with retrieval and synthesis"""

    def __init__(
        self,
        citation_service: CitationService,
        trust_service: TrustScoringService,
        contradiction_detector: ContradictionDetector,
    ):
        self.citation = citation_service
        self.trust = trust_service
        self.contradiction = contradiction_detector

    async def retrieve_and_synthesize(
        self,
        query: str,
        knowledge_sources: list[dict[str, Any]],
        top_k: int = 10,
        min_relevance: float = 0.5,
        include_citations: bool = True,
        detect_contradictions: bool = True,
    ) -> dict[str, Any]:
        """Execute full RAG pipeline"""
        retrieved_items = []
        all_citations: list[Citation] = []
        trust_scores: list[TrustScore] = []

        # Stage 1: Retrieve and rank
        for source in knowledge_sources:
            if source.get("relevance_score", 0) >= min_relevance:
                retrieved_items.append(source)

        retrieved_items.sort(key=lambda x: x.get("relevance_score", 0), reverse=True)
        retrieved_items = retrieved_items[:top_k]

        # Stage 2: Generate citations and trust scores
        for item in retrieved_items:
            if "source" in item:
                citation = await self.citation.create_citation(
                    source_type=SourceType(item.get("source_type", "web")),
                    source_id=item.get("source_id", ""),
                    source_url=item.get("source_url"),
                    source_title=item.get("title"),
                    excerpt=item.get("excerpt") or item.get("content", "")[:200],
                )
                all_citations.append(citation)

                trust_score = await self.trust.compute_trust_score(
                    source_type=citation.source_type,
                    source_url=citation.source_url,
                    source_date=citation.source_date,
                    citation_count=item.get("citation_count", 0),
                )
                trust_scores.append(trust_score)

        # Stage 3: Check for contradictions
        contradictions = []
        if detect_contradictions:
            for item in retrieved_items:
                claim_content = item.get("content", "")
                if claim_content:
                    claim_id = await self.contradiction.register_claim(
                        content=claim_content[:500],  # Truncate for comparison
                        fact_type=FactType.INFERENCE if item.get("inferred") else FactType.FACT,
                        citations=[c for c in all_citations if c.source_id == item.get("source_id")],
                    )
                    new_contradictions = await self.contradiction.check_contradiction(claim_id)
                    contradictions.extend(new_contradictions)

        # Stage 4: Generate answer with citations
        formatted_citations, citations_list = await self.citation.generate_citation_chain(
            retrieved_items, format_style="academic"
        )

        # Stage 5: Compute overall trust
        avg_trust = sum(s.score for s in trust_scores) / len(trust_scores) if trust_scores else 0.5
        overall_trust = TrustLevel.HIGH if avg_trust >= 0.75 else (
            TrustLevel.MEDIUM if avg_trust >= 0.6 else TrustLevel.LOW
        )

        return {
            "retrieved_items": retrieved_items,
            "total_results": len(retrieved_items),
            "citations": [c.model_dump() for c in citations_list],
            "formatted_citations": formatted_citations,
            "trust_scores": [s.model_dump() for s in trust_scores],
            "overall_trust": overall_trust.value,
            "average_trust_score": avg_trust,
            "contradictions_detected": len(contradictions),
            "contradictions": contradictions,
            "fact_types": {
                "facts": sum(1 for i in retrieved_items if not i.get("inferred")),
                "inferences": sum(1 for i in retrieved_items if i.get("inferred")),
            },
        }


class KnowledgeIngestionService:
    """Document and knowledge ingestion pipeline"""

    def __init__(
        self,
        citation_service: CitationService,
        trust_service: TrustScoringService,
    ):
        self.citation = citation_service
        self.trust = trust_service

    async def ingest_document(
        self,
        document_id: str,
        content: str,
        source_type: SourceType,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Ingest document into knowledge system"""
        metadata = metadata or {}

        # Create citation for document
        citation = await self.citation.create_citation(
            source_type=source_type,
            source_id=document_id,
            source_url=metadata.get("url"),
            source_title=metadata.get("title"),
            source_author=metadata.get("author"),
            source_date=metadata.get("date"),
        )

        # Compute trust score
        trust_score = await self.trust.compute_trust_score(
            source_type=source_type,
            source_url=metadata.get("url"),
            source_date=metadata.get("date"),
            citation_count=metadata.get("citation_count", 0),
        )

        # Chunk document for storage
        chunks = await self._chunk_document(content)

        return {
            "document_id": document_id,
            "citation_id": citation.citation_id,
            "trust_score": trust_score.model_dump(),
            "chunks_created": len(chunks),
            "chunk_preview": [c["text"][:100] for c in chunks[:3]],
        }

    async def _chunk_document(
        self,
        content: str,
        chunk_size: int = 1000,
        overlap: int = 100,
    ) -> list[dict[str, Any]]:
        """Split document into chunks"""
        chunks = []
        start = 0

        while start < len(content):
            end = min(start + chunk_size, len(content))
            chunk_text = content[start:end]

            # Try to break at sentence boundaries
            if end < len(content):
                last_period = chunk_text.rfind(".")
                last_newline = chunk_text.rfind("\n")
                break_point = max(last_period, last_newline)

                if break_point > chunk_size // 2:
                    end = start + break_point + 1

            chunks.append({
                "chunk_id": f"chunk_{len(chunks)}",
                "text": content[start:end].strip(),
                "start_index": start,
                "end_index": end,
            })

            start = end - overlap
            if start >= len(content):
                break

        return chunks

    async def extract_metadata(
        self,
        content: str,
        source_type: SourceType,
    ) -> dict[str, Any]:
        """Extract metadata from document content"""
        metadata = {
            "source_type": source_type.value,
            "content_length": len(content),
            "word_count": len(content.split()),
        }

        # Simple metadata extraction
        lines = content.split("\n")
        if lines:
            # First line often contains title
            if len(lines[0]) < 200:
                metadata["title"] = lines[0].strip()

        # Look for dates
        import re
        date_pattern = r'\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}/\d{2,4}'
        dates = re.findall(date_pattern, content)
        if dates:
            metadata["first_date"] = dates[0]

        return metadata