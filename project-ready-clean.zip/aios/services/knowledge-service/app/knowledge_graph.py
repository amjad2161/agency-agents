"""
Knowledge Graph Service - Graph Database and Relationships
Handles graph storage and traversal for knowledge relationships
"""
from typing import Any, Optional, AsyncIterator
from enum import Enum
from datetime import datetime
from uuid import uuid4

from pydantic import BaseModel, Field


class NodeLabel(str, Enum):
    """Graph node labels"""
    ENTITY = "Entity"
    CONCEPT = "Concept"
    EVENT = "Event"
    DOCUMENT = "Document"
    AGENT = "Agent"
    TOOL = "Tool"
    TASK = "Task"
    MEMORY = "Memory"
    POLICY = "Policy"


class RelationshipType(str, Enum):
    """Graph relationship types"""
    RELATED_TO = "RELATED_TO"
    DEPENDS_ON = "DEPENDS_ON"
    PART_OF = "PART_OF"
    CAUSED_BY = "CAUSED_BY"
    REFERENCES = "REFERENCES"
    DERIVED_FROM = "DERIVED_FROM"
    SUPPORTS = "SUPPORTS"
    CONTRADICTS = "CONTRADICTS"
    SUBTYPE_OF = "SUBTYPE_OF"
    INSTANCE_OF = "INSTANCE_OF"


class GraphNode(BaseModel):
    """Graph node structure"""
    node_id: str = Field(default_factory=lambda: str(uuid4()))
    label: NodeLabel
    properties: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    embedding: list[float] | None = None


class GraphRelationship(BaseModel):
    """Graph relationship structure"""
    relationship_id: str = Field(default_factory=lambda: str(uuid4()))
    source_node_id: str
    target_node_id: str
    relationship_type: RelationshipType
    properties: dict[str, Any] = Field(default_factory=dict)
    weight: float = 1.0
    confidence: float = 1.0
    created_at: datetime = Field(default_factory=datetime.utcnow)


class GraphQuery(BaseModel):
    """Graph query specification"""
    start_node_id: str | None = None
    end_node_id: str | None = None
    labels: list[NodeLabel] | None = None
    relationship_types: list[RelationshipType] | None = None
    depth: int = 1
    max_results: int = 100
    property_filters: dict[str, Any] | None = None


class KnowledgeGraphService:
    """Knowledge graph management service"""

    def __init__(self, config: dict[str, Any] | None = None):
        self.config = config or {}
        self._nodes: dict[str, GraphNode] = {}
        self._relationships: list[GraphRelationship] = []
        self._adjacency: dict[str, dict[str, list[str]]] = {}  # node_id -> {relationship_type -> [target_ids]}

    async def initialize(self) -> None:
        """Initialize graph database connection"""
        pass

    # === Node Operations ===

    async def create_node(self, node: GraphNode) -> str:
        """Create new graph node"""
        self._nodes[node.node_id] = node
        if node.node_id not in self._adjacency:
            self._adjacency[node.node_id] = {}
        return node.node_id

    async def get_node(self, node_id: str) -> GraphNode | None:
        """Get node by ID"""
        return self._nodes.get(node_id)

    async def update_node(self, node_id: str, properties: dict[str, Any]) -> GraphNode | None:
        """Update node properties"""
        if node_id not in self._nodes:
            return None
        node = self._nodes[node_id]
        node.properties.update(properties)
        node.updated_at = datetime.utcnow()
        return node

    async def delete_node(self, node_id: str) -> bool:
        """Delete node and its relationships"""
        if node_id not in self._nodes:
            return False

        del self._nodes[node_id]

        # Remove all relationships involving this node
        self._relationships = [
            r for r in self._relationships
            if r.source_node_id != node_id and r.target_node_id != node_id
        ]

        if node_id in self._adjacency:
            del self._adjacency[node_id]

        # Remove from adjacency of other nodes
        for node_id_adj in self._adjacency:
            for rel_type in self._adjacency[node_id_adj]:
                self._adjacency[node_id_adj][rel_type] = [
                    tid for tid in self._adjacency[node_id_adj][rel_type]
                    if tid != node_id
                ]

        return True

    async def find_nodes(
        self,
        label: NodeLabel | None = None,
        property_filters: dict[str, Any] | None = None,
        limit: int = 100,
    ) -> list[GraphNode]:
        """Find nodes by label and properties"""
        results = list(self._nodes.values())

        if label:
            results = [n for n in results if n.label == label]

        if property_filters:
            for node in results[:]:
                if not all(node.properties.get(k) == v for k, v in property_filters.items()):
                    results.remove(node)

        return results[:limit]

    # === Relationship Operations ===

    async def create_relationship(self, relationship: GraphRelationship) -> str:
        """Create new relationship between nodes"""
        if relationship.source_node_id not in self._nodes:
            raise ValueError(f"Source node {relationship.source_node_id} not found")
        if relationship.target_node_id not in self._nodes:
            raise ValueError(f"Target node {relationship.target_node_id} not found")

        self._relationships.append(relationship)

        rel_type = relationship.relationship_type.value
        if rel_type not in self._adjacency.get(relationship.source_node_id, {}):
            self._adjacency.setdefault(relationship.source_node_id, {})[rel_type] = []
        self._adjacency[relationship.source_node_id][rel_type].append(relationship.target_node_id)

        return relationship.relationship_id

    async def get_relationships(
        self,
        node_id: str,
        direction: str = "outgoing",  # outgoing, incoming, both
        relationship_type: RelationshipType | None = None,
    ) -> list[GraphRelationship]:
        """Get relationships for a node"""
        results = []

        for rel in self._relationships:
            if direction in ["outgoing", "both"] and rel.source_node_id == node_id:
                if relationship_type is None or rel.relationship_type == relationship_type:
                    results.append(rel)
            if direction in ["incoming", "both"] and rel.target_node_id == node_id:
                if relationship_type is None or rel.relationship_type == relationship_type:
                    results.append(rel)

        return results

    async def delete_relationship(self, relationship_id: str) -> bool:
        """Delete relationship by ID"""
        for i, rel in enumerate(self._relationships):
            if rel.relationship_id == relationship_id:
                self._relationships.pop(i)
                return True
        return False

    # === Graph Traversal ===

    async def traverse(
        self,
        start_node_id: str,
        max_depth: int = 3,
        relationship_types: list[RelationshipType] | None = None,
        direction: str = "outgoing",
    ) -> list[dict[str, Any]]:
        """Traverse graph from starting node"""
        visited = set()
        results = []
        queue = [(start_node_id, 0, [])]

        while queue:
            node_id, depth, path = queue.pop(0)

            if node_id in visited or depth > max_depth:
                continue

            visited.add(node_id)
            node = self._nodes.get(node_id)
            if node:
                results.append({
                    "node": node,
                    "depth": depth,
                    "path": path,
                })

            # Get neighbors
            rels = await self.get_relationships(node_id, direction)
            for rel in rels:
                if relationship_types and rel.relationship_type not in relationship_types:
                    continue

                target = rel.target_node_id if direction == "outgoing" else rel.source_node_id
                if target not in visited:
                    queue.append((target, depth + 1, path + [rel.relationship_id]))

        return results

    async def find_path(
        self,
        start_node_id: str,
        end_node_id: str,
        max_depth: int = 5,
    ) -> list[list[str]] | None:
        """Find shortest path between two nodes using BFS"""
        if start_node_id == end_node_id:
            return [[start_node_id]]

        visited = {start_node_id}
        queue = [(start_node_id, [start_node_id])]

        while queue:
            current, path = queue.pop(0)

            rels = await self.get_relationships(current, "outgoing")
            for rel in rels:
                if rel.target_node_id == end_node_id:
                    return [path + [rel.target_node_id]]

                if rel.target_node_id not in visited and len(path) < max_depth:
                    visited.add(rel.target_node_id)
                    queue.append((rel.target_node_id, path + [rel.target_node_id]))

        return None

    # === Query Operations ===

    async def query(self, query: GraphQuery) -> list[dict[str, Any]]:
        """Execute graph query"""
        results = []

        # Find start nodes
        if query.start_node_id:
            start_nodes = [query.start_node_id]
        else:
            start_nodes = [
                node_id for node_id, node in self._nodes.items()
                if not query.labels or node.label in query.labels
            ]

        for node_id in start_nodes:
            if query.labels and self._nodes[node_id].label not in query.labels:
                continue

            traverse_results = await self.traverse(
                node_id,
                max_depth=query.depth,
                relationship_types=query.relationship_types,
            )

            for result in traverse_results:
                if query.end_node_id and result["node"].node_id != query.end_node_id:
                    continue
                results.append(result)

                if len(results) >= query.max_results:
                    return results

        return results

    # === Knowledge Extraction ===

    async def extract_entities(self, text: str) -> list[GraphNode]:
        """Extract named entities and create graph nodes"""
        # Simplified - would use NER model in production
        words = text.split()
        entities = []

        for word in words:
            if word[0].isupper() and len(word) > 2:
                node = GraphNode(
                    label=NodeLabel.CONCEPT,
                    properties={"name": word, "text_source": text[:100]},
                )
                node_id = await self.create_node(node)
                entities.append(self._nodes[node_id])

        return entities

    async def link_knowledge(
        self,
        source_node_id: str,
        target_node_id: str,
        relationship: RelationshipType,
        confidence: float = 1.0,
    ) -> str:
        """Link two knowledge nodes with relationship"""
        rel = GraphRelationship(
            source_node_id=source_node_id,
            target_node_id=target_node_id,
            relationship_type=relationship,
            confidence=confidence,
        )
        return await self.create_relationship(rel)

    # === Similarity and Recommendation ===

    async def find_similar_nodes(
        self,
        node_id: str,
        label: NodeLabel | None = None,
        top_k: int = 10,
    ) -> list[tuple[GraphNode, float]]:
        """Find similar nodes using embedding similarity"""
        if node_id not in self._nodes:
            return []

        source_node = self._nodes[node_id]
        if not source_node.embedding:
            return []

        candidates = [
            (nid, node) for nid, node in self._nodes.items()
            if nid != node_id and node.embedding
            and (label is None or node.label == label)
        ]

        # Calculate cosine similarity
        similarities = []
        for nid, node in candidates:
            similarity = self._cosine_similarity(source_node.embedding, node.embedding)
            similarities.append((node, similarity))

        similarities.sort(key=lambda x: x[1], reverse=True)
        return similarities[:top_k]

    def _cosine_similarity(self, vec1: list[float], vec2: list[float]) -> float:
        """Calculate cosine similarity between two vectors"""
        if len(vec1) != len(vec2):
            return 0.0

        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        magnitude1 = sum(a * a for a in vec1) ** 0.5
        magnitude2 = sum(b * b for b in vec2) ** 0.5

        if magnitude1 == 0 or magnitude2 == 0:
            return 0.0

        return dot_product / (magnitude1 * magnitude2)

    # === Statistics ===

    async def get_statistics(self) -> dict[str, Any]:
        """Get graph statistics"""
        label_counts = {}
        for node in self._nodes.values():
            label_counts[node.label.value] = label_counts.get(node.label.value, 0) + 1

        rel_type_counts = {}
        for rel in self._relationships:
            rel_type_counts[rel.relationship_type.value] = (
                rel_type_counts.get(rel.relationship_type.value, 0) + 1
            )

        return {
            "total_nodes": len(self._nodes),
            "total_relationships": len(self._relationships),
            "nodes_by_label": label_counts,
            "relationships_by_type": rel_type_counts,
        }


class KnowledgeGraphRAGBridge:
    """Bridge between knowledge graph and RAG system"""

    def __init__(self, graph_service: KnowledgeGraphService):
        self.graph = graph_service

    async def insert_into_graph(self, document_id: str, chunks: list[dict[str, Any]]) -> None:
        """Insert document chunks into knowledge graph"""
        doc_node = GraphNode(
            label=NodeLabel.DOCUMENT,
            properties={
                "document_id": document_id,
                "chunk_count": len(chunks),
            },
        )
        doc_id = await self.graph.create_node(doc_node)

        for i, chunk in enumerate(chunks):
            chunk_node = GraphNode(
                label=NodeLabel.ENTITY,
                properties={
                    "chunk_index": i,
                    "content_preview": chunk.get("text", "")[:200],
                    "document_id": document_id,
                },
                embedding=chunk.get("embedding"),
            )
            chunk_id = await self.graph.create_node(chunk_node)

            # Link chunk to document
            await self.graph.link_knowledge(
                chunk_id, doc_id, RelationshipType.PART_OF, confidence=1.0
            )

    async def expand_retrieval_with_graph(
        self,
        retrieved_chunks: list[dict[str, Any]],
        expand_depth: int = 2,
    ) -> list[dict[str, Any]]:
        """Expand RAG retrieval using knowledge graph"""
        expanded_context = []

        for chunk in retrieved_chunks:
            chunk_id = chunk.get("node_id")
            if not chunk_id:
                continue

            context = {
                "chunk": chunk,
                "related": [],
            }

            # Get related nodes from graph
            traverse_results = await self.graph.traverse(
                chunk_id,
                max_depth=expand_depth,
            )

            for result in traverse_results:
                if result["depth"] > 0:
                    context["related"].append({
                        "node_id": result["node"].node_id,
                        "label": result["node"].label.value,
                        "properties": result["node"].properties,
                        "depth": result["depth"],
                    })

            expanded_context.append(context)

        return expanded_context

    async def find_knowledge_conflicts(
        self, entity_name: str
    ) -> list[dict[str, Any]]:
        """Find contradictory knowledge in graph"""
        # Find all nodes related to this entity
        nodes = await self.graph.find_nodes(property_filters={"name": entity_name})

        conflicts = []
        checked_pairs = set()

        for node1 in nodes:
            for node2 in nodes:
                if node1.node_id >= node2.node_id:
                    continue

                rels = await self.graph.get_relationships(
                    node1.node_id, "outgoing", RelationshipType.CONTRADICTS
                )

                if any(r.target_node_id == node2.node_id for r in rels):
                    conflicts.append({
                        "node1": node1,
                        "node2": node2,
                        "conflict_type": "explicit_contradiction",
                    })

                # Check for logical conflicts (same entity, different properties)
                if (node1.label == node2.label and
                    node1.label == NodeLabel.CONCEPT):
                    prop_keys = set(node1.properties.keys()) & set(node2.properties.keys())
                    for key in prop_keys:
                        if node1.properties[key] != node2.properties[key]:
                            conflicts.append({
                                "node1": node1,
                                "node2": node2,
                                "conflict_type": "property_mismatch",
                                "property": key,
                                "values": [node1.properties[key], node2.properties[key]],
                            })

        return conflicts