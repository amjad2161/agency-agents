"""
AI-OS Knowledge Pipeline
GraphRAG + Hybrid Search + Real-time Knowledge Synthesis
Integrated from Microsoft GraphRAG architecture
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class IndexingStrategy(str, Enum):
    """Knowledge indexing strategies"""
    NAIVE = "naive"  # Simple chunk + embed
    GRAPH = "graph"  # Knowledge graph extraction
    HYBRID = "hybrid"  # Vector + graph combined


class QueryStrategy(str, Enum):
    """Query execution strategies"""
    LOCAL = "local"  # Specific entity queries
    GLOBAL = "global"  # Global community summaries
    HYBRID = "hybrid"  # Both local and global


@dataclass
class Document:
    """Source document for indexing"""
    doc_id: str
    content: str
    source: str
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)


@dataclass
class Entity:
    """Extracted entity from document"""
    entity_id: str
    name: str
    type: str  # Person, Org, Location, Concept, etc.
    description: str
    sources: list[str] = field(default_factory=list)
    community_id: int | None = None
    embedding: list[float] = field(default_factory=list)


@dataclass
class Relationship:
    """Relationship between entities"""
    relationship_id: str
    source_entity_id: str
    target_entity_id: str
    relationship_type: str  # owns, manages, part_of, etc.
    weight: float = 1.0
    description: str = ""
    sources: list[str] = field(default_factory=list)


@dataclass
class Community:
    """Entity community (from community detection)"""
    community_id: int
    level: int  # Hierarchical level
    summary: str  # Community summary
    findings: list[str] = field(default_factory=list)
    entity_count: int = 0


@dataclass
class KnowledgeGraph:
    """Complete knowledge graph"""
    entities: dict[str, Entity] = field(default_factory=dict)
    relationships: dict[str, Relationship] = field(default_factory=dict)
    communities: dict[int, Community] = field(default_factory=dict)
    document_count: int = 0


@dataclass
class SearchResult:
    """Search result"""
    content: str
    score: float
    source: str
    entity_references: list[str] = field(default_factory=list)
    is_graph_derived: bool = False


class BaseGraphExtractor(ABC):
    """Base class for graph extraction from text"""

    @abstractmethod
    async def extract_entities(self, text: str) -> list[Entity]:
        """Extract entities from text"""
        pass

    @abstractmethod
    async def extract_relationships(
        self,
        text: str,
        entities: list[Entity]
    ) -> list[Relationship]:
        """Extract relationships between entities"""
        pass

    @abstractmethod
    async def summarize_community(
        self,
        entities: list[Entity],
        relationships: list[Relationship]
    ) -> str:
        """Generate community summary"""
        pass


class KnowledgePipeline:
    """
    Knowledge pipeline with GraphRAG.
    Based on Microsoft GraphRAG architecture.
    """

    def __init__(
        self,
        strategy: IndexingStrategy = IndexingStrategy.HYBRID,
        embedding_model: str = "text-embedding-3-small",
        llm_model: str = "gpt-4",
    ):
        self.strategy = strategy
        self.embedding_model = embedding_model
        self.llm_model = llm_model

        self.graph = KnowledgeGraph()
        self.documents: dict[str, Document] = {}
        self.chunks: list[dict[str, Any]] = []

        # Statistics
        self.stats = {
            "documents_indexed": 0,
            "entities_extracted": 0,
            "relationships_found": 0,
            "communities_created": 0,
        }

    async def index_documents(
        self,
        documents: list[Document],
        extractor: BaseGraphExtractor | None = None,
    ) -> KnowledgeGraph:
        """Index documents and build knowledge graph"""
        logger.info(f"Indexing {len(documents)} documents")

        for doc in documents:
            await self._index_document(doc, extractor)

        # Detect communities
        await self._detect_communities(extractor)

        self.stats["documents_indexed"] += len(documents)

        logger.info(f"Indexed: {self.stats}")
        return self.graph

    async def _index_document(
        self,
        doc: Document,
        extractor: BaseGraphExtractor | None = None,
    ) -> None:
        """Index single document"""
        self.documents[doc.doc_id] = doc

        # Chunk document
        chunks = self._chunk_document(doc.content)
        self.chunks.extend(chunks)

        if extractor and self.strategy != IndexingStrategy.NAIVE:
            # Extract entities
            entities = await extractor.extract_entities(doc.content)
            for entity in entities:
                self.graph.entities[entity.entity_id] = entity

            # Extract relationships
            relationships = await extractor.extract_relationships(
                doc.content, entities
            )
            for rel in relationships:
                self.graph.relationships[rel.relationship_id] = rel

            self.stats["entities_extracted"] += len(entities)
            self.stats["relationships_found"] += len(relationships)

    def _chunk_document(self, content: str, chunk_size: int = 300) -> list[dict[str, Any]]:
        """Split document into chunks"""
        words = content.split()
        chunks = []
        current_chunk = []
        current_size = 0

        for word in words:
            current_chunk.append(word)
            current_size += len(word) + 1

            if current_size >= chunk_size:
                chunk_text = " ".join(current_chunk)
                chunk_hash = hashlib.md5(chunk_text.encode()).hexdigest()[:12]

                chunks.append({
                    "chunk_id": f"chunk_{chunk_hash}",
                    "content": chunk_text,
                    "size": current_size,
                })

                current_chunk = []
                current_size = 0

        if current_chunk:
            chunk_text = " ".join(current_chunk)
            chunk_hash = hashlib.md5(chunk_text.encode()).hexdigest()[:12]
            chunks.append({
                "chunk_id": f"chunk_{chunk_hash}",
                "content": chunk_text,
                "size": current_size,
            })

        return chunks

    async def _detect_communities(
        self,
        extractor: BaseGraphExtractor | None = None,
    ) -> None:
        """Detect communities using Leiden algorithm (simplified)"""
        # Simplified community detection
        # In production, would use proper graph algorithms

        entities_by_type: dict[str, list[str]] = {}
        for entity_id, entity in self.graph.entities.items():
            if entity.type not in entities_by_type:
                entities_by_type[entity.type] = []
            entities_by_type[entity.type].append(entity_id)

        community_id = 0
        for entity_type, entity_ids in entities_by_type.items():
            if len(entity_ids) > 0:
                community = Community(
                    community_id=community_id,
                    level=0,
                    summary=f"Community of {entity_type} entities",
                    entity_count=len(entity_ids),
                )

                if extractor and self.strategy == IndexingStrategy.HYBRID:
                    entities = [self.graph.entities[eid] for eid in entity_ids]
                    community.summary = await extractor.summarize_community(
                        entities, []
                    )

                self.graph.communities[community_id] = community

                for eid in entity_ids:
                    self.graph.entities[eid].community_id = community_id

                community_id += 1

        self.stats["communities_created"] = len(self.graph.communities)

    async def query(
        self,
        query: str,
        strategy: QueryStrategy = QueryStrategy.HYBRID,
        top_k: int = 10,
    ) -> list[SearchResult]:
        """Query the knowledge graph"""
        logger.info(f"Querying with strategy: {strategy}")

        results: list[SearchResult] = []

        if strategy == QueryStrategy.LOCAL:
            results = await self._query_local(query, top_k)
        elif strategy == QueryStrategy.GLOBAL:
            results = await self._query_global(query, top_k)
        elif strategy == QueryStrategy.HYBRID:
            local_results = await self._query_local(query, top_k // 2)
            global_results = await self._query_global(query, top_k // 2)
            results = self._merge_results(local_results, global_results, query)

        return results[:top_k]

    async def _query_local(
        self,
        query: str,
        top_k: int,
    ) -> list[SearchResult]:
        """Local entity queries"""
        results = []

        # Search for entities matching query
        query_lower = query.lower()
        for entity_id, entity in self.graph.entities.items():
            if (query_lower in entity.name.lower() or
                query_lower in entity.description.lower()):
                results.append(SearchResult(
                    content=entity.description,
                    score=0.9,
                    source=f"entity:{entity.name}",
                    entity_references=[entity_id],
                    is_graph_derived=True,
                ))

        # Search chunks
        for chunk in self.chunks:
            if query_lower in chunk["content"].lower():
                results.append(SearchResult(
                    content=chunk["content"],
                    score=0.7,
                    source=f"chunk:{chunk['chunk_id']}",
                    is_graph_derived=False,
                ))

        return results

    async def _query_global(
        self,
        query: str,
        top_k: int,
    ) -> list[SearchResult]:
        """Global community summary queries"""
        results = []

        # Get community summaries
        for community_id, community in self.graph.communities.items():
            results.append(SearchResult(
                content=community.summary,
                score=0.8,
                source=f"community:{community_id}",
                entity_references=[
                    eid for eid, e in self.graph.entities.items()
                    if e.community_id == community_id
                ],
                is_graph_derived=True,
            ))

        return results

    def _merge_results(
        self,
        local: list[SearchResult],
        global_results: list[SearchResult],
        query: str,
    ) -> list[SearchResult]:
        """Merge and rerank results using RRF"""
        all_results = local + global_results

        # Reciprocal Rank Fusion
        scored: dict[str, SearchResult] = {}
        for i, result in enumerate(all_results):
            key = result.source
            if key not in scored:
                scored[key] = result

            # RRF scoring
            rank = i + 1
            new_score = result.score + (1.0 / (60 + rank))
            scored[key] = SearchResult(
                content=result.content,
                score=new_score,
                source=result.source,
                entity_references=result.entity_references,
                is_graph_derived=result.is_graph_derived,
            )

        return list(scored.values())

    def get_graph_stats(self) -> dict[str, Any]:
        """Get knowledge graph statistics"""
        return {
            "documents": self.stats["documents_indexed"],
            "chunks": len(self.chunks),
            "entities": len(self.graph.entities),
            "relationships": len(self.graph.relationships),
            "communities": len(self.graph.communities),
            "entity_types": list(set(e.type for e in self.graph.entities.values())),
        )


# Example extractor implementation
class LLMGraphExtractor(BaseGraphExtractor):
    """LLM-based graph extractor"""

    async def extract_entities(self, text: str) -> list[Entity]:
        """Extract entities using LLM"""
        # Simplified - would use LLM for extraction
        # Looking for patterns like "X is Y" or "X who Y"

        entities = []
        words = text.split()

        for i, word in enumerate(words):
            # Simple heuristic: Capitalized words might be entities
            if word and word[0].isupper() and len(word) > 2:
                entity_id = hashlib.md5(word.encode()).hexdigest()[:12]
                entities.append(Entity(
                    entity_id=f"entity_{entity_id}",
                    name=word,
                    type="Concept",
                    description=f"Found in context: {text[max(0, i*20):i*20+100]}",
                    sources=["text"],
                ))

        return entities[:20]  # Limit for demo

    async def extract_relationships(
        self,
        text: str,
        entities: list[Entity]
    ) -> list[Relationship]:
        """Extract relationships using LLM"""
        relationships = []

        # Simple pattern matching for relationships
        relation_patterns = [
            ("works for", ["works for", "employed by"]),
            ("located in", ["located in", "based in"]),
            ("part of", ["part of", "member of"]),
        ]

        for rel_type, patterns in relation_patterns:
            for pattern in patterns:
                if pattern in text.lower():
                    rel_id = hashlib.md5(f"{rel_type}_{text[:50]}".encode()).hexdigest()[:12]
                    relationships.append(Relationship(
                        relationship_id=f"rel_{rel_id}",
                        source_entity_id=entities[0].entity_id if entities else "",
                        target_entity_id=entities[-1].entity_id if len(entities) > 1 else "",
                        relationship_type=rel_type,
                        description=f"Found via pattern: {pattern}",
                    ))

        return relationships[:10]

    async def summarize_community(
        self,
        entities: list[Entity],
        relationships: list[Relationship]
    ) -> str:
        """Generate community summary"""
        if not entities:
            return "Empty community"

        entity_types = list(set(e.type for e in entities))
        return f"This community contains {len(entities)} {', '.join(entity_types)} entities"


async def example():
    """Example knowledge pipeline usage"""
    pipeline = KnowledgePipeline(
        strategy=IndexingStrategy.HYBRID,
    )

    # Sample documents
    docs = [
        Document(
            doc_id="doc1",
            content="Apple Inc. is a technology company based in Cupertino, California. "
                    "Steve Jobs was a co-founder. Tim Cook is the CEO.",
            source="wikipedia",
        ),
        Document(
            doc_id="doc2",
            content="Microsoft was founded by Bill Gates and Paul Allen. "
                    "Satya Nadella is the current CEO. The company is based in Redmond.",
            source="wikipedia",
        ),
    ]

    extractor = LLMGraphExtractor()

    # Index
    graph = await pipeline.index_documents(docs, extractor)

    # Query
    results = await pipeline.query("Who is the CEO of tech companies?", QueryStrategy.HYBRID)

    print("Graph Stats:", pipeline.get_graph_stats())
    print("\nQuery Results:")
    for r in results[:5]:
        print(f"  - {r.source}: {r.content[:80]}...")

    print(f"\nTotal entities: {len(graph.entities)}")
    print(f"Total relationships: {len(graph.relationships)}")


if __name__ == "__main__":
    asyncio.run(example())
