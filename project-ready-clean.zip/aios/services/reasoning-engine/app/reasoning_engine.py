"""
AI-OS Reasoning Engine
Tree of Thoughts + Chain of Thought + Advanced Reasoning
"""
from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class ReasoningStrategy(str, Enum):
    """Reasoning strategies"""
    CHAIN_OF_THOUGHT = "chain_of_thought"
    TREE_OF_THOUGHTS = "tree_of_thoughts"
    GRAPH_OF_THOUGHTS = "graph_of_thoughts"
    REACT = "react"
    REFLEXION = "reflexion"


class SearchMethod(str, Enum):
    """Search methods for tree search"""
    BFS = "bfs"
    DFS = "dfs"
    BEAM = "beam"
    MONTE_CARLO = "monte_carlo"


@dataclass
class ThoughtStep:
    """Single thought in reasoning chain"""
    step_id: int
    thought: str
    action: str | None = None
    observation: str | None = None
    confidence: float = 0.0
    parent_id: int | None = None
    children_ids: list[int] = field(default_factory=list)


@dataclass
class ReasoningTrace:
    """Complete reasoning trace"""
    strategy: ReasoningStrategy
    problem: str
    steps: list[ThoughtStep]
    final_answer: str
    confidence_score: float
    alternatives_considered: int
    search_path: list[int]  # Path from root to final answer
    duration_ms: float
    token_usage: int


@dataclass
class ThoughtState:
    """State in tree search"""
    state_id: str
    content: str
    value: float = 0.0
    depth: int = 0
    parent: str | None = None
    children: list[str] = field(default_factory=list)
    is_complete: bool = False
    is_terminal: bool = False


@dataclass
class ReasoningConfig:
    """Configuration for reasoning engine"""
    strategy: ReasoningStrategy = ReasoningStrategy.TREE_OF_THOUGHTS
    max_depth: int = 10
    max_branches: int = 5
    n_generate_sample: int = 1
    n_evaluate_sample: int = 3
    n_select_sample: int = 5
    temperature: float = 0.7
    search_method: SearchMethod = SearchMethod.BFS
    enable_reflection: bool = True
    max_reflection_rounds: int = 2


class ReasoningTask(ABC):
    """Base class for reasoning tasks"""

    @abstractmethod
    def generate_thoughts(self, state: str, n: int) -> list[str]:
        """Generate candidate thoughts from state"""
        pass

    @abstractmethod
    def evaluate_states(self, states: list[str], goal: str) -> list[float]:
        """Evaluate states and return value scores"""
        pass

    @abstractmethod
    def is_terminal(self, state: str) -> bool:
        """Check if state is terminal (solution found)"""
        pass

    @abstractmethod
    def get_answer(self, state: str) -> str:
        """Extract answer from terminal state"""
        pass


class ReasoningEngine:
    """
    Advanced reasoning engine with Tree of Thoughts, Chain of Thought, etc.
    Based on Yao et al. "Tree of Thoughts" (NeurIPS 2023).
    """

    def __init__(self, config: ReasoningConfig | None = None):
        self.config = config or ReasoningConfig()
        self.thought_history: list[ThoughtStep] = []
        self.state_history: dict[str, ThoughtState] = {}

    async def solve(
        self,
        problem: str,
        task: ReasoningTask,
    ) -> ReasoningTrace:
        """Solve problem using configured reasoning strategy"""
        start_time = datetime.utcnow()

        if self.config.strategy == ReasoningStrategy.CHAIN_OF_THOUGHT:
            return await self._chain_of_thought(problem, task)
        elif self.config.strategy == ReasoningStrategy.TREE_OF_THOUGHTS:
            return await self._tree_of_thoughts(problem, task)
        elif self.config.strategy == ReasoningStrategy.REACT:
            return await self._react_reasoning(problem, task)
        elif self.config.strategy == ReasoningStrategy.REFLEXION:
            return await self._reflexion(problem, task)
        else:
            return await self._chain_of_thought(problem, task)

    async def _chain_of_thought(
        self,
        problem: str,
        task: ReasoningTask,
    ) -> ReasoningTrace:
        """Chain of Thought reasoning"""
        steps = []
        state = problem
        step_id = 0
        alternatives = 0

        while not task.is_terminal(state) and step_id < self.config.max_depth:
            # Generate thoughts
            thoughts = task.generate_thoughts(state, 1)
            if not thoughts:
                break

            thought = thoughts[0]

            # Evaluate
            values = task.evaluate_states([thought], problem)
            confidence = values[0] if values else 0.5

            step = ThoughtStep(
                step_id=step_id,
                thought=thought,
                confidence=confidence,
            )
            steps.append(step)
            self.thought_history.append(step)

            state = thought
            step_id += 1

        duration = (datetime.utcnow() - start_time).total_seconds() * 1000

        return ReasoningTrace(
            strategy=ReasoningStrategy.CHAIN_OF_THOUGHT,
            problem=problem,
            steps=steps,
            final_answer=task.get_answer(state),
            confidence_score=sum(s.confidence for s in steps) / len(steps) if steps else 0.0,
            alternatives_considered=alternatives,
            search_path=list(range(len(steps))),
            duration_ms=duration,
            token_usage=len(" ".join([s.thought for s in steps])) // 4,
        )

    async def _tree_of_thoughts(
        self,
        problem: str,
        task: ReasoningTask,
    ) -> ReasoningTrace:
        """Tree of Thoughts reasoning with BFS/DFS"""
        start_time = datetime.utcnow()

        steps: list[ThoughtStep] = []
        states: dict[str, ThoughtState] = {}
        final_answer = ""
        best_score = 0.0
        alternatives = 0

        # Initialize with problem
        root_state = ThoughtState(
            state_id="root",
            content=problem,
            depth=0,
        )
        states["root"] = root_state
        current_frontier = ["root"]

        step_id = 0

        while current_frontier and step_id < self.config.max_depth:
            new_frontier = []

            for state_id in current_frontier:
                state = states[state_id]

                if task.is_terminal(state.content):
                    # Found solution
                    answer = task.get_answer(state.content)
                    score = 1.0 - (state.depth / self.config.max_depth)
                    if score > best_score:
                        best_score = score
                        final_answer = answer
                    state.is_complete = True
                    continue

                # Generate candidate thoughts
                if self.config.search_method == SearchMethod.BFS:
                    thoughts = task.generate_thoughts(
                        state.content,
                        self.config.n_select_sample
                    )
                else:
                    thoughts = task.generate_thoughts(
                        state.content,
                        self.config.n_generate_sample
                    )

                alternatives += len(thoughts)

                for thought in thoughts:
                    child_id = f"step_{step_id}"
                    child_state = ThoughtState(
                        state_id=child_id,
                        content=thought,
                        depth=state.depth + 1,
                        parent=state_id,
                    )

                    # Evaluate
                    values = task.evaluate_states([thought], problem)
                    child_state.value = values[0] if values else 0.5

                    states[child_id] = child_state
                    state.children.append(child_id)
                    new_frontier.append(child_id)

                    step = ThoughtStep(
                        step_id=step_id,
                        thought=thought,
                        confidence=child_state.value,
                        parent_id=step_id - 1 if step_id > 0 else None,
                    )
                    steps.append(step)
                    self.thought_history.append(step)

                    step_id += 1

            # Select top states for next iteration
            if new_frontier and self.config.n_select_sample < len(new_frontier):
                scored = [(sid, states[sid].value) for sid in new_frontier]
                scored.sort(key=lambda x: x[1], reverse=True)
                current_frontier = [s[0] for s in scored[:self.config.n_select_sample]]
            else:
                current_frontier = new_frontier

        duration = (datetime.utcnow() - start_time).total_seconds() * 1000

        return ReasoningTrace(
            strategy=ReasoningStrategy.TREE_OF_THOUGHTS,
            problem=problem,
            steps=steps,
            final_answer=final_answer or task.get_answer(problem),
            confidence_score=best_score,
            alternatives_considered=alternatives,
            search_path=[s.step_id for s in steps],
            duration_ms=duration,
            token_usage=len(" ".join([s.thought for s in steps])) // 4,
        )

    async def _react_reasoning(
        self,
        problem: str,
        task: ReasoningTask,
    ) -> ReasoningTrace:
        """REACT-style reasoning (Reasoning + Acting)"""
        steps = []
        state = problem
        step_id = 0
        max_steps = self.config.max_depth

        while not task.is_terminal(state) and step_id < max_steps:
            # Thought
            thoughts = task.generate_thoughts(state, 1)
            thought = thoughts[0] if thoughts else "Continue reasoning..."

            # Action (simulate)
            action = f"Action_{step_id}"

            # Observation
            values = task.evaluate_states([state], problem)
            observation = f"Evaluated with score: {values[0] if values else 0.5}"

            step = ThoughtStep(
                step_id=step_id,
                thought=thought,
                action=action,
                observation=observation,
                confidence=values[0] if values else 0.5,
            )
            steps.append(step)
            self.thought_history.append(step)

            state = thought
            step_id += 1

        duration = (datetime.utcnow() - start_time).total_seconds() * 1000

        return ReasoningTrace(
            strategy=ReasoningStrategy.REACT,
            problem=problem,
            steps=steps,
            final_answer=task.get_answer(state),
            confidence_score=sum(s.confidence for s in steps) / len(steps) if steps else 0.0,
            alternatives_considered=0,
            search_path=list(range(len(steps))),
            duration_ms=duration,
            token_usage=len(" ".join([f"{s.thought} {s.observation}" for s in steps])) // 4,
        )

    async def _reflexion(
        self,
        problem: str,
        task: ReasoningTask,
    ) -> ReasoningTrace:
        """Reflexion: Self-reflective reasoning"""
        max_rounds = self.config.max_reflection_rounds
        best_trace = None
        best_score = 0.0

        for round_num in range(max_rounds):
            # Generate solution
            trace = await self._chain_of_thought(problem, task)

            # Self-reflect
            reflection = await self._reflect_on_trace(trace, task)

            if reflection["score"] > best_score:
                best_score = reflection["score"]
                best_trace = trace

            if best_score >= 0.95:
                break

            # Adjust based on reflection
            problem = f"{problem}\n\nPrevious attempt feedback: {reflection['feedback']}"

        return best_trace or trace


# Example task implementation
class GameOf24Task(ReasoningTask):
    """Game of 24: Use numbers to make 24"""

    def __init__(self, numbers: list[int]):
        self.numbers = numbers
        self.target = 24

    def generate_thoughts(self, state: str, n: int) -> list[str]:
        """Generate possible next expressions"""
        # Simplified - would parse state and generate expressions
        expressions = [
            f"({state} + {self.numbers[0]}) * {self.numbers[1]}",
            f"({state} - {self.numbers[0]}) / {self.numbers[1]}",
            f"({state} + {self.numbers[0]}) + {self.numbers[1]}",
        ]
        return expressions[:n]

    def evaluate_states(self, states: list[str], goal: str) -> list[float]:
        """Evaluate closeness to target"""
        scores = []
        for state in states:
            try:
                # Extract numbers and check if close to target
                score = 1.0 - abs(24 - 20) / 24  # Simplified
                scores.append(max(0.0, min(1.0, score)))
            except:
                scores.append(0.5)
        return scores

    def is_terminal(self, state: str) -> bool:
        """Check if solved"""
        try:
            result = eval(state)
            return abs(result - 24) < 0.001
        except:
            return False

    def get_answer(self, state: str) -> str:
        """Get final answer"""
        return state


async def example():
    """Example reasoning"""
    engine = ReasoningEngine(ReasoningConfig(
        strategy=ReasoningStrategy.TREE_OF_THOUGHTS,
        max_depth=5,
        n_select_sample=3,
    ))

    task = GameOf24Task([4, 4, 4, 4])
    result = await engine.solve("4 + 4 + 4 + 4", task)

    print(f"Strategy: {result.strategy}")
    print(f"Steps: {len(result.steps)}")
    print(f"Answer: {result.final_answer}")
    print(f"Confidence: {result.confidence_score:.2f}")
    print(f"Alternatives: {result.alternatives_considered}")


if __name__ == "__main__":
    asyncio.run(example())
