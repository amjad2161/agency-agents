"""
AI-OS Multi-Modal Cross-Lingual Engine
Cross-lingual content generation with RTL support for Arabic & Hebrew
Integrates with language-service for proper text handling
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class ContentModality(str, Enum):
    """Content modality types"""
    TEXT = "text"
    IMAGE = "image"
    VIDEO = "video"
    AUDIO = "audio"


class ImageStyle(str, Enum):
    """Image generation styles with RTL adaptations"""
    PHOTOREALISTIC = "photorealistic"
    ILLUSTRATION = "illustration"
    ABSTRACT = "abstract"
    ARABIC_CALLIGRAPHY = "arabic_calligraphy"
    HEBREW_CALLIGRAPHY = "hebrew_calligraphy"
    RTL_DOCUMENT = "rtl_document"
    ISLAMIC_ART = "islamic_art"
    JEWISH_ART = "jewish_art"


class VideoStyle(str, Enum):
    """Video generation styles with RTL adaptations"""
    CINEMATIC = "cinematic"
    DOCUMENTARY = "documentary"
    ANIMATION = "animation"
    ARABIC_NARRATIVE = "arabic_narrative"
    HEBREW_NARRATIVE = "hebrew_narrative"
    RTL_EXPLANATION = "rtl_explanation"


@dataclass
class CrossLingualPrompt:
    """Cross-lingual prompt with RTL metadata"""
    original_prompt: str
    target_language: str
    text_direction: str = "LTR"
    text_overlay: dict[str, str] | None = None
    style_guidance: dict[str, Any] = field(default_factory=dict)
    cultural_context: dict[str, Any] = field(default_factory=dict)
    visual_elements: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ImageGenerationRequest:
    """Image generation request with cross-lingual support"""
    prompt: CrossLingualPrompt
    style: ImageStyle = ImageStyle.PHOTOREALISTIC
    aspect_ratio: str = "1:1"
    resolution: str = "1024x1024"
    quality: str = "high"
    seed: int | None = None
    guidance_scale: float = 7.5
    safety_check: bool = True


@dataclass
class VideoGenerationRequest:
    """Video generation request with cross-lingual support"""
    prompt: CrossLingualPrompt
    style: VideoStyle = VideoStyle.CINEMATIC
    duration: int = 6
    resolution: str = "1024x768"
    fps: int = 24
    seed: int | None = None
    motion_strength: float = 0.5
    safety_check: bool = True


@dataclass
class GeneratedContent:
    """Generated content result"""
    content_id: str
    modality: ContentModality
    url: str = ""
    local_path: str = ""
    prompt_used: str
    generation_params: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    rtl_optimized: bool = False
    language: str = "en"


@dataclass
class CulturalElement:
    """Cultural element for cross-lingual generation"""
    element_id: str
    name: str
    language: str
    category: str
    description: str
    visual_keywords: list[str]
    text_samples: list[str]
    usage_context: str


@dataclass
class CalligraphyStyle:
    """Calligraphy style for RTL languages"""
    style_id: str
    name: str
    language: str
    characteristics: list[str]
    common_uses: list[str]
    font_suggestions: list[str]


# RTL Language Configuration
RTL_LANGUAGES = {
    "ar": {
        "name": "Arabic",
        "direction": "RTL",
        "script": "العربية",
        "calligraphy_styles": [
            "thuluth", "naskh", "dIWani", "ruqaa", "kufic", "persian"
        ],
        "cultural_elements": {
            "islamic": ["mosque", "geometric_patterns", "arabesque", "crescent"],
            "traditional": ["souq", "desert", "oasis", "caravan", "falcon"],
            "modern": ["skyline", "technology", "business"],
        },
        "color_symbolism": {
            "green": "Islamic, paradise, nature",
            "gold": "Royalty, prosperity, wisdom",
            "blue": " spirituality, heaven, protection",
            "white": "Purity, peace",
        },
        "visual_composition": "right_to_left_flow",
    },
    "he": {
        "name": "Hebrew",
        "direction": "RTL",
        "script": "עברית",
        "calligraphy_styles": [
            "block_letter", "cursive", "Rashi", "Crown", "Sephardic"
        ],
        "cultural_elements": {
            "jewish": ["star_of_david", "menorah", "torah", "hamesh_hand"],
            "israeli": ["flag", "david_star", "jerusalem", "zionism"],
            "traditional": ["shtetl", "diaspora", "holocaust_memorial"],
            "modern": ["tech_hub", "startup_nation", "tel_aviv"],
        },
        "color_symbolism": {
            "blue": "Jewish identity, sky, spirituality",
            "white": "Purity, Torah, tallit",
            "gold": "Joy, Hanukkah, prosperity",
            "purple": "Royalty, spirituality",
        },
        "visual_composition": "right_to_left_flow",
    },
}

# Cross-lingual translation patterns for prompts
TRANSLATION_ENHANCEMENTS = {
    "ar": {
        "additions": [
            "in Arabic artistic style",
            "with Arabic calligraphy",
            "Arabic cultural elements",
            "Arabic script and typography",
            "Islamic geometric patterns",
        ],
        "cultural_boosters": [
            "traditional Arabic architecture",
            "Arabic coffee (qahwa) setting",
            "Middle Eastern landscape",
            "Arabic marketplace atmosphere",
            "Desert OASIS backdrop",
        ],
    },
    "he": {
        "additions": [
            "in Hebrew artistic style",
            "with Hebrew calligraphy",
            "Jewish cultural elements",
            "Hebrew script and typography",
            "Star of David motifs",
        ],
        "cultural_boosters": [
            "traditional Jewish setting",
            "Jerusalem stone architecture",
            "Mediterranean atmosphere",
            "Tel Aviv modern skyline",
            "Jewish historical context",
        ],
    },
}


class CulturalElementLibrary:
    """Library of cultural elements for cross-lingual generation"""

    def __init__(self):
        self.elements: dict[str, CulturalElement] = {}
        self.calligraphy_styles: dict[str, CalligraphyStyle] = {}
        self._initialize_elements()

    def _initialize_elements(self):
        """Initialize cultural elements library"""

        # Arabic cultural elements
        arabic_elements = [
            CulturalElement(
                element_id="ar_mosque",
                name="Mosque Architecture",
                language="ar",
                category="islamic",
                description="Traditional Islamic mosque with minarets and domes",
                visual_keywords=["dome", "minaret", "geometric_tiles", "arched_entrance", "courtyard"],
                text_samples=["مسجد", "جامع", "��الله"],
                usage_context="religious_architecture",
            ),
            CulturalElement(
                element_id="ar_geometric",
                name="Islamic Geometric Patterns",
                language="ar",
                category="islamic_art",
                description="Intricate Islamic geometric tessellations",
                visual_keywords=["tessellation", "star_pattern", "arabesque", "symmetry", "zellige"],
                text_samples=["زخرفة", "نقش", "ت着一个"],
                usage_context="decorative_art",
            ),
            CulturalElement(
                element_id="ar_coffee",
                name="Arabic Coffee Ceremony",
                language="ar",
                category="tradition",
                description="Arabic coffee serving with dallah and dates",
                visual_keywords=["dallah", "coffee_cup", "dates", "incense", "traditional_rug"],
                text_samples=["قهوة عربية", "دلة", "تمر", "بخور"],
                usage_context="social_gathering",
            ),
            CulturalElement(
                element_id="ar_desert",
                name="Desert Landscape",
                language="ar",
                category="landscape",
                description="Arabian desert with dunes, oasis, and stars",
                visual_keywords=["sand_dunes", "oasis", "palm_trees", "desert_sky", "camel", "tent"],
                text_samples=["صحراء", "واحة", "نخيل", "بادية"],
                usage_context="landscape",
            ),
            CulturalElement(
                element_id="ar_calligraphy",
                name="Arabic Calligraphy Art",
                language="ar",
                category="art",
                description="Arabic calligraphy in various styles",
                visual_keywords=["thuluth", "naskh", "dIWani", "diacritics", "ink", "paper"],
                text_samples=["خط عربي", "ثلث", "نسخ", "ديواني"],
                usage_context="calligraphy",
            ),
        ]

        # Hebrew cultural elements
        hebrew_elements = [
            CulturalElement(
                element_id="he_menorah",
                name="Menorah",
                language="he",
                category="jewish",
                description="Jewish menorah with seven or nine branches",
                visual_keywords=["branches", "candles", "flames", "golden", "star_shape"],
                text_samples=["מנורה", "חנוכה", "נרות"],
                usage_context="religious_symbol",
            ),
            CulturalElement(
                element_id="he_torah",
                name="Torah Scroll",
                language="he",
                category="jewish",
                description="Torah scroll with Hebrew script",
                visual_keywords=["scroll", "pointer", "crown", "hebrew_letters", "roller"],
                text_samples=["תורה", "ספר", "קלף"],
                usage_context="religious_text",
            ),
            CulturalElement(
                element_id="he_jerusalem",
                name="Jerusalem Architecture",
                language="he",
                category="landmark",
                description="Jerusalem stone buildings and holy sites",
                visual_keywords=["jerusalem_stone", "dome_of_rock", "western_wall", "old_city", "arches"],
                text_samples=["ירושלים", "כותל", "עיר העתיקה"],
                text_samples=["ירושלים", "כותל", "עיר העתיקה"],
                usage_context="landmark",
            ),
            CulturalElement(
                element_id="he_telaviv",
                name="Tel Aviv Modern Cityscape",
                language="he",
                category="modern",
                description="Modern Tel Aviv with Bauhaus architecture",
                visual_keywords=["bauhaus", "white_buildings", "mediterranean", "beach", "skyscraper"],
                text_samples=["תל אביב", "באוהאוס", "ים תיכון"],
                usage_context="modern_city",
            ),
            CulturalElement(
                element_id="he_calligraphy",
                name="Hebrew Calligraphy Art",
                language="he",
                category="art",
                description="Hebrew calligraphy in various styles",
                visual_keywords=["block_letter", "cursive", "serif", "scroll", "tablet"],
                text_samples=["כתב עברי", "אותיות", "קלף"],
                usage_context="calligraphy",
            ),
        ]

        for element in arabic_elements + hebrew_elements:
            self.elements[element.element_id] = element

        # Initialize calligraphy styles
        self.calligraphy_styles = {
            "ar_thuluth": CalligraphyStyle(
                style_id="ar_thuluth",
                name="Thuluth Script",
                language="ar",
                characteristics=["flowing", "decorative", "curved", "large"],
                common_uses=["architectural inscriptions", "title treatments"],
                font_suggestions=["Thuluth Script", "Arabic Thuluth"],
            ),
            "ar_naskh": CalligraphyStyle(
                style_id="ar_naskh",
                name="Naskh Script",
                language="ar",
                characteristics=["clear", "legible", "small", "angular"],
                common_uses=["print", "books", "official documents"],
                font_suggestions=["Traditional Naskh", "Naskh"],
            ),
            "he_block": CalligraphyStyle(
                style_id="he_block",
                name="Hebrew Block Letters",
                language="he",
                characteristics=["angular", "clear", "formal", "ancient"],
                common_uses=["torah scrolls", "ceremonial texts", "inscriptions"],
                font_suggestions=["Franken Ruhl", "Hebrew Block"],
            ),
            "he_cursive": CalligraphyStyle(
                style_id="he_cursive",
                name="Hebrew Cursive",
                language="he",
                characteristics=["flowing", "connected", "modern", "rapid"],
                common_uses=["handwriting", "modern documents", "everyday use"],
                font_suggestions=["Cursive Hebrew", "Rashi Script"],
            ),
        }

    async def get_cultural_elements(
        self,
        language: str,
        category: str | None = None,
    ) -> list[CulturalElement]:
        """Get cultural elements by language and category"""
        results = []
        for element in self.elements.values():
            if element.language == language:
                if category is None or element.category == category:
                    results.append(element)
        return results

    async def get_calligraphy_style(
        self,
        language: str,
        style_name: str | None = None,
    ) -> list[CalligraphyStyle]:
        """Get calligraphy styles by language"""
        results = []
        for style in self.calligraphy_styles.values():
            if style.language == language:
                if style_name is None or style.name.lower() in style_name.lower():
                    results.append(style)
        return results


class CrossLingualEngine:
    """
    Cross-lingual content generation engine.
    Handles RTL language support for image and video generation.
    """

    def __init__(
        self,
        image_model: str = "dalle-3",
        video_model: str = "sora",
        enable_cultural_elements: bool = True,
    ):
        self.image_model = image_model
        self.video_model = video_model
        self.enable_cultural_elements = enable_cultural_elements

        self.cultural_library = CulturalElementLibrary()
        self.rtl_languages = RTL_LANGUAGES

        # Statistics
        self.stats = {
            "images_generated": 0,
            "videos_generated": 0,
            "languages_supported": len(RTL_LANGUAGES),
            "cultural_elements_loaded": len(self.cultural_library.elements),
        }

    async def prepare_image_prompt(
        self,
        prompt: str,
        language: str = "ar",
        style: ImageStyle = ImageStyle.PHOTOREALISTIC,
        include_cultural_elements: bool = True,
    ) -> ImageGenerationRequest:
        """Prepare RTL-aware image generation request"""

        rtl_config = self.rtl_languages.get(language, {})
        text_direction = rtl_config.get("direction", "LTR")

        # Build cross-lingual prompt
        cross_lingual_prompt = CrossLingualPrompt(
            original_prompt=prompt,
            target_language=language,
            text_direction=text_direction,
        )

        # Add style guidance based on language
        if language in RTL_LANGUAGES:
            style_guidance = {
                "text_direction": text_direction,
                "calligraphy_style": style in [ImageStyle.ARABIC_CALLIGRAPHY, ImageStyle.HEBREW_CALLIGRAPHY],
                "cultural_boost": include_cultural_elements,
                "color_palette": self._get_color_palette(language, prompt),
            }
            cross_lingual_prompt.style_guidance = style_guidance

            # Add cultural context
            cultural_context = {
                "language": rtl_config.get("name"),
                "script": rtl_config.get("script"),
                "cultural_elements": rtl_config.get("cultural_elements", {}),
                "visual_composition": rtl_config.get("visual_composition"),
            }
            cross_lingual_prompt.cultural_context = cultural_context

        # Add visual elements based on cultural library
        if include_cultural_elements and self.enable_cultural_elements:
            visual_elements = await self._get_visual_elements(language, style)
            cross_lingual_prompt.visual_elements = visual_elements

        # Build enhanced prompt
        enhanced_prompt = self._build_enhanced_prompt(
            prompt, language, style, cross_lingual_prompt
        )
        cross_lingual_prompt.metadata["enhanced_prompt"] = enhanced_prompt
        cross_lingual_prompt.metadata["original_style"] = style.value

        return ImageGenerationRequest(
            prompt=cross_lingual_prompt,
            style=style,
            rtl_optimized=language in RTL_LANGUAGES,
        )

    async def prepare_video_prompt(
        self,
        prompt: str,
        language: str = "ar",
        style: VideoStyle = VideoStyle.CINEMATIC,
        duration: int = 6,
        include_cultural_elements: bool = True,
    ) -> VideoGenerationRequest:
        """Prepare RTL-aware video generation request"""

        rtl_config = self.rtl_languages.get(language, {})
        text_direction = rtl_config.get("direction", "LTR")

        cross_lingual_prompt = CrossLingualPrompt(
            original_prompt=prompt,
            target_language=language,
            text_direction=text_direction,
        )

        # Add style guidance based on language
        if language in RTL_LANGUAGES:
            style_guidance = {
                "text_direction": text_direction,
                "narrative_style": style in [VideoStyle.ARABIC_NARRATIVE, VideoStyle.HEBREW_NARRATIVE],
                "cultural_boost": include_cultural_elements,
                "motion_pattern": "right_to_left" if language in RTL_LANGUAGES else "left_to_right",
            }
            cross_lingual_prompt.style_guidance = style_guidance

            cultural_context = {
                "language": rtl_config.get("name"),
                "script": rtl_config.get("script"),
                "cultural_elements": rtl_config.get("cultural_elements", {}),
            }
            cross_lingual_prompt.cultural_context = cultural_context

        # Add visual elements
        if include_cultural_elements and self.enable_cultural_elements:
            visual_elements = await self._get_visual_elements(language, style)
            cross_lingual_prompt.visual_elements = visual_elements

        # Build enhanced prompt
        enhanced_prompt = self._build_video_enhanced_prompt(
            prompt, language, style, cross_lingual_prompt
        )
        cross_lingual_prompt.metadata["enhanced_prompt"] = enhanced_prompt
        cross_lingual_prompt.metadata["duration"] = duration

        return VideoGenerationRequest(
            prompt=cross_lingual_prompt,
            style=style,
            duration=duration,
            rtl_optimized=language in RTL_LANGUAGES,
        )

    async def prepare_text_content(
        self,
        content: str,
        language: str = "ar",
        content_type: str = "article",
    ) -> CrossLingualPrompt:
        """Prepare RTL-aware text content"""

        rtl_config = self.rtl_languages.get(language, {})
        text_direction = rtl_config.get("direction", "LTR")

        cross_lingual_prompt = CrossLingualPrompt(
            original_prompt=content,
            target_language=language,
            text_direction=text_direction,
        )

        if language in RTL_LANGUAGES:
            # Add text overlay info
            cross_lingual_prompt.text_overlay = {
                "language": rtl_config.get("name"),
                "script": rtl_config.get("script"),
                "direction": text_direction,
            }

            # Add style guidance
            cross_lingual_prompt.style_guidance = {
                "content_type": content_type,
                "text_direction": text_direction,
                "typography": self._get_typography_settings(language, content_type),
            }

        return cross_lingual_prompt

    def _build_enhanced_prompt(
        self,
        prompt: str,
        language: str,
        style: ImageStyle,
        cross_lingual: CrossLingualPrompt,
    ) -> str:
        """Build enhanced prompt with cultural and RTL elements"""

        enhanced_parts = [prompt]

        if language in TRANSLATION_ENHANCEMENTS:
            enhancements = TRANSLATION_ENHANCEMENTS[language]

            # Add style additions
            if style == ImageStyle.ARABIC_CALLIGRAPHY and language == "ar":
                enhanced_parts.append("with Arabic calligraphy")
                enhanced_parts.append("thuluth script")
            elif style == ImageStyle.HEBREW_CALLIGRAPHY and language == "he":
                enhanced_parts.append("with Hebrew calligraphy")
                enhanced_parts.append("block letters")

            # Add cultural boosters from enhancements
            if cross_lingual.cultural_context:
                category = self._detect_category(prompt)
                if category and category in cross_lingual.cultural_context.get("cultural_elements", {}):
                    elements = cross_lingual.cultural_context["cultural_elements"][category]
                    if elements:
                        enhanced_parts.append(f"featuring {' and '.join(elements[:3])}")

        # Add visual elements
        if cross_lingual.visual_elements:
            enhanced_parts.append(" ".join(cross_lingual.visual_elements[:3]))

        return ", ".join(enhanced_parts)

    def _build_video_enhanced_prompt(
        self,
        prompt: str,
        language: str,
        style: VideoStyle,
        cross_lingual: CrossLingualPrompt,
    ) -> str:
        """Build enhanced video prompt"""

        enhanced_parts = [prompt]

        if language == "ar":
            if style == VideoStyle.ARABIC_NARRATIVE:
                enhanced_parts.append("Arabic narrative style")
                enhanced_parts.append("traditional Arabic storytelling")
            enhanced_parts.append("Arabic cultural context")
        elif language == "he":
            if style == VideoStyle.HEBREW_NARRATIVE:
                enhanced_parts.append("Hebrew narrative style")
                enhanced_parts.append("traditional Jewish storytelling")
            enhanced_parts.append("Jewish cultural context")

        return ", ".join(enhanced_parts)

    async def _get_visual_elements(
        self,
        language: str,
        style: ImageStyle | VideoStyle,
    ) -> list[str]:
        """Get visual elements for the style"""

        elements = []

        if language == "ar":
            if style in [ImageStyle.ISLAMIC_ART, ImageStyle.ARABIC_CALLIGRAPHY]:
                elements = [
                    "geometric patterns",
                    "arabesque design",
                    "islamic arch",
                    "zellige tiles",
                ]
            else:
                elements = [
                    "traditional Arabic setting",
                    "Middle Eastern atmosphere",
                    "Arabic architectural elements",
                ]
        elif language == "he":
            if style in [ImageStyle.JEWISH_ART, ImageStyle.HEBREW_CALLIGRAPHY]:
                elements = [
                    "star of david motif",
                    "jerusalem stone texture",
                    "torah scroll",
                    " menorah lighting",
                ]
            else:
                elements = [
                    "traditional Jewish setting",
                    "Mediterranean atmosphere",
                    "Israeli landscape",
                ]

        return elements

    def _get_color_palette(self, language: str, prompt: str) -> dict[str, str]:
        """Get culturally appropriate color palette"""

        if language == "ar":
            return {
                "primary": "#006C35",  # Green
                "secondary": "#C8A951",  # Gold
                "accent": "#003B6F",  # Blue
                "background": "#F5F0E6",  # Cream
            }
        elif language == "he":
            return {
                "primary": "#0038A8",  # Blue
                "secondary": "#FFFFFF",  # White
                "accent": "#FFD700",  # Gold
                "background": "#F5F0E6",  # Cream
            }
        return {}

    def _get_typography_settings(self, language: str, content_type: str) -> dict[str, Any]:
        """Get typography settings for RTL content"""

        base_settings = {
            "line_height": 1.6,
            "paragraph_spacing": 1.5,
        }

        if language == "ar":
            base_settings.update({
                "font_family": "Noto Sans Arabic, Tahoma, Arial",
                "text_direction": "RTL",
                "alignment": "right",
                "font_sizes": {
                    "heading": "2.5em",
                    "subheading": "1.75em",
                    "body": "1.1em",
                },
            })
        elif language == "he":
            base_settings.update({
                "font_family": "Franken Ruhl, David, Arial",
                "text_direction": "RTL",
                "alignment": "right",
                "font_sizes": {
                    "heading": "2.5em",
                    "subheading": "1.75em",
                    "body": "1.1em",
                },
            })

        return base_settings

    def _detect_category(self, prompt: str) -> str | None:
        """Detect content category from prompt"""

        prompt_lower = prompt.lower()

        # Arabic categories
        if any(word in prompt_lower for word in ["mosque", "islamic", "religious", "allah"]):
            return "islamic"
        if any(word in prompt_lower for word in ["traditional", "heritage", "old"]):
            return "traditional"
        if any(word in prompt_lower for word in ["modern", "city", "building"]):
            return "modern"

        # Hebrew categories
        if any(word in prompt_lower for word in ["jewish", "torah", "temple", "holy"]):
            return "jewish"
        if any(word in prompt_lower for word in ["jerusalem", "western wall"]):
            return "landmark"
        if any(word in prompt_lower for word in ["tel aviv", "modern", "tech"]):
            return "modern"

        return None

    async def generate_image(
        self,
        request: ImageGenerationRequest,
    ) -> GeneratedContent:
        """Generate image with cross-lingual support"""

        content_id = hashlib.md5(
            f"{request.prompt.original_prompt}_{datetime.utcnow().isoformat()}".encode()
        ).hexdigest()[:16]

        enhanced_prompt = request.prompt.metadata.get("enhanced_prompt", request.prompt.original_prompt)

        self.stats["images_generated"] += 1

        return GeneratedContent(
            content_id=f"img_{content_id}",
            modality=ContentModality.IMAGE,
            prompt_used=enhanced_prompt,
            generation_params={
                "style": request.style.value,
                "aspect_ratio": request.aspect_ratio,
                "resolution": request.resolution,
                "guidance_scale": request.guidance_scale,
            },
            metadata={
                "original_prompt": request.prompt.original_prompt,
                "language": request.prompt.target_language,
                "text_direction": request.prompt.text_direction,
                "cultural_elements": request.prompt.visual_elements,
                "rtl_optimized": request.prompt.target_language in RTL_LANGUAGES,
            },
            rtl_optimized=request.prompt.target_language in RTL_LANGUAGES,
            language=request.prompt.target_language,
        )

    async def generate_video(
        self,
        request: VideoGenerationRequest,
    ) -> GeneratedContent:
        """Generate video with cross-lingual support"""

        content_id = hashlib.md5(
            f"{request.prompt.original_prompt}_{datetime.utcnow().isoformat()}".encode()
        ).hexdigest()[:16]

        enhanced_prompt = request.prompt.metadata.get("enhanced_prompt", request.prompt.original_prompt)

        self.stats["videos_generated"] += 1

        return GeneratedContent(
            content_id=f"vid_{content_id}",
            modality=ContentModality.VIDEO,
            prompt_used=enhanced_prompt,
            generation_params={
                "style": request.style.value,
                "duration": request.duration,
                "resolution": request.resolution,
                "fps": request.fps,
                "motion_strength": request.motion_strength,
            },
            metadata={
                "original_prompt": request.prompt.original_prompt,
                "language": request.prompt.target_language,
                "text_direction": request.prompt.text_direction,
                "cultural_elements": request.prompt.visual_elements,
                "rtl_optimized": request.prompt.target_language in RTL_LANGUAGES,
            },
            rtl_optimized=request.prompt.target_language in RTL_LANGUAGES,
            language=request.prompt.target_language,
        )

    def get_stats(self) -> dict[str, Any]:
        """Get engine statistics"""
        return {
            **self.stats,
            "supported_languages": list(RTL_LANGUAGES.keys()),
            "cultural_elements": len(self.cultural_library.elements),
        }


async def example():
    """Example cross-lingual generation usage"""

    engine = CrossLingualEngine()

    # Arabic image generation
    print("=" * 60)
    print("Arabic Image Generation")
    print("=" * 60)

    ar_request = await engine.prepare_image_prompt(
        prompt="A beautiful mosque at sunset with geometric patterns",
        language="ar",
        style=ImageStyle.ISLAMIC_ART,
    )

    print(f"\nOriginal Prompt: {ar_request.prompt.original_prompt}")
    print(f"Enhanced Prompt: {ar_request.prompt.metadata.get('enhanced_prompt')}")
    print(f"Text Direction: {ar_request.prompt.text_direction}")
    print(f"Cultural Elements: {ar_request.prompt.visual_elements}")
    print(f"Style: {ar_request.style.value}")

    ar_image = await engine.generate_image(ar_request)
    print(f"\nGenerated Image ID: {ar_image.content_id}")
    print(f"RTL Optimized: {ar_image.rtl_optimized}")

    # Hebrew video generation
    print("\n" + "=" * 60)
    print("Hebrew Video Generation")
    print("=" * 60)

    he_request = await engine.prepare_video_prompt(
        prompt="Jerusalem old city with traditional Jewish storytelling",
        language="he",
        style=VideoStyle.HEBREW_NARRATIVE,
        duration=10,
    )

    print(f"\nOriginal Prompt: {he_request.prompt.original_prompt}")
    print(f"Enhanced Prompt: {he_request.prompt.metadata.get('enhanced_prompt')}")
    print(f"Text Direction: {he_request.prompt.text_direction}")
    print(f"Duration: {he_request.duration}s")

    he_video = await engine.generate_video(he_request)
    print(f"\nGenerated Video ID: {he_video.content_id}")
    print(f"RTL Optimized: {he_video.rtl_optimized}")

    # Mixed language text
    print("\n" + "=" * 60)
    print("Cross-Lingual Text Preparation")
    print("=" * 60)

    ar_text = await engine.prepare_text_content(
        content="مرحبا بكم في عصر الذكاء الاصطناعي",
        language="ar",
        content_type="article",
    )
    print(f"\nArabic Text: {ar_text.original_prompt}")
    print(f"Typography: {ar_text.style_guidance.get('typography', {})}")

    # Engine stats
    print("\n" + "=" * 60)
    print("Engine Statistics")
    print("=" * 60)
    print(f"\n{engine.get_stats()}")


if __name__ == "__main__":
    asyncio.run(example())
