# AI-OS Monorepo

## Project Structure

```text
aios/
├── apps/                          # Application layer
│   ├── api/                       # FastAPI REST gateway
│   ├── worker/                    # Background task workers
│   └── ui/                        # Dashboard UI
├── services/                      # Core microservices
│   ├── orchestrator/              # Task orchestration & DAG execution
│   ├── agent-fabric/              # Multi-agent runtime
│   ├── memory-service/            # Multi-tier memory system
│   ├── knowledge-service/         # RAG & knowledge retrieval
│   ├── tool-runtime/              # Tool registry & execution
│   ├── execution-engine/          # Sandboxed execution & approval
│   ├── security-gateway/          # Policy & injection detection
│   └── observability/             # Metrics, logs, tracing
├── packages/                      # Shared libraries
│   ├── schemas/                   # Pydantic models & protobuf
│   ├── sdk-python/                # Python SDK
│   ├── sdk-ts/                    # TypeScript SDK
│   └── shared-utils/              # Common utilities
├── infra/                         # Infrastructure as code
│   ├── docker/                    # Dockerfiles & compose
│   ├── k8s/                       # Kubernetes manifests
│   ├── terraform/                 # Terraform modules
│   ├── monitoring/                # Prometheus & Grafana
│   └── secrets/                   # Secret management
├── db/                            # Database schemas
│   ├── postgres/                  # PostgreSQL + pgvector
│   ├── redis/                     # Redis configurations
│   ├── neo4j/                     # Neo4j graph schemas
│   └── vector/                    # Vector DB schemas
├── tests/                         # Test suites
│   ├── unit/                      # Unit tests
│   ├── integration/               # Integration tests
│   └── e2e/                       # End-to-end tests
├── docs/                          # Documentation
└── examples/                      # Example workflows
```

## Core Services

| Service | Description | Language | Framework |
| ------- | ----------- | -------- | --------- |
| orchestrator | Task DAG builder & executor | Python | FastAPI + Celery |
| agent-fabric | Multi-agent runtime | Python | Custom async |
| memory-service | Vector + Redis memory | Python | FastAPI + Redis |
| knowledge-service | RAG pipeline | Python | FastAPI + pgvector |
| tool-runtime | Tool registry & sandbox | Python | FastAPI + Docker |
| execution-engine | Code execution | Python | Docker SDK |
| security-gateway | Policy enforcement | Python | FastAPI |
| observability | Telemetry collection | Python | OpenTelemetry |

## Quick Start

```bash
# Local development
cd infra/docker
docker-compose -f docker-compose.dev.yml up -d

# Deploy to Kubernetes
kubectl apply -k infra/k8s/overlays/dev

# Run tests
pytest tests/ -v --tb=short
```

## Documentation

- [Architecture Overview](docs/ARCHITECTURE.md)
- [API Reference](docs/API_REFERENCE.md)
- [Deployment Guide](docs/DEPLOYMENT.md)
- [Security Model](docs/SECURITY.md)
