"""
Sample Workflow Trace - Research Task
Demonstrates end-to-end execution path through AI-OS architecture
"""
from datetime import datetime
from typing import Any
from uuid import uuid4

# Sample trace ID for this workflow execution
TRACE_ID = "wf-trace-2024-001"
TASK_ID = "task-sample-001"


def create_workflow_trace():
    """Create a sample workflow trace for: Research a topic, gather evidence,
    generate a structured answer, critique it, and return citations."""

    trace = {
        "workflow_id": "research-answer-workflow",
        "trace_id": TRACE_ID,
        "task_id": TASK_ID,
        "started_at": datetime.utcnow().isoformat(),
        "user_input": {
            "query": "What are the effects of quantum computing on cryptography?",
            "mode": "research",
            "include_citations": True,
            "depth": "comprehensive",
        },
        "stages": [],
    }

    # === STAGE 1: Task Creation & Routing ===
    stage_1 = {
        "stage": "task_creation",
        "timestamp": datetime.utcnow().isoformat(),
        "actions": [
            {
                "component": "API Gateway",
                "action": "Received chat completion request",
                "input": {
                    "tenant_id": "tenant-001",
                    "user_id": "user-001",
                    "model": "gpt-4-turbo",
                },
                "output": {
                    "request_id": str(uuid4()),
                    "trace_id": TRACE_ID,
                },
            },
            {
                "component": "Tenant Middleware",
                "action": "Validated tenant and rate limits",
                "output": {"rate_limit_ok": True, "budget_ok": True},
            },
            {
                "component": "Auth Middleware",
                "action": "Verified API key",
                "output": {"authenticated": True, "scopes": ["chat:write", "memory:read"]},
            },
        ],
    }
    trace["stages"].append(stage_1)

    # === STAGE 2: Orchestrator Task Creation ===
    stage_2 = {
        "stage": "orchestrator_create_task",
        "timestamp": datetime.utcnow().isoformat(),
        "actions": [
            {
                "component": "OrchestratorService",
                "action": "create_task()",
                "input": {
                    "task_type": "research",
                    "tenant_id": "tenant-001",
                    "user_id": "user-001",
                    "input_data": {"query": "quantum computing effects on cryptography"},
                    "priority": "normal",
                },
                "output": {
                    "task_id": TASK_ID,
                    "status": "PENDING",
                    "graph_id": f"graph-{TASK_ID}",
                },
            },
            {
                "component": "TaskGraph",
                "action": "create_graph_for_task_type('research')",
                "output": {
                    "nodes_created": 9,
                    "edges_created": 8,
                    "entry_node": "node-plan-1",
                    "exit_node": "node-finalize-9",
                },
            },
        ],
    }
    trace["stages"].append(stage_2)

    # === STAGE 3: Task Graph Nodes Execution ===
    # Node 1: PLAN
    stage_3 = {
        "stage": "node_execution_plan",
        "timestamp": datetime.utcnow().isoformat(),
        "node_id": "node-plan-1",
        "node_type": "PLAN",
        "actions": [
            {
                "component": "TaskGraphExecutor",
                "action": "_handle_plan()",
                "input": {"query": "quantum computing effects on cryptography"},
                "output": {
                    "subtasks": [
                        "1. Search for quantum computing basics",
                        "2. Research current cryptographic standards (RSA, ECC)",
                        "3. Find post-quantum cryptography developments",
                        "4. Analyze impact on blockchain/security",
                        "5. Generate structured answer with citations",
                    ],
                    "estimated_steps": 5,
                },
            },
        ],
    }
    trace["stages"].append(stage_3)

    # Node 2: RETRIEVE_MEMORY
    stage_4 = {
        "stage": "node_execution_retrieve_memory",
        "timestamp": datetime.utcnow().isoformat(),
        "node_id": "node-memory-2",
        "node_type": "RETRIEVE_MEMORY",
        "actions": [
            {
                "component": "MemoryManager",
                "action": "retrieve() - 10-stage pipeline",
                "stages": [
                    {"stage": 1, "action": "_normalize_query", "output": "quantum computing cryptography"},
                    {"stage": 2, "action": "_generate_embedding", "output": "vector[1536] generated"},
                    {
                        "stage": 3,
                        "action": "_vector_recall",
                        "output": {"results_found": 12, "top_score": 0.94},
                    },
                    {"stage": 4, "action": "_rerank_results", "output": {"ordered_results": 12}},
                    {"stage": 5, "action": "_symbolic_lookup", "output": {"kg_results": 3}},
                    {
                        "stage": 6,
                        "action": "merge + recency_weight",
                        "output": {"merged": 15, "recency_applied": True},
                    },
                    {"stage": 7, "action": "_apply_tenant_filter", "output": {"filtered": 15}},
                    {"stage": 8, "action": "_apply_privacy_filter", "output": {"privacy_ok": True}},
                    {"stage": 9, "action": "_apply_relevance_threshold", "output": {"above_threshold": 10}},
                    {"stage": 10, "action": "_compress_context", "output": {"context_tokens": 800}},
                ],
                "output": {
                    "memory_results": 10,
                    "context_for_agent": "Previous research on quantum computing...",
                },
            },
        ],
    }
    trace["stages"].append(stage_4)

    # Node 3: Agent Communication - PLANNER
    stage_5 = {
        "stage": "node_execution_planner_agent",
        "timestamp": datetime.utcnow().isoformat(),
        "node_id": "node-agent-3",
        "node_type": "AGENT",
        "actions": [
            {
                "component": "AgentRouter",
                "action": "route_task()",
                "output": {"agent_type": "PlannerAgent", "agent_id": "planner-001"},
            },
            {
                "component": "PlannerAgent",
                "action": "process()",
                "input": {
                    "message_type": "PLAN",
                    "payload": {
                        "task": "Research quantum computing effects",
                        "context": {"memory_results": 10},
                    },
                },
                "output": {
                    "message_type": "RESULT",
                    "payload": {
                        "plan_steps": [
                            {"step": 1, "action": "web_search", "params": {"query": "quantum computing cryptography 2024"}},
                            {"step": 2, "action": "web_search", "params": {"query": "post-quantum cryptography algorithms"}},
                            {"step": 3, "action": "web_search", "params": {"query": "NIST post-quantum standards"}},
                        ],
                    },
                },
            },
        ],
    }
    trace["stages"].append(stage_5)

    # Node 4: INVOKE_TOOL - Web Search
    stage_6 = {
        "stage": "node_execution_web_search",
        "timestamp": datetime.utcnow().isoformat(),
        "node_id": "node-tool-4",
        "node_type": "INVOKE_TOOL",
        "actions": [
            {
                "component": "ToolRegistry",
                "action": "execute_tool('web_search')",
                "input": {
                    "tool_id": "web_search",
                    "parameters": {"query": "quantum computing cryptography 2024", "num_results": 10},
                    "context": {"tenant_id": "tenant-001"},
                },
                "pre_checks": [
                    {"check": "permission", "result": "granted"},
                    {"check": "rate_limit", "result": "ok"},
                    {"check": "security_scan", "result": "clean"},
                ],
                "output": {
                    "success": True,
                    "results": [
                        {
                            "title": "Quantum Computing and Cryptography: A Comprehensive Overview",
                            "url": "https://example.com/quantum-crypto",
                            "snippet": "Quantum computers threaten current encryption...",
                        },
                        {
                            "title": "NIST Post-Quantum Cryptography Standards",
                            "url": "https://nist.gov/pq-crypto",
                            "snippet": "NIST has standardized CRYSTALS-Kyber and CRYSTALS-Dilithium...",
                        },
                    ],
                    "execution_time_ms": 245,
                },
            },
        ],
    }
    trace["stages"].append(stage_6)

    # Node 5: REASON
    stage_7 = {
        "stage": "node_execution_reason",
        "timestamp": datetime.utcnow().isoformat(),
        "node_id": "node-reason-5",
        "node_type": "REASON",
        "actions": [
            {
                "component": "TaskGraphExecutor",
                "action": "_handle_reason()",
                "input": {
                    "context": {
                        "web_results": 2,
                        "memory_results": 10,
                        "plan_steps_completed": 1,
                    }
                },
                "reasoning_trace": [
                    {"step": 1, "thought": "Current RSA-2048 is vulnerable to Shor's algorithm"},
                    {
                        "step": 2,
                        "thought": "ECC is also vulnerable but requires more qubits",
                    },
                    {
                        "step": 3,
                        "thought": "Post-quantum algorithms (lattice-based) are the solution",
                    },
                ],
                "output": {
                    "reasoning_summary": "Quantum computing poses significant threat to current cryptographic standards. RSA and ECC are vulnerable to quantum algorithms. Post-quantum cryptography (lattice-based) is the emerging solution.",
                    "confidence": 0.92,
                },
            },
        ],
    }
    trace["stages"].append(stage_7)

    # Node 6: Agent Communication - GENERATOR
    stage_8 = {
        "stage": "node_execution_generator_agent",
        "timestamp": datetime.utcnow().isoformat(),
        "node_id": "node-agent-6",
        "node_type": "AGENT",
        "actions": [
            {
                "component": "AgentRouter",
                "action": "route_task()",
                "output": {"agent_type": "GeneratorAgent", "agent_id": "generator-001"},
            },
            {
                "component": "GeneratorAgent",
                "action": "process()",
                "input": {
                    "message_type": "ACTION",
                    "payload": {
                        "task": "Generate structured answer",
                        "context": {
                            "reasoning": stage_7["actions"][0]["reasoning_summary"],
                            "web_results": stage_6["actions"][0]["output"]["results"],
                        },
                    },
                },
                "output": {
                    "message_type": "RESULT",
                    "payload": {
                        "answer": {
                            "title": "Impact of Quantum Computing on Cryptography",
                            "sections": [
                                {
                                    "heading": "Current Threat Level",
                                    "content": "High - Shor's algorithm can break RSA and ECC",
                                    "citations": ["NIST-2024", "arXiv:quant-ph/0012"],
                                },
                                {
                                    "heading": "Post-Quantum Solutions",
                                    "content": "Lattice-based cryptography (CRYSTALS-Kyber)",
                                    "citations": ["NIST-PQC-2024"],
                                },
                                {
                                    "heading": "Timeline to Threat",
                                    "content": "Estimated 10-15 years for cryptographically relevant quantum computer",
                                    "citations": ["IBM-Quantum-2024"],
                                },
                            ],
                            "references": [
                                {"id": "NIST-2024", "title": "NIST Post-Quantum Cryptography Standards", "url": "https://nist.gov/pq-crypto"},
                                {"id": "arXiv:quant-ph/0012", "title": "Quantum Computing and Cryptography", "url": "https://arxiv.org/quant-ph/0012"},
                            ],
                        }
                    },
                },
            },
        ],
    }
    trace["stages"].append(stage_8)

    # Node 7: INVOKE_TOOL - Store Memory
    stage_9 = {
        "stage": "node_execution_store_memory",
        "timestamp": datetime.utcnow().isoformat(),
        "node_id": "node-tool-7",
        "node_type": "INVOKE_TOOL",
        "actions": [
            {
                "component": "MemoryManager",
                "action": "store()",
                "input": {
                    "memory_type": "SEMANTIC",
                    "content": "Research on quantum computing impact on cryptography completed. Key findings: RSA/ECC vulnerable, post-quantum (lattice) is solution.",
                    "tenant_id": "tenant-001",
                    "tags": ["quantum", "cryptography", "post-quantum"],
                    "embedding": "[vector-1536]",
                },
                "output": {"memory_id": f"mem-{uuid4()}", "stored": True},
            },
        ],
    }
    trace["stages"].append(stage_9)

    # Node 8: CRITIQUE
    stage_10 = {
        "stage": "node_execution_critique",
        "timestamp": datetime.utcnow().isoformat(),
        "node_id": "node-critique-8",
        "node_type": "CRITIQUE",
        "actions": [
            {
                "component": "CriticAgent",
                "action": "process()",
                "input": {
                    "message_type": "CRITIQUE",
                    "payload": {"content_to_review": stage_8["actions"][1]["output"]["payload"]["answer"]},
                },
                "critique_results": [
                    {
                        "issue": "Missing timeline analysis",
                        "severity": "medium",
                        "suggestion": "Add section on when quantum threat becomes real",
                    },
                    {
                        "issue": "Citation format inconsistent",
                        "severity": "low",
                        "suggestion": "Standardize all citations to same format",
                    },
                ],
                "output": {
                    "message_type": "RESULT",
                    "payload": {
                        "approved": True,
                        "modifications": [
                            "Add 'Timeline' section with 10-15 year estimate",
                            "Standardize citation format",
                        ],
                    },
                },
            },
        ],
    }
    trace["stages"].append(stage_10)

    # Node 9: FINALIZE
    stage_11 = {
        "stage": "node_execution_finalize",
        "timestamp": datetime.utcnow().isoformat(),
        "node_id": "node-finalize-9",
        "node_type": "FINALIZE",
        "actions": [
            {
                "component": "TaskGraphExecutor",
                "action": "_handle_finalize()",
                "input": {
                    "original_answer": stage_8["actions"][1]["output"]["payload"]["answer"],
                    "critique_modifications": stage_10["actions"][0]["modifications"],
                },
                "output": {
                    "final_answer": {
                        "title": "Impact of Quantum Computing on Cryptography",
                        "sections": [
                            {"heading": "Current Threat Level", "content": "High"},
                            {"heading": "Post-Quantum Solutions", "content": "Lattice-based"},
                            {"heading": "Timeline to Quantum Threat", "content": "10-15 years"},
                        ],
                        "all_citations": 5,
                    },
                    "token_usage": {"prompt": 1200, "completion": 800, "total": 2000},
                    "execution_time_ms": 3450,
                },
            },
        ],
    }
    trace["stages"].append(stage_11)

    # === Final Response ===
    trace["completed_at"] = datetime.utcnow().isoformat()
    trace["status"] = "completed"
    trace["summary"] = {
        "task_id": TASK_ID,
        "graph_completed": True,
        "nodes_executed": 9,
        "tools_invoked": 2,
        "agents_used": 3,
        "memory_operations": 2,
        "total_time_ms": 3450,
        "citations_returned": 5,
    }

    return trace


def print_workflow_diagram():
    """Print a visual diagram of the workflow"""
    diagram = """
    ╔══════════════════════════════════════════════════════════════════════════╗
    ║                    AI-OS WORKFLOW EXECUTION TRACE                        ║
    ║              "Research a topic, generate answer, critique"              ║
    ╠══════════════════════════════════════════════════════════════════════════╣
    ║                                                                          ║
    ║   [User Input]                                                           ║
    ║   "What are the effects of quantum computing on cryptography?"          ║
    ║                              │                                           ║
    ║                              ▼                                           ║
    ║   ┌─────────────────────────────────────────────────────────────────┐    ║
    ║   │                    API GATEWAY                                   │    ║
    ║   │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐            │    ║
    ║   │  │ Tracing │→│ Tenant  │→│  Auth   │→│RateLimit│            │    ║
    ║   │  │Middleware│ │Middleware│ │Middleware│ │Middleware│           │    ║
    ║   │  └─────────┘  └─────────┘  └─────────┘  └─────────┘            │    ║
    ║   └─────────────────────────────────────────────────────────────────┘    ║
    ║                              │                                           ║
    ║                              ▼                                           ║
    ║   ┌─────────────────────────────────────────────────────────────────┐    ║
    ║   │                     ORCHESTRATOR                                  │    ║
    ║   │  ┌──────────────────────────────────────────────────────────┐    │    ║
    ║   │  │              TASK GRAPH (DAG) - 9 Nodes                  │    │    ║
    ║   │  │                                                          │    │    ║
    ║   │  │    [1:PLAN] → [2:MEMORY] → [3:PLANNER] → [4:WEB_SEARCH]  │    │    ║
    ║   │  │                                    ↓                      │    │    ║
    ║   │  │    [9:FINALIZE] ← [8:CRITIQUE] ← [7:GENERATOR]          │    │    ║
    ║   │  │                      ↑                                     │    │    ║
    ║   │  │              [6:REASON] ─────────────────────────────────┘    │    ║
    ║   │  └──────────────────────────────────────────────────────────┘    │    ║
    ║   └─────────────────────────────────────────────────────────────────┘    ║
    ║                              │                                           ║
    ║          ┌───────────────────┼───────────────────┐                     ║
    ║          ▼                   ▼                   ▼                     ║
    ║   ┌─────────────┐   ┌─────────────┐   ┌─────────────┐                 ║
    ║   │  AGENT       │   │   TOOL      │   │   MEMORY    │                 ║
    ║   │  FABRIC      │   │   RUNTIME   │   │   SERVICE   │                 ║
    ║   ├─────────────┤   ├─────────────┤   ├─────────────┤                 ║
    ║   │• PlannerAgent│   │• web_search │   │• 10-stage   │                 ║
    ║   │• Generator   │   │• store_mem  │   │  retrieval  │                 ║
    ║   │• CriticAgent │   │             │   │• embedding  │                 ║
    ║   └─────────────┘   └─────────────┘   └─────────────┘                 ║
    ║                              │                                           ║
    ║                              ▼                                           ║
    ║   ┌─────────────────────────────────────────────────────────────────┐    ║
    ║   │                   EXECUTION ENGINE                               │    ║
    ║   │  Risk Level: MEDIUM → Auto-execute with audit logging           │    ║
    ║   └─────────────────────────────────────────────────────────────────┘    ║
    ║                              │                                           ║
    ║                              ▼                                           ║
    ║   ┌─────────────────────────────────────────────────────────────────┐    ║
    ║   │                 SECURITY GATEWAY                                │    ║
    ║   │  • Prompt injection scan: CLEAN                                 │    ║
    ║   │  • Output validation: PASSED                                    │    ║
    ║   │  • Secret redaction: APPLIED                                    │    ║
    ║   └─────────────────────────────────────────────────────────────────┘    ║
    ║                              │                                           ║
    ║                              ▼                                           ║
    ║   [Final Response]                                                        ║
    ║   • Structured answer with 5 citations                                 ║
    ║   • Execution time: 3450ms                                             ║
    ║   • Memory stored for future retrieval                                 ║
    ║                                                                          ║
    ╚══════════════════════════════════════════════════════════════════════════╝
    """
    print(diagram)


def print_metrics_summary(trace: dict) -> str:
    """Print execution metrics summary"""
    summary = f"""
    ╔═══════════════════════════════════════════════════════════╗
    ║               WORKFLOW EXECUTION METRICS                   ║
    ╠═══════════════════════════════════════════════════════════╣
    ║  Trace ID: {trace['trace_id']:<40}  ║
    ║  Task ID:  {trace['task_id']:<40}  ║
    ║  Status:   {trace['status']:<40}  ║
    ╠═══════════════════════════════════════════════════════════╣
    ║                    NODE EXECUTION                          ║
    ║  ┌─────────────────────┬───────────────────────────────┐   ║
    ║  │ Node                │ Type                          │   ║
    ║  ├─────────────────────┼───────────────────────────────┤   ║
    ║  │ node-plan-1         │ PLAN                          │   ║
    ║  │ node-memory-2       │ RETRIEVE_MEMORY               │   ║
    ║  │ node-agent-3        │ AGENT (PlannerAgent)          │   ║
    ║  │ node-tool-4         │ INVOKE_TOOL (web_search)       │   ║
    ║  │ node-reason-5       │ REASON                        │   ║
    ║  │ node-agent-6        │ AGENT (GeneratorAgent)        │   ║
    ║  │ node-tool-7         │ INVOKE_TOOL (memory_store)     │   ║
    ║  │ node-critique-8     │ CRITIQUE (CriticAgent)        │   ║
    ║  │ node-finalize-9     │ FINALIZE                      │   ║
    ║  └─────────────────────┴───────────────────────────────┘   ║
    ╠═══════════════════════════════════════════════════════════╣
    ║                    SERVICE INTERACTIONS                    ║
    ║  • API Gateway:          1 request processed               ║
    ║  • Orchestrator:         1 task created, 9 nodes executed ║
    ║  • Agent Fabric:         3 agents invoked                 ║
    ║  • Memory Service:       10-stage retrieval + 1 store     ║
    ║  • Tool Runtime:         2 tools executed                 ║
    ║  • Execution Engine:     Risk level MEDIUM assigned        ║
    ║  • Security Gateway:     2 scans passed                   ║
    ╠═══════════════════════════════════════════════════════════╣
    ║                      PERFORMANCE                           ║
    ║  • Total execution time: {trace['summary']['total_time_ms']}ms                    ║
    ║  • Token usage:           {trace['summary'].get('token_usage', {}).get('total', 'N/A')} tokens                      ║
    ║  • Citations returned:    {trace['summary']['citations_returned']}                          ║
    ╚═══════════════════════════════════════════════════════════╝
    """
    return summary


if __name__ == "__main__":
    print("Generating AI-OS Sample Workflow Trace...")
    print()

    trace = create_workflow_trace()
    print_workflow_diagram()
    print()
    print(metrics_summary := print_metrics_summary(trace))

    # Output the full JSON trace
    import json

    print("\n--- FULL TRACE JSON ---")
    print(json.dumps(trace, indent=2))