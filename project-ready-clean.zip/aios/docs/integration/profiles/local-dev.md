# Profile: local-dev

Purpose: Fast local iteration with broad capability coverage and low operational friction.

## Characteristics

- Security posture: moderate
- Approval mode: selective
- External connectivity: enabled
- Tool runtime: sandboxed by default, escalation on allowlist
- Observability: debug-level traces in local storage

## Enabled Waves

- Wave 1: enabled
- Wave 2: enabled (non-destructive tools only by default)
- Wave 3: optional
- Wave 4: disabled

## Suggested Services

- unified-ai-system core services
- provider gateway (local model + remote fallback)
- memory service + vector store
- protocol adapter service
- local browser automation runner

## Policy Defaults

- Require explicit user confirmation for shell/file-write outside workspace.
- Disable outbound actions to finance/admin integrations unless allowlisted.
- Log all cross-agent delegation events.
