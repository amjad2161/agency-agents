# Profile: production-gated

Purpose: Enterprise production deployment with strong policy governance.

## Characteristics

- Security posture: very high
- Approval mode: policy-driven and role-aware
- External connectivity: controlled via gateway
- Tool runtime: hardened, rate-limited, and monitored
- Observability: SLO dashboards + compliance audit retention

## Enabled Waves

- Wave 1: enabled
- Wave 2: enabled after passing security and reliability gates
- Wave 3: selective enablement per business domain
- Wave 4: isolated experiments only

## Suggested Services

- orchestrator + execution engine
- security gateway + approval service
- compliance + audit pipeline
- protocol adapter cluster
- observability/tracing + SIEM export

## Policy Defaults

- Mandatory human approval for destructive or financial actions.
- Policy-as-code checks on every new manifest entry.
- Incident kill-switch for all external action channels.
- Periodic key rotation and signed workload identities.
