# Profile: secure-lab

Purpose: Security-first staging for red-team evaluation and compliance checks.

## Characteristics

- Security posture: high
- Approval mode: strict
- External connectivity: deny by default
- Tool runtime: constrained with deterministic allowlists
- Observability: full audit traces + immutable event sink

## Enabled Waves

- Wave 1: enabled
- Wave 2: partially enabled (read-only and simulation actions)
- Wave 3: disabled unless explicitly reviewed
- Wave 4: disabled

## Suggested Services

- unified-ai-system core services
- security gateway + policy engine
- approval service (mandatory for side effects)
- threat-intelligence service
- protocol adapter with mTLS and token rotation

## Policy Defaults

- No direct internet access without policy exception.
- All external tool actions require signed approval tokens.
- Enforce per-agent capability scopes and least privilege.
- Run security-reviewer pass before enabling a new connector class.
