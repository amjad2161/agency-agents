# Integration Artifacts

This folder contains manifest-driven artifacts for large-scale capability integration into JARVIS.

## Files

- repo_capability_manifest.schema.json
  - JSON schema describing the structure and policy fields for repository capability ingestion.
- repo_capability_manifest.yaml
  - Canonical repository capability manifest seeded from user-specified sources.
- integration_priority_matrix.md
  - Wave schedule, scoring model, and gating logic.
- profiles/local-dev.md
- profiles/secure-lab.md
- profiles/production-gated.md

## Usage

1. Update repo_capability_manifest.yaml with newly approved repositories.
2. Keep capabilities and runtime_mode aligned with schema enums.
3. Use the priority matrix to assign wave and rollout profile.
4. Validate manifest/tests from unified-ai-system test suite.
