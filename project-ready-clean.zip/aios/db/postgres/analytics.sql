-- AI-OS Analytics Schema
-- Event tracking, analytics, and business intelligence tables

-- =============================================================================
-- Analytics Enums
-- =============================================================================

DO $$ BEGIN
    CREATE TYPE event_type AS ENUM (
        'api_request', 'task_created', 'task_completed', 'task_failed',
        'session_started', 'session_ended', 'tool_executed', 'tool_failed',
        'agent_invoked', 'approval_requested', 'approval_decision',
        'user_login', 'user_logout', 'error_occurred', 'budget_alert',
        'security_event', 'cache_hit', 'cache_miss', 'model_invoked'
    );
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE alert_severity AS ENUM ('info', 'warning', 'error', 'critical');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

-- =============================================================================
-- Event Log (Append-Only)
-- =============================================================================
CREATE TABLE analytics_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

    event_id VARCHAR(100) UNIQUE NOT NULL,
    event_type event_type NOT NULL,

    -- Context
    tenant_id UUID REFERENCES tenants(id),
    user_id UUID REFERENCES users(id),
    session_id UUID,
    task_id UUID,

    -- Event Data
    event_name VARCHAR(200),
    properties JSONB DEFAULT '{}',
    metrics JSONB DEFAULT '{}',

    -- Resource Tracking
    model_id VARCHAR(100),
    tokens_used INTEGER,
    latency_ms INTEGER,
    cost_usd DECIMAL(12, 6),

    -- Environment
    environment VARCHAR(50),
    region VARCHAR(50),
    version VARCHAR(50),

    -- Attribution
    trace_id UUID,
    span_id VARCHAR(50),
    source_service VARCHAR(100),

    -- Metadata
    ip_address INET,
    user_agent TEXT,
    referrer TEXT,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
) PARTITION BY RANGE (created_at);

-- Create monthly partitions
CREATE TABLE analytics_events_2024_01 PARTITION OF analytics_events
    FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');

CREATE TABLE analytics_events_2024_02 PARTITION OF analytics_events
    FOR VALUES FROM ('2024-02-01') TO ('2024-03-01');

CREATE TABLE analytics_events_2024_03 PARTITION OF analytics_events
    FOR VALUES FROM ('2024-03-01') TO ('2024-04-01');

-- Add partitions as needed

CREATE INDEX idx_analytics_events_type ON analytics_events(event_type);
CREATE INDEX idx_analytics_events_tenant ON analytics_events(tenant_id);
CREATE INDEX idx_analytics_events_user ON analytics_events(user_id);
CREATE INDEX idx_analytics_events_session ON analytics_events(session_id);
CREATE INDEX idx_analytics_events_task ON analytics_events(task_id);
CREATE INDEX idx_analytics_events_created ON analytics_events(created_at);
CREATE INDEX idx_analytics_events_trace ON analytics_events(trace_id);

-- =============================================================================
-- Aggregated Metrics (Materialized Daily)
-- =============================================================================
CREATE TABLE analytics_daily_metrics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

    tenant_id UUID REFERENCES tenants(id),
    date DATE NOT NULL,

    -- Request Metrics
    total_requests INTEGER DEFAULT 0,
    successful_requests INTEGER DEFAULT 0,
    failed_requests INTEGER DEFAULT 0,
    unique_users INTEGER DEFAULT 0,
    unique_sessions INTEGER DEFAULT 0,

    -- Token Metrics
    total_input_tokens BIGINT DEFAULT 0,
    total_output_tokens BIGINT DEFAULT 0,
    total_tokens BIGINT GENERATED ALWAYS AS (total_input_tokens + total_output_tokens) STORED,

    -- Cost Metrics
    total_cost_usd DECIMAL(14, 6) DEFAULT 0,

    -- Latency Metrics
    avg_latency_ms FLOAT DEFAULT 0,
    p50_latency_ms FLOAT DEFAULT 0,
    p95_latency_ms FLOAT DEFAULT 0,
    p99_latency_ms FLOAT DEFAULT 0,
    max_latency_ms INTEGER DEFAULT 0,

    -- Task Metrics
    tasks_created INTEGER DEFAULT 0,
    tasks_completed INTEGER DEFAULT 0,
    tasks_failed INTEGER DEFAULT 0,

    -- Tool Metrics
    tools_executed INTEGER DEFAULT 0,
    tool_failures INTEGER DEFAULT 0,

    -- Model Breakdown (JSONB for flexibility)
    model_breakdown JSONB DEFAULT '{}',

    -- Error Breakdown
    error_counts JSONB DEFAULT '{}',

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    UNIQUE(tenant_id, date)
);

CREATE INDEX idx_analytics_daily_tenant ON analytics_daily_metrics(tenant_id);
CREATE INDEX idx_analytics_daily_date ON analytics_daily_metrics(date DESC);

-- =============================================================================
-- User Activity Summary
-- =============================================================================
CREATE TABLE analytics_user_activity (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

    user_id UUID REFERENCES users(id),
    tenant_id UUID REFERENCES tenants(id),
    date DATE NOT NULL,

    -- Activity Counts
    requests_sent INTEGER DEFAULT 0,
    messages_sent INTEGER DEFAULT 0,
    tasks_created INTEGER DEFAULT 0,
    tools_used INTEGER DEFAULT 0,
    sessions_started INTEGER DEFAULT 0,

    -- Usage
    tokens_consumed BIGINT DEFAULT 0,
    cost_incurred DECIMAL(12, 6) DEFAULT 0,

    -- Time Metrics
    total_active_minutes INTEGER DEFAULT 0,
    first_activity_at TIMESTAMP WITH TIME ZONE,
    last_activity_at TIMESTAMP WITH TIME ZONE,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    UNIQUE(user_id, date)
);

CREATE INDEX idx_analytics_user_activity_user ON analytics_user_activity(user_id);
CREATE INDEX idx_analytics_user_activity_tenant ON analytics_user_activity(tenant_id);
CREATE INDEX idx_analytics_user_activity_date ON analytics_user_activity(date DESC);

-- =============================================================================
-- Retention Cohorts
-- =============================================================================
CREATE TABLE analytics_retention_cohorts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

    cohort_date DATE NOT NULL,
    cohort_size INTEGER NOT NULL,
    tenant_id UUID REFERENCES tenants(id),

    -- Retention by day
    day_0_users INTEGER NOT NULL,
    day_1_users INTEGER DEFAULT 0,
    day_3_users INTEGER DEFAULT 0,
    day_7_users INTEGER DEFAULT 0,
    day_14_users INTEGER DEFAULT 0,
    day_30_users INTEGER DEFAULT 0,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    UNIQUE(cohort_date, tenant_id)
);

-- =============================================================================
-- Alerts and Notifications
-- =============================================================================
CREATE TABLE analytics_alerts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

    tenant_id UUID REFERENCES tenants(id),
    user_id UUID REFERENCES users(id),

    alert_type VARCHAR(100) NOT NULL,
    severity alert_severity NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT,

    -- Trigger Info
    metric_name VARCHAR(100),
    threshold_value FLOAT,
    actual_value FLOAT,
    comparison VARCHAR(10),

    -- Resolution
    status VARCHAR(50) DEFAULT 'open',
    resolved_by UUID REFERENCES users(id),
    resolved_at TIMESTAMP WITH TIME ZONE,
    resolution_note TEXT,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_analytics_alerts_tenant ON analytics_alerts(tenant_id);
CREATE INDEX idx_analytics_alerts_status ON analytics_alerts(status);
CREATE INDEX idx_analytics_alerts_severity ON analytics_alerts(severity);
CREATE INDEX idx_analytics_alerts_created ON analytics_alerts(created_at DESC);

-- =============================================================================
-- Feature Usage Tracking
-- =============================================================================
CREATE TABLE analytics_feature_usage (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

    tenant_id UUID REFERENCES tenants(id),
    feature_name VARCHAR(100) NOT NULL,
    user_id UUID REFERENCES users(id),

    -- Usage Metrics
    usage_count INTEGER DEFAULT 1,
    success_count INTEGER DEFAULT 0,
    failure_count INTEGER DEFAULT 0,

    date DATE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    UNIQUE(tenant_id, feature_name, user_id, date)
);

CREATE INDEX idx_analytics_feature_tenant ON analytics_feature_usage(tenant_id);
CREATE INDEX idx_analytics_feature_name ON analytics_feature_usage(feature_name);
CREATE INDEX idx_analytics_feature_date ON analytics_feature_usage(date DESC);

-- =============================================================================
-- Anomaly Detection Results
-- =============================================================================
CREATE TABLE analytics_anomalies (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

    tenant_id UUID REFERENCES tenants(id),

    anomaly_type VARCHAR(100) NOT NULL,
    metric_name VARCHAR(100),

    -- Detection Info
    detected_value FLOAT,
    expected_value FLOAT,
    deviation_percent FLOAT,

    -- Severity
    severity VARCHAR(50),
    confidence FLOAT,

    -- Context
    possible_causes JSONB DEFAULT '[]',
    recommended_actions JSONB DEFAULT '[]',

    status VARCHAR(50) DEFAULT 'detected',
    investigated_by UUID REFERENCES users(id),
    investigated_at TIMESTAMP WITH TIME ZONE,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_analytics_anomalies_tenant ON analytics_anomalies(tenant_id);
CREATE INDEX idx_analytics_anomalies_type ON analytics_anomalies(anomaly_type);
CREATE INDEX idx_analytics_anomalies_created ON analytics_anomalies(created_at DESC);

-- =============================================================================
-- Report Schedules
-- =============================================================================
CREATE TABLE analytics_reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

    tenant_id UUID REFERENCES tenants(id),
    created_by UUID REFERENCES users(id),

    name VARCHAR(255) NOT NULL,
    description TEXT,

    report_type VARCHAR(100) NOT NULL,
    parameters JSONB DEFAULT '{}',

    schedule_cron VARCHAR(100),
    schedule_timezone VARCHAR(50) DEFAULT 'UTC',

    recipients JSONB DEFAULT '[]',
    last_sent_at TIMESTAMP WITH TIME ZONE,
    last_status VARCHAR(50),

    is_active BOOLEAN DEFAULT true,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_analytics_reports_tenant ON analytics_reports(tenant_id);
CREATE INDEX idx_analytics_reports_active ON analytics_reports(is_active);

-- =============================================================================
-- Funnels
-- =============================================================================
CREATE TABLE analytics_funnels (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

    tenant_id UUID REFERENCES tenants(id),
    funnel_name VARCHAR(255) NOT NULL,

    steps JSONB NOT NULL,  -- [{name: "step1", event: "event1"}, ...]

    -- Aggregated Results
    conversion_rates JSONB DEFAULT '{}',
    drop_off_points JSONB DEFAULT '{}',

    period_start DATE,
    period_end DATE,

    computed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =============================================================================
-- Triggers
-- =============================================================================

CREATE TRIGGER update_analytics_daily_metrics_updated_at
    BEFORE UPDATE ON analytics_daily_metrics
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_analytics_user_activity_updated_at
    BEFORE UPDATE ON analytics_user_activity
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_analytics_reports_updated_at
    BEFORE UPDATE ON analytics_reports
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- =============================================================================
-- Materialized Views for Dashboard
-- =============================================================================

-- Last 7 days summary
CREATE MATERIALIZED VIEW analytics_weekly_summary AS
SELECT
    tenant_id,
    DATE_TRUNC('week', date) AS week_start,
    SUM(total_requests) AS total_requests,
    SUM(total_tokens) AS total_tokens,
    SUM(total_cost_usd) AS total_cost,
    AVG(avg_latency_ms) AS avg_latency,
    SUM(tasks_completed) AS tasks_completed,
    SUM(tasks_failed) AS tasks_failed,
    COUNT(DISTINCT date) AS days_active
FROM analytics_daily_metrics
WHERE date >= CURRENT_DATE - INTERVAL '7 days'
GROUP BY tenant_id, DATE_TRUNC('week', date);

CREATE UNIQUE INDEX idx_analytics_weekly_summary_tenant ON analytics_weekly_summary(tenant_id, week_start);

-- Top users by usage
CREATE MATERIALIZED VIEW analytics_top_users AS
SELECT
    tenant_id,
    user_id,
    SUM(requests_sent) AS total_requests,
    SUM(tokens_consumed) AS total_tokens,
    SUM(cost_incurred) AS total_cost,
    COUNT(DISTINCT date) AS active_days
FROM analytics_user_activity
WHERE date >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY tenant_id, user_id
ORDER BY total_requests DESC;

CREATE INDEX idx_analytics_top_users_cost ON analytics_top_users(total_cost DESC);
