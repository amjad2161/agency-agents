-- AI-OS PostgreSQL Schema
-- Complete database schema for production deployment

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE EXTENSION IF NOT EXISTS "vector";

-- =============================================================================
-- Enums (via check constraints)
-- =============================================================================

-- Task status enum
DO $$ BEGIN
    CREATE TYPE task_status AS ENUM (
        'pending', 'queued', 'running', 'blocked', 'completed',
        'failed', 'cancelled', 'timed_out'
    );
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Task priority enum
DO $$ BEGIN
    CREATE TYPE task_priority AS ENUM ('critical', 'high', 'normal', 'low', 'background');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Node status enum
DO $$ BEGIN
    CREATE TYPE node_status AS ENUM (
        'pending', 'ready', 'running', 'blocked', 'failed', 'completed', 'skipped'
    );
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Agent message type enum
DO $$ BEGIN
    CREATE TYPE agent_message_type AS ENUM (
        'PLAN', 'ACTION', 'CRITIQUE', 'VERIFY', 'RESULT', 'ERROR', 'STATUS',
        'QUERY', 'RESPONSE', 'HEARTBEAT'
    );
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Memory type enum
DO $$ BEGIN
    CREATE TYPE memory_type AS ENUM (
        'working', 'semantic', 'episodic', 'procedural', 'sensory'
    );
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Execution risk level enum
DO $$ BEGIN
    CREATE TYPE execution_risk_level AS ENUM ('low', 'medium', 'high', 'critical');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Execution status enum
DO $$ BEGIN
    CREATE TYPE execution_status AS ENUM (
        'pending', 'approved', 'running', 'completed', 'failed',
        'cancelled', 'rolling_back', 'rolled_back'
    );
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Approval status enum
DO $$ BEGIN
    CREATE TYPE approval_status AS ENUM ('pending', 'approved', 'rejected', 'expired');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Session status enum
DO $$ BEGIN
    CREATE TYPE session_status AS ENUM ('active', 'idle', 'expired', 'closed');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Tenant tier enum
DO $$ BEGIN
    CREATE TYPE tenant_tier AS ENUM ('free', 'starter', 'professional', 'enterprise', 'custom');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Tool category enum
DO $$ BEGIN
    CREATE TYPE tool_category AS ENUM (
        'web', 'code', 'data', 'communication', 'integration', 'system', 'creative', 'analysis'
    );
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- =============================================================================
-- Tenants
-- =============================================================================
CREATE TABLE tenants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    tier tenant_tier DEFAULT 'free',
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    is_active BOOLEAN DEFAULT true,
    is_verified BOOLEAN DEFAULT false,
    config JSONB DEFAULT '{}',
    budget_config JSONB DEFAULT '{}',
    rate_limit_config JSONB DEFAULT '{}',
    max_users INTEGER DEFAULT 10,
    max_api_keys INTEGER DEFAULT 5,
    max_storage_gb INTEGER DEFAULT 10,
    current_spend_usd DECIMAL(12, 4) DEFAULT 0,
    current_tokens_used BIGINT DEFAULT 0,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    CONSTRAINT tenants_slug_check CHECK (slug ~ '^[a-z0-9-]+$')
);

CREATE INDEX idx_tenants_slug ON tenants(slug);
CREATE INDEX idx_tenants_tier ON tenants(tier);
CREATE INDEX idx_tenants_active ON tenants(is_active);

-- =============================================================================
-- Users
-- =============================================================================
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    email VARCHAR(255) NOT NULL,
    username VARCHAR(100) NOT NULL,
    password_hash VARCHAR(255),
    full_name VARCHAR(255),
    avatar_url TEXT,
    phone VARCHAR(50),
    role VARCHAR(50) DEFAULT 'user',
    permissions TEXT[] DEFAULT '{}',
    is_active BOOLEAN DEFAULT true,
    is_verified BOOLEAN DEFAULT false,
    settings JSONB DEFAULT '{}',
    preferences JSONB DEFAULT '{}',
    tokens_used BIGINT DEFAULT 0,
    tasks_created INTEGER DEFAULT 0,
    last_login_at TIMESTAMP WITH TIME ZONE,
    last_active_at TIMESTAMP WITH TIME ZONE,
    external_ids JSONB DEFAULT '{}',
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(tenant_id, email),
    UNIQUE(tenant_id, username)
);

CREATE INDEX idx_users_tenant ON users(tenant_id);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_username ON users(username);

-- =============================================================================
-- API Keys
-- =============================================================================
CREATE TABLE api_keys (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    key_hash VARCHAR(255) NOT NULL,
    key_prefix VARCHAR(20) NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    scopes TEXT[] DEFAULT '{}',
    rate_limit_per_minute INTEGER,
    rate_limit_per_hour INTEGER,
    is_active BOOLEAN DEFAULT true,
    expires_at TIMESTAMP WITH TIME ZONE,
    last_used_at TIMESTAMP WITH TIME ZONE,
    request_count BIGINT DEFAULT 0,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_api_keys_tenant ON api_keys(tenant_id);
CREATE INDEX idx_api_keys_hash ON api_keys(key_hash);
CREATE INDEX idx_api_keys_prefix ON api_keys(key_prefix);

-- =============================================================================
-- Sessions
-- =============================================================================
CREATE TABLE sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    session_type VARCHAR(50) DEFAULT 'chat',
    title VARCHAR(255),
    status session_status DEFAULT 'active',
    config JSONB DEFAULT '{}',
    parent_session_id UUID REFERENCES sessions(id) ON DELETE SET NULL,
    root_session_id UUID,
    message_count INTEGER DEFAULT 0,
    token_usage BIGINT DEFAULT 0,
    tool_calls INTEGER DEFAULT 0,
    last_activity_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_message_at TIMESTAMP WITH TIME ZONE,
    expires_at TIMESTAMP WITH TIME ZONE,
    archived_at TIMESTAMP WITH TIME ZONE,
    tags TEXT[] DEFAULT '{}',
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_sessions_tenant ON sessions(tenant_id);
CREATE INDEX idx_sessions_user ON sessions(user_id);
CREATE INDEX idx_sessions_status ON sessions(status);
CREATE INDEX idx_sessions_activity ON sessions(last_activity_at);

-- =============================================================================
-- Messages
-- =============================================================================
CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id UUID NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    role VARCHAR(50) NOT NULL,
    content TEXT NOT NULL,
    model VARCHAR(100),
    tokens_used INTEGER,
    input_tokens INTEGER,
    output_tokens INTEGER,
    parent_message_id UUID REFERENCES messages(id) ON DELETE SET NULL,
    task_id UUID,
    attachments JSONB DEFAULT '[]',
    tool_calls JSONB DEFAULT '[]',
    citations JSONB DEFAULT '[]',
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_messages_session ON messages(session_id);
CREATE INDEX idx_messages_role ON messages(role);
CREATE INDEX idx_messages_created ON messages(created_at);

-- =============================================================================
-- Tasks
-- =============================================================================
CREATE TABLE tasks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    session_id UUID REFERENCES sessions(id) ON DELETE SET NULL,

    task_type VARCHAR(100) NOT NULL,
    description TEXT,
    status task_status DEFAULT 'pending',
    priority task_priority DEFAULT 'normal',

    graph_id UUID,
    current_node_id VARCHAR(255),

    input_data JSONB DEFAULT '{}',
    output_data JSONB,

    error TEXT,
    error_code VARCHAR(100),
    retry_count INTEGER DEFAULT 0,
    max_retries INTEGER DEFAULT 3,

    agent_id VARCHAR(100),
    model_id VARCHAR(100),
    tokens_used INTEGER,

    deadline_at TIMESTAMP WITH TIME ZONE,
    started_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,

    tags TEXT[] DEFAULT '{}',
    metadata JSONB DEFAULT '{}',

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_tasks_tenant ON tasks(tenant_id);
CREATE INDEX idx_tasks_user ON tasks(user_id);
CREATE INDEX idx_tasks_status ON tasks(status);
CREATE INDEX idx_tasks_priority ON tasks(priority);
CREATE INDEX idx_tasks_created ON tasks(created_at);
CREATE INDEX idx_tasks_type ON tasks(task_type);

-- =============================================================================
-- Task Graphs
-- =============================================================================
CREATE TABLE task_graphs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    task_id UUID REFERENCES tasks(id) ON DELETE CASCADE,

    name VARCHAR(255) NOT NULL,
    description TEXT,
    graph_data JSONB NOT NULL DEFAULT '{}',
    nodes JSONB NOT NULL DEFAULT '[]',
    edges JSONB NOT NULL DEFAULT '[]',

    entry_node_id VARCHAR(255),
    exit_node_id VARCHAR(255),
    variables JSONB DEFAULT '{}',
    config JSONB DEFAULT '{}',

    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_task_graphs_tenant ON task_graphs(tenant_id);
CREATE INDEX idx_task_graphs_task ON task_graphs(task_id);

-- =============================================================================
-- Agent Runs
-- =============================================================================
CREATE TABLE agent_runs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    task_id UUID REFERENCES tasks(id) ON DELETE CASCADE,
    agent_id VARCHAR(100) NOT NULL,
    agent_role VARCHAR(100),
    trace_id UUID,

    messages JSONB DEFAULT '[]',
    output TEXT,

    status VARCHAR(50) DEFAULT 'running',
    tokens_used INTEGER,
    execution_time_ms INTEGER,

    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,

    metadata JSONB DEFAULT '{}'
);

CREATE INDEX idx_agent_runs_task ON agent_runs(task_id);
CREATE INDEX idx_agent_runs_agent ON agent_runs(agent_id);
CREATE INDEX idx_agent_runs_trace ON agent_runs(trace_id);

-- =============================================================================
-- Tool Registry
-- =============================================================================
CREATE TABLE tools (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tool_id VARCHAR(100) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category tool_category,

    version VARCHAR(20) DEFAULT '1.0.0',
    status VARCHAR(50) DEFAULT 'active',

    input_schema JSONB NOT NULL DEFAULT '{}',
    output_schema JSONB NOT NULL DEFAULT '{}',

    timeout_seconds INTEGER DEFAULT 60,
    max_retries INTEGER DEFAULT 3,
    safe_mode BOOLEAN DEFAULT true,

    cost_per_use_usd DECIMAL(10, 4) DEFAULT 0,
    rate_limit_per_minute INTEGER DEFAULT 100,
    rate_limit_per_hour INTEGER DEFAULT 1000,

    required_permissions TEXT[] DEFAULT '{}',
    min_permission_level VARCHAR(50) DEFAULT 'read',

    provider VARCHAR(100),
    endpoint TEXT,
    tags TEXT[] DEFAULT '{}',
    examples JSONB DEFAULT '[]',

    supports_streaming BOOLEAN DEFAULT false,
    supports_batch BOOLEAN DEFAULT false,
    requires_approval BOOLEAN DEFAULT false,

    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_tools_id ON tools(tool_id);
CREATE INDEX idx_tools_category ON tools(category);
CREATE INDEX idx_tools_status ON tools(status);

-- =============================================================================
-- Tool Executions
-- =============================================================================
CREATE TABLE tool_executions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    invocation_id VARCHAR(100) UNIQUE NOT NULL,
    tool_id UUID NOT NULL REFERENCES tools(id) ON DELETE SET NULL,
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,

    parameters JSONB DEFAULT '{}',
    result JSONB,
    status VARCHAR(50) DEFAULT 'queued',

    execution_time_ms INTEGER,
    tokens_used INTEGER,
    cost_usd DECIMAL(10, 4),

    error TEXT,
    error_code VARCHAR(100),

    risk_level execution_risk_level,
    requires_approval BOOLEAN DEFAULT false,
    approved_by UUID REFERENCES users(id),
    approved_at TIMESTAMP WITH TIME ZONE,

    task_id UUID,
    trace_id UUID,
    session_id UUID,

    output_valid BOOLEAN DEFAULT true,
    validation_error TEXT,

    logs JSONB DEFAULT '[]',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    started_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_tool_executions_tool ON tool_executions(tool_id);
CREATE INDEX idx_tool_executions_tenant ON tool_executions(tenant_id);
CREATE INDEX idx_tool_executions_status ON tool_executions(status);
CREATE INDEX idx_tool_executions_created ON tool_executions(created_at);

-- =============================================================================
-- Memory Records
-- =============================================================================
CREATE TABLE memory_records (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    memory_id VARCHAR(100) UNIQUE NOT NULL,

    memory_type memory_type NOT NULL,
    content TEXT NOT NULL,
    content_hash VARCHAR(64),

    embedding VECTOR(1536),
    embedding_model VARCHAR(100),

    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    session_id UUID REFERENCES sessions(id) ON DELETE SET NULL,
    parent_memory_id UUID REFERENCES memory_records(id) ON DELETE SET NULL,

    importance_score FLOAT DEFAULT 0.5,
    access_count INTEGER DEFAULT 0,
    last_accessed_at TIMESTAMP WITH TIME ZONE,

    access_level VARCHAR(50) DEFAULT 'private',
    tags TEXT[] DEFAULT '{}',
    source TEXT,
    source_url TEXT,
    confidence FLOAT DEFAULT 1.0,
    privacy_classification VARCHAR(100),

    entity_type VARCHAR(100),
    entity_id VARCHAR(255),
    relations JSONB DEFAULT '[]',
    keywords TEXT[] DEFAULT '{}',
    topics TEXT[] DEFAULT '{}',

    status VARCHAR(50) DEFAULT 'active',
    expires_at TIMESTAMP WITH TIME ZONE,
    retention_days INTEGER,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    allowed_users TEXT[] DEFAULT '{}',
    denied_users TEXT[] DEFAULT '{}'
);

CREATE INDEX idx_memory_records_tenant ON memory_records(tenant_id);
CREATE INDEX idx_memory_records_user ON memory_records(user_id);
CREATE INDEX idx_memory_records_type ON memory_records(memory_type);
CREATE INDEX idx_memory_records_embedding ON memory_records USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
CREATE INDEX idx_memory_records_session ON memory_records(session_id);
CREATE INDEX idx_memory_records_created ON memory_records(created_at);

-- =============================================================================
-- Citations
-- =============================================================================
CREATE TABLE citations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    memory_record_id UUID REFERENCES memory_records(id) ON DELETE CASCADE,

    source_type VARCHAR(50),
    source_id VARCHAR(255),
    source_title VARCHAR(500),
    source_url TEXT,
    source_content TEXT,

    page_number INTEGER,
    chunk_index INTEGER,

    relevance_score FLOAT DEFAULT 0,
    trust_score FLOAT DEFAULT 1.0,

    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_citations_memory ON citations(memory_record_id);
CREATE INDEX idx_citations_source ON citations(source_type, source_id);

-- =============================================================================
-- Execution Records
-- =============================================================================
CREATE TABLE execution_records (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    execution_id VARCHAR(100) UNIQUE NOT NULL,

    task_id UUID REFERENCES tasks(id) ON DELETE SET NULL,
    trace_id UUID,
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,

    plan_id UUID,
    steps JSONB DEFAULT '[]',
    mode VARCHAR(50) DEFAULT 'standard',
    status execution_status DEFAULT 'pending',

    risk_level execution_risk_level DEFAULT 'low',
    risk_score FLOAT DEFAULT 0,
    policy_passed BOOLEAN DEFAULT true,
    policy_violations JSONB DEFAULT '[]',

    approval_id UUID,
    approval_status VARCHAR(50),

    output JSONB,
    error TEXT,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    started_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    timeout_at TIMESTAMP WITH TIME ZONE,

    rollback_plan JSONB DEFAULT '[]',
    rolled_back BOOLEAN DEFAULT false,

    execution_time_ms INTEGER,
    tokens_used INTEGER,
    cost_usd DECIMAL(10, 4),

    environment VARCHAR(100),
    sandbox_id VARCHAR(255),
    container_id VARCHAR(255)
);

CREATE INDEX idx_execution_records_tenant ON execution_records(tenant_id);
CREATE INDEX idx_execution_records_task ON execution_records(task_id);
CREATE INDEX idx_execution_records_status ON execution_records(status);
CREATE INDEX idx_execution_records_created ON execution_records(created_at);

-- =============================================================================
-- Approval Requests
-- =============================================================================
CREATE TABLE approval_requests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

    task_id UUID REFERENCES tasks(id) ON DELETE CASCADE,
    execution_plan_id UUID,

    risk_level execution_risk_level NOT NULL,
    risk_factors TEXT[] DEFAULT '{}',

    action_description TEXT,
    affected_resources JSONB DEFAULT '[]',

    requested_by UUID REFERENCES users(id) ON DELETE SET NULL,
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

    status approval_status DEFAULT 'pending',
    requested_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE,
    responded_at TIMESTAMP WITH TIME ZONE,
    responded_by UUID REFERENCES users(id),

    decision VARCHAR(50),
    reason TEXT,
    conditions JSONB,

    callback_url TEXT,
    notification_channels TEXT[] DEFAULT '{}',

    metadata JSONB DEFAULT '{}'
);

CREATE INDEX idx_approval_requests_tenant ON approval_requests(tenant_id);
CREATE INDEX idx_approval_requests_status ON approval_requests(status);
CREATE INDEX idx_approval_requests_requested ON approval_requests(requested_at);

-- =============================================================================
-- Agent Messages
-- =============================================================================
CREATE TABLE agent_messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    message_id VARCHAR(100) UNIQUE NOT NULL,

    trace_id UUID,
    task_id UUID REFERENCES tasks(id) ON DELETE CASCADE,

    sender VARCHAR(100) NOT NULL,
    recipient VARCHAR(100),
    sender_role VARCHAR(100),
    recipient_roles TEXT[] DEFAULT '{}',

    message_type agent_message_type NOT NULL,
    priority INTEGER DEFAULT 2,

    payload JSONB NOT NULL DEFAULT '{}',
    tool_permissions TEXT[] DEFAULT '{}',
    memory_refs TEXT[] DEFAULT '{}',

    metadata JSONB DEFAULT '{}',
    status VARCHAR(50) DEFAULT 'pending',

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    deadline_at TIMESTAMP WITH TIME ZONE,
    delivered_at TIMESTAMP WITH TIME ZONE,
    error TEXT
);

CREATE INDEX idx_agent_messages_trace ON agent_messages(trace_id);
CREATE INDEX idx_agent_messages_task ON agent_messages(task_id);
CREATE INDEX idx_agent_messages_sender ON agent_messages(sender);
CREATE INDEX idx_agent_messages_type ON agent_messages(message_type);
CREATE INDEX idx_agent_messages_created ON agent_messages(created_at);

-- =============================================================================
-- Documents
-- =============================================================================
CREATE TABLE documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

    title VARCHAR(500) NOT NULL,
    content TEXT,
    source VARCHAR(255),
    source_url TEXT,
    document_type VARCHAR(100),
    language VARCHAR(50) DEFAULT 'en',

    file_path TEXT,
    file_hash VARCHAR(64),
    file_size_bytes BIGINT,

    metadata JSONB DEFAULT '{}',
    tags TEXT[] DEFAULT '{}',

    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_documents_tenant ON documents(tenant_id);
CREATE INDEX idx_documents_type ON documents(document_type);
CREATE INDEX idx_documents_created ON documents(created_at);

-- =============================================================================
-- Document Chunks
-- =============================================================================
CREATE TABLE document_chunks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,

    content TEXT NOT NULL,
    chunk_index INTEGER NOT NULL,
    page_number INTEGER,
    position_start INTEGER,
    position_end INTEGER,

    embedding VECTOR(1536),
    embedding_model VARCHAR(100),

    tokens_count INTEGER,
    metadata JSONB DEFAULT '{}',

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_document_chunks_document ON document_chunks(document_id);
CREATE INDEX idx_document_chunks_embedding ON document_chunks USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);

-- =============================================================================
-- Model Usage
-- =============================================================================
CREATE TABLE model_usage (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,

    model_id VARCHAR(100) NOT NULL,
    provider VARCHAR(100),

    input_tokens INTEGER,
    output_tokens INTEGER,
    total_tokens INTEGER,

    cost_usd DECIMAL(12, 6),

    task_id UUID,
    session_id UUID,

    request_type VARCHAR(50),
    latency_ms INTEGER,

    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_model_usage_tenant ON model_usage(tenant_id);
CREATE INDEX idx_model_usage_user ON model_usage(user_id);
CREATE INDEX idx_model_usage_model ON model_usage(model_id);
CREATE INDEX idx_model_usage_created ON model_usage(created_at);

-- =============================================================================
-- Audit Logs
-- =============================================================================
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE SET NULL,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,

    action VARCHAR(100) NOT NULL,
    resource_type VARCHAR(100),
    resource_id VARCHAR(255),

    details JSONB DEFAULT '{}',
    ip_address INET,
    user_agent TEXT,
    trace_id UUID,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_audit_logs_tenant ON audit_logs(tenant_id);
CREATE INDEX idx_audit_logs_user ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_action ON audit_logs(action);
CREATE INDEX idx_audit_logs_created ON audit_logs(created_at);

-- =============================================================================
-- Connectors
-- =============================================================================
CREATE TABLE connectors (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

    connector_type VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,

    auth_type VARCHAR(50),
    credentials JSONB,  -- Encrypted
    config JSONB DEFAULT '{}',

    is_active BOOLEAN DEFAULT true,
    last_sync_at TIMESTAMP WITH TIME ZONE,

    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_connectors_tenant ON connectors(tenant_id);
CREATE INDEX idx_connectors_type ON connectors(connector_type);
CREATE INDEX idx_connectors_active ON connectors(is_active);

-- =============================================================================
-- Budget Tracking
-- =============================================================================
CREATE TABLE budget_records (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

    period_start TIMESTAMP WITH TIME ZONE NOT NULL,
    period_end TIMESTAMP WITH TIME ZONE NOT NULL,
    period_type VARCHAR(50) NOT NULL,

    spending_limit_usd DECIMAL(12, 4),
    spent_usd DECIMAL(12, 4) DEFAULT 0,
    tokens_limit BIGINT,
    tokens_used BIGINT DEFAULT 0,

    alerts_sent INTEGER DEFAULT 0,
    blocked_at TIMESTAMP WITH TIME ZONE,

    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_budget_records_tenant ON budget_records(tenant_id);
CREATE INDEX idx_budget_records_period ON budget_records(period_start, period_end);

-- =============================================================================
-- Trigger Functions
-- =============================================================================

-- Update timestamp trigger
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Update budget spend on model usage
CREATE OR REPLACE FUNCTION update_tenant_spend()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE tenants
    SET current_spend_usd = current_spend_usd + COALESCE(NEW.cost_usd, 0),
        current_tokens_used = current_tokens_used + COALESCE(NEW.total_tokens, 0)
    WHERE id = NEW.tenant_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- =============================================================================
-- Apply Triggers
-- =============================================================================

CREATE TRIGGER update_tenants_updated_at
    BEFORE UPDATE ON tenants
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_sessions_updated_at
    BEFORE UPDATE ON sessions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_tasks_updated_at
    BEFORE UPDATE ON tasks
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_documents_updated_at
    BEFORE UPDATE ON documents
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_budget_records_updated_at
    BEFORE UPDATE ON budget_records
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_model_usage_spend
    AFTER INSERT ON model_usage
    FOR EACH ROW EXECUTE FUNCTION update_tenant_spend();

-- =============================================================================
-- Initial Data
-- =============================================================================

-- Insert default tools
INSERT INTO tools (tool_id, name, description, category, input_schema, output_schema) VALUES
('web_search', 'Web Search', 'Search the web for information', 'web',
 '{"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]}',
 '{"type": "object", "properties": {"results": {"type": "array"}}}'),

('code_execution', 'Code Execution', 'Execute code in sandboxed environment', 'code',
 '{"type": "object", "properties": {"code": {"type": "string"}, "language": {"type": "string"}},"required": ["code"]}',
 '{"type": "object", "properties": {"output": {"type": "string"}, "exit_code": {"type": "integer"}}}'),

('http_request', 'HTTP Request', 'Make HTTP requests to external APIs', 'web',
 '{"type": "object", "properties": {"url": {"type": "string"}, "method": {"type": "string"}, "headers": {"type": "object"}, "body": {"type": "object"}}, "required": ["url"]}',
 '{"type": "object", "properties": {"status": {"type": "integer"}, "body": {"type": "object"}}}');