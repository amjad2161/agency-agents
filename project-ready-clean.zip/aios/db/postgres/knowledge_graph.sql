-- AI-OS Knowledge Graph Schema
-- Tables for knowledge graph, entities, relations, and graph queries

-- =============================================================================
-- Knowledge Graph Enums
-- =============================================================================

DO $$ BEGIN
    CREATE TYPE entity_status AS ENUM ('active', 'archived', 'merged', 'deleted');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE relation_type AS ENUM (
        'owns', 'manages', 'depends_on', 'part_of', 'related_to',
        'causes', 'enables', 'precedes', 'contradicts', 'supports'
    );
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE evidence_type AS ENUM ('direct', 'inferred', 'cited', 'disputed');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

-- =============================================================================
-- Entities (Nodes)
-- =============================================================================
CREATE TABLE kg_entities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_id VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(500) NOT NULL,
    entity_type VARCHAR(100) NOT NULL,
    description TEXT,

    -- Identification
    canonical_name VARCHAR(500),
    aliases TEXT[] DEFAULT '{}',
    external_ids JSONB DEFAULT '{}',  -- {wikipedia: "...", dbpedia: "..."}

    -- Properties
    properties JSONB DEFAULT '{}',
    embedding VECTOR(1536),

    -- Classification
    confidence FLOAT DEFAULT 1.0,
    verification_status VARCHAR(50) DEFAULT 'unverified',
    source_knowledge BOOLEAN DEFAULT false,

    -- Metadata
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    created_by UUID REFERENCES users(id),
    status entity_status DEFAULT 'active',

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    merged_at TIMESTAMP WITH TIME ZONE,
    merged_into_id UUID REFERENCES kg_entities(id)
);

CREATE INDEX idx_kg_entities_type ON kg_entities(entity_type);
CREATE INDEX idx_kg_entities_name ON kg_entities(name);
CREATE INDEX idx_kg_entities_embedding ON kg_entities USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
CREATE INDEX idx_kg_entities_tenant ON kg_entities(tenant_id);
CREATE INDEX idx_kg_entities_status ON kg_entities(status);

-- =============================================================================
-- Relations (Edges)
-- =============================================================================
CREATE TABLE kg_relations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    relation_id VARCHAR(255) UNIQUE NOT NULL,

    -- Source and Target
    source_entity_id UUID NOT NULL REFERENCES kg_entities(id) ON DELETE CASCADE,
    target_entity_id UUID NOT NULL REFERENCES kg_entities(id) ON DELETE CASCADE,
    relation_type relation_type NOT NULL,

    -- Properties
    properties JSONB DEFAULT '{}',
    weight FLOAT DEFAULT 1.0,

    -- Evidence
    evidence_type evidence_type DEFAULT 'cited',
    evidence_sources JSONB DEFAULT '[]',
    confidence FLOAT DEFAULT 1.0,

    -- Temporal
    valid_from TIMESTAMP WITH TIME ZONE,
    valid_to TIMESTAMP WITH TIME ZONE,

    -- Context
    context TEXT,
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    created_by UUID REFERENCES users(id),

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    CONSTRAINT kg_relations_no_self_loop CHECK (source_entity_id != target_entity_id)
);

CREATE INDEX idx_kg_relations_source ON kg_relations(source_entity_id);
CREATE INDEX idx_kg_relations_target ON kg_relations(target_entity_id);
CREATE INDEX idx_kg_relations_type ON kg_relations(relation_type);
CREATE INDEX idx_kg_relations_tenant ON kg_relations(tenant_id);

-- =============================================================================
-- Entity Categories
-- =============================================================================
CREATE TABLE kg_categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    parent_category_id UUID REFERENCES kg_categories(id),
    properties_schema JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_kg_categories_parent ON kg_categories(parent_category_id);

-- =============================================================================
-- Entity-Category Membership
-- =============================================================================
CREATE TABLE kg_entity_categories (
    entity_id UUID NOT NULL REFERENCES kg_entities(id) ON DELETE CASCADE,
    category_id UUID NOT NULL REFERENCES kg_categories(id) ON DELETE CASCADE,
    confidence FLOAT DEFAULT 1.0,
    PRIMARY KEY (entity_id, category_id)
);

CREATE INDEX idx_kg_entity_categories_entity ON kg_entity_categories(entity_id);
CREATE INDEX idx_kg_entity_categories_category ON kg_entity_categories(category_id);

-- =============================================================================
-- Knowledge Assertions (Facts)
-- =============================================================================
CREATE TABLE kg_assertions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    assertion_id VARCHAR(255) UNIQUE NOT NULL,

    entity_id UUID NOT NULL REFERENCES kg_entities(id) ON DELETE CASCADE,
    predicate VARCHAR(200) NOT NULL,
    value TEXT NOT NULL,
    value_type VARCHAR(50),

    -- Provenance
    source_type VARCHAR(50),
    source_id VARCHAR(255),
    source_url TEXT,
    citation_id UUID REFERENCES citations(id),

    -- Verification
    confidence FLOAT DEFAULT 1.0,
    verification_status VARCHAR(50) DEFAULT 'pending',
    verified_by UUID REFERENCES users(id),
    verified_at TIMESTAMP WITH TIME ZONE,

    -- Temporal
    valid_from TIMESTAMP WITH TIME ZONE,
    valid_to TIMESTAMP WITH TIME ZONE,

    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_kg_assertions_entity ON kg_assertions(entity_id);
CREATE INDEX idx_kg_assertions_predicate ON kg_assertions(predicate);
CREATE INDEX idx_kg_assertions_tenant ON kg_assertions(tenant_id);

-- =============================================================================
-- Contradiction Tracking
-- =============================================================================
CREATE TABLE kg_contradictions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

    assertion_a_id UUID NOT NULL REFERENCES kg_assertions(id),
    assertion_b_id UUID NOT NULL REFERENCES kg_assertions(id),

    resolution VARCHAR(50),
    resolved_by UUID REFERENCES users(id),
    resolution_note TEXT,

    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_kg_contradictions_a ON kg_contradictions(assertion_a_id);
CREATE INDEX idx_kg_contradictions_b ON kg_contradictions(assertion_b_id);

-- =============================================================================
-- Graph Versioning
-- =============================================================================
CREATE TABLE kg_versions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    version_number INTEGER NOT NULL,

    changes_summary TEXT,
    entities_added INTEGER DEFAULT 0,
    entities_updated INTEGER DEFAULT 0,
    entities_removed INTEGER DEFAULT 0,
    relations_added INTEGER DEFAULT 0,
    relations_updated INTEGER DEFAULT 0,
    relations_removed INTEGER DEFAULT 0,

    created_by UUID REFERENCES users(id),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    UNIQUE(tenant_id, version_number)
);

CREATE INDEX idx_kg_versions_tenant ON kg_versions(tenant_id);
CREATE INDEX idx_kg_versions_number ON kg_versions(version_number DESC);

-- =============================================================================
-- Graph Analytics (Materialized)
-- =============================================================================
CREATE TABLE kg_entity_metrics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_id UUID NOT NULL REFERENCES kg_entities(id) ON DELETE CASCADE,

    in_degree INTEGER DEFAULT 0,
    out_degree INTEGER DEFAULT 0,
    total_degree INTEGER GENERATED ALWAYS AS (in_degree + out_degree) STORED,

    pagerank_score FLOAT,
    betweenness_centrality FLOAT,
    clustering_coefficient FLOAT,

    computed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    UNIQUE(entity_id)
);

CREATE INDEX idx_kg_entity_metrics_pagerank ON kg_entity_metrics(pagerank_score DESC);

-- =============================================================================
-- Knowledge Ingestion Tracking
-- =============================================================================
CREATE TABLE kg_ingestion_runs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

    source_type VARCHAR(100),
    source_identifier VARCHAR(255),

    entities_processed INTEGER DEFAULT 0,
    relations_processed INTEGER DEFAULT 0,
    assertions_processed INTEGER DEFAULT 0,

    errors JSONB DEFAULT '[]',
    warnings JSONB DEFAULT '[]',

    status VARCHAR(50) DEFAULT 'running',
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_kg_ingestion_runs_status ON kg_ingestion_runs(status);

-- =============================================================================
-- Triggers
-- =============================================================================

-- Update timestamp
CREATE TRIGGER update_kg_entities_updated_at
    BEFORE UPDATE ON kg_entities
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_kg_relations_updated_at
    BEFORE UPDATE ON kg_relations
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Update entity degree counts
CREATE OR REPLACE FUNCTION update_entity_degrees()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE kg_entity_metrics SET
            out_degree = out_degree + 1
        WHERE entity_id = NEW.source_entity_id;

        UPDATE kg_entity_metrics SET
            in_degree = in_degree + 1
        WHERE entity_id = NEW.target_entity_id;

    ELSIF TG_OP = 'DELETE' THEN
        UPDATE kg_entity_metrics SET
            out_degree = out_degree - 1
        WHERE entity_id = OLD.source_entity_id;

        UPDATE kg_entity_metrics SET
            in_degree = in_degree - 1
        WHERE entity_id = OLD.target_entity_id;
    END IF;

    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER kg_relations_degree_trigger
    AFTER INSERT OR DELETE ON kg_relations
    FOR EACH ROW EXECUTE FUNCTION update_entity_degrees();

-- =============================================================================
-- Sample Data
-- =============================================================================

-- Insert sample categories
INSERT INTO kg_categories (name, description) VALUES
('Person', 'Human individuals'),
('Organization', 'Companies, agencies, institutions'),
('Technology', 'Software, hardware, techniques'),
('Concept', 'Abstract ideas and theories'),
('Location', 'Places and geographic entities');

-- Insert sample entities
INSERT INTO kg_entities (entity_id, name, entity_type, description, properties) VALUES
('e-ai', 'Artificial Intelligence', 'Concept', 'Field of computer science focused on intelligent systems',
 '{"subfields": ["machine learning", "deep learning", "NLP"]}'),
('e-ml', 'Machine Learning', 'Technology', 'Subset of AI using statistical techniques',
 '{"type": "supervised", " unsupervised"]}');
