"""
AI-OS Model Router - Provider Abstraction and Routing
"""
from __future__ import annotations

import logging
from datetime import datetime
from enum import Enum
from typing import Any, Protocol

logger = logging.getLogger(__name__)


class TaskComplexity(str, Enum):
    """Task complexity classification"""
    SIMPLE = "simple"       # Direct Q&A, simple transformations
    MODERATE = "moderate"  # Multi-step reasoning, context needed
    COMPLEX = "complex"     # Planning, analysis, creative tasks
    EXPERT = "expert"       # Deep reasoning, research, synthesis


class ModelTier(str, Enum):
    """Model tier classification"""
    LIGHTWEIGHT = "lightweight"  # Fast, cheap models
    STANDARD = "standard"        # Balanced models
    PREMIUM = "premium"         # High capability models
    SPECIALIZED = "specialized"  # Domain-specific models


class ModelConfig:
    """Model configuration"""
    def __init__(
        self,
        model_id: str,
        provider: str,
        tier: ModelTier,
        max_tokens: int,
        capabilities: list[str],
        fallback_models: list[str] | None = None,
        cost_per_1k_input: float = 0.0,
        cost_per_1k_output: float = 0.0,
        latency_ms: int = 1000,
    ):
        self.model_id = model_id
        self.provider = provider
        self.tier = tier
        self.max_tokens = max_tokens
        self.capabilities = capabilities
        self.fallback_models = fallback_models or []
        self.cost_per_1k_input = cost_per_1k_input
        self.cost_per_1k_output = cost_per_1k_output
        self.latency_ms = latency_ms
        self.is_healthy = True
        self.last_health_check = datetime.utcnow()

    def estimate_cost(self, input_tokens: int, output_tokens: int) -> float:
        """Estimate cost for given token counts"""
        return (
            (input_tokens / 1000) * self.cost_per_1k_input +
            (output_tokens / 1000) * self.cost_per_1k_output
        )


class ModelProvider(Protocol):
    """Protocol for model providers"""

    async def complete(
        self,
        messages: list[dict],
        model: str,
        **kwargs,
    ) -> dict[str, Any]:
        """Generate completion"""
        ...

    async def embed(
        self,
        texts: list[str],
        model: str,
    ) -> list[list[float]]:
        """Generate embeddings"""
        ...

    async def health_check(self) -> bool:
        """Check provider health"""
        ...


class OpenAIProvider:
    """OpenAI model provider adapter"""

    def __init__(self, api_key: str | None = None):
        self.api_key = api_key
        self.base_url = "https://api.openai.com/v1"

    async def complete(
        self,
        messages: list[dict],
        model: str,
        **kwargs,
    ) -> dict[str, Any]:
        """Call OpenAI API"""
        # In production, would call actual API
        return {
            "id": f"openai-{model}",
            "model": model,
            "choices": [{
                "message": {
                    "role": "assistant",
                    "content": "Generated response",
                },
                "finish_reason": "stop",
            }],
            "usage": {
                "prompt_tokens": 50,
                "completion_tokens": 100,
                "total_tokens": 150,
            },
        }

    async def embed(self, texts: list[str], model: str) -> list[list[float]]:
        """Generate embeddings via OpenAI"""
        # Return dummy embeddings
        return [[0.1] * 1536 for _ in texts]

    async def health_check(self) -> bool:
        """Check OpenAI API health"""
        return True


class AnthropicProvider:
    """Anthropic model provider adapter"""

    def __init__(self, api_key: str | None = None):
        self.api_key = api_key
        self.base_url = "https://api.anthropic.com/v1"

    async def complete(
        self,
        messages: list[dict],
        model: str,
        **kwargs,
    ) -> dict[str, Any]:
        """Call Anthropic API"""
        return {
            "id": f"anthropic-{model}",
            "model": model,
            "content": [{
                "type": "text",
                "text": "Generated response",
            }],
            "usage": {
                "input_tokens": 50,
                "output_tokens": 100,
            },
        }

    async def health_check(self) -> bool:
        """Check Anthropic API health"""
        return True


class ModelRouter:
    """
    Intelligent model routing based on task requirements.
    Handles provider abstraction, fallback, and cost optimization.
    """

    def __init__(self):
        # Model configurations
        self.models: dict[str, ModelConfig] = {
            "gpt-4-turbo": ModelConfig(
                model_id="gpt-4-turbo",
                provider="openai",
                tier=ModelTier.PREMIUM,
                max_tokens=128000,
                capabilities=["reasoning", "generation", "code", "analysis"],
                fallback_models=["gpt-4", "gpt-3.5-turbo"],
                cost_per_1k_input=0.01,
                cost_per_1k_output=0.03,
                latency_ms=2000,
            ),
            "gpt-3.5-turbo": ModelConfig(
                model_id="gpt-3.5-turbo",
                provider="openai",
                tier=ModelTier.STANDARD,
                max_tokens=16385,
                capabilities=["generation", "code"],
                fallback_models=["gpt-3.5-turbo-16k"],
                cost_per_1k_input=0.0005,
                cost_per_1k_output=0.0015,
                latency_ms=500,
            ),
            "claude-3-opus": ModelConfig(
                model_id="claude-3-opus",
                provider="anthropic",
                tier=ModelTier.PREMIUM,
                max_tokens=200000,
                capabilities=["reasoning", "generation", "analysis", "creative"],
                fallback_models=["claude-3-sonnet", "claude-2"],
                cost_per_1k_input=0.015,
                cost_per_1k_output=0.075,
                latency_ms=2500,
            ),
            "claude-3-sonnet": ModelConfig(
                model_id="claude-3-sonnet",
                provider="anthropic",
                tier=ModelTier.STANDARD,
                max_tokens=200000,
                capabilities=["reasoning", "generation", "analysis"],
                fallback_models=["claude-2"],
                cost_per_1k_input=0.003,
                cost_per_1k_output=0.015,
                latency_ms=1500,
            ),
            "gemini-pro": ModelConfig(
                model_id="gemini-pro",
                provider="google",
                tier=ModelTier.STANDARD,
                max_tokens=32000,
                capabilities=["reasoning", "generation", "multimodal"],
                fallback_models=["gemini-flash"],
                cost_per_1k_input=0.001,
                cost_per_1k_output=0.002,
                latency_ms=800,
            ),
        }

        # Providers
        self.providers: dict[str, ModelProvider] = {
            "openai": OpenAIProvider(),
            "anthropic": AnthropicProvider(),
        }

        # Budget tracking
        self.budgets: dict[str, dict[str, float]] = {}  # tenant_id -> {spent, limit}

    def classify_complexity(
        self,
        task_type: str,
        messages: list[dict],
        context: dict[str, Any] | None = None,
    ) -> TaskComplexity:
        """
        Classify task complexity based on input.

        Uses heuristics:
        - Message count (more messages = more complex)
        - Token count (longer = more complex)
        - Task type (specific types are more complex)
        - Tool usage (tools = complex)
        """
        # Simple task types
        if task_type in ["chat", "simple_qa"]:
            # Check if simple
            if len(messages) <= 2:
                return TaskComplexity.SIMPLE

        # Complex task types
        if task_type in ["research", "analysis", "code_generation", "planning"]:
            return TaskComplexity.COMPLEX

        # Check message count
        if len(messages) > 10:
            return TaskComplexity.COMPLEX
        elif len(messages) > 5:
            return TaskComplexity.MODERATE

        # Check for tools
        if context and context.get("tools"):
            return TaskComplexity.COMPLEX

        return TaskComplexity.MODERATE

    def route_model(
        self,
        complexity: TaskComplexity,
        requirements: dict[str, Any] | None = None,
        tenant_id: str | None = None,
    ) -> ModelConfig | None:
        """
        Route to appropriate model based on complexity and requirements.

        Args:
            complexity: Task complexity level
            requirements: Additional requirements (modalities, capabilities, etc.)
            tenant_id: Tenant for budget checking

        Returns:
            Selected model configuration or None
        """
        requirements = requirements or {}

        # Check budget constraints
        if tenant_id and self.budgets.get(tenant_id, {}).get("limit", 0) > 0:
            spent = self.budgets[tenant_id].get("spent", 0)
            limit = self.budgets[tenant_id]["limit"]
            if spent >= limit:
                # Budget exceeded - route to cheaper model
                return self._get_lightest_model()

        # Route based on complexity
        if complexity == TaskComplexity.SIMPLE:
            # Use lightweight models
            for model_id in ["gemini-pro", "gpt-3.5-turbo"]:
                if model_id in self.models:
                    return self.models[model_id]

        elif complexity == TaskComplexity.MODERATE:
            # Use standard models
            for model_id in ["gpt-3.5-turbo", "gemini-pro", "claude-3-sonnet"]:
                if model_id in self.models:
                    return self.models[model_id]

        elif complexity == TaskComplexity.COMPLEX:
            # Use premium models
            for model_id in ["claude-3-opus", "gpt-4-turbo", "claude-3-sonnet"]:
                if model_id in self.models:
                    return self.models[model_id]

        elif complexity == TaskComplexity.EXPERT:
            # Use highest capability models
            for model_id in ["claude-3-opus", "gpt-4-turbo"]:
                if model_id in self.models:
                    return self.models[model_id]

        # Fallback
        return self._get_default_model()

    def _get_lightest_model(self) -> ModelConfig | None:
        """Get the lightest/cheapest available model"""
        candidates = [
            m for m in self.models.values()
            if m.tier == ModelTier.LIGHTWEIGHT
        ]
        if not candidates:
            candidates = list(self.models.values())
        return min(candidates, key=lambda m: m.cost_per_1k_input + m.cost_per_1k_output)

    def _get_default_model(self) -> ModelConfig | None:
        """Get default model"""
        return self.models.get("gpt-3.5-turbo")

    async def route_and_execute(
        self,
        messages: list[dict],
        task_type: str,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Route request and execute with fallback support.

        Args:
            messages: Chat messages
            task_type: Type of task
            context: Request context

        Returns:
            Model response
        """
        tenant_id = context.get("tenant_id") if context else None

        # Classify complexity
        complexity = self.classify_complexity(task_type, messages, context)

        # Route to model
        model_config = self.route_model(complexity, context, tenant_id)

        if not model_config:
            raise ValueError("No suitable model available")

        # Get provider
        provider = self.providers.get(model_config.provider)

        if not provider:
            raise ValueError(f"Provider {model_config.provider} not available")

        # Execute with fallback
        try:
            response = await provider.complete(
                messages=messages,
                model=model_config.model_id,
            )

            # Track cost
            if context and context.get("usage"):
                self._track_cost(tenant_id, model_config, context["usage"])

            return response

        except Exception as e:
            logger.error(f"Model error: {e}")

            # Try fallback models
            for fallback_id in model_config.fallback_models:
                if fallback_id in self.models:
                    fallback = self.models[fallback_id]
                    try:
                        fallback_provider = self.providers.get(fallback.provider)
                        if fallback_provider:
                            return await fallback_provider.complete(
                                messages=messages,
                                model=fallback.model_id,
                            )
                    except Exception:
                        continue

            raise

    def _track_cost(
        self,
        tenant_id: str | None,
        model_config: ModelConfig,
        usage: dict[str, int],
    ) -> None:
        """Track cost for budget management"""
        if not tenant_id:
            return

        if tenant_id not in self.budgets:
            self.budgets[tenant_id] = {"spent": 0, "limit": 0}

        cost = model_config.estimate_cost(
            usage.get("prompt_tokens", 0),
            usage.get("completion_tokens", 0),
        )

        self.budgets[tenant_id]["spent"] += cost

    def set_budget(
        self,
        tenant_id: str,
        limit: float,
    ) -> None:
        """Set budget for tenant"""
        if tenant_id not in self.budgets:
            self.budgets[tenant_id] = {"spent": 0, "limit": 0}
        self.budgets[tenant_id]["limit"] = limit

    def get_remaining_budget(self, tenant_id: str) -> float:
        """Get remaining budget for tenant"""
        if tenant_id not in self.budgets:
            return 0.0
        budget = self.budgets[tenant_id]
        return max(0.0, budget["limit"] - budget["spent"])


# Global router instance
model_router = ModelRouter()


__all__ = [
    "ModelRouter",
    "ModelConfig",
    "ModelProvider",
    "OpenAIProvider",
    "AnthropicProvider",
    "TaskComplexity",
    "ModelTier",
    "model_router",
]