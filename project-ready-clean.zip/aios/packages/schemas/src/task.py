"""
AI-OS Task Schemas - Task Graph and Orchestration Models
"""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, ConfigDict

from .common import BaseModel as CommonBaseModel, UUIDMixin, TimestampsMixin, PaginationParams


def _utcnow() -> datetime:
    """Return a naive UTC timestamp for compatibility with existing schema fields."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


class TaskStatus(str, Enum):
    """Task execution status"""
    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    BLOCKED = "blocked"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMED_OUT = "timed_out"


class TaskPriority(int, Enum):
    """Task priority levels (lower = higher priority)"""
    CRITICAL = 0
    HIGH = 1
    NORMAL = 2
    LOW = 3
    BACKGROUND = 4


class TaskType(str, Enum):
    """Task type classification"""
    CHAT = "chat"
    RESEARCH = "research"
    CODE_GENERATION = "code_generation"
    DATA_ANALYSIS = "data_analysis"
    CREATIVE = "creative"
    AGENTIC = "agentic"
    WORKFLOW = "workflow"
    SYSTEM = "system"


class NodeStatus(str, Enum):
    """Task graph node status"""
    PENDING = "pending"
    READY = "ready"
    RUNNING = "running"
    BLOCKED = "blocked"
    FAILED = "failed"
    COMPLETED = "completed"
    SKIPPED = "skipped"


class NodeType(str, Enum):
    """Task graph node types"""
    PLAN = "plan"
    REASON = "reason"
    RETRIEVE_MEMORY = "retrieve_memory"
    RETRIEVE_KNOWLEDGE = "retrieve_knowledge"
    INVOKE_TOOL = "invoke_tool"
    VALIDATE = "validate"
    CRITIQUE = "critique"
    SYNTHESIZE = "synthesize"
    FINALIZE = "finalize"
    AGENT = "agent"
    CONDITION = "condition"
    LOOP = "loop"


class TaskMetadata(CommonBaseModel):
    """Task metadata and context"""
    user_id: str | None = None
    session_id: str | None = None
    conversation_id: str | None = None
    parent_task_id: str | None = None
    root_task_id: str | None = None
    agent_id: str | None = None
    model_id: str | None = None
    temperature: float = 0.7
    max_tokens: int | None = None
    streaming: bool = False
    tags: list[str] = Field(default_factory=list)
    custom: dict[str, Any] = Field(default_factory=dict)


class TaskNode(CommonBaseModel):
    """Node in task graph"""
    node_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    node_type: NodeType
    label: str | None = None
    description: str | None = None
    status: NodeStatus = NodeStatus.PENDING
    config: dict[str, Any] = Field(default_factory=dict)
    input_mappings: dict[str, str] = Field(default_factory=dict)
    output_mapping: str | None = None
    depends_on: list[str] = Field(default_factory=list)
    retry_count: int = 0
    max_retries: int = 3
    timeout_seconds: int = 300
    agent_id: str | None = None
    tool_id: str | None = None
    result: dict[str, Any] | None = None
    error: str | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class TaskEdge(CommonBaseModel):
    """Edge connecting nodes in task graph"""
    edge_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    source_node_id: str
    target_node_id: str
    condition: str | None = None  # Optional condition for conditional edges
    priority: int = 0
    metadata: dict[str, Any] = Field(default_factory=dict)


class TaskGraph(CommonBaseModel):
    """Task execution graph (DAG)"""
    graph_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    description: str | None = None
    nodes: list[TaskNode] = Field(default_factory=list)
    edges: list[TaskEdge] = Field(default_factory=list)
    entry_node_id: str | None = None
    exit_node_id: str | None = None
    variables: dict[str, Any] = Field(default_factory=dict)
    config: dict[str, Any] = Field(default_factory=dict)

    def get_node(self, node_id: str) -> TaskNode | None:
        """Get node by ID"""
        for node in self.nodes:
            if node.node_id == node_id:
                return node
        return None

    def get_dependencies(self, node_id: str) -> list[TaskNode]:
        """Get all nodes that the given node depends on"""
        deps = []
        for edge in self.edges:
            if edge.target_node_id == node_id:
                if node := self.get_node(edge.source_node_id):
                    deps.append(node)
        return deps

    def get_dependents(self, node_id: str) -> list[TaskNode]:
        """Get all nodes that depend on the given node"""
        deps = []
        for edge in self.edges:
            if edge.source_node_id == node_id:
                if node := self.get_node(edge.target_node_id):
                    deps.append(node)
        return deps

    def topological_sort(self) -> list[TaskNode]:
        """Return nodes in topological order"""
        in_degree = {n.node_id: 0 for n in self.nodes}
        for edge in self.edges:
            in_degree[edge.target_node_id] = in_degree.get(edge.target_node_id, 0) + 1

        queue = [n for n in self.nodes if in_degree[n.node_id] == 0]
        sorted_nodes = []

        while queue:
            node = queue.pop(0)
            sorted_nodes.append(node)
            for dep in self.get_dependents(node.node_id):
                in_degree[dep.node_id] -= 1
                if in_degree[dep.node_id] == 0:
                    queue.append(dep)

        return sorted_nodes

    def get_ready_nodes(self) -> list[TaskNode]:
        """Get nodes that are ready to execute (all dependencies completed)"""
        ready = []
        for node in self.nodes:
            if node.status != NodeStatus.PENDING:
                continue
            deps = self.get_dependencies(node.node_id)
            if all(d.status == NodeStatus.COMPLETED for d in deps):
                ready.append(node)
        return ready


class TaskResult(CommonBaseModel):
    """Task execution result"""
    task_id: str
    status: TaskStatus
    output: Any = None
    error: str | None = None
    error_code: str | None = None
    execution_time_ms: int | None = None
    tokens_used: int | None = None
    steps_completed: int | None = None
    total_steps: int | None = None
    output_format: str | None = None  # text, json, code, etc.
    citations: list[dict[str, Any]] | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class CreateTaskRequest(CommonBaseModel):
    """Request to create a new task"""
    task_type: TaskType
    description: str | None = None
    priority: TaskPriority = TaskPriority.NORMAL
    input_data: dict[str, Any] = Field(default_factory=dict)
    graph: TaskGraph | None = None  # Optional pre-defined task graph
    parent_task_id: str | None = None
    session_id: str | None = None
    metadata: TaskMetadata = Field(default_factory=TaskMetadata)
    callbacks: list[str] | None = None  # Webhook URLs
    deadline_at: datetime | None = None
    tags: list[str] = Field(default_factory=list)


class UpdateTaskRequest(CommonBaseModel):
    """Request to update task status"""
    status: TaskStatus | None = None
    progress: float | None = None
    output: Any | None = None
    error: str | None = None
    metadata: dict[str, Any] | None = None


class Task(UUIDMixin, TimestampsMixin):
    """Main task entity"""
    task_type: TaskType
    description: str | None = None
    status: TaskStatus = TaskStatus.PENDING
    priority: TaskPriority = TaskPriority.NORMAL

    # Execution tracking
    graph_id: str | None = None
    current_node_id: str | None = None

    # Input/Output
    input_data: dict[str, Any] = Field(default_factory=dict)
    output_data: Any = None

    # Error handling
    error: str | None = None
    error_code: str | None = None
    retry_count: int = 0
    max_retries: int = 3

    # Timing
    deadline_at: datetime | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None

    # Execution metadata
    agent_id: str | None = None
    model_id: str | None = None
    tokens_used: int | None = None

    # Relationships
    tenant_id: str
    user_id: str | None = None
    session_id: str | None = None

    # Metadata
    tags: list[str] = Field(default_factory=list)
    metadata: TaskMetadata = Field(default_factory=TaskMetadata)

    def is_completed(self) -> bool:
        """Check if task is in terminal state"""
        return self.status in {
            TaskStatus.COMPLETED,
            TaskStatus.FAILED,
            TaskStatus.CANCELLED,
            TaskStatus.TIMED_OUT
        }

    def can_retry(self) -> bool:
        """Check if task can be retried"""
        return self.retry_count < self.max_retries and not self.is_completed()

    @property
    def execution_time_ms(self) -> int | None:
        """Calculate execution time in milliseconds"""
        if self.started_at and self.completed_at:
            return int((self.completed_at - self.started_at).total_seconds() * 1000)
        return None

    @property
    def is_overdue(self) -> bool:
        """Check if task has passed its deadline"""
        if self.deadline_at and self.started_at:
            return _utcnow() > self.deadline_at
        return False


class TaskListResponse(CommonBaseModel):
    """Paginated task list response"""
    tasks: list[Task]
    pagination: PaginationParams
    total: int