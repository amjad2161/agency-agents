"""
AI-OS Shared Schemas - Common Data Models
Unified schemas for all services in the AI-OS monorepo.
"""

from .task import (
    Task,
    TaskStatus,
    TaskPriority,
    TaskType,
    TaskNode,
    TaskEdge,
    TaskGraph,
    TaskResult,
    TaskMetadata,
    CreateTaskRequest,
    UpdateTaskRequest,
)
from .agent_message import (
    AgentMessage,
    AgentMessageType,
    AgentRole,
    MessagePriority,
    MessagePayload,
    MessageMetadata,
)
from .tool_call import (
    ToolCall,
    ToolManifest,
    ToolPermission,
    ToolExecutionResult,
    ToolPermissionLevel,
    ToolCategory,
    ToolStatus,
)
from .memory_record import (
    MemoryRecord,
    MemoryType,
    MemoryMetadata,
    MemorySearchRequest,
    MemorySearchResult,
    SemanticMemoryRecord,
    EpisodicMemoryRecord,
    WorkingMemoryRecord,
    ProceduralMemoryRecord,
)
from .execution_record import (
    ExecutionRecord,
    ExecutionStatus,
    ExecutionRiskLevel,
    ApprovalRequest,
    ApprovalDecision,
    ApprovalStatus,
    ExecutionPlan,
    ExecutionStep,
    RollbackAction,
    RiskPolicy,
)
from .session import (
    Session,
    SessionStatus,
    SessionConfig,
    CreateSessionRequest,
)
from .tenant import (
    Tenant,
    TenantConfig,
    TenantTier,
    BudgetConfig,
    RateLimitConfig,
)
from .common import (
    BaseModel,
    UUIDMixin,
    TimestampsMixin,
    PaginationParams,
    FilterParams,
    SortOrder,
    HealthStatus,
    MetricsData,
    ErrorResponse,
)

__all__ = [
    # Task schemas
    "Task",
    "TaskStatus",
    "TaskPriority",
    "TaskType",
    "TaskNode",
    "TaskEdge",
    "TaskGraph",
    "TaskResult",
    "TaskMetadata",
    "CreateTaskRequest",
    "UpdateTaskRequest",
    # Agent message schemas
    "AgentMessage",
    "AgentMessageType",
    "AgentRole",
    "MessagePriority",
    "MessagePayload",
    "MessageMetadata",
    # Tool schemas
    "ToolCall",
    "ToolManifest",
    "ToolPermission",
    "ToolExecutionResult",
    "ToolPermissionLevel",
    "ToolCategory",
    "ToolStatus",
    # Memory schemas
    "MemoryRecord",
    "MemoryType",
    "MemoryMetadata",
    "MemorySearchRequest",
    "MemorySearchResult",
    "SemanticMemoryRecord",
    "EpisodicMemoryRecord",
    "WorkingMemoryRecord",
    "ProceduralMemoryRecord",
    # Execution schemas
    "ExecutionRecord",
    "ExecutionStatus",
    "ExecutionRiskLevel",
    "ApprovalRequest",
    "ApprovalDecision",
    "ApprovalStatus",
    "ExecutionPlan",
    "ExecutionStep",
    "RollbackAction",
    "RiskPolicy",
    # Session schemas
    "Session",
    "SessionStatus",
    "SessionConfig",
    "CreateSessionRequest",
    # Tenant schemas
    "Tenant",
    "TenantConfig",
    "TenantTier",
    "BudgetConfig",
    "RateLimitConfig",
    # Common schemas
    "BaseModel",
    "UUIDMixin",
    "TimestampsMixin",
    "PaginationParams",
    "FilterParams",
    "SortOrder",
    "HealthStatus",
    "MetricsData",
    "ErrorResponse",
]

__version__ = "1.0.0"