"""
AI-OS Session Schemas - Session Management
"""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any

from pydantic import Field

from .common import BaseModel as CommonBaseModel, UUIDMixin, TimestampsMixin


def _utcnow() -> datetime:
    """Return a naive UTC timestamp for compatibility with existing schema fields."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


class SessionStatus(str, Enum):
    """Session status"""
    ACTIVE = "active"
    IDLE = "idle"
    EXPIRED = "expired"
    CLOSED = "closed"


class SessionConfig(CommonBaseModel):
    """Session configuration"""
    max_history_length: int = 50
    max_token_budget: int = 100000
    context_window_tokens: int = 8000
    auto_archive: bool = True
    archive_after_seconds: int = 3600  # 1 hour idle
    memory_type: str = "hybrid"  # working, semantic, hybrid

    # Model preferences
    preferred_model: str | None = None
    temperature: float = 0.7
    max_response_tokens: int = 4096

    # Safety settings
    content_filter: bool = True
    injection_detection: bool = True
    max_tool_calls: int = 20


class CreateSessionRequest(CommonBaseModel):
    """Request to create a session"""
    user_id: str
    tenant_id: str

    session_type: str = "chat"  # chat, agentic, research
    title: str | None = None

    config: SessionConfig = Field(default_factory=SessionConfig)

    # Context
    parent_session_id: str | None = None
    initial_context: dict[str, Any] | None = None

    # Metadata
    metadata: dict[str, Any] = Field(default_factory=dict)
    tags: list[str] = Field(default_factory=list)


class Session(UUIDMixin, TimestampsMixin):
    """Session entity"""
    user_id: str
    tenant_id: str

    session_type: str = "chat"
    title: str | None = None

    status: SessionStatus = SessionStatus.ACTIVE

    # Configuration
    config: SessionConfig = Field(default_factory=SessionConfig)

    # Context
    parent_session_id: str | None = None
    root_session_id: str | None = None

    # Usage tracking
    message_count: int = 0
    token_usage: int = 0
    tool_calls: int = 0

    # Activity
    last_activity_at: datetime = Field(default_factory=_utcnow)
    last_message_at: datetime | None = None

    # Expiration
    expires_at: datetime | None = None
    archived_at: datetime | None = None

    # Metadata
    tags: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)

    # Relationships
    agent_ids: list[str] = Field(default_factory=list)
    tool_ids: list[str] = Field(default_factory=list)

    def is_active(self) -> bool:
        """Check if session is active"""
        return self.status == SessionStatus.ACTIVE

    def is_expired(self) -> bool:
        """Check if session has expired"""
        if self.expires_at and _utcnow() > self.expires_at:
            return True
        if self.status == SessionStatus.EXPIRED:
            return True
        return False

    def update_activity(self) -> None:
        """Update last activity timestamp"""
        now = _utcnow()
        self.last_activity_at = now
        self.last_message_at = now

    def archive(self) -> None:
        """Archive the session"""
        self.status = SessionStatus.EXPIRED
        self.archived_at = _utcnow()


class Message(UUIDMixin):
    """Chat message"""
    session_id: str
    role: str  # system, user, assistant, tool

    content: str
    model: str | None = None

    # Usage
    tokens_used: int | None = None
    input_tokens: int | None = None
    output_tokens: int | None = None

    # Context
    parent_message_id: str | None = None
    task_id: str | None = None

    # Attachments
    attachments: list[dict[str, Any]] = Field(default_factory=list)

    # Metadata
    metadata: dict[str, Any] = Field(default_factory=dict)

    # Timestamps
    created_at: datetime = Field(default_factory=_utcnow)

    # Processing
    tool_calls: list[dict[str, Any]] = Field(default_factory=list)
    citations: list[dict[str, Any]] = Field(default_factory=list)


class ConversationContext(CommonBaseModel):
    """Conversation context for LLM"""
    session_id: str
    messages: list[Message]

    # System prompt
    system_prompt: str | None = None

    # Context data
    memory_context: list[dict[str, Any]] = Field(default_factory=list)
    knowledge_context: list[dict[str, Any]] = Field(default_factory=list)

    # Configuration
    model: str
    temperature: float = 0.7
    max_tokens: int = 4096

    # Token accounting
    total_tokens: int = 0
    remaining_tokens: int = 0

    # Active task
    active_task_id: str | None = None
    active_agent_id: str | None = None