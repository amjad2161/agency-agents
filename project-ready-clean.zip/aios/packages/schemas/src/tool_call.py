"""
AI-OS Tool Call Schemas - Tool Registry and Execution
"""
from __future__ import annotations

import uuid
from datetime import datetime
from enum import Enum
from typing import Any, Callable

from pydantic import BaseModel, Field

from .common import BaseModel, UUIDMixin


class ToolPermissionLevel(str, Enum):
    """Tool permission levels"""
    NONE = "none"
    READ = "read"
    WRITE = "write"
    EXECUTE = "execute"
    ADMIN = "admin"


class ToolCategory(str, Enum):
    """Tool category classification"""
    WEB = "web"                    # Web search, scraping, APIs
    CODE = "code"                  # Code execution, generation
    DATA = "data"                  # Database, file operations
    COMMUNICATION = "communication"  # Email, messaging
    INTEGRATION = "integration"    # External service integration
    SYSTEM = "system"              # System operations
    CREATIVE = "creative"          # Content generation
    ANALYSIS = "analysis"          # Data analysis


class ToolStatus(str, Enum):
    """Tool status"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    DEPRECATED = "deprecated"
    BETA = "beta"


class ToolManifest(BaseModel):
    """Tool manifest describing tool capabilities"""
    tool_id: str
    name: str
    description: str
    category: ToolCategory

    version: str = "1.0.0"
    status: ToolStatus = ToolStatus.ACTIVE

    # Schema definitions
    input_schema: dict[str, Any]  # JSON Schema for inputs
    output_schema: dict[str, Any]  # JSON Schema for outputs

    # Execution parameters
    timeout_seconds: int = 60
    max_retries: int = 3
    safe_mode: bool = True  # Sandboxed execution

    # Cost and rate limiting
    cost_per_use_usd: float = 0.0
    rate_limit_per_minute: int = 100
    rate_limit_per_hour: int = 1000

    # Permission requirements
    required_permissions: list[str] = Field(default_factory=list)
    min_permission_level: ToolPermissionLevel = ToolPermissionLevel.READ

    # Metadata
    provider: str | None = None  # External service provider
    endpoint: str | None = None  # API endpoint
    tags: list[str] = Field(default_factory=list)
    examples: list[dict[str, Any]] = Field(default_factory=list)

    # Capabilities
    supports_streaming: bool = False
    supports_batch: bool = False
    requires_approval: bool = False  # Human-in-the-loop required

    # Dependencies
    depends_on: list[str] = Field(default_factory=list)

    metadata: dict[str, Any] = Field(default_factory=dict)


class ToolPermission(BaseModel):
    """Tool permission record"""
    tool_id: str
    tenant_id: str | None = None
    user_id: str | None = None
    permission_level: ToolPermissionLevel
    granted_by: str
    granted_at: datetime = Field(default_factory=datetime.utcnow)
    expires_at: datetime | None = None
    conditions: dict[str, Any] = Field(default_factory=dict)
    revoke_reason: str | None = None


class ToolCall(UUIDMixin):
    """Tool invocation request"""
    invocation_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    tool_id: str

    # Input parameters
    parameters: dict[str, Any] = Field(default_factory=dict)

    # Execution context
    task_id: str | None = None
    trace_id: str | None = None
    tenant_id: str
    user_id: str | None = None
    session_id: str | None = None

    # Execution control
    mode: str = "execute"  # execute, dry_run, preview
    timeout_seconds: int | None = None
    retry_count: int = 0

    # Risk assessment
    risk_level: str | None = None
    requires_approval: bool = False
    approved_by: str | None = None
    approved_at: datetime | None = None

    # Timing
    queued_at: datetime = Field(default_factory=datetime.utcnow)
    started_at: datetime | None = None
    completed_at: datetime | None = None

    # Status
    status: str = "queued"  # queued, running, completed, failed, cancelled
    error: str | None = None

    # Output
    result: Any = None
    output_validated: bool = False
    validation_error: str | None = None

    # Metadata
    tool_version: str | None = None
    execution_context: dict[str, Any] = Field(default_factory=dict)

    def is_completed(self) -> bool:
        """Check if tool call is in terminal state"""
        return self.status in {"completed", "failed", "cancelled"}

    def can_retry(self) -> bool:
        """Check if tool call can be retried"""
        return self.retry_count < 3 and self.status == "failed"


class ToolExecutionResult(BaseModel):
    """Tool execution result"""
    invocation_id: str
    tool_id: str

    success: bool
    status: str

    # Output
    output: Any = None
    error: str | None = None
    error_code: str | None = None

    # Execution metrics
    execution_time_ms: int | None = None
    tokens_used: int | None = None
    cost_usd: float | None = None

    # Validation
    output_valid: bool = True
    validation_warnings: list[str] = Field(default_factory=list)

    # Metadata
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    metadata: dict[str, Any] = Field(default_factory=dict)

    # Citations for knowledge tools
    citations: list[dict[str, Any]] | None = None

    # Logs
    logs: list[dict[str, Any]] = Field(default_factory=list)


class ToolInvocationHistory(BaseModel):
    """History of tool invocations for a user/tenant"""
    invocation_id: str
    tool_id: str
    tool_name: str

    # Context
    tenant_id: str
    user_id: str | None = None
    task_id: str | None = None

    # Execution
    status: str
    parameters: dict[str, Any] = Field(default_factory=dict)
    result_size_bytes: int | None = None

    # Timing
    created_at: datetime
    completed_at: datetime | None = None
    execution_time_ms: int | None = None

    # Metrics
    cost_usd: float | None = None
    success: bool


class ToolHealthStatus(BaseModel):
    """Tool health status"""
    tool_id: str
    status: str  # healthy, degraded, unhealthy, unknown

    # Metrics
    latency_p50_ms: float | None = None
    latency_p95_ms: float | None = None
    latency_p99_ms: float | None = None
    error_rate: float = 0.0
    success_rate: float = 1.0

    # Capacity
    requests_per_minute: int = 0
    capacity_utilization: float = 0.0

    # Status
    last_check: datetime = Field(default_factory=datetime.utcnow)
    last_error: str | None = None
    is_available: bool = True


class BatchToolCall(BaseModel):
    """Batch tool invocation request"""
    batch_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    tool_calls: list[ToolCall]

    mode: str = "sequential"  # sequential, parallel
    stop_on_error: bool = True

    max_parallel: int = 5
    timeout_per_call: int = 60
    total_timeout: int = 3600


class BatchToolResult(BaseModel):
    """Batch tool execution results"""
    batch_id: str
    total_calls: int
    successful: int = 0
    failed: int = 0

    results: list[ToolExecutionResult]

    total_execution_time_ms: int | None = None
    total_cost_usd: float = 0.0

    metadata: dict[str, Any] = Field(default_factory=dict)