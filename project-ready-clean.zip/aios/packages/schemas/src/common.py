"""
AI-OS Base Schemas - Common Foundation Models
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Generic, TypeVar

from pydantic import BaseModel as PydanticBaseModel, Field, ConfigDict


T = TypeVar("T")


class SortOrder(str, Enum):
    """Sort order for queries"""
    ASC = "asc"
    DESC = "desc"


class HealthStatus(str, Enum):
    """Health check status"""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


class BaseModel(PydanticBaseModel):
    """Enhanced Pydantic base model with common configuration"""

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        arbitrary_types_allowed=False,
        use_enum_values=False,
    )


class UUIDMixin(BaseModel):
    """Mixin providing UUID primary key"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))


class TimestampsMixin(BaseModel):
    """Mixin providing created/updated timestamps"""
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc).replace(tzinfo=None))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc).replace(tzinfo=None))
    created_by: str | None = None
    updated_by: str | None = None


class PaginationParams(BaseModel):
    """Pagination parameters for list endpoints"""
    page: int = Field(default=1, ge=1, description="Page number")
    page_size: int = Field(default=20, ge=1, le=100, description="Items per page")
    total: int | None = Field(default=None, ge=0, description="Total count")

    @property
    def offset(self) -> int:
        """Calculate offset for database queries"""
        return (self.page - 1) * self.page_size

    @property
    def limit(self) -> int:
        """Return page size as limit"""
        return self.page_size

    @property
    def has_next(self) -> bool:
        """Check if there are more pages"""
        if self.total is None:
            return False
        return self.page * self.page_size < self.total

    @property
    def has_prev(self) -> bool:
        """Check if there is a previous page"""
        return self.page > 1


class FilterParams(BaseModel):
    """Filter parameters for query endpoints"""
    search: str | None = Field(default=None, max_length=500, description="Search text")
    status: list[str] | None = Field(default=None, description="Status filter")
    tags: list[str] | None = Field(default=None, description="Tag filter")
    date_from: datetime | None = Field(default=None, description="Date range start")
    date_to: datetime | None = Field(default=None, description="Date range end")
    tenant_id: str | None = Field(default=None, description="Tenant filter")


class MetricsData(BaseModel):
    """Metrics data for monitoring"""
    name: str
    value: float | int
    unit: str | None = None
    labels: dict[str, str] | None = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc).replace(tzinfo=None))
    metric_type: str = "gauge"  # gauge, counter, histogram


class ErrorResponse(BaseModel):
    """Standard error response"""
    error_code: str
    message: str
    details: dict[str, Any] | None = None
    request_id: str | None = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc).replace(tzinfo=None))
    path: str | None = None
    method: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for logging"""
        return {
            "error_code": self.error_code,
            "message": self.message,
            "details": self.details,
            "request_id": self.request_id,
            "timestamp": self.timestamp.isoformat(),
            "path": self.path,
            "method": self.method,
        }


class PaginatedResponse(BaseModel, Generic[T]):
    """Paginated response wrapper"""
    items: list[T]
    pagination: PaginationParams
    filters: FilterParams | None = None


class SuccessResponse(BaseModel):
    """Generic success response"""
    success: bool = True
    message: str | None = None
    data: dict[str, Any] | None = None
    request_id: str | None = None


class TracingContext(BaseModel):
    """Distributed tracing context"""
    trace_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    span_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:16])
    parent_span_id: str | None = None
    tenant_id: str | None = None
    user_id: str | None = None
    session_id: str | None = None

    def to_dict(self) -> dict[str, str]:
        """Convert to dictionary for propagation"""
        return {
            "trace_id": self.trace_id,
            "span_id": self.span_id,
            "parent_span_id": self.parent_span_id or "",
            "tenant_id": self.tenant_id or "",
            "user_id": self.user_id or "",
            "session_id": self.session_id or "",
        }

    @classmethod
    def from_dict(cls, data: dict[str, str]) -> TracingContext:
        """Create from dictionary"""
        return cls(
            trace_id=data.get("trace_id", str(uuid.uuid4())),
            span_id=data.get("span_id", str(uuid.uuid4())[:16]),
            parent_span_id=data.get("parent_span_id"),
            tenant_id=data.get("tenant_id"),
            user_id=data.get("user_id"),
            session_id=data.get("session_id"),
        )


class HealthCheckResponse(BaseModel):
    """Health check response"""
    status: HealthStatus
    service: str
    version: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    checks: dict[str, HealthStatus] | None = None
    metadata: dict[str, Any] | None = None