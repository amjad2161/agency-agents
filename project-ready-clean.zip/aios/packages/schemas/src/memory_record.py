"""
AI-OS Memory Record Schemas - Multi-tier Memory System
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

from .common import BaseModel as CommonBaseModel, UUIDMixin


def _utcnow() -> datetime:
    """Return a naive UTC timestamp for compatibility with existing schema fields."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


class MemoryType(str, Enum):
    """Memory type classification"""
    WORKING = "working"           # Short-term, session-scoped
    SEMANTIC = "semantic"         # Long-term, vector-indexed
    EPISODIC = "episodic"        # Event/experience records
    PROCEDURAL = "procedural"     # Learned skills/procedures
    SENSORY = "sensory"           # Raw perception data


class MemoryStatus(str, Enum):
    """Memory record status"""
    ACTIVE = "active"
    ARCHIVED = "archived"
    EXPIRED = "expired"
    DELETED = "deleted"


class MemoryAccessLevel(str, Enum):
    """Memory access level"""
    PUBLIC = "public"
    PRIVATE = "private"
    SHARED = "shared"
    CONFIDENTIAL = "confidential"


class MemoryMetadata(CommonBaseModel):
    """Memory metadata"""
    importance_score: float = Field(default=0.5, ge=0.0, le=1.0)
    access_count: int = 0
    last_accessed_at: datetime | None = None
    access_level: MemoryAccessLevel = MemoryAccessLevel.PRIVATE
    tags: list[str] = Field(default_factory=list)
    source: str | None = None
    source_url: str | None = None
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    privacy_classification: str | None = None  # PII, PHI, etc.


class MemorySearchRequest(BaseModel):
    """Memory search request"""
    query: str
    memory_types: list[MemoryType] | None = None

    # Filtering
    tenant_id: str | None = None
    user_id: str | None = None
    session_id: str | None = None
    tags: list[str] | None = None
    date_from: datetime | None = None
    date_to: datetime | None = None

    # Retrieval parameters
    top_k: int = 10
    min_relevance: float = 0.0
    include_embeddings: bool = False

    # Processing options
    rerank: bool = True
    compress: bool = False
    max_context_tokens: int = 4000


class MemorySearchResult(BaseModel):
    """Memory search result"""
    memory_id: str
    memory_type: MemoryType
    content: str

    # Relevance scoring
    relevance_score: float = Field(ge=0.0, le=1.0)
    vector_score: float | None = None
    symbolic_score: float | None = None

    # Temporal weighting
    recency_weight: float = 1.0

    # Combined score
    combined_score: float = Field(default=0.0, ge=0.0, le=1.0)

    # Metadata
    metadata: MemoryMetadata = Field(default_factory=MemoryMetadata)
    created_at: datetime

    # Source attribution
    source: str | None = None
    citations: list[dict[str, Any]] = Field(default_factory=list)

    # Context
    session_id: str | None = None
    conversation_id: str | None = None


class MemoryRecord(UUIDMixin):
    """Base memory record"""
    memory_type: MemoryType

    # Content
    content: str
    content_hash: str | None = None

    # Embeddings
    embedding: list[float] | None = None
    embedding_model: str | None = None

    # Relationships
    tenant_id: str
    user_id: str | None = None
    session_id: str | None = None
    parent_memory_id: str | None = None

    # Metadata
    metadata: MemoryMetadata = Field(default_factory=MemoryMetadata)

    # Retention
    status: MemoryStatus = MemoryStatus.ACTIVE
    expires_at: datetime | None = None
    retention_days: int | None = None

    # Timestamps
    created_at: datetime = Field(default_factory=_utcnow)
    updated_at: datetime = Field(default_factory=_utcnow)

    # Access control
    allowed_users: list[str] = Field(default_factory=list)
    denied_users: list[str] = Field(default_factory=list)

    def access(self) -> None:
        """Record memory access"""
        self.metadata.access_count += 1
        self.metadata.last_accessed_at = _utcnow()


class SemanticMemoryRecord(MemoryRecord):
    """Semantic memory - long-term knowledge storage"""
    memory_type: MemoryType = MemoryType.SEMANTIC

    # Knowledge graph
    entity_type: str | None = None
    entity_id: str | None = None
    relations: list[dict[str, str]] = Field(default_factory=list)

    # Indexing
    keywords: list[str] = Field(default_factory=list)
    topics: list[str] = Field(default_factory=list)

    # Verification
    verified: bool = False
    verified_by: str | None = None
    verified_at: datetime | None = None

    # Source tracking
    source_document_id: str | None = None
    page_number: int | None = None
    chunk_index: int | None = None


class EpisodicMemoryRecord(MemoryRecord):
    """Episodic memory - event/experience records"""
    memory_type: MemoryType = MemoryType.EPISODIC

    # Event classification
    event_type: str
    event_category: str | None = None

    # Event details
    event_data: dict[str, Any] = Field(default_factory=dict)
    participants: list[str] = Field(default_factory=list)

    # Temporal context
    duration_seconds: int | None = None
    location: str | None = None

    # Emotional/contextual
    sentiment: float | None = None
    importance: float = 0.5
    emotional_tags: list[str] = Field(default_factory=list)

    # Links to other memories
    related_memory_ids: list[str] = Field(default_factory=list)


class WorkingMemoryRecord(MemoryRecord):
    """Working memory - session-scoped temporary storage"""
    memory_type: MemoryType = MemoryType.WORKING

    # Scope
    scope: str = "session"  # session, task, step

    # Key-value style storage
    key: str
    value: Any

    # TTL
    ttl_seconds: int | None = None
    auto_extend: bool = True

    # LRU tracking
    last_used_at: datetime = Field(default_factory=datetime.utcnow)
    use_count: int = 0


class ProceduralMemoryRecord(MemoryRecord):
    """Procedural memory - learned skills and procedures"""
    memory_type: MemoryType = MemoryType.PROCEDURAL

    # Skill definition
    skill_name: str
    skill_category: str | None = None
    description: str | None = None

    # Procedure definition
    procedure: dict[str, Any]  # Serialized procedure/steps
    code_snippet: str | None = None
    language: str | None = None

    # Usage tracking
    times_used: int = 0
    success_rate: float = 1.0
    avg_execution_time_ms: int | None = None

    # Requirements
    required_permissions: list[str] = Field(default_factory=list)
    required_tools: list[str] = Field(default_factory=list)

    # Version tracking
    version: str = "1.0.0"
    previous_version_id: str | None = None


class MemoryRetrievalContext(BaseModel):
    """Context for memory retrieval pipeline"""
    request: MemorySearchRequest

    # Pipeline state
    stage: str  # query_normalization, embedding, vector_recall, etc.
    stages_completed: list[str] = Field(default_factory=list)

    # Intermediate results
    normalized_query: str | None = None
    query_embedding: list[float] | None = None
    vector_results: list[MemorySearchResult] = Field(default_factory=list)
    symbolic_results: list[MemorySearchResult] = Field(default_factory=list)
    merged_results: list[MemorySearchResult] = Field(default_factory=list)
    compressed_results: list[MemorySearchResult] = Field(default_factory=list)

    # Timing
    started_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: datetime | None = None

    # Metrics
    total_tokens_used: int = 0
    total_cost_usd: float = 0.0


class MemoryConsolidationRequest(BaseModel):
    """Request to consolidate memories"""
    source_types: list[MemoryType]
    target_type: MemoryType

    user_id: str
    tenant_id: str

    strategy: str = "importance"  # importance, recency, similarity
    max_memories: int = 100

    min_importance: float = 0.3
    min_recency_days: int = 7