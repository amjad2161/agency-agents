"""
AI-OS Agent Message Schemas - Inter-Agent Communication
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any

from pydantic import Field, model_validator

from .common import BaseModel, UUIDMixin


def _utcnow() -> datetime:
    """Return a naive UTC timestamp for compatibility with existing schema fields."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


class AgentMessageType(str, Enum):
    """Agent message types"""
    PLAN = "PLAN"           # Planning intent
    ACTION = "ACTION"       # Request to perform action
    CRITIQUE = "CRITIQUE"   # Feedback/critique
    VERIFY = "VERIFY"       # Verification request
    RESULT = "RESULT"       # Execution result
    ERROR = "ERROR"         # Error notification
    STATUS = "STATUS"       # Status update
    QUERY = "QUERY"         # Information request
    RESPONSE = "RESPONSE"   # Information response
    HEARTBEAT = "HEARTBEAT" # Health check


class AgentRole(str, Enum):
    """Agent role classifications"""
    PLANNER = "planner"         # Strategic planning
    EXECUTOR = "executor"      # Task execution
    CRITIC = "critic"          # Quality assurance
    VERIFIER = "verifier"      # Verification
    RESEARCHER = "researcher"   # Information gathering
    GENERATOR = "generator"    # Content creation
    COORDINATOR = "coordinator" # Orchestration
    MONITOR = "monitor"        # Observation
    ORCHESTRATOR = "orchestrator"  # Master coordinator


class MessagePriority(int, Enum):
    """Message priority levels"""
    CRITICAL = 0
    HIGH = 1
    NORMAL = 2
    LOW = 3
    BACKGROUND = 4


class MessagePayload(BaseModel):
    """Message payload content"""
    intent: str = "message"
    action: str | None = None
    content: Any = None
    context: dict[str, Any] = Field(default_factory=dict)
    parameters: dict[str, Any] = Field(default_factory=dict)
    result: Any = None
    error: str | None = None
    attachments: list[dict[str, Any]] = Field(default_factory=list)

    @model_validator(mode="before")
    @classmethod
    def normalize_legacy_payload(cls, value: Any) -> Any:
        if not isinstance(value, dict):
            return value

        normalized = dict(value)
        if "intent" not in normalized:
            normalized["intent"] = normalized.get("type") or normalized.get("action") or "message"
        if "parameters" not in normalized and "params" in normalized:
            normalized["parameters"] = normalized["params"]
        return normalized


class MessageMetadata(BaseModel):
    """Message metadata"""
    correlation_id: str | None = None
    reply_to: str | None = None
    conversation_id: str | None = None
    workflow_id: str | None = None
    step_number: int | None = None
    total_steps: int | None = None
    estimated_duration_ms: int | None = None
    tags: list[str] = Field(default_factory=list)
    custom: dict[str, Any] = Field(default_factory=dict)


class AgentMessage(UUIDMixin):
    """Agent-to-agent message model"""
    trace_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    task_id: str | None = None
    tenant_id: str | None = None
    user_id: str | None = None
    session_id: str | None = None

    # Routing
    sender: str
    recipient: str | None = None  # None means broadcast
    sender_role: AgentRole = AgentRole.COORDINATOR
    recipient_roles: list[AgentRole] = Field(default_factory=list)

    # Message classification
    message_type: AgentMessageType
    priority: MessagePriority = MessagePriority.NORMAL

    # Content
    payload: MessagePayload

    # Execution control
    tool_permissions: list[str] = Field(default_factory=list)
    memory_refs: list[str] = Field(default_factory=list)

    # Timing
    created_at: datetime = Field(default_factory=_utcnow)
    deadline_at: datetime | None = None
    processing_timeout_seconds: int = 300

    # Retry handling
    retry_count: int = 0
    max_retries: int = 3

    # Status tracking
    metadata: MessageMetadata = Field(default_factory=MessageMetadata)
    status: str = "pending"  # pending, processing, delivered, failed
    delivered_at: datetime | None = None

    # Results
    error: str | None = None

    @model_validator(mode="before")
    @classmethod
    def normalize_legacy_fields(cls, value: Any) -> Any:
        if not isinstance(value, dict):
            return value

        normalized = dict(value)
        if "id" not in normalized and "message_id" in normalized:
            normalized["id"] = normalized["message_id"]
        if "priority" in normalized and isinstance(normalized["priority"], str):
            priority_map = {
                "critical": MessagePriority.CRITICAL,
                "high": MessagePriority.HIGH,
                "normal": MessagePriority.NORMAL,
                "low": MessagePriority.LOW,
                "background": MessagePriority.BACKGROUND,
            }
            mapped = priority_map.get(normalized["priority"].lower())
            if mapped is not None:
                normalized["priority"] = mapped
        return normalized

    @property
    def message_id(self) -> str:
        return self.id

    def is_broadcast(self) -> bool:
        """Check if message is broadcast to all agents"""
        return self.recipient is None and len(self.recipient_roles) == 0

    def is_direct(self) -> bool:
        """Check if message is directed to specific agent"""
        return self.recipient is not None

    def can_retry(self) -> bool:
        """Check if message can be retried"""
        return self.retry_count < self.max_retries

    def mark_delivered(self) -> None:
        """Mark message as delivered"""
        self.status = "delivered"
        self.delivered_at = _utcnow()

    def mark_failed(self, error: str) -> None:
        """Mark message as failed"""
        self.status = "failed"
        self.error = error
        self.retry_count += 1


class AgentState(BaseModel):
    """Agent runtime state"""
    agent_id: str
    agent_role: AgentRole
    status: str  # idle, busy, error, offline
    current_task_id: str | None = None
    message_queue_size: int = 0
    active_messages: list[str] = Field(default_factory=list)
    last_heartbeat: datetime = Field(default_factory=_utcnow)
    capabilities: list[str] = Field(default_factory=list)
    loaded_tools: list[str] = Field(default_factory=list)
    memory_usage_mb: float | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class AgentRegistration(BaseModel):
    """Agent registration request"""
    agent_id: str
    agent_role: AgentRole
    name: str
    description: str | None = None
    system_prompt: str | None = None
    capabilities: list[str] = Field(default_factory=list)
    max_concurrent_tasks: int = 5
    tool_ids: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class AgentMetrics(BaseModel):
    """Agent performance metrics"""
    agent_id: str
    agent_role: str

    # Task metrics
    tasks_processed: int = 0
    tasks_succeeded: int = 0
    tasks_failed: int = 0
    avg_execution_time_ms: float | None = None

    # Message metrics
    messages_sent: int = 0
    messages_received: int = 0
    avg_message_latency_ms: float | None = None

    # Resource metrics
    cpu_usage_percent: float | None = None
    memory_usage_mb: float | None = None

    # Model usage
    tokens_used: int = 0
    cost_usd: float = 0.0

    timestamp: datetime = Field(default_factory=_utcnow)