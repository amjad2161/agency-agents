"""
AI-OS Tenant Schemas - Multi-tenancy and Access Control
"""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any

from pydantic import Field

from .common import BaseModel as CommonBaseModel, UUIDMixin, TimestampsMixin


def _utcnow() -> datetime:
    """Return a naive UTC timestamp for compatibility with existing schema fields."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


class TenantTier(str, Enum):
    """Tenant subscription tier"""
    FREE = "free"
    STARTER = "starter"
    PROFESSIONAL = "professional"
    ENTERPRISE = "enterprise"
    CUSTOM = "custom"


class BudgetPeriod(str, Enum):
    """Budget period"""
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"
    YEARLY = "yearly"


class RateLimitScope(str, Enum):
    """Rate limit scope"""
    GLOBAL = "global"
    PER_USER = "per_user"
    PER_API_KEY = "per_api_key"


class TenantConfig(CommonBaseModel):
    """Tenant configuration"""
    max_sessions: int = 10
    max_concurrent_tasks: int = 5
    max_tokens_per_day: int = 1000000
    max_storage_gb: int = 10

    # Model access
    allowed_models: list[str] = Field(default_factory=list)
    default_model: str = "gpt-4-turbo"

    # Feature flags
    features: dict[str, bool] = Field(default_factory=dict)

    # Custom settings
    custom_config: dict[str, Any] = Field(default_factory=dict)


class BudgetConfig(CommonBaseModel):
    """Budget configuration"""
    enabled: bool = False
    period: BudgetPeriod = BudgetPeriod.MONTHLY

    # Limits
    spending_limit_usd: float = 0.0
    tokens_limit: int = 0

    # Alerts
    alert_threshold_percent: float = 80.0
    alert_email: str | None = None

    # Actions
    block_on_exceeded: bool = False
    notify_on_exceeded: bool = True


class RateLimitConfig(CommonBaseModel):
    """Rate limit configuration"""
    requests_per_minute: int = 60
    requests_per_hour: int = 1000
    requests_per_day: int = 10000

    tokens_per_minute: int = 100000
    tokens_per_hour: int = 1000000

    concurrent_requests: int = 10

    scope: RateLimitScope = RateLimitScope.PER_USER


class Tenant(UUIDMixin, TimestampsMixin):
    """Tenant entity"""
    name: str
    slug: str  # URL-safe identifier

    tier: TenantTier = TenantTier.FREE

    # Contact
    email: str
    phone: str | None = None

    # Status
    is_active: bool = True
    is_verified: bool = False

    # Configuration
    config: TenantConfig = Field(default_factory=TenantConfig)

    # Billing
    billing_email: str | None = None
    billing_address: dict[str, Any] | None = None

    # Budget
    budget_config: BudgetConfig = Field(default_factory=BudgetConfig)
    current_spend_usd: float = 0.0
    current_tokens_used: int = 0
    budget_period_start: datetime = Field(default_factory=_utcnow)
    budget_period_end: datetime | None = None

    # Rate limits
    rate_limit_config: RateLimitConfig = Field(default_factory=RateLimitConfig)

    # Usage
    user_count: int = 0
    api_key_count: int = 0
    storage_used_gb: float = 0.0

    # Limits
    max_users: int = 10
    max_api_keys: int = 5
    max_storage_gb: int = 10

    # Metadata
    metadata: dict[str, Any] = Field(default_factory=dict)

    def is_budget_exceeded(self) -> bool:
        """Check if spending limit exceeded"""
        if not self.budget_config.enabled:
            return False
        if self.budget_config.spending_limit_usd > 0:
            return self.current_spend_usd >= self.budget_config.spending_limit_usd
        if self.budget_config.tokens_limit > 0:
            return self.current_tokens_used >= self.budget_config.tokens_limit
        return False


class User(UUIDMixin, TimestampsMixin):
    """User entity"""
    tenant_id: str
    email: str
    username: str

    # Authentication
    password_hash: str | None = None

    # Profile
    full_name: str | None = None
    avatar_url: str | None = None
    phone: str | None = None

    # Role and permissions
    role: str = "user"  # admin, user, viewer, api_user
    permissions: list[str] = Field(default_factory=list)

    # Status
    is_active: bool = True
    is_verified: bool = False

    # Settings
    settings: dict[str, Any] = Field(default_factory=dict)
    preferences: dict[str, Any] = Field(default_factory=dict)

    # Usage tracking
    tokens_used: int = 0
    tasks_created: int = 0

    # Sessions
    last_login_at: datetime | None = None
    last_active_at: datetime | None = None

    # External identities
    external_ids: dict[str, str] = Field(default_factory=dict)

    # Metadata
    metadata: dict[str, Any] = Field(default_factory=dict)

    def has_permission(self, permission: str) -> bool:
        """Check if user has permission"""
        return permission in self.permissions or self.role == "admin"


class APIKey(UUIDMixin, TimestampsMixin):
    """API Key entity"""
    tenant_id: str
    user_id: str | None = None

    key_hash: str
    key_prefix: str  # First 8 chars for identification

    name: str
    description: str | None = None

    # Scopes
    scopes: list[str] = Field(default_factory=list)

    # Rate limits (override tenant)
    rate_limit_per_minute: int | None = None
    rate_limit_per_hour: int | None = None

    # Status
    is_active: bool = True

    # Expiration
    expires_at: datetime | None = None

    # Usage
    last_used_at: datetime | None = None
    request_count: int = 0

    # Metadata
    metadata: dict[str, Any] = Field(default_factory=dict)

    def is_expired(self) -> bool:
        """Check if key has expired"""
        if self.expires_at and _utcnow() > self.expires_at:
            return True
        return False

    def has_scope(self, scope: str) -> bool:
        """Check if key has scope"""
        return scope in self.scopes or "*" in self.scopes