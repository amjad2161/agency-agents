"""
AI-OS Execution Record Schemas - Execution Engine and Safety
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable

from pydantic import Field

from .common import BaseModel, UUIDMixin


class ExecutionStatus(str, Enum):
    """Execution status"""
    PENDING = "pending"
    APPROVED = "approved"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    ROLLING_BACK = "rolling_back"
    ROLLED_BACK = "rolled_back"


class ExecutionRiskLevel(str, Enum):
    """Risk level classification"""
    LOW = "low"           # Safe, automatic execution
    MEDIUM = "medium"     # Execute with full audit
    HIGH = "high"         # Policy check required
    CRITICAL = "critical" # Human approval required


class ApprovalStatus(str, Enum):
    """Approval status"""
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"


class ExecutionStep(BaseModel):
    """Single step in execution plan"""
    step_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    step_index: int

    name: str
    description: str | None = None

    action: str  # Tool/action to execute
    parameters: dict[str, Any] = Field(default_factory=dict)

    dependencies: list[str] = Field(default_factory=list)  # Step IDs
    allows_failure: bool = False
    critical: bool = False

    timeout_seconds: int = 60
    retry_count: int = 0

    status: ExecutionStatus = ExecutionStatus.PENDING
    result: Any = None
    error: str | None = None

    started_at: datetime | None = None
    completed_at: datetime | None = None


class ExecutionPlan(BaseModel):
    """Multi-step execution plan"""
    plan_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    description: str | None = None

    steps: list[ExecutionStep]

    # Execution settings
    mode: str = "sequential"  # sequential, parallel, conditional
    stop_on_error: bool = True

    # Context
    task_id: str | None = None
    tenant_id: str
    user_id: str | None = None

    # Status
    status: ExecutionStatus = ExecutionStatus.PENDING

    # Results
    completed_steps: int = 0
    failed_steps: int = 0

    # Timing
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc).replace(tzinfo=None))
    started_at: datetime | None = None
    completed_at: datetime | None = None
    deadline_at: datetime | None = None

    # Metadata
    created_by: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    def get_step(self, step_id: str) -> ExecutionStep | None:
        """Get step by ID"""
        for step in self.steps:
            if step.step_id == step_id:
                return step
        return None

    def get_ready_steps(self) -> list[ExecutionStep]:
        """Get steps ready to execute"""
        ready = []
        for step in self.steps:
            if step.status != ExecutionStatus.PENDING:
                continue
            deps_complete = all(
                (dep_step is not None and dep_step.status == ExecutionStatus.COMPLETED)
                for dep_id in step.dependencies
                for dep_step in [self.get_step(dep_id)]
            )
            if deps_complete:
                ready.append(step)
        return ready

    def is_complete(self) -> bool:
        """Check if plan is complete"""
        return all(s.status in {ExecutionStatus.COMPLETED, ExecutionStatus.FAILED}
                   for s in self.steps)


class RollbackAction(BaseModel):
    """Rollback action for recovery"""
    action_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    step_id: str
    action_type: str  # revert, cleanup, notify

    rollback_data: dict[str, Any] = Field(default_factory=dict)
    execution_order: int

    status: str = "pending"  # pending, executed, failed, skipped
    executed_at: datetime | None = None
    error: str | None = None


class ApprovalRequest(UUIDMixin):
    """Human approval request"""
    task_id: str
    execution_plan_id: str | None = None

    # Risk assessment
    risk_level: ExecutionRiskLevel
    risk_factors: list[str] = Field(default_factory=list)

    # Details
    action_description: str
    affected_resources: list[dict[str, str]] = Field(default_factory=list)

    # Requester
    requested_by: str
    tenant_id: str

    # Approval
    status: ApprovalStatus = ApprovalStatus.PENDING
    requested_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc).replace(tzinfo=None))
    expires_at: datetime
    responded_at: datetime | None = None
    responded_by: str | None = None

    # Decision
    decision: str | None = None  # approved, rejected
    reason: str | None = None
    conditions: dict[str, Any] | None = None

    # Context
    callback_url: str | None = None
    notification_channels: list[str] = Field(default_factory=list)

    metadata: dict[str, Any] = Field(default_factory=dict)


class ApprovalDecision(BaseModel):
    """Approval decision"""
    approval_id: str
    decision: str  # approve, reject
    reason: str | None = None
    conditions: dict[str, Any] | None = None
    decided_by: str
    decided_at: datetime = Field(default_factory=datetime.utcnow)


class ExecutionRecord(UUIDMixin):
    """Execution record for tracking"""
    execution_id: str

    # Context
    task_id: str | None = None
    trace_id: str | None = None
    tenant_id: str
    user_id: str | None = None

    # Plan reference
    plan_id: str | None = None
    steps: list[dict[str, Any]] = Field(default_factory=list)

    # Execution
    mode: str = "standard"
    status: ExecutionStatus = ExecutionStatus.PENDING
    current_step: int = 0

    # Risk
    risk_level: ExecutionRiskLevel = ExecutionRiskLevel.LOW
    risk_score: float = 0.0
    policy_passed: bool = True
    policy_violations: list[dict[str, Any]] = Field(default_factory=list)

    # Approval
    approval_id: str | None = None
    approval_status: ApprovalStatus | None = None

    # Results
    output: Any = None
    error: str | None = None

    # Timing
    created_at: datetime = Field(default_factory=datetime.utcnow)
    started_at: datetime | None = None
    completed_at: datetime | None = None
    timeout_at: datetime | None = None

    # Rollback
    rollback_plan: list[RollbackAction] = Field(default_factory=list)
    rolled_back: bool = False

    # Metrics
    execution_time_ms: int | None = None
    tokens_used: int | None = None
    cost_usd: float | None = None

    # Metadata
    environment: str | None = None
    sandbox_id: str | None = None
    container_id: str | None = None


class ExecutionMetrics(BaseModel):
    """Execution metrics for monitoring"""
    execution_id: str
    task_id: str | None = None

    # Performance
    duration_ms: int
    wait_time_ms: int = 0

    # Resource usage
    cpu_seconds: float | None = None
    memory_mb: float | None = None
    disk_mb: float | None = None

    # Cost
    compute_cost_usd: float | None = None
    api_cost_usd: float | None = None
    total_cost_usd: float | None = None

    # Outcomes
    success: bool
    error_type: str | None = None

    # Steps
    steps_total: int
    steps_completed: int
    steps_failed: int
    steps_skipped: int

    timestamp: datetime = Field(default_factory=datetime.utcnow)


class RiskPolicy(BaseModel):
    """Risk policy configuration"""
    policy_id: str
    name: str
    description: str | None = None

    # Scope
    tenant_id: str | None = None
    user_id: str | None = None
    tool_ids: list[str] = Field(default_factory=list)

    # Risk thresholds
    auto_approve_risk_level: ExecutionRiskLevel = ExecutionRiskLevel.LOW
    require_approval_risk_level: ExecutionRiskLevel = ExecutionRiskLevel.HIGH
    block_risk_level: ExecutionRiskLevel | None = None

    # Conditions
    conditions: dict[str, Any] = Field(default_factory=dict)

    # Actions
    on_violation: str = "block"  # block, warn, approve

    # Status
    is_active: bool = True
    priority: int = 0

    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)