/**
 * AI-OS TypeScript SDK
 * Client library for AI-OS platform integration
 */
import http from 'http';
import https from 'https';
import { EventEmitter } from 'events';

// Types
export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
  name?: string;
}

export interface ChatCompletionRequest {
  model: string;
  messages: ChatMessage[];
  temperature?: number;
  max_tokens?: number;
  top_p?: number;
  stream?: boolean;
  stop?: string[];
}

export interface ChatCompletionChoice {
  index: number;
  message: ChatMessage;
  finish_reason: string;
}

export interface ChatCompletionResponse {
  id: string;
  object: string;
  created: number;
  model: string;
  choices: ChatCompletionChoice[];
  usage?: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

export interface TaskStatus {
  task_id: string;
  task_type: string;
  status: 'pending' | 'queued' | 'running' | 'completed' | 'failed' | 'blocked' | 'cancelled';
  priority: 'low' | 'normal' | 'high' | 'urgent';
  created_at: string;
  updated_at: string;
  metadata?: Record<string, unknown>;
}

export interface MemorySearchRequest {
  query: string;
  memory_type?: 'semantic' | 'working' | 'episodic' | 'procedural';
  top_k?: number;
  min_relevance?: number;
  rerank?: boolean;
  compress?: boolean;
}

export interface MemoryRecord {
  memory_id: string;
  memory_type: string;
  content: string;
  created_at: string;
  relevance_score?: number;
  metadata?: Record<string, unknown>;
}

export interface ToolManifest {
  tool_id: string;
  name: string;
  description: string;
  category: string;
  input_schema: Record<string, unknown>;
  output_schema: Record<string, unknown>;
  timeout_seconds: number;
  requires_approval: boolean;
}

export interface ToolExecutionResult {
  invocation_id: string;
  tool_id: string;
  success: boolean;
  output?: unknown;
  error?: string;
  execution_time_ms: number;
}

export interface SystemMetrics {
  active_tasks: number;
  queued_tasks: number;
  total_tasks: number;
  success_rate: number;
  avg_response_time_ms: number;
}

export interface HealthResponse {
  status: string;
  timestamp: string;
  services: Array<{
    service: string;
    status: 'healthy' | 'degraded' | 'unhealthy';
    latency_ms: number;
  }>;
  version: string;
}

// Configuration
export interface AIOSConfig {
  apiKey: string;
  baseUrl?: string;
  timeout?: number;
  maxRetries?: number;
}

// HTTP Client
class HTTPClient {
  private config: AIOSConfig;
  private agent: http.Agent | https.Agent;

  constructor(config: AIOSConfig) {
    this.config = config;
    this.agent = config.baseUrl?.startsWith('https')
      ? new https.Agent({ keepAlive: true })
      : new http.Agent({ keepAlive: true });
  }

  async request<T>(
    method: string,
    path: string,
    body?: unknown,
    headers: Record<string, string> = {}
  ): Promise<T> {
    const url = `${this.config.baseUrl || 'http://localhost:8000'}${path}`;

    const options: http.RequestOptions = {
      method,
      headers: {
        'Authorization': `Bearer ${this.config.apiKey}`,
        'Content-Type': 'application/json',
        ...headers,
      },
      timeout: this.config.timeout || 60000,
      agent: this.agent,
    };

    return new Promise((resolve, reject) => {
      const req = (url.startsWith('https') ? https : http).request(url, options, (res) => {
        let data = '';

        res.on('data', (chunk) => {
          data += chunk;
        });

        res.on('end', () => {
          if (res.statusCode && res.statusCode >= 400) {
            reject(new Error(`HTTP ${res.statusCode}: ${data}`));
            return;
          }

          try {
            resolve(JSON.parse(data));
          } catch {
            resolve(data as unknown as T);
          }
        });
      });

      req.on('error', reject);
      req.on('timeout', () => {
        req.destroy();
        reject(new Error('Request timeout'));
      });

      if (body) {
        req.write(JSON.stringify(body));
      }

      req.end();
    });
  }

  async *streamRequest(
    path: string,
    body: unknown,
    headers: Record<string, string> = {}
  ): AsyncGenerator<string, void, unknown> {
    const url = `${this.config.baseUrl || 'http://localhost:8000'}${path}`;

    const options: http.RequestOptions = {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.config.apiKey}`,
        'Content-Type': 'application/json',
        ...headers,
      },
      timeout: this.config.timeout || 60000,
      agent: this.agent,
    };

    yield* this.streamResponse(url, options, body);
  }

  private async *streamResponse(
    url: string,
    options: http.RequestOptions,
    body: unknown
  ): AsyncGenerator<string, void, unknown> {
    const req = (url.startsWith('https') ? https : http).request(url, options, (res) => {
      res.on('data', (chunk) => {
        const lines = chunk.toString().split('\n');
        for (const line of lines) {
          if (line.trim()) {
            yield line;
          }
        }
      });

      res.on('end', () => {
        return;
      });
    });

    req.on('error', (err) => {
      throw err;
    });

    req.write(JSON.stringify(body));
    req.end();
  }
}

// Main Client
export class AIOSClient extends EventEmitter {
  private http: HTTPClient;
  private config: AIOSConfig;

  constructor(config: AIOSConfig) {
    super();
    this.config = config;
    this.http = new HTTPClient(config);
  }

  // === Chat Completions ===

  async chatCompletion(
    request: ChatCompletionRequest
  ): Promise<ChatCompletionResponse> {
    return this.http.request<ChatCompletionResponse>(
      'POST',
      '/v1/chat/completions',
      request
    );
  }

  async *chatCompletionStream(
    request: ChatCompletionRequest
  ): AsyncGenerator<ChatCompletionChoice, void, unknown> {
    request.stream = true;

    for await (const line of this.http.streamRequest(
      '/v1/chat/completions',
      request
    )) {
      if (line.startsWith('data: ')) {
        const data = line.slice(6);
        if (data === '[DONE]') {
          return;
        }

        try {
          const parsed = JSON.parse(data);
          if (parsed.choices?.[0]) {
            yield parsed.choices[0] as ChatCompletionChoice;
          }
        } catch {
          // Skip invalid JSON
        }
      }
    }
  }

  // === Tasks ===

  async createTask(
    taskType: string,
    inputData: Record<string, unknown>,
    priority: string = 'normal'
  ): Promise<{ task_id: string }> {
    return this.http.request<{ task_id: string }>('POST', '/v1/tasks', {
      task_type: taskType,
      input_data: inputData,
      priority,
    });
  }

  async getTask(taskId: string): Promise<TaskStatus> {
    return this.http.request<TaskStatus>('GET', `/v1/tasks/${taskId}`);
  }

  async listTasks(
    status?: string,
    limit: number = 50,
    offset: number = 0
  ): Promise<TaskStatus[]> {
    const params = new URLSearchParams({
      limit: String(limit),
      offset: String(offset),
    });
    if (status) params.set('status', status);

    return this.http.request<TaskStatus[]>('GET', `/v1/tasks?${params}`);
  }

  async cancelTask(taskId: string): Promise<{ success: boolean }> {
    return this.http.request<{ success: boolean }>(
      'POST',
      `/v1/tasks/${taskId}/cancel`
    );
  }

  async retryTask(taskId: string): Promise<{ new_task_id: string }> {
    return this.http.request<{ new_task_id: string }>(
      'POST',
      `/v1/tasks/${taskId}/retry`
    );
  }

  async getTaskGraph(taskId: string): Promise<{
    graph_id: string;
    nodes: Array<{
      node_id: string;
      node_type: string;
      status: string;
    }>;
    edges: Array<{ source: string; target: string }>;
  }> {
    return this.http.request('GET', `/v1/tasks/${taskId}/graph`);
  }

  // === Memory ===

  async searchMemory(request: MemorySearchRequest): Promise<MemoryRecord[]> {
    const response = await this.http.request<{ results: MemoryRecord[] }>(
      'POST',
      '/v1/memory/search',
      request
    );
    return response.results;
  }

  async storeMemory(
    content: string,
    memoryType: string = 'semantic',
    tags?: string[],
    metadata?: Record<string, unknown>
  ): Promise<{ memory_id: string }> {
    return this.http.request<{ memory_id: string }>('POST', '/v1/memory/store', {
      content,
      memory_type: memoryType,
      tags: tags || [],
      metadata: metadata || {},
    });
  }

  async getMemory(memoryId: string): Promise<MemoryRecord> {
    return this.http.request<MemoryRecord>('GET', `/v1/memory/${memoryId}`);
  }

  async getWorkingMemory(
    sessionId: string,
    key?: string
  ): Promise<MemoryRecord[]> {
    const params = key ? `?key=${key}` : '';
    return this.http.request<MemoryRecord[]>(
      'GET',
      `/v1/memory/working/${sessionId}${params}`
    );
  }

  // === Tools ===

  async listTools(): Promise<ToolManifest[]> {
    const response = await this.http.request<{ tools: ToolManifest[] }>(
      'GET',
      '/v1/tools'
    );
    return response.tools;
  }

  async getTool(toolId: string): Promise<ToolManifest> {
    return this.http.request<ToolManifest>('GET', `/v1/tools/${toolId}`);
  }

  async executeTool(
    toolId: string,
    parameters: Record<string, unknown>,
    waitForApproval: boolean = true
  ): Promise<ToolExecutionResult> {
    return this.http.request<ToolExecutionResult>(
      'POST',
      `/v1/tools/${toolId}/execute`,
      { parameters, wait_for_approval: waitForApproval }
    );
  }

  // === Admin ===

  async getMetrics(): Promise<SystemMetrics> {
    return this.http.request<SystemMetrics>('GET', '/admin/metrics');
  }

  async getHealth(): Promise<HealthResponse> {
    return this.http.request<HealthResponse>('GET', '/health');
  }

  async listAgents(): Promise<Array<{
    agent_id: string;
    agent_type: string;
    status: string;
    tasks_processed: number;
  }>> {
    return this.http.request('GET', '/admin/agents');
  }

  // === Approvals ===

  async listPendingApprovals(): Promise<Array<{
    approval_id: string;
    task_id: string;
    risk_level: string;
    requested_at: string;
  }>> {
    return this.http.request('GET', '/v1/approvals/pending');
  }

  async approveRequest(
    approvalId: string,
    reason?: string
  ): Promise<{ status: string }> {
    return this.http.request('POST', `/v1/approvals/${approvalId}`, {
      decision: 'approve',
      reason,
    });
  }

  async rejectRequest(
    approvalId: string,
    reason: string
  ): Promise<{ status: string }> {
    return this.http.request('POST', `/v1/approvals/${approvalId}`, {
      decision: 'reject',
      reason,
    });
  }

  // === Utility ===

  async waitForTask(
    taskId: string,
    pollInterval: number = 500,
    timeout: number = 300000
  ): Promise<TaskStatus> {
    const startTime = Date.now();

    while (true) {
      const task = await this.getTask(taskId);

      if (['completed', 'failed', 'cancelled'].includes(task.status)) {
        return task;
      }

      if (Date.now() - startTime > timeout) {
        throw new Error(`Task ${taskId} did not complete within ${timeout}ms`);
      }

      await new Promise(resolve => setTimeout(resolve, pollInterval));
    }
  }
}

// Factory function
export function createClient(config: AIOSConfig): AIOSClient {
  return new AIOSClient(config);
}

// React Hook (for frontend integration)
export function useAIOSClient(config: AIOSConfig) {
  const client = new AIOSClient(config);

  return {
    client,
    chatCompletion: client.chatCompletion.bind(client),
    chatCompletionStream: client.chatCompletionStream.bind(client),
    createTask: client.createTask.bind(client),
    getTask: client.getTask.bind(client),
    searchMemory: client.searchMemory.bind(client),
    executeTool: client.executeTool.bind(client),
    getMetrics: client.getMetrics.bind(client),
    getHealth: client.getHealth.bind(client),
  };
}

// SDK version
export const SDK_VERSION = '1.0.0';

export default {
  AIOSClient,
  createClient,
  useAIOSClient,
  SDK_VERSION,
};