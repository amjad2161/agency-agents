"""
AI-OS Python SDK - Client Library
Provides programmatic access to AI-OS services
"""
import asyncio
from typing import Any, Optional, AsyncIterator
from datetime import datetime
import aiohttp

from .models import (
    ChatMessage,
    ChatCompletionRequest,
    ChatCompletionResponse,
    TaskStatus,
    MemorySearchRequest,
    ToolManifest,
)


class AIOSClient:
    """Main client for AI-OS API"""

    def __init__(
        self,
        api_key: str,
        base_url: str = "http://localhost:8000",
        timeout: int = 60,
    ):
        self.api_key = api_key
        self.base_url = base_url
        self.timeout = timeout
        self._session: Optional[aiohttp.ClientSession] = None

    async def __aenter__(self):
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    async def connect(self) -> None:
        """Initialize HTTP session"""
        self._session = aiohttp.ClientSession(
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            timeout=aiohttp.ClientTimeout(total=self.timeout),
        )

    async def close(self) -> None:
        """Close HTTP session"""
        if self._session:
            await self._session.close()

    async def _request(
        self,
        method: str,
        path: str,
        params: dict | None = None,
        json: dict | None = None,
    ) -> dict[str, Any]:
        """Make HTTP request"""
        if not self._session:
            raise RuntimeError("Client not connected. Call connect() first.")

        url = f"{self.base_url}{path}"
        async with self._session.request(
            method, url, params=params, json=json
        ) as response:
            response.raise_for_status()
            return await response.json()

    # === Chat Completions ===

    async def chat_completion(
        self,
        messages: list[dict[str, str]],
        model: str = "gpt-4-turbo",
        temperature: float = 0.7,
        max_tokens: int | None = None,
        stream: bool = False,
        **kwargs,
    ) -> ChatCompletionResponse:
        """Send chat completion request"""
        request = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "stream": stream,
            **kwargs,
        }
        if max_tokens:
            request["max_tokens"] = max_tokens

        data = await self._request("POST", "/v1/chat/completions", json=request)
        return ChatCompletionResponse(**data)

    async def chat_completion_stream(
        self, messages: list[dict[str, str]], model: str = "gpt-4-turbo", **kwargs
    ) -> AsyncIterator[dict[str, Any]]:
        """Stream chat completion responses"""
        request = {
            "model": model,
            "messages": messages,
            "stream": True,
            **kwargs,
        }

        if not self._session:
            raise RuntimeError("Client not connected")

        url = f"{self.base_url}/v1/chat/completions"
        async with self._session.post(url, json=request) as response:
            async for line in response.content:
                if line:
                    yield line.decode("utf-8")

    # === Tasks ===

    async def create_task(
        self,
        task_type: str,
        input_data: dict[str, Any],
        priority: str = "normal",
    ) -> str:
        """Create new task"""
        data = await self._request(
            "POST",
            "/v1/tasks",
            json={
                "task_type": task_type,
                "input_data": input_data,
                "priority": priority,
            },
        )
        return data["task_id"]

    async def get_task(self, task_id: str) -> dict[str, Any]:
        """Get task details"""
        return await self._request("GET", f"/v1/tasks/{task_id}")

    async def list_tasks(
        self,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """List tasks"""
        params = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status
        return await self._request("GET", "/v1/tasks", params=params)

    async def cancel_task(self, task_id: str) -> bool:
        """Cancel task"""
        result = await self._request("POST", f"/v1/tasks/{task_id}/cancel")
        return result.get("success", False)

    async def retry_task(self, task_id: str) -> str:
        """Retry failed task"""
        data = await self._request("POST", f"/v1/tasks/{task_id}/retry")
        return data["new_task_id"]

    async def get_task_graph(self, task_id: str) -> dict[str, Any]:
        """Get task execution graph"""
        return await self._request("GET", f"/v1/tasks/{task_id}/graph")

    # === Memory ===

    async def search_memory(
        self,
        query: str,
        memory_type: str = "semantic",
        top_k: int = 10,
        min_relevance: float = 0.5,
    ) -> list[dict[str, Any]]:
        """Search memory"""
        request = {
            "query": query,
            "memory_type": memory_type,
            "top_k": top_k,
            "min_relevance": min_relevance,
        }
        data = await self._request("POST", "/v1/memory/search", json=request)
        return data["results"]

    async def store_memory(
        self,
        content: str,
        memory_type: str = "semantic",
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Store memory"""
        request = {
            "content": content,
            "memory_type": memory_type,
            "tags": tags or [],
            "metadata": metadata or {},
        }
        data = await self._request("POST", "/v1/memory/store", json=request)
        return data["memory_id"]

    async def get_memory(self, memory_id: str) -> dict[str, Any]:
        """Get specific memory"""
        return await self._request("GET", f"/v1/memory/{memory_id}")

    # === Tools ===

    async def list_tools(self) -> list[ToolManifest]:
        """List available tools"""
        data = await self._request("GET", "/v1/tools")
        return [ToolManifest(**t) for t in data["tools"]]

    async def get_tool(self, tool_id: str) -> ToolManifest:
        """Get tool manifest"""
        data = await self._request("GET", f"/v1/tools/{tool_id}")
        return ToolManifest(**data)

    async def execute_tool(
        self, tool_id: str, parameters: dict[str, Any], wait_for_approval: bool = False
    ) -> dict[str, Any]:
        """Execute tool"""
        request = {"parameters": parameters, "wait_for_approval": wait_for_approval}
        return await self._request("POST", f"/v1/tools/{tool_id}/execute", json=request)

    # === Admin ===

    async def get_metrics(self) -> dict[str, Any]:
        """Get system metrics"""
        return await self._request("GET", "/admin/metrics")

    async def get_health(self) -> dict[str, Any]:
        """Get system health"""
        return await self._request("GET", "/health")

    async def list_agents(self) -> list[dict[str, Any]]:
        """List active agents"""
        return await self._request("GET", "/admin/agents")


class AsyncAIOSClient(AIOSClient):
    """Async version of AI-OS client with additional utilities"""

    async def wait_for_task(
        self, task_id: str, poll_interval: float = 0.5, timeout: float = 300
    ) -> dict[str, Any]:
        """Wait for task completion"""
        start_time = datetime.utcnow()
        while True:
            task = await self.get_task(task_id)
            status = task.get("status")

            if status in ["completed", "failed", "cancelled"]:
                return task

            elapsed = (datetime.utcnow() - start_time).total_seconds()
            if elapsed > timeout:
                raise TimeoutError(f"Task {task_id} did not complete within {timeout}s")

            await asyncio.sleep(poll_interval)

    async def execute_with_retry(
        self,
        func,
        max_retries: int = 3,
        backoff: float = 1.0,
    ):
        """Execute with automatic retry"""
        last_error = None
        for attempt in range(max_retries):
            try:
                return await func()
            except Exception as e:
                last_error = e
                if attempt < max_retries - 1:
                    await asyncio.sleep(backoff * (2**attempt))
        raise last_error


# === Synchronous Client ===

class SyncAIOSClient:
    """Synchronous wrapper for AI-OS client"""

    def __init__(
        self,
        api_key: str,
        base_url: str = "http://localhost:8000",
    ):
        self._async_client = AIOSClient(api_key, base_url)
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    def _ensure_loop(self):
        """Ensure event loop exists"""
        try:
            self._loop = asyncio.get_running_loop()
        except RuntimeError:
            self._loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._loop)

    def _run(self, coro):
        """Run coroutine in event loop"""
        self._ensure_loop()
        return self._loop.run_until_complete(coro)

    def chat_completion(self, messages: list[dict[str, str]], **kwargs):
        return self._run(self._async_client.chat_completion(messages, **kwargs))

    def create_task(self, task_type: str, input_data: dict, **kwargs):
        return self._run(self._async_client.create_task(task_type, input_data, **kwargs))

    def get_task(self, task_id: str):
        return self._run(self._async_client.get_task(task_id))

    def search_memory(self, query: str, **kwargs):
        return self._run(self._async_client.search_memory(query, **kwargs))

    def store_memory(self, content: str, **kwargs):
        return self._run(self._async_client.store_memory(content, **kwargs))

    def list_tools(self):
        return self._run(self._async_client.list_tools())

    def execute_tool(self, tool_id: str, parameters: dict, **kwargs):
        return self._run(self._async_client.execute_tool(tool_id, parameters, **kwargs))

    def get_metrics(self):
        return self._run(self._async_client.get_metrics())

    def get_health(self):
        return self._run(self._async_client.get_health())

    def close(self):
        if self._loop:
            self._loop.close()