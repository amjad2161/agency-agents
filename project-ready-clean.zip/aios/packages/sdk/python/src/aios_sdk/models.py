"""
AI-OS SDK - Data Models
Pydantic models for SDK types
"""
from typing import Any, Optional
from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field


class TaskStatus(str, Enum):
    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"
    CANCELLED = "cancelled"
    TIMED_OUT = "timed_out"


class TaskPriority(str, Enum):
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    URGENT = "urgent"


class MemoryType(str, Enum):
    SEMANTIC = "semantic"
    WORKING = "working"
    EPISODIC = "episodic"
    PROCEDURAL = "procedural"


class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


# === Chat Models ===

class ChatMessage(BaseModel):
    """Chat message"""
    role: str = Field(..., description="Role: system, user, or assistant")
    content: str = Field(..., description="Message content")
    name: Optional[str] = Field(None, description="Name for function calls")


class ChatCompletionRequest(BaseModel):
    """Chat completion request"""
    model: str = Field(..., description="Model to use")
    messages: list[ChatMessage] = Field(..., description="Message history")
    temperature: float = Field(0.7, ge=0, le=2)
    max_tokens: Optional[int] = Field(None, ge=1)
    top_p: Optional[float] = Field(None, ge=0, le=1)
    stream: bool = Field(False)
    stop: Optional[list[str]] = None
    presence_penalty: Optional[float] = Field(None, ge=-2, le=2)
    frequency_penalty: Optional[float] = Field(None, ge=-2, le=2)


class ChatCompletionChoice(BaseModel):
    """Chat completion choice"""
    index: int
    message: ChatMessage
    finish_reason: str


class ChatCompletionUsage(BaseModel):
    """Token usage"""
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


class ChatCompletionResponse(BaseModel):
    """Chat completion response"""
    id: str
    object: str = "chat.completion"
    created: int
    model: str
    choices: list[ChatCompletionChoice]
    usage: Optional[ChatCompletionUsage] = None


# === Task Models ===

class TaskCreateRequest(BaseModel):
    """Task creation request"""
    task_type: str
    input_data: dict[str, Any]
    priority: TaskPriority = TaskPriority.NORMAL
    metadata: dict[str, Any] = Field(default_factory=dict)


class TaskResponse(BaseModel):
    """Task response"""
    task_id: str
    task_type: str
    status: TaskStatus
    priority: TaskPriority
    created_at: datetime
    updated_at: datetime
    metadata: dict[str, Any] = Field(default_factory=dict)
    error: Optional[str] = None
    result: Optional[dict[str, Any]] = None


class TaskNode(BaseModel):
    """Task graph node"""
    node_id: str
    node_type: str
    status: str
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None


class TaskGraphResponse(BaseModel):
    """Task graph"""
    graph_id: str
    nodes: list[TaskNode]
    edges: list[dict[str, Any]]
    status: str
    progress: float


# === Memory Models ===

class MemorySearchRequest(BaseModel):
    """Memory search request"""
    query: str
    memory_type: Optional[MemoryType] = None
    top_k: int = Field(10, ge=1, le=100)
    min_relevance: float = Field(0.5, ge=0, le=1)
    rerank: bool = True
    compress: bool = False
    tags: Optional[list[str]] = None


class MemoryRecord(BaseModel):
    """Memory record"""
    memory_id: str
    memory_type: MemoryType
    content: str
    created_at: datetime
    relevance_score: Optional[float] = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class MemorySearchResult(BaseModel):
    """Memory search result"""
    memory_id: str
    content: str
    memory_type: MemoryType
    relevance_score: float
    created_at: datetime
    metadata: dict[str, Any] = Field(default_factory=dict)


class MemoryStoreRequest(BaseModel):
    """Memory store request"""
    content: str
    memory_type: MemoryType = MemoryType.SEMANTIC
    tags: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class MemoryStoreResponse(BaseModel):
    """Memory store response"""
    memory_id: str
    success: bool
    chunks_created: int = 0


# === Tool Models ===

class ToolManifest(BaseModel):
    """Tool manifest"""
    tool_id: str
    name: str
    description: str
    category: str
    input_schema: dict[str, Any]
    output_schema: dict[str, Any]
    timeout_seconds: int = 60
    requires_approval: bool = False
    permission_level: str = "default"


class ToolExecuteRequest(BaseModel):
    """Tool execution request"""
    tool_id: str
    parameters: dict[str, Any]
    wait_for_approval: bool = True


class ToolExecutionResult(BaseModel):
    """Tool execution result"""
    invocation_id: str
    tool_id: str
    success: bool
    output: Optional[Any] = None
    error: Optional[str] = None
    execution_time_ms: int


# === Metrics Models ===

class SystemMetrics(BaseModel):
    """System metrics"""
    active_tasks: int
    queued_tasks: int
    total_tasks: int
    success_rate: float
    avg_response_time_ms: float
    memory_usage_mb: float
    cpu_usage_percent: float


class AgentMetrics(BaseModel):
    """Agent metrics"""
    agent_id: str
    agent_type: str
    tasks_processed: int
    success_rate: float
    avg_execution_time_ms: float
    active: bool


# === Health Models ===

class ServiceHealth(BaseModel):
    """Service health status"""
    service: str
    status: str  # healthy, degraded, unhealthy
    latency_ms: float
    last_check: datetime


class HealthResponse(BaseModel):
    """Health check response"""
    status: str
    timestamp: datetime
    services: list[ServiceHealth]
    version: str