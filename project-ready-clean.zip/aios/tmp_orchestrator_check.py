import asyncio
from services.orchestrator.app.orchestrator import OrchestratorService, OrchestratorConfig

async def main():
    service = OrchestratorService(OrchestratorConfig(max_concurrent_tasks=10, task_timeout_seconds=300))
    await service.initialize()
    task_id = await service.create_task(
        task_type='chat',
        tenant_id='test-tenant',
        user_id='test-user',
        input_data={'message': 'Hello, how are you?', 'model': 'gpt-4-turbo'},
        priority='normal',
    )
    task = await service.get_task(task_id)
    print({'task_id': task_id, 'status': task['status'], 'task_type': task['task_type']})
    await service.shutdown()

asyncio.run(main())
