"""
AI-OS API Middleware - Auth, Tenant, Rate Limiting, Tracing
"""
from __future__ import annotations

import hashlib
import hmac
import logging
import time
import uuid
from datetime import datetime, timedelta
from typing import Callable

from fastapi import Request, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response

logger = logging.getLogger(__name__)

# Security scheme
security = HTTPBearer(auto_error=False)


class TracingMiddleware(BaseHTTPMiddleware):
    """Middleware for distributed tracing"""

    async def dispatch(self, request: Request, call_next):
        # Generate or extract trace ID
        trace_id = request.headers.get("X-Trace-ID", str(uuid.uuid4()))
        span_id = str(uuid.uuid4())[:16]

        # Add to request state
        request.state.trace_id = trace_id
        request.state.span_id = span_id
        request.state.request_id = str(uuid.uuid4())

        # Add tracing headers
        headers = {
            "X-Trace-ID": trace_id,
            "X-Span-ID": span_id,
            "X-Request-ID": request.state.request_id,
        }

        response = await call_next(request)

        # Add tracing headers to response
        for key, value in headers.items():
            response.headers[key] = value

        return response


class TenantMiddleware(BaseHTTPMiddleware):
    """Middleware for tenant extraction and validation"""

    async def dispatch(self, request: Request, call_next):
        # Extract tenant from header or subdomain
        tenant_id = request.headers.get("X-Tenant-ID")

        if not tenant_id:
            # Try subdomain
            host = request.headers.get("Host", "")
            if "." in host:
                tenant_id = host.split(".")[0]

        # Validate tenant (would check database)
        if not tenant_id:
            # Allow public endpoints
            if request.url.path in ["/health", "/health/live", "/health/ready", "/metrics", "/v1"]:
                return await call_next(request)

            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Tenant ID required"
            )

        # Add to request state
        request.state.tenant_id = tenant_id

        # Add tenant header for downstream services
        request.state.headers = request.state.headers or {}
        request.state.headers["X-Tenant-ID"] = tenant_id

        response = await call_next(request)
        return response


class AuthMiddleware(BaseHTTPMiddleware):
    """Middleware for authentication"""

    # Paths that don't require authentication
    PUBLIC_PATHS = {
        "/health",
        "/health/live",
        "/health/ready",
        "/metrics",
        "/docs",
        "/redoc",
        "/openapi.json",
        "/v1",
    }

    async def dispatch(self, request: Request, call_next):
        # Skip auth for public paths
        if request.url.path in self.PUBLIC_PATHS:
            return await call_next(request)

        # Extract API key or bearer token
        auth_header = request.headers.get("Authorization", "")
        api_key = request.headers.get("X-API-Key", "")

        credentials = None

        if auth_header.startswith("Bearer "):
            token = auth_header[7:]
            credentials = {"type": "bearer", "token": token}
        elif api_key:
            credentials = {"type": "api_key", "key": api_key}

        if not credentials:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authentication required",
                headers={"WWW-Authenticate": "Bearer"},
            )

        # Validate credentials (would check database)
        user_id = await self._validate_credentials(credentials)

        if not user_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid credentials",
            )

        # Add to request state
        request.state.user_id = user_id

        response = await call_next(request)
        return response

    async def _validate_credentials(self, credentials: dict) -> str | None:
        """Validate authentication credentials"""
        # In production, would validate against database
        if credentials["type"] == "api_key":
            # Validate API key
            return "user_from_api_key"
        else:
            # Validate JWT token
            return "user_from_token"


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Middleware for rate limiting"""

    # Simple in-memory rate limiter (would use Redis in production)
    _rate_limit_store: dict[str, list[datetime]] = {}

    # Rate limits per tier
    RATE_LIMITS = {
        "free": {"requests_per_minute": 60, "requests_per_hour": 1000},
        "starter": {"requests_per_minute": 120, "requests_per_hour": 5000},
        "professional": {"requests_per_minute": 300, "requests_per_hour": 20000},
        "enterprise": {"requests_per_minute": 1000, "requests_per_hour": 100000},
    }

    async def dispatch(self, request: Request, call_next):
        # Get client identifier
        client_id = self._get_client_id(request)

        # Get tenant tier (would fetch from database)
        tier = getattr(request.state, "tier", "free")
        limits = self.RATE_LIMITS.get(tier, self.RATE_LIMITS["free"])

        # Check rate limit
        allowed, remaining = self._check_rate_limit(client_id, limits)

        if not allowed:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Rate limit exceeded",
                headers={
                    "Retry-After": "60",
                    "X-RateLimit-Limit": str(limits["requests_per_minute"]),
                    "X-RateLimit-Remaining": "0",
                }
            )

        response = await call_next(request)

        # Add rate limit headers
        response.headers["X-RateLimit-Limit"] = str(limits["requests_per_minute"])
        response.headers["X-RateLimit-Remaining"] = str(remaining)

        return response

    def _get_client_id(self, request: Request) -> str:
        """Get client identifier for rate limiting"""
        # Use user_id if authenticated, otherwise use IP
        user_id = getattr(request.state, "user_id", None)
        if user_id:
            return f"user:{user_id}"

        tenant_id = getattr(request.state, "tenant_id", None)
        if tenant_id:
            return f"tenant:{tenant_id}"

        # Fall back to IP
        client = request.client
        if client:
            return f"ip:{client.host}"

        return "unknown"

    def _check_rate_limit(
        self,
        client_id: str,
        limits: dict[str, int],
    ) -> tuple[bool, int]:
        """Check if request is within rate limit"""
        now = datetime.utcnow()

        # Initialize or get timestamps
        if client_id not in self._rate_limit_store:
            self._rate_limit_store[client_id] = []

        timestamps = self._rate_limit_store[client_id]

        # Clean old timestamps (older than 1 hour)
        cutoff = now - timedelta(hours=1)
        timestamps = [t for t in timestamps if t > cutoff]

        # Check minute limit
        minute_cutoff = now - timedelta(minutes=1)
        recent_minute = [t for t in timestamps if t > minute_cutoff]

        if len(recent_minute) >= limits["requests_per_minute"]:
            return False, 0

        # Check hour limit
        if len(timestamps) >= limits["requests_per_hour"]:
            return False, 0

        # Add current timestamp
        timestamps.append(now)
        self._rate_limit_store[client_id] = timestamps

        remaining = limits["requests_per_minute"] - len(recent_minute) - 1

        return True, remaining


class APIKeyValidator:
    """API Key validation utilities"""

    @staticmethod
    def hash_key(api_key: str) -> str:
        """Hash an API key for storage"""
        return hashlib.sha256(api_key.encode()).hexdigest()

    @staticmethod
    def verify_key(api_key: str, stored_hash: str) -> bool:
        """Verify an API key against stored hash"""
        return hmac.compare_digest(
            APIKeyValidator.hash_key(api_key),
            stored_hash
        )

    @staticmethod
    def generate_key() -> str:
        """Generate a new API key"""
        import secrets
        return secrets.token_urlsafe(32)

    @staticmethod
    def get_prefix(api_key: str) -> str:
        """Get the prefix of an API key for identification"""
        return api_key[:8]


class JWTTokenValidator:
    """JWT Token validation utilities"""

    # In production, would use proper JWT library
    SECRET_KEY = "your-secret-key-here"  # Would be from environment

    @staticmethod
    def decode(token: str) -> dict | None:
        """Decode and validate JWT token"""
        # In production, would use python-jose
        try:
            # Simplified - would decode and verify signature
            parts = token.split(".")
            if len(parts) != 3:
                return None

            # Would verify signature here
            payload = parts[1]
            import base64
            import json

            # Add padding if needed
            payload += "=" * (4 - len(payload) % 4)
            decoded = base64.b64decode(payload)

            return json.loads(decoded)

        except Exception:
            return None

    @staticmethod
    def encode(payload: dict, expires_in: int = 3600) -> str:
        """Encode payload into JWT token"""
        import base64
        import json
        import time

        header = {"alg": "HS256", "typ": "JWT"}
        payload["exp"] = int(time.time()) + expires_in
        payload["iat"] = int(time.time())

        header_enc = base64.b64encode(
            json.dumps(header).encode()
        ).decode().rstrip("=")

        payload_enc = base64.b64encode(
            json.dumps(payload).encode()
        ).decode().rstrip("=")

        # Would create signature here
        signature = "fake_signature"

        return f"{header_enc}.{payload_enc}.{signature}"