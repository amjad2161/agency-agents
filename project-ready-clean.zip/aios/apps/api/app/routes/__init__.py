"""
AI-OS API Routes - Route Exports
"""
from .chat import router as chat_router
from .tasks import router as tasks_router
from .memory import router as memory_router
from .tools import router as tools_router
from .admin import router as admin_router

__all__ = [
    "chat_router",
    "tasks_router",
    "memory_router",
    "tools_router",
    "admin_router",
]
