"""
AI-OS API Gateway - Main Application
FastAPI-based REST API with authentication, rate limiting, and tenant extraction
"""
from __future__ import annotations

import asyncio
import logging
import time
import uuid
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Any

from fastapi import FastAPI, Request, HTTPException, Depends, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field
from opentelemetry import trace
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from prometheus_client import Counter, Histogram, Gauge

from .routes import chat, tasks, memory, tools, admin
from .middleware import AuthMiddleware, TenantMiddleware, RateLimitMiddleware, TracingMiddleware

# Initialize logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize tracer
tracer = trace.get_tracer(__name__)

# Prometheus metrics
REQUEST_COUNT = Counter(
    "aios_api_requests_total",
    "Total API requests",
    ["method", "endpoint", "status"]
)
REQUEST_LATENCY = Histogram(
    "aios_api_request_duration_seconds",
    "Request duration in seconds",
    ["method", "endpoint"]
)
ACTIVE_REQUESTS = Gauge(
    "aios_api_active_requests",
    "Number of active requests"
)
TOKEN_USAGE = Counter(
    "aios_model_tokens_total",
    "Total tokens used",
    ["model", "type"]
)


# Pydantic Models
class HealthResponse(BaseModel):
    status: str
    version: str
    timestamp: str
    services: dict[str, str]


class ErrorResponse(BaseModel):
    error: str
    message: str
    request_id: str
    timestamp: str


class MetricsResponse(BaseModel):
    requests_total: int
    requests_success: int
    requests_failed: int
    avg_latency_ms: float
    active_connections: int
    token_usage: dict[str, int]


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan management"""
    logger.info("Starting AI-OS API Gateway")

    # Initialize services
    # await initialize_services()

    yield

    # Cleanup
    logger.info("Shutting down AI-OS API Gateway")


# Create FastAPI application
app = FastAPI(
    title="AI-OS API Gateway",
    description="Unified AI Operating System - API Gateway",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
)

# Add middleware
app.add_middleware(TracingMiddleware)
app.add_middleware(TenantMiddleware)
app.add_middleware(AuthMiddleware)
app.add_middleware(RateLimitMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Instrument for tracing
FastAPIInstrumentor.instrument_app(app)


# Middleware for metrics
@app.middleware("http")
async def metrics_middleware(request: Request, call_next):
    """Track request metrics"""
    ACTIVE_REQUESTS.inc()
    start_time = time.time()

    try:
        response = await call_next(request)

        # Record metrics
        duration = time.time() - start_time
        REQUEST_COUNT.labels(
            method=request.method,
            endpoint=request.url.path,
            status=response.status_code
        ).inc()
        REQUEST_LATENCY.labels(
            method=request.method,
            endpoint=request.url.path
        ).observe(duration)

        return response

    finally:
        ACTIVE_REQUESTS.dec()


# Exception handlers
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Handle HTTP exceptions"""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": "http_error",
            "message": exc.detail,
            "request_id": request.state.request_id if hasattr(request.state, "request_id") else None,
            "timestamp": datetime.utcnow().isoformat(),
        }
    )


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Handle unexpected exceptions"""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)

    request_id = getattr(request.state, "request_id", str(uuid.uuid4()))

    return JSONResponse(
        status_code=500,
        content={
            "error": "internal_error",
            "message": "An unexpected error occurred",
            "request_id": request_id,
            "timestamp": datetime.utcnow().isoformat(),
        }
    )


# Health endpoints
@app.get("/health", response_model=HealthResponse, tags=["Health"])
async def health_check():
    """Basic health check"""
    return {
        "status": "healthy",
        "version": "1.0.0",
        "timestamp": datetime.utcnow().isoformat(),
        "services": {
            "api": "healthy",
            "orchestrator": "healthy",
            "agent_fabric": "healthy",
        }
    }


@app.get("/health/ready", tags=["Health"])
async def readiness_check():
    """Readiness check - verify all dependencies"""
    checks = {
        "database": await check_database(),
        "redis": await check_redis(),
        "orchestrator": await check_orchestrator(),
        "agent_fabric": await check_agent_fabric(),
    }

    all_healthy = all(c["healthy"] for c in checks.values())

    return {
        "status": "ready" if all_healthy else "not_ready",
        "checks": checks,
        "timestamp": datetime.utcnow().isoformat(),
    }


@app.get("/health/live", tags=["Health"])
async def liveness_check():
    """Liveness check"""
    return {"status": "alive", "timestamp": datetime.utcnow().isoformat()}


# Include routers
app.include_router(chat.router, prefix="/v1", tags=["Chat"])
app.include_router(tasks.router, prefix="/v1", tags=["Tasks"])
app.include_router(memory.router, prefix="/v1", tags=["Memory"])
app.include_router(tools.router, prefix="/v1", tags=["Tools"])
app.include_router(admin.router, prefix="/v1/admin", tags=["Admin"])


# Metrics endpoint (Prometheus format)
@app.get("/metrics", tags=["Monitoring"])
async def get_metrics():
    """Prometheus metrics endpoint"""
    from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
    from starlette.responses import Response

    return Response(
        content=generate_latest(),
        media_type=CONTENT_TYPE_LATEST
    )


# API version info
@app.get("/v1", tags=["Info"])
async def get_api_info():
    """Get API version and capabilities"""
    return {
        "version": "1.0.0",
        "name": "AI-OS API Gateway",
        "description": "Unified AI Operating System API",
        "capabilities": [
            "chat",
            "tasks",
            "memory",
            "agents",
            "tools",
            "knowledge",
            "webhooks",
        ],
        "models": [
            "gpt-4-turbo",
            "gpt-3.5-turbo",
            "claude-3-opus",
            "claude-3-sonnet",
            "gemini-pro",
        ],
    }


# WebSocket endpoint for real-time communication
@app.websocket("/v1/ws/{session_id}")
async def websocket_endpoint(websocket: WebSocket, session_id: str):
    """WebSocket for real-time chat"""
    await websocket.accept()

    try:
        while True:
            # Receive message
            data = await websocket.receive_json()

            # Process message (would call orchestrator)
            response = {
                "type": "message",
                "session_id": session_id,
                "content": "Response to: " + str(data.get("content", "")),
                "timestamp": datetime.utcnow().isoformat(),
            }

            await websocket.send_json(response)

    except Exception as e:
        logger.error(f"WebSocket error: {e}")
    finally:
        await websocket.close()


# Helper functions for health checks
async def check_database() -> dict[str, Any]:
    """Check database connectivity"""
    try:
        # Would ping database
        return {"healthy": True, "latency_ms": 5}
    except Exception as e:
        return {"healthy": False, "error": str(e)}


async def check_redis() -> dict[str, Any]:
    """Check Redis connectivity"""
    try:
        # Would ping Redis
        return {"healthy": True, "latency_ms": 2}
    except Exception as e:
        return {"healthy": False, "error": str(e)}


async def check_orchestrator() -> dict[str, Any]:
    """Check orchestrator service"""
    try:
        return {"healthy": True}
    except Exception as e:
        return {"healthy": False, "error": str(e)}


async def check_agent_fabric() -> dict[str, Any]:
    """Check agent fabric service"""
    try:
        return {"healthy": True, "available_agents": 6}
    except Exception as e:
        return {"healthy": False, "error": str(e)}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)