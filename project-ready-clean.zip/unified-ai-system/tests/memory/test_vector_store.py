"""Tests for src/memory/vector_store.py."""

import asyncio
from datetime import UTC, datetime, timedelta

import pytest

from memory.vector_store import (
    EmbeddingModel,
    MemoryEntry,
    MemoryManager,
    MemoryRetrievalPipeline,
    MemoryType,
    RetrievalResult,
    SessionMemory,
    VectorStore,
)

# ---------------------------------------------------------------------------
# Enums & dataclasses
# ---------------------------------------------------------------------------


def test_memory_type_values():
    assert MemoryType.WORKING.value == "working"
    assert MemoryType.EPISODIC.value == "episodic"
    assert MemoryType.SEMANTIC.value == "semantic"
    assert MemoryType.PROCEDURAL.value == "procedural"
    assert MemoryType.USER_PREFERENCE.value == "user_preference"
    assert MemoryType.SYSTEM.value == "system"


def test_embedding_model_values():
    assert EmbeddingModel.TEXT_EMBEDDING_3_LARGE.value == ("text-embedding-3-large", 3072)
    assert EmbeddingModel.TEXT_EMBEDDING_3.value == ("text-embedding-3", 1536)
    assert EmbeddingModel.TEXT_EMBEDDING_ADA.value == ("text-embedding-ada-002", 1536)


def test_memory_entry_defaults():
    m = MemoryEntry(
        memory_id="mem_x",
        memory_type=MemoryType.WORKING,
        content="hi",
        embedding=[0.0] * 4,
    )
    assert m.embedding_model == "text-embedding-3"
    assert m.chunk_index == 0
    assert m.parent_memory_id is None
    assert m.tags == []
    assert m.source_type == "user"
    assert m.importance_score == 0.5
    assert m.access_count == 0
    assert m.attention_weight == 1.0
    assert m.confidence == 1.0
    assert m.trust_score == 1.0
    assert m.verification_count == 0
    assert m.is_compressed is False
    assert m.compression_ratio == 1.0
    assert m.related_memories == []
    assert m.references == []


# ---------------------------------------------------------------------------
# VectorStore
# ---------------------------------------------------------------------------


@pytest.fixture
def vs():
    return VectorStore(dimension=1536)


def test_vector_store_init_state(vs):
    assert vs.dimension == 1536
    assert vs.metric == "cosine"
    assert vs.index_type == "ivfflat"
    assert vs.vectors == []
    assert vs.metadata == {}
    assert vs.id_to_index == {}
    assert vs.type_index == {}
    assert vs.user_index == {}
    assert vs._index_built is False
    assert vs._embedding_model is None


def test_initialize_sets_model(vs):
    asyncio.run(vs.initialize())
    assert vs._embedding_model == "text-embedding-3"


def test_generate_embedding_deterministic(vs):
    a = vs._generate_embedding("hello", "text-embedding-3")
    b = vs._generate_embedding("hello", "text-embedding-3")
    assert a == b
    assert len(a) == vs.dimension
    assert all(-1.0 <= x <= 1.0 for x in a)


def test_generate_embedding_different_text(vs):
    a = vs._generate_embedding("hello", "text-embedding-3")
    b = vs._generate_embedding("world", "text-embedding-3")
    assert a != b


def test_cosine_similarity_identity(vs):
    v = [1.0, 2.0, 3.0]
    assert vs._cosine_similarity(v, v) == pytest.approx(1.0, abs=1e-6)


def test_cosine_similarity_zero(vs):
    assert vs._cosine_similarity([0.0, 0.0], [1.0, 2.0]) == 0.0
    assert vs._cosine_similarity([1.0, 2.0], [0.0, 0.0]) == 0.0


def test_cosine_similarity_orthogonal(vs):
    assert vs._cosine_similarity([1.0, 0.0], [0.0, 1.0]) == pytest.approx(0.0, abs=1e-6)


def test_add_returns_prefixed_id(vs):
    mid = asyncio.run(vs.add("content", metadata={"memory_type": MemoryType.WORKING}))
    assert mid.startswith("mem_")
    assert len(mid) == 4 + 12


def test_add_populates_indices_enum_key(vs):
    mid = asyncio.run(
        vs.add(
            "content",
            metadata={"memory_type": MemoryType.EPISODIC, "user_id": "u1"},
        )
    )
    assert mid in vs.metadata
    assert vs.metadata[mid].memory_type == MemoryType.EPISODIC
    assert mid in vs.type_index[MemoryType.EPISODIC]
    assert mid in vs.user_index["u1"]
    assert vs._index_built is False
    assert len(vs.vectors) == 1


def test_add_without_user_id_skips_user_index(vs):
    mid = asyncio.run(vs.add("c", metadata={"memory_type": MemoryType.WORKING}))
    assert vs.user_index == {}
    assert mid in vs.type_index[MemoryType.WORKING]


def test_retrieve_returns_results(vs):
    asyncio.run(vs.add("python programming", metadata={"memory_type": MemoryType.SEMANTIC}))
    asyncio.run(vs.add("rust language", metadata={"memory_type": MemoryType.SEMANTIC}))
    results = asyncio.run(vs.retrieve("python programming", top_k=5))
    assert len(results) >= 1
    assert all(isinstance(r, RetrievalResult) for r in results)
    assert results[0].explanation.startswith("Semantic match with ")


def test_retrieve_top_k_cap(vs):
    for i in range(10):
        asyncio.run(vs.add(f"doc {i}", metadata={"memory_type": MemoryType.WORKING}))
    results = asyncio.run(vs.retrieve("doc", top_k=3))
    assert len(results) <= 3


def test_retrieve_filter_by_memory_types(vs):
    asyncio.run(vs.add("a", metadata={"memory_type": MemoryType.SEMANTIC}))
    asyncio.run(vs.add("b", metadata={"memory_type": MemoryType.EPISODIC}))
    results = asyncio.run(vs.retrieve("a", top_k=10, memory_types=[MemoryType.SEMANTIC]))
    assert all(r.memory.memory_type == MemoryType.SEMANTIC for r in results)


def test_retrieve_filter_by_user_id(vs):
    asyncio.run(vs.add("x", metadata={"memory_type": MemoryType.WORKING, "user_id": "u1"}))
    asyncio.run(vs.add("y", metadata={"memory_type": MemoryType.WORKING, "user_id": "u2"}))
    results = asyncio.run(vs.retrieve("x", top_k=10, user_id="u1"))
    assert all(r.memory.user_id == "u1" for r in results)


def test_retrieve_empty_store(vs):
    results = asyncio.run(vs.retrieve("q", top_k=5))
    assert results == []


def test_delete_removes_entry(vs):
    mid = asyncio.run(vs.add("c", metadata={"memory_type": MemoryType.WORKING, "user_id": "u1"}))
    asyncio.run(vs.delete(mid))
    assert mid not in vs.metadata
    assert mid not in vs.type_index[MemoryType.WORKING]
    assert mid not in vs.user_index["u1"]


def test_delete_nonexistent_returns_false(vs):
    asyncio.run(vs.delete("mem_doesnotexist"))


def test_get_by_type_and_limit(vs):
    for i in range(5):
        asyncio.run(vs.add(f"m{i}", metadata={"memory_type": MemoryType.SEMANTIC}))
    results = asyncio.run(vs.get_by_type(MemoryType.SEMANTIC, limit=3))
    assert len(results) == 3
    assert all(isinstance(r, MemoryEntry) for r in results)


def test_get_by_type_empty(vs):
    results = asyncio.run(vs.get_by_type(MemoryType.PROCEDURAL))
    assert results == []


# ---------------------------------------------------------------------------
# SessionMemory
# ---------------------------------------------------------------------------


@pytest.fixture
def sm():
    return SessionMemory(max_size_tokens=1000)


def test_session_init(sm):
    assert sm.max_size_tokens == 1000
    assert sm.sessions == {}


def test_create_session_shape(sm):
    s = sm.create_session("s1", "u1")
    assert s["session_id"] == "s1"
    assert s["user_id"] == "u1"
    assert s["messages"] == []
    assert s["context"] == {}
    assert s["memory_refs"] == []
    assert s["config"] == {}
    assert "task_queue" in s["state"]


def test_get_session_updates_activity(sm):
    sm.create_session("s1", "u1")
    before = sm.sessions["s1"]["last_activity"]
    s = sm.get_session("s1")
    assert s is not None
    assert s["last_activity"] >= before


def test_get_session_missing(sm):
    assert sm.get_session("missing") is None


def test_add_message(sm):
    sm.create_session("s1", "u1")
    sm.add_message("s1", "user", "hi there")
    msgs = sm.sessions["s1"]["messages"]
    assert len(msgs) == 1
    assert msgs[0]["role"] == "user"
    assert msgs[0]["content"] == "hi there"
    assert "message_id" in msgs[0]
    assert isinstance(msgs[0]["timestamp"], str)


def test_add_message_missing_session_silent(sm):
    sm.add_message("nope", "user", "hi")  # should not raise


def test_context_window_eviction(sm):
    sm.create_session("s1", "u1")
    # Each msg ~5 words * 1.3 = 6.5 tokens; add enough to exceed 1000
    for _i in range(300):
        sm.add_message("s1", "user", "word " * 10)
    # While loop pops while total > max AND len > 2
    assert len(sm.sessions["s1"]["messages"]) >= 2


def test_get_recent_messages(sm):
    sm.create_session("s1", "u1")
    for i in range(5):
        sm.add_message("s1", "user", f"m{i}")
    recent = sm.get_recent_messages("s1", count=3)
    assert len(recent) == 3
    assert recent[-1]["content"] == "m4"


def test_get_recent_messages_missing(sm):
    assert sm.get_recent_messages("missing", count=3) == []


def test_update_context(sm):
    sm.create_session("s1", "u1")
    sm.update_context("s1", "key", "value")
    assert sm.sessions["s1"]["context"]["key"] == "value"


def test_update_context_missing_silent(sm):
    sm.update_context("nope", "k", "v")  # no raise


def test_add_memory_ref(sm):
    sm.create_session("s1", "u1")
    sm.add_memory_ref("s1", "mem_abc", "ctx")
    refs = sm.sessions["s1"]["memory_refs"]
    assert refs[0]["memory_id"] == "mem_abc"
    assert refs[0]["context"] == "ctx"


def test_get_context_for_task_missing(sm):
    assert sm.get_context_for_task("missing") == {}


def test_get_context_for_task_full(sm):
    sm.create_session("s1", "u1")
    sm.add_message("s1", "user", "hi")
    ctx = sm.get_context_for_task("s1")
    assert ctx["session_id"] == "s1"
    assert ctx["user_id"] == "u1"
    assert len(ctx["recent_messages"]) == 1


def test_cleanup_old_sessions(sm):
    sm.create_session("s1", "u1")
    sm.sessions["s1"]["last_activity"] = datetime.now(UTC) - timedelta(hours=48)
    sm.cleanup_old_sessions(max_age_hours=24)
    assert "s1" not in sm.sessions


# ---------------------------------------------------------------------------
# MemoryRetrievalPipeline
# ---------------------------------------------------------------------------


@pytest.fixture
def pipeline():
    vs = VectorStore(dimension=64)
    sm = SessionMemory(max_size_tokens=10000)
    return MemoryRetrievalPipeline(vs, sm)


def test_pipeline_init(pipeline):
    assert pipeline.recency_weight == 0.25
    assert pipeline.importance_weight == 0.25
    assert pipeline.relevance_threshold == 0.5


def test_rerank_applies_overlap_boost(pipeline):
    m = MemoryEntry(
        memory_id="mem_1",
        memory_type=MemoryType.WORKING,
        content="python async await",
        embedding=[],
    )
    r = RetrievalResult(
        memory=m, relevance_score=1.0, recency_score=1.0, importance_score=1.0, combined_score=0.5
    )
    out = asyncio.run(pipeline._rerank_results("python async", [r]))
    # 2 overlapping terms => score *= 1 + 2*0.1 = 1.2
    assert out[0].combined_score == pytest.approx(0.5 * 1.2, abs=1e-6)


def test_filter_by_recency_cutoff(pipeline):
    recent = MemoryEntry(
        memory_id="r",
        memory_type=MemoryType.WORKING,
        content="x",
        embedding=[],
        last_accessed_at=datetime.now(UTC),
    )
    old = MemoryEntry(
        memory_id="o",
        memory_type=MemoryType.WORKING,
        content="x",
        embedding=[],
        last_accessed_at=datetime.now(UTC) - timedelta(hours=200),
    )
    rr = [
        RetrievalResult(
            memory=recent, relevance_score=1, recency_score=1, importance_score=1, combined_score=1
        ),
        RetrievalResult(
            memory=old, relevance_score=1, recency_score=1, importance_score=1, combined_score=1
        ),
    ]
    out = pipeline._filter_by_recency(rr, max_age_hours=168)
    ids = [r.memory.memory_id for r in out]
    assert "r" in ids and "o" not in ids


def test_merge_context_adds_session_messages(pipeline):
    pipeline.session_memory.create_session("s1", "u1")
    for i in range(3):
        pipeline.session_memory.add_message("s1", "user", f"msg{i}")
    entries = asyncio.run(pipeline._merge_context([], "s1"))
    assert len(entries) == 3
    assert all(e.memory_type == MemoryType.WORKING for e in entries)
    assert all(e.importance_score == 0.7 for e in entries)
    assert entries[0].content.startswith("[user]: ")


def test_compress_context_empty(pipeline):
    win = pipeline._compress_context([], max_tokens=1000)
    assert win.entries == []
    assert win.total_tokens == 0
    assert win.compression_ratio == 1.0
    assert win.coverage_percentage == 0.0


def test_compress_context_under_budget(pipeline):
    entries = [
        MemoryEntry(
            memory_id="a", memory_type=MemoryType.WORKING, content="hello world", embedding=[]
        ),
    ]
    win = pipeline._compress_context(entries, max_tokens=10000)
    assert win.compression_ratio == 1.0
    assert win.coverage_percentage == 100.0
    assert len(win.entries) == 1


def test_compress_context_over_budget(pipeline):
    entries = [
        MemoryEntry(
            memory_id=f"m{i}",
            memory_type=MemoryType.WORKING,
            content="word " * 50,
            embedding=[],
            importance_score=0.5,
        )
        for i in range(20)
    ]
    win = pipeline._compress_context(entries, max_tokens=50)
    assert win.compression_ratio != 1.0
    assert 0 <= win.coverage_percentage <= 100.0


# ---------------------------------------------------------------------------
# MemoryManager
# ---------------------------------------------------------------------------


@pytest.fixture
def mgr():
    return MemoryManager()


def test_manager_lazy_initialize(mgr):
    asyncio.run(mgr.initialize())
    asyncio.run(mgr.initialize())  # idempotent
    assert mgr._initialized is True


def test_manager_store_auto_injects_memory_type(mgr):
    asyncio.run(mgr.initialize())
    mid = asyncio.run(mgr.store("hello", memory_type=MemoryType.SEMANTIC))
    assert mid in mgr.vector_store.metadata
    assert mgr.vector_store.metadata[mid].memory_type == MemoryType.SEMANTIC


def test_manager_store_with_session_adds_ref(mgr):
    asyncio.run(mgr.initialize())
    mgr.create_session("s1", "u1")
    mid = asyncio.run(mgr.store("x" * 300, memory_type=MemoryType.WORKING, session_id="s1"))
    refs = mgr.session_memory.sessions["s1"]["memory_refs"]
    assert refs[0]["memory_id"] == mid
    assert len(refs[0]["context"]) == 200


def test_manager_create_and_get_session(mgr):
    mgr.create_session("s1", "u1")
    assert mgr.get_session("s1") is not None


def test_manager_clear_session_cascades(mgr):
    asyncio.run(mgr.initialize())
    mgr.create_session("s1", "u1")
    mid = asyncio.run(mgr.store("hello", memory_type=MemoryType.WORKING, session_id="s1"))
    assert mid in mgr.vector_store.metadata
    mgr.clear_session("s1")
    assert "s1" not in mgr.session_memory.sessions
    assert mid not in mgr.vector_store.metadata
