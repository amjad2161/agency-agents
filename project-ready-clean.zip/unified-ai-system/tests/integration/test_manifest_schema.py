import json
from pathlib import Path

import yaml  # type: ignore

ROOT = Path(__file__).resolve().parents[3]
SCHEMA_PATH = ROOT / "aios" / "docs" / "integration" / "repo_capability_manifest.schema.json"
MANIFEST_PATH = ROOT / "aios" / "docs" / "integration" / "repo_capability_manifest.yaml"


def test_manifest_and_schema_are_present():
    assert SCHEMA_PATH.exists(), f"Missing schema: {SCHEMA_PATH}"
    assert MANIFEST_PATH.exists(), f"Missing manifest: {MANIFEST_PATH}"


def test_manifest_has_required_top_level_keys():
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    manifest = yaml.safe_load(MANIFEST_PATH.read_text(encoding="utf-8"))

    required = set(schema.get("required", []))
    # Support both historical key names while the manifest format settles.
    if "repositories" in required and "repositories" not in manifest and "entries" in manifest:
        required.remove("repositories")
    missing = [key for key in required if key not in manifest]
    assert not missing, f"Missing required manifest keys: {missing}"

    repository_items = manifest.get("repositories", manifest.get("entries"))
    assert isinstance(repository_items, list)
    assert len(repository_items) > 0
