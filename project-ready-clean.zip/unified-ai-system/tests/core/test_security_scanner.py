"""Tests for SecurityScanner.scan_params recursive value-only walker."""

from __future__ import annotations

import pytest

from core.execution_engine import SecurityScanner


@pytest.fixture()
def scanner() -> SecurityScanner:
    return SecurityScanner()


# ---------------------------------------------------------------------------
# Benign inputs
# ---------------------------------------------------------------------------


def test_benign_url_params_pass(scanner: SecurityScanner) -> None:
    result = scanner.scan_params(
        {
            "url": "https://api.example.com/v1/users",
            "method": "GET",
            "timeout": 30,
        }
    )
    assert result["passed"] is True
    assert result["findings"] == []
    assert result["severity"] == "none"


def test_empty_params_pass(scanner: SecurityScanner) -> None:
    result = scanner.scan_params({})
    assert result == {"passed": True, "findings": [], "severity": "none"}


def test_non_string_values_do_not_raise(scanner: SecurityScanner) -> None:
    result = scanner.scan_params(
        {
            "count": 42,
            "ratio": 3.14,
            "flag": True,
            "nothing": None,
        }
    )
    assert result["passed"] is True
    assert result["findings"] == []


def test_repr_quotes_do_not_false_match(scanner: SecurityScanner) -> None:
    # Regression: earlier naive str(params) leaked quotes/semicolons.
    result = scanner.scan_params({"q": "hello world", "tag": "ok"})
    assert result["passed"] is True


# ---------------------------------------------------------------------------
# SQL injection
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "payload",
    [
        "' OR 1=1 --",
        "admin' UNION SELECT password FROM users",
        "foo /* comment */ bar",
    ],
)
def test_sql_injection_detected(scanner: SecurityScanner, payload: str) -> None:
    result = scanner.scan_params({"q": payload})
    assert result["passed"] is False
    assert result["severity"] == "high"
    assert any(f["type"] == "sql_injection" for f in result["findings"])


# ---------------------------------------------------------------------------
# Command injection
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "payload",
    [
        "foo; rm -rf /",
        "`whoami`",
        "$(id)",
        "a|b",
        "x & y",
    ],
)
def test_command_injection_detected(scanner: SecurityScanner, payload: str) -> None:
    result = scanner.scan_params({"arg": payload})
    assert result["passed"] is False
    assert any(f["type"] == "command_injection" for f in result["findings"])


# ---------------------------------------------------------------------------
# Path traversal
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "payload",
    [
        "../../etc/passwd",
        "..\\..\\windows\\system32",
        "%2e%2e/secret",
    ],
)
def test_path_traversal_detected(scanner: SecurityScanner, payload: str) -> None:
    result = scanner.scan_params({"file": payload})
    assert result["passed"] is False
    assert any(f["type"] == "path_traversal" for f in result["findings"])


# ---------------------------------------------------------------------------
# XSS
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "payload",
    [
        "<script>alert(1)</script>",
        "javascript:alert('xss')",
        "</script><img src=x>",
    ],
)
def test_xss_detected(scanner: SecurityScanner, payload: str) -> None:
    result = scanner.scan_params({"html": payload})
    assert result["passed"] is False
    assert any(f["type"] == "xss" for f in result["findings"])


# ---------------------------------------------------------------------------
# Nested structures + path reporting
# ---------------------------------------------------------------------------


def test_nested_dict_reports_dotted_path(scanner: SecurityScanner) -> None:
    result = scanner.scan_params(
        {
            "outer": {
                "inner": {
                    "q": "' OR 1=1 --",
                },
            },
        }
    )
    assert result["passed"] is False
    paths = [f["path"] for f in result["findings"]]
    assert "outer.inner.q" in paths


def test_nested_list_reports_indexed_path(scanner: SecurityScanner) -> None:
    result = scanner.scan_params(
        {
            "items": ["safe", "../../etc/passwd", "also-safe"],
        }
    )
    assert result["passed"] is False
    paths = [f["path"] for f in result["findings"]]
    assert "items[1]" in paths


def test_tuple_is_walked(scanner: SecurityScanner) -> None:
    result = scanner.scan_params({"args": ("ok", "<script>x</script>")})
    assert result["passed"] is False
    assert any(f["path"] == "args[1]" for f in result["findings"])


def test_every_finding_has_required_keys(scanner: SecurityScanner) -> None:
    result = scanner.scan_params({"bad": "; rm -rf /", "worse": "<script>x</script>"})
    assert result["passed"] is False
    for finding in result["findings"]:
        assert set(finding.keys()) >= {"type", "matches", "severity", "path"}
        assert finding["severity"] == "high"


def test_return_shape(scanner: SecurityScanner) -> None:
    result = scanner.scan_params({"x": "ok"})
    assert set(result.keys()) == {"passed", "findings", "severity"}
