import asyncio
from typing import cast

from fastapi.testclient import TestClient

from api.server import APIServer
from core.aios_bridge import AIOSBridge


class _StubBridge(AIOSBridge):
    def __init__(self):
        super().__init__(base_url="http://aios.local")

    async def health(self):
        await asyncio.sleep(0)
        return {"status": "ok", "service": "aios"}

    async def forward_task(self, payload):
        await asyncio.sleep(0)
        return {"task_id": "aios-123", "status": "queued", "payload": payload}


class _DeferredOrchestrator:
    class _LocalTask:
        def __init__(self):
            self.status = "waiting_input"
            self.outputs = {}
            self.completed_at = None

    def __init__(self):
        self.active_tasks = {"task-local-001": self._LocalTask()}
        self.completed_tasks = {}

    async def submit_task(self, task_type, description, inputs, constraints):
        await asyncio.sleep(0)
        return "task-local-001"

    async def get_task_status(self, task_id):
        await asyncio.sleep(0)
        return {
            "task_id": task_id,
            "status": "waiting_input" if task_id not in self.completed_tasks else "completed",
            "reasoning_confidence": 0.22,
            "reasoning_mode": "defer",
            "reasoning_deferred": True,
            "trace_id": "trace-local-001",
            "lineage": {"request_id": "req-local-001"},
            "outputs": (
                self.completed_tasks.get(task_id).outputs
                if task_id in self.completed_tasks
                else None
            ),
        }

    def _update_memory(self, task, event_type):
        return None

    def _persist_task_snapshot(self, task):
        return None


def test_aios_health_returns_503_when_bridge_not_configured() -> None:
    server = APIServer(aios_bridge=None)
    client = TestClient(server.app, raise_server_exceptions=False)

    response = client.get("/v1/integrations/aios/health")

    assert response.status_code == 503
    assert "not configured" in response.text.lower()


def test_aios_health_returns_upstream_payload() -> None:
    server = APIServer(aios_bridge=cast(AIOSBridge, _StubBridge()))
    client = TestClient(server.app, raise_server_exceptions=False)

    response = client.get("/v1/integrations/aios/health")

    assert response.status_code == 200
    payload = response.json()
    assert payload["bridge"] == "aios"
    assert payload["ok"] is True
    assert payload["upstream"]["status"] == "ok"


def test_aios_forward_task_returns_upstream_response() -> None:
    server = APIServer(aios_bridge=cast(AIOSBridge, _StubBridge()))
    client = TestClient(server.app, raise_server_exceptions=False)

    response = client.post(
        "/v1/integrations/aios/tasks/forward",
        json={
            "task_type": "analysis",
            "description": "Analyze cross-project task",
            "inputs": {"query": "status"},
            "constraints": {"mode": "safe"},
            "priority": "high",
        },
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["bridge"] == "aios"
    assert payload["forwarded"] is True
    assert payload["upstream"]["task_id"] == "aios-123"
    assert payload["upstream"]["payload"]["task_type"] == "analysis"


def test_task_endpoint_auto_forwards_deferred_task_to_aios() -> None:
    orchestrator = _DeferredOrchestrator()
    server = APIServer(orchestrator=orchestrator, aios_bridge=cast(AIOSBridge, _StubBridge()))
    client = TestClient(server.app, raise_server_exceptions=False)

    response = client.post(
        "/v1/tasks",
        json={
            "task_type": "analysis",
            "description": "Deferred task requiring handoff",
            "inputs": {"session_id": "s-1", "query": "handoff"},
            "constraints": {"action_risk_levels": ["critical"]},
            "priority": "high",
        },
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["status"] == "forwarded"
    assert payload["reasoning_deferred"] is True
    assert payload["metadata"]["forwarded_to_aios"] is True
    assert payload["result"]["status"] == "queued"

    # Local task state must also transition from waiting_input to completed.
    assert "task-local-001" in orchestrator.completed_tasks
    assert orchestrator.active_tasks.get("task-local-001") is None


def test_task_endpoint_timeout_has_execution_time() -> None:
    class _NeverCompletesOrchestrator:
        async def submit_task(self, task_type, description, inputs, constraints):
            await asyncio.sleep(0)
            return "task-timeout-001"

        async def get_task_status(self, task_id):
            await asyncio.sleep(0)
            return {"task_id": task_id, "status": "running", "reasoning_deferred": False}

    server = APIServer(orchestrator=_NeverCompletesOrchestrator(), aios_bridge=None)
    server.task_wait_timeout_seconds = 1
    client = TestClient(server.app, raise_server_exceptions=False)

    response = client.post(
        "/v1/tasks",
        json={
            "task_type": "analysis",
            "description": "Long running",
            "inputs": {"session_id": "s-timeout"},
            "constraints": {},
            "priority": "normal",
        },
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["status"] == "timeout"
    assert payload["execution_time_ms"] > 0
