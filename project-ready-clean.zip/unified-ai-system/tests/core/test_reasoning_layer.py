import pytest

from core.reasoning_layer import (
    ContradictionFlag,
    ExecutionMode,
    MythosReasoner,
    ReasoningAssessment,
    assess_risk_and_reasoning,
)


def test_assessment_bypassed_when_disabled() -> None:
    assessment = assess_risk_and_reasoning(
        task_description="delete temp logs",
        action_risk_levels=["high"],
        contradictions=[],
        enabled=False,
    )

    assert assessment.execution_mode == ExecutionMode.NORMAL
    assert assessment.confidence_score == pytest.approx(1.0)
    assert assessment.bypassed_by_flag is True


def test_high_risk_forces_defer_mode() -> None:
    assessment = assess_risk_and_reasoning(
        task_description="drop production database",
        action_risk_levels=["critical"],
        contradictions=[],
        enabled=True,
    )

    assert assessment.execution_mode == ExecutionMode.DEFER
    assert assessment.confidence_score <= 0.4
    assert assessment.defer_reason is not None


def test_contradictions_reduce_confidence() -> None:
    contradictions = [
        ContradictionFlag(
            field_a="constraints.read_only",
            field_b="actions.write",
            description="Task asked for read-only while execution contains write action.",
            severity=0.4,
        )
    ]

    assessment = assess_risk_and_reasoning(
        task_description="inspect records",
        action_risk_levels=["low"],
        contradictions=contradictions,
        enabled=True,
    )

    assert assessment.execution_mode in (ExecutionMode.CAUTIOUS, ExecutionMode.DEFER)
    assert assessment.confidence_score < 1.0
    assert len(assessment.contradiction_flags) == 1


def test_low_risk_normal_mode() -> None:
    assessment = assess_risk_and_reasoning(
        task_description="summarize text",
        action_risk_levels=["low", "low"],
        contradictions=[],
        enabled=True,
    )

    assert assessment.execution_mode == ExecutionMode.NORMAL
    assert assessment.defer_reason is None


def test_reasoner_emits_serializable_metadata() -> None:
    reasoner = MythosReasoner(enabled=True)
    assessment = reasoner.assess(
        task_description="sync invoices",
        action_risk_levels=["medium", "high"],
        contradictions=[],
    )

    payload = reasoner.to_metadata(assessment)

    assert payload["execution_mode"] in {"normal", "cautious", "defer"}
    assert isinstance(payload["confidence_score"], float)
    assert "contradiction_flags" in payload


def test_assessment_dataclass_defaults() -> None:
    assessment = ReasoningAssessment(confidence_score=0.8, execution_mode=ExecutionMode.CAUTIOUS)

    assert assessment.contradiction_flags == []
    assert assessment.defer_reason is None
    assert assessment.bypassed_by_flag is False
