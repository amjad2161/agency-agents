from fastapi.testclient import TestClient

from api.server import APIServer


def test_supreme_status_default_not_initialized():
    server = APIServer()
    client = TestClient(server.app)

    response = client.get("/v1/supreme/status")
    assert response.status_code == 200
    payload = response.json()
    assert payload["initialized"] is False


def test_supreme_init_then_cycle():
    server = APIServer()
    client = TestClient(server.app)

    init_response = client.post(
        "/v1/supreme/init",
        json={
            "directive_text": "1. initialize registry\n2. run recursive cycles\n3. synthesize insights"
        },
    )
    assert init_response.status_code == 200
    init_payload = init_response.json()
    assert init_payload["initialized"] is True
    assert init_payload["task_count"] == 3

    cycle_response = client.post("/v1/supreme/cycle", json={"iterations": 2})
    assert cycle_response.status_code == 200
    cycle_payload = cycle_response.json()
    assert cycle_payload["iterations"] == 2
    assert len(cycle_payload["cycles"]) == 2


def test_supreme_cycle_before_init_returns_400():
    server = APIServer()
    client = TestClient(server.app)

    response = client.post("/v1/supreme/cycle", json={"iterations": 1})
    assert response.status_code == 400


def test_supreme_init_omega_preset():
    server = APIServer()
    client = TestClient(server.app)

    response = client.post("/v1/supreme/init/omega", json={"append": False})
    assert response.status_code == 200
    payload = response.json()
    assert payload["preset"] == "omega-premium"
    assert payload["task_count"] == 5


def test_supreme_registry_after_omega_init():
    server = APIServer()
    client = TestClient(server.app)

    init_response = client.post("/v1/supreme/init/omega", json={"append": False})
    assert init_response.status_code == 200

    response = client.get("/v1/supreme/registry")
    assert response.status_code == 200
    payload = response.json()
    assert payload["authorization"] == "omega-premium"
    assert payload["mode"] == "god-mode unleashed"
    assert payload["autonomous_layers"]["task_management"] is True


def test_supreme_init_rejects_metadata_only_payload():
    server = APIServer()
    client = TestClient(server.app)

    response = client.post(
        "/v1/supreme/init",
        json={"directive_text": "[SYSTEM AUTHORIZATION: OMEGA-PREMIUM]"},
    )

    assert response.status_code == 400


def test_supreme_init_rejects_oversized_payload():
    server = APIServer()
    client = TestClient(server.app)

    response = client.post(
        "/v1/supreme/init",
        json={"directive_text": "x" * 51000},
    )

    assert response.status_code == 422


def test_supreme_init_rejects_too_many_directives():
    server = APIServer()
    client = TestClient(server.app)

    payload = "\n".join(f"{index}. task {index}" for index in range(1, 202))
    response = client.post("/v1/supreme/init", json={"directive_text": payload})

    assert response.status_code == 400
    assert "too many directives" in response.json()["detail"].lower()


def test_supreme_metrics_endpoint_reports_observability():
    server = APIServer()
    client = TestClient(server.app)

    init_response = client.post("/v1/supreme/init", json={"directive_text": "1. boot"})
    assert init_response.status_code == 200

    metrics_response = client.get("/v1/supreme/metrics")
    assert metrics_response.status_code == 200
    payload = metrics_response.json()
    assert payload["api"]["requests_total"] >= 2
    assert payload["core"]["task_count"] >= 1


def test_supreme_auth_enforced_when_token_is_configured(monkeypatch):
    monkeypatch.setenv("SUPREME_API_TOKEN", "secret-token")

    server = APIServer()
    client = TestClient(server.app)

    unauthorized = client.get("/v1/supreme/status")
    assert unauthorized.status_code == 401

    authorized = client.get("/v1/supreme/status", headers={"X-Supreme-Token": "secret-token"})
    assert authorized.status_code == 200


def test_supreme_rate_limit_triggers_429(monkeypatch):
    monkeypatch.delenv("SUPREME_API_TOKEN", raising=False)
    monkeypatch.setenv("SUPREME_RATE_LIMIT_PER_MINUTE", "2")

    server = APIServer()
    client = TestClient(server.app)

    first = client.get("/v1/supreme/status")
    second = client.get("/v1/supreme/status")
    third = client.get("/v1/supreme/status")

    assert first.status_code == 200
    assert second.status_code == 200
    assert third.status_code == 429
