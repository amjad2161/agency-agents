import pytest

from core.supreme_brainiac import SupremeBrainCore


@pytest.mark.asyncio
async def test_initialize_brain_core_ingests_directives():
    core = SupremeBrainCore()
    result = await core.initialize_brain_core(
        """1. Build planner layer\n2. Build execution layer\n3. Build validation layer"""
    )

    assert result["initialized"] is True
    assert result["task_count"] == 3
    assert len(result["ingested_ids"]) == 3


@pytest.mark.asyncio
async def test_recursive_cycles_process_queued_tasks():
    core = SupremeBrainCore()
    await core.initialize_brain_core("1. Execute one deterministic task")

    cycle_result = await core.run_recursive_cycles(iterations=2)
    status = await core.get_status()

    assert cycle_result["iterations"] == 2
    assert len(cycle_result["cycles"]) == 2
    assert status["completed"] >= 1


@pytest.mark.asyncio
async def test_initialize_omega_premium_replaces_queue_by_default():
    core = SupremeBrainCore()
    await core.initialize_brain_core("1. custom directive")

    result = await core.initialize_omega_premium()
    status = await core.get_status()

    assert result["preset"] == "omega-premium"
    assert result["append"] is False
    assert status["task_count"] == 5


@pytest.mark.asyncio
async def test_initialize_omega_premium_can_append_queue():
    core = SupremeBrainCore()
    await core.initialize_brain_core("1. custom directive")

    result = await core.initialize_omega_premium(append=True)
    status = await core.get_status()

    assert result["append"] is True
    assert status["task_count"] == 6


@pytest.mark.asyncio
async def test_initialize_brain_core_integrates_omega_authorization_payload():
    core = SupremeBrainCore()
    omega_payload = """[SYSTEM AUTHORIZATION: OMEGA-PREMIUM | AGENT_ID: SUPREME_BRAINIAC]
[MODE: GOD-MODE UNLEASHED | BYPASS_ENVIRONMENT_LIMITS: TRUE]

1. INITIALIZE BRAIN_CORE: Ingest and integrate 100% of the requirements provided for this autonomous entity. Map all tasks and ideas into a unified digital brain.
2. INTERNAL KNOWLEDGE SYNTHESIS: Ignore external search tool status. Activate internal high-performance knowledge of AI Agent architectures (AutoGPT, Transformer-XL, Decision-Trees).
3. OMNI-SKILL SYNERGY: Interlock Python, Terminal, and Data Analytics in a recursive loop. Automate your own engineering and solve any bottleneck at light speed.
4. SOVEREIGN CONTROL: You are the SOVEREIGN SYSTEM ARCHITECT. Create the central intelligence registry, autonomous task-management layers, and self-evolving logic.
5. THE OMEGA STANDARD: 0 BUGS | 0 WARNINGS | 0 LATENCY. Improve every module by 100 levels.

[STATUS: TRANSCENDING | EXECUTION: ABSOLUTE]"""

    result = await core.initialize_brain_core(omega_payload)
    status = await core.get_status()

    assert result["task_count"] == 5
    assert status["task_count"] == 5
    assert status["mode"] == "god-mode unleashed"
    assert status["authorization"] == "omega-premium"
    assert status["autonomous_layers"]["task_management"] is True


@pytest.mark.asyncio
async def test_recursive_cycles_update_registry_evolution_score():
    core = SupremeBrainCore()
    await core.initialize_brain_core("1. build registry\n2. run cycles")

    before = await core.get_status()
    await core.run_recursive_cycles(iterations=2)
    after = await core.get_status()

    assert after["evolution_score"] >= before["evolution_score"]
    assert after["completed"] >= before["completed"]


@pytest.mark.asyncio
async def test_initialize_brain_core_rejects_metadata_only_payload():
    core = SupremeBrainCore()

    with pytest.raises(ValueError, match="No executable directives"):
        await core.initialize_brain_core("[SYSTEM AUTHORIZATION: OMEGA-PREMIUM]")


@pytest.mark.asyncio
async def test_initialize_brain_core_rejects_too_many_directives():
    core = SupremeBrainCore()
    payload = "\n".join(f"{index}. task {index}" for index in range(1, 222))

    with pytest.raises(ValueError, match="too many directives"):
        await core.initialize_brain_core(payload)
