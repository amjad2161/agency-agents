import asyncio
from typing import Any
from unittest.mock import patch

import httpx
import pytest

from core.aios_bridge import AIOSBridge


class _DummyResponse:
    def __init__(self, payload: dict[str, Any] | None = None, status_code: int = 200):
        self._payload = payload or {}
        self.status_code = status_code
        self.content = b"{}"
        self.text = str(self._payload)

    def raise_for_status(self) -> None:
        return

    def json(self) -> dict[str, Any]:
        return dict(self._payload)


class _DummyClient:
    def __init__(self, response: _DummyResponse):
        self._response = response

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def request(self, method: str, url: str, json=None, params=None, headers=None):
        await asyncio.sleep(0)
        return self._response


def test_aios_bridge_health_success() -> None:
    bridge = AIOSBridge(base_url="http://aios.local")

    with patch(
        "src.core.aios_bridge.httpx.AsyncClient",
        return_value=_DummyClient(_DummyResponse({"status": "ok"})),
    ):
        result = asyncio.run(bridge.health())

    assert result["status"] == "ok"


def test_aios_bridge_forward_task_success() -> None:
    bridge = AIOSBridge(base_url="http://aios.local")
    payload = {
        "task_type": "analysis",
        "description": "Run analysis",
        "inputs": {"topic": "integration"},
        "constraints": {},
    }

    with patch(
        "src.core.aios_bridge.httpx.AsyncClient",
        return_value=_DummyClient(_DummyResponse({"task_id": "task-123", "status": "queued"})),
    ):
        result = asyncio.run(bridge.forward_task(payload))

    assert result["task_id"] == "task-123"
    assert result["status"] == "queued"


def test_aios_bridge_request_error_raises_connection_error() -> None:
    bridge = AIOSBridge(base_url="http://aios.local")

    class _FailingClient:
        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        async def request(self, method: str, url: str, json=None, params=None, headers=None):
            await asyncio.sleep(0)
            request = httpx.Request(method, url)
            raise httpx.RequestError("network down", request=request)

    with patch("src.core.aios_bridge.httpx.AsyncClient", return_value=_FailingClient()):
        with pytest.raises(ConnectionError):
            asyncio.run(bridge.health())


def test_aios_bridge_http_error_raises_value_error() -> None:
    bridge = AIOSBridge(base_url="http://aios.local")

    class _HttpErrorClient:
        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        async def request(self, method: str, url: str, json=None, params=None, headers=None):
            await asyncio.sleep(0)
            request = httpx.Request(method, url)
            response = httpx.Response(502, request=request, text="upstream bad gateway")
            raise httpx.HTTPStatusError("bad gateway", request=request, response=response)

    with patch("src.core.aios_bridge.httpx.AsyncClient", return_value=_HttpErrorClient()):
        with pytest.raises(ValueError, match="HTTP error 502"):
            asyncio.run(bridge.health())


def test_aios_bridge_forward_task_requires_fields() -> None:
    bridge = AIOSBridge(base_url="http://aios.local")

    with pytest.raises(ValueError, match="missing required fields"):
        asyncio.run(bridge.forward_task({"inputs": {"x": 1}}))


def test_aios_bridge_api_key_added_to_headers() -> None:
    bridge = AIOSBridge(base_url="http://aios.local", api_key="secret-key")
    captured_headers: dict[str, Any] = {}

    class _HeaderClient:
        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        async def request(self, method: str, url: str, json=None, params=None, headers=None):
            await asyncio.sleep(0)
            captured_headers.update(headers or {})
            return _DummyResponse({"ok": True})

    with patch("src.core.aios_bridge.httpx.AsyncClient", return_value=_HeaderClient()):
        result = asyncio.run(bridge.health())

    assert result["ok"] is True
    assert captured_headers.get("Authorization") == "Bearer secret-key"
