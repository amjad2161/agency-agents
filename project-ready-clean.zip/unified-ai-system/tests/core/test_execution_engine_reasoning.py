import asyncio

from core.execution_engine import ExecutionAction, ExecutionEngine, ExecutionJob, ExecutionMode


def test_execution_engine_rejects_deferred_reasoning_job() -> None:
    engine = ExecutionEngine()
    job = ExecutionJob(
        job_id="job-1",
        task_id="task-1",
        actions=[],
        mode=ExecutionMode.DRY_RUN,
        reasoning_mode="defer",
        reasoning_confidence=0.2,
        reasoning_defer_reason="Explicit defer for high-risk contradiction",
    )

    result = asyncio.run(engine.execute_job(job))

    assert result.status == "rejected"
    assert "defer" in (result.error or "").lower()


def test_execution_engine_allows_cautious_job() -> None:
    engine = ExecutionEngine()
    job = ExecutionJob(
        job_id="job-2",
        task_id="task-2",
        actions=[],
        mode=ExecutionMode.DRY_RUN,
        reasoning_mode="cautious",
        reasoning_confidence=0.65,
    )

    result = asyncio.run(engine.execute_job(job))

    assert result.status == "completed"


def test_execution_engine_rejects_unsafe_api_endpoint() -> None:
    engine = ExecutionEngine()
    job = ExecutionJob(
        job_id="job-3",
        task_id="task-3",
        mode=ExecutionMode.LIVE,
        actions=[
            ExecutionAction(
                action_id="action-1",
                action_type="api_call",
                target="http://127.0.0.1/private",
                parameters={
                    "endpoint": "http://127.0.0.1/private",
                    "method": "GET",
                },
            )
        ],
    )

    result = asyncio.run(engine.execute_job(job))

    assert result.status == "failed"
    assert "unsafe http endpoint" in (result.error or "").lower()
