"""
Comprehensive tests for src/core/model_router.py

Covers:
- Enums (TaskComplexity, ModelTier)
- Dataclasses (Model, RouteDecision, TokenBudget)
- ComplexityClassifier (classification, keyword detection, token estimation)
- ModelRouter (initialization, routing, candidates, selection, health, cache,
  budgets, circuit breaker, cost estimation, confidence, reasoning, cache keys,
  metrics)
- CostControlEngine (budget checks, warnings, reports, monthly projection)
- SelfCritiqueLoop (critique, revise, execute_loop success and max-iter paths)
"""

import asyncio
import hashlib
import logging
from datetime import UTC, datetime, timedelta

import pytest

from core.model_router import (
    ComplexityClassifier,
    CostControlEngine,
    Model,
    ModelRouter,
    ModelTier,
    RouteDecision,
    SelfCritiqueLoop,
    TaskComplexity,
    TokenBudget,
)

# =============================================================================
# Enums
# =============================================================================


class TestTaskComplexity:
    def test_values(self):
        assert TaskComplexity.TRIVIAL.value == 0
        assert TaskComplexity.SIMPLE.value == 1
        assert TaskComplexity.MODERATE.value == 2
        assert TaskComplexity.COMPLEX.value == 3
        assert TaskComplexity.HIGHLY_COMPLEX.value == 4

    def test_count(self):
        assert len(list(TaskComplexity)) == 5


class TestModelTier:
    def test_values(self):
        assert ModelTier.FAST.value == "fast"
        assert ModelTier.STANDARD.value == "standard"
        assert ModelTier.ADVANCED.value == "advanced"
        assert ModelTier.PREMIUM.value == "premium"

    def test_count(self):
        assert len(list(ModelTier)) == 4


# =============================================================================
# Dataclasses
# =============================================================================


class TestModelDataclass:
    def test_required_fields(self):
        m = Model(
            model_id="x",
            provider="p",
            tier=ModelTier.FAST,
            max_tokens=1000,
            latency_ms_estimate=100,
            cost_per_1k_input=0.001,
            cost_per_1k_output=0.002,
        )
        assert m.model_id == "x"
        assert m.supports_multimodal is False
        assert m.supports_code is False
        assert m.supports_reasoning is False
        assert m.supports_long_context is False
        assert m.requests_per_minute == 100
        assert m.tokens_per_minute == 100000
        assert m.fallback_model_id is None


class TestRouteDecision:
    def test_default_alternative_models(self):
        m = Model(
            model_id="x",
            provider="p",
            tier=ModelTier.FAST,
            max_tokens=1,
            latency_ms_estimate=1,
            cost_per_1k_input=0.0,
            cost_per_1k_output=0.0,
        )
        d = RouteDecision(
            selected_model=m,
            confidence=0.5,
            reasoning="r",
            estimated_cost=0.1,
            estimated_latency_ms=100,
        )
        assert d.alternative_models == []

    def test_independent_defaults(self):
        m = Model(
            model_id="x",
            provider="p",
            tier=ModelTier.FAST,
            max_tokens=1,
            latency_ms_estimate=1,
            cost_per_1k_input=0.0,
            cost_per_1k_output=0.0,
        )
        d1 = RouteDecision(
            selected_model=m, confidence=0, reasoning="", estimated_cost=0, estimated_latency_ms=0
        )
        d2 = RouteDecision(
            selected_model=m, confidence=0, reasoning="", estimated_cost=0, estimated_latency_ms=0
        )
        d1.alternative_models.append(m)
        assert d2.alternative_models == []


class TestTokenBudget:
    def test_initial(self):
        b = TokenBudget(max_tokens=100)
        assert b.current_usage == 0
        assert b.budget_type == "per_request"

    def test_can_spend_within(self):
        b = TokenBudget(max_tokens=100)
        assert b.can_spend(50) is True

    def test_can_spend_boundary_equal(self):
        b = TokenBudget(max_tokens=100)
        # can_spend uses >=, so exact fit still succeeds
        assert b.can_spend(100) is True

    def test_can_spend_overflow(self):
        b = TokenBudget(max_tokens=100)
        assert b.can_spend(101) is False

    def test_spend_success(self):
        b = TokenBudget(max_tokens=100)
        assert b.spend(40) is True
        assert b.current_usage == 40

    def test_spend_failure_no_mutation(self):
        b = TokenBudget(max_tokens=100)
        b.spend(60)
        assert b.spend(50) is False
        assert b.current_usage == 60


# =============================================================================
# ComplexityClassifier
# =============================================================================


class TestComplexityClassifier:
    def setup_method(self):
        self.c = ComplexityClassifier()

    def test_keyword_counts(self):
        assert len(ComplexityClassifier.HIGH_COMPLEXITY_KEYWORDS) == 14
        assert len(ComplexityClassifier.MULTIMODAL_KEYWORDS) == 11
        assert len(ComplexityClassifier.CODE_KEYWORDS) == 10

    def test_trivial(self):
        assert self.c.classify("hi") == TaskComplexity.TRIVIAL

    def test_simple_single_keyword(self):
        assert self.c.classify("compare two items") == TaskComplexity.SIMPLE

    def test_moderate_two_keywords(self):
        assert self.c.classify("analyze and compare data") == TaskComplexity.MODERATE

    def test_complex_high_score(self):
        q = "analyze compare evaluate design"  # 4 keywords → 4
        assert self.c.classify(q) == TaskComplexity.COMPLEX

    def test_highly_complex_long_with_keywords(self):
        # long query (>500 words adds 2) + keywords
        words = ["analyze", "compare", "evaluate", "design"] + ["word"] * 600
        q = " ".join(words)
        assert self.c.classify(q) == TaskComplexity.HIGHLY_COMPLEX

    def test_wc_over_200_adds_1(self):
        words = ["analyze"] + ["word"] * 250  # 1 keyword + 1 len bump = 2 → MODERATE
        q = " ".join(words)
        assert self.c.classify(q) == TaskComplexity.MODERATE

    def test_history_cap(self):
        # len(history)//5=20, capped to 2; "analyze" 1 + 2 cap = 3 → MODERATE
        assert self.c.classify("analyze", history=list(range(100))) == TaskComplexity.MODERATE

    def test_context_reasoning_flag(self):
        # "analyze" 1 + reasoning 1 = 2 → MODERATE
        assert (
            self.c.classify("analyze", context={"requires_reasoning": True})
            == TaskComplexity.MODERATE
        )

    def test_context_creativity_flag(self):
        assert (
            self.c.classify("analyze", context={"requires_creativity": True})
            == TaskComplexity.MODERATE
        )

    def test_requires_multimodal_true(self):
        assert self.c.requires_multimodal("show the image please") is True

    def test_requires_multimodal_false(self):
        assert self.c.requires_multimodal("just text here") is False

    def test_requires_code_true(self):
        assert self.c.requires_code("write a python function") is True

    def test_requires_code_false(self):
        assert self.c.requires_code("tell me a story") is False

    def test_estimate_tokens(self):
        q = "one two three four five"  # 5 words * 1.3 = 6.5 → int = 6
        assert self.c.estimate_tokens(q) == 6

    def test_all_high_complexity_keywords_trigger(self):
        for kw in ComplexityClassifier.HIGH_COMPLEXITY_KEYWORDS:
            assert self.c.classify(kw).value >= TaskComplexity.SIMPLE.value

    def test_all_multimodal_keywords_trigger(self):
        for kw in ComplexityClassifier.MULTIMODAL_KEYWORDS:
            assert self.c.requires_multimodal(kw) is True

    def test_all_code_keywords_trigger(self):
        for kw in ComplexityClassifier.CODE_KEYWORDS:
            assert self.c.requires_code(kw) is True


# =============================================================================
# ModelRouter
# =============================================================================


class TestModelRouterInit:
    def test_initializes_five_models(self):
        r = ModelRouter()
        assert set(r.models) == {
            "gpt-4-turbo",
            "gpt-3.5-turbo",
            "claude-3-opus",
            "claude-3-sonnet",
            "gemini-pro",
        }

    def test_gpt4_turbo_fields(self):
        m = ModelRouter().models["gpt-4-turbo"]
        assert m.provider == "openai"
        assert m.tier == ModelTier.ADVANCED
        assert m.max_tokens == 128000
        assert m.latency_ms_estimate == 2000
        assert m.cost_per_1k_input == 0.01
        assert m.cost_per_1k_output == 0.03
        assert m.supports_reasoning and m.supports_code and m.supports_long_context
        assert m.fallback_model_id == "gpt-4"

    def test_gpt35_turbo_fields(self):
        m = ModelRouter().models["gpt-3.5-turbo"]
        assert m.tier == ModelTier.FAST
        assert m.max_tokens == 16385
        assert m.latency_ms_estimate == 500
        assert m.cost_per_1k_input == 0.0005
        assert m.cost_per_1k_output == 0.0015
        assert m.supports_code is True
        assert m.fallback_model_id is None

    def test_claude_opus_fields(self):
        m = ModelRouter().models["claude-3-opus"]
        assert m.tier == ModelTier.PREMIUM
        assert m.max_tokens == 200000
        assert m.latency_ms_estimate == 3000
        assert m.cost_per_1k_input == 0.015
        assert m.cost_per_1k_output == 0.075
        assert m.supports_reasoning and m.supports_multimodal and m.supports_long_context
        assert m.fallback_model_id == "claude-3-sonnet"

    def test_claude_sonnet_fields(self):
        m = ModelRouter().models["claude-3-sonnet"]
        assert m.tier == ModelTier.ADVANCED
        assert m.max_tokens == 200000
        assert m.latency_ms_estimate == 1500
        assert m.cost_per_1k_input == 0.003
        assert m.cost_per_1k_output == 0.015
        assert m.fallback_model_id == "claude-3-haiku"

    def test_gemini_pro_fields(self):
        m = ModelRouter().models["gemini-pro"]
        assert m.provider == "google"
        assert m.tier == ModelTier.STANDARD
        assert m.max_tokens == 32000
        assert m.latency_ms_estimate == 1000
        assert m.cost_per_1k_input == 0.001
        assert m.cost_per_1k_output == 0.002
        assert m.supports_multimodal is True
        assert m.fallback_model_id == "gemini-flash"

    def test_health_initialized(self):
        r = ModelRouter()
        for mid in r.models:
            h = r.model_health[mid]
            assert h == {
                "success_count": 0,
                "failure_count": 0,
                "last_failure_time": None,
                "circuit_open": False,
            }

    def test_budget_defaults(self):
        r = ModelRouter()
        assert r.hourly_budget.max_tokens == 500000
        assert r.daily_budget.max_tokens == 5000000
        assert r.request_budget.max_tokens == 128000
        assert r.cache_ttl_seconds == 300
        assert r.circuit_breaker_threshold == 5
        assert r.circuit_breaker_timeout == 60


class TestModelRouterRoute:
    def test_route_returns_decision(self):
        r = ModelRouter()
        d = r.route("What is Python?")
        assert isinstance(d, RouteDecision)
        assert d.selected_model.model_id in r.models

    def test_route_simple_picks_fast_tier(self):
        r = ModelRouter()
        d = r.route("hello")  # TRIVIAL → FAST tier candidates
        assert d.selected_model.tier == ModelTier.FAST

    def test_route_complex_picks_advanced_or_premium(self):
        r = ModelRouter()
        q = "analyze compare evaluate design optimize synthesize"
        d = r.route(q)
        assert d.selected_model.tier in (ModelTier.ADVANCED, ModelTier.PREMIUM)

    def test_route_cache_hit(self):
        r = ModelRouter()
        d1 = r.route("hello world")
        d2 = r.route("hello world")
        # Same underlying object reference because cached
        assert d1 is d2

    def test_route_cache_expiry(self):
        r = ModelRouter()
        r.cache_ttl_seconds = 0  # force expiry
        d1 = r.route("hello world")
        d2 = r.route("hello world")
        assert d1 is not d2

    def test_route_alternative_models_slice(self):
        r = ModelRouter()
        d = r.route("analyze and compare")  # MODERATE → multiple candidates
        assert len(d.alternative_models) <= 3

    def test_route_budget_warning(self, caplog):
        r = ModelRouter()
        r.request_budget = TokenBudget(max_tokens=1)
        with caplog.at_level(logging.WARNING):
            r.route("this query has more than one token worth of words here okay")
        assert any("Request budget exceeded" in rec.message for rec in caplog.records)

    def test_route_spends_request_budget(self):
        r = ModelRouter()
        before = r.request_budget.current_usage
        r.route("hello world this is a test")
        assert r.request_budget.current_usage > before


class TestFindCandidates:
    def test_tier_map_coverage(self):
        r = ModelRouter()
        for complexity in TaskComplexity:
            cands = r._find_candidates(complexity, False, False, None)
            assert isinstance(cands, list)

    def test_multimodal_filter(self):
        r = ModelRouter()
        cands = r._find_candidates(TaskComplexity.MODERATE, True, False, None)
        assert all(m.supports_multimodal for m in cands)

    def test_code_filter(self):
        r = ModelRouter()
        cands = r._find_candidates(TaskComplexity.SIMPLE, False, True, None)
        assert all(m.supports_code for m in cands)

    def test_context_length_filter(self):
        r = ModelRouter()
        cands = r._find_candidates(
            TaskComplexity.SIMPLE,
            False,
            False,
            {"estimated_tokens": 999999},
        )
        # None of the FAST/STANDARD models support that many tokens
        assert cands == []

    def test_default_estimated_tokens_8000(self):
        r = ModelRouter()
        cands = r._find_candidates(TaskComplexity.MODERATE, False, False, None)
        # All candidates should have max_tokens >= 8000
        assert all(m.max_tokens >= 8000 for m in cands)

    def test_cost_sorted(self):
        r = ModelRouter()
        cands = r._find_candidates(TaskComplexity.COMPLEX, False, False, None)
        costs = [(m.cost_per_1k_input + m.cost_per_1k_output) * 0.5 for m in cands]
        assert costs == sorted(costs)

    def test_unhealthy_models_skipped(self):
        r = ModelRouter()
        r.model_health["gpt-4-turbo"]["circuit_open"] = True
        r.model_health["gpt-4-turbo"]["last_failure_time"] = datetime.now(UTC)
        cands = r._find_candidates(TaskComplexity.COMPLEX, False, False, None)
        assert all(m.model_id != "gpt-4-turbo" for m in cands)


class TestSelectModel:
    def test_empty_candidates_fallback(self):
        r = ModelRouter()
        selected = r._select_model([], TaskComplexity.SIMPLE, None)
        assert selected.model_id == "gpt-3.5-turbo"

    def test_budget_constrained_picks_cheapest(self):
        r = ModelRouter()
        m1 = r.models["gpt-4-turbo"]
        m2 = r.models["gpt-3.5-turbo"]
        selected = r._select_model([m1, m2], TaskComplexity.MODERATE, {"budget_constrained": True})
        assert selected is m2

    def test_simple_picks_first(self):
        r = ModelRouter()
        m1 = r.models["gpt-3.5-turbo"]
        m2 = r.models["gemini-pro"]
        selected = r._select_model([m1, m2], TaskComplexity.SIMPLE, None)
        assert selected is m1

    def test_complex_picks_second_when_available(self):
        r = ModelRouter()
        m1 = r.models["gpt-3.5-turbo"]
        m2 = r.models["claude-3-opus"]
        selected = r._select_model([m1, m2], TaskComplexity.COMPLEX, None)
        assert selected is m2

    def test_complex_single_candidate(self):
        r = ModelRouter()
        m1 = r.models["claude-3-opus"]
        selected = r._select_model([m1], TaskComplexity.COMPLEX, None)
        assert selected is m1


class TestCircuitBreaker:
    def test_record_success(self):
        r = ModelRouter()
        r.record_success("gpt-4-turbo")
        assert r.model_health["gpt-4-turbo"]["success_count"] == 1

    def test_record_failure_increments(self):
        r = ModelRouter()
        r.record_failure("gpt-4-turbo")
        assert r.model_health["gpt-4-turbo"]["failure_count"] == 1
        assert r.model_health["gpt-4-turbo"]["last_failure_time"] is not None

    def test_circuit_opens_at_threshold(self, caplog):
        r = ModelRouter()
        with caplog.at_level(logging.WARNING):
            for _ in range(5):
                r.record_failure("gpt-4-turbo")
        assert r.model_health["gpt-4-turbo"]["circuit_open"] is True
        assert any("Circuit breaker opened" in rec.message for rec in caplog.records)

    def test_is_model_healthy_open_circuit_within_timeout(self):
        r = ModelRouter()
        r.model_health["gpt-4-turbo"]["circuit_open"] = True
        r.model_health["gpt-4-turbo"]["last_failure_time"] = datetime.now(UTC)
        assert r._is_model_healthy("gpt-4-turbo") is False

    def test_is_model_healthy_resets_after_timeout(self):
        r = ModelRouter()
        r.model_health["gpt-4-turbo"]["circuit_open"] = True
        r.model_health["gpt-4-turbo"]["failure_count"] = 5
        r.model_health["gpt-4-turbo"]["last_failure_time"] = datetime.now(UTC) - timedelta(
            seconds=120
        )
        assert r._is_model_healthy("gpt-4-turbo") is True
        assert r.model_health["gpt-4-turbo"]["circuit_open"] is False
        assert r.model_health["gpt-4-turbo"]["failure_count"] == 0

    def test_unknown_model_healthy(self):
        r = ModelRouter()
        assert r._is_model_healthy("unknown") is True

    def test_record_success_unknown_noop(self):
        r = ModelRouter()
        r.record_success("unknown")  # should not raise

    def test_record_failure_unknown_noop(self):
        r = ModelRouter()
        r.record_failure("unknown")  # should not raise


class TestEstimateCost:
    def test_formula(self):
        r = ModelRouter()
        m = r.models["gpt-3.5-turbo"]
        # (1000/1000)*0.0005 + (1500/1000)*0.0015 = 0.0005 + 0.00225 = 0.00275
        assert r._estimate_cost(m, 1000) == pytest.approx(0.00275)


class TestCalculateConfidence:
    def test_base_confidence(self):
        r = ModelRouter()
        m = r.models["gemini-pro"]  # no reasoning, STANDARD tier
        c = r._calculate_confidence(m, TaskComplexity.SIMPLE)
        assert c == pytest.approx(0.7)

    def test_complex_advanced_tier_bonus(self):
        r = ModelRouter()
        m = r.models["gpt-4-turbo"]  # ADVANCED + supports_reasoning
        c = r._calculate_confidence(m, TaskComplexity.COMPLEX)
        # 0.7 + 0.2 (tier) + 0.1 (reasoning) = 1.0
        assert c == pytest.approx(1.0)

    def test_capped_at_one(self):
        r = ModelRouter()
        m = r.models["claude-3-opus"]  # PREMIUM + reasoning
        c = r._calculate_confidence(m, TaskComplexity.HIGHLY_COMPLEX)
        assert c <= 1.0

    def test_reasoning_only_bonus(self):
        r = ModelRouter()
        m = r.models["gpt-4-turbo"]  # reasoning, ADVANCED
        c = r._calculate_confidence(m, TaskComplexity.SIMPLE)
        # SIMPLE → no tier bonus; +0.1 reasoning = 0.8
        assert c == pytest.approx(0.8)


class TestGenerateReasoning:
    def test_join_semicolon(self):
        r = ModelRouter()
        m = r.models["gpt-4-turbo"]
        reason = r._generate_routing_reasoning("q", TaskComplexity.COMPLEX, m, False, False)
        assert "; " in reason
        assert "COMPLEX" in reason
        assert "gpt-4-turbo" in reason
        assert "openai" in reason

    def test_multimodal_flag(self):
        r = ModelRouter()
        m = r.models["claude-3-opus"]
        reason = r._generate_routing_reasoning("q", TaskComplexity.SIMPLE, m, True, False)
        assert "multimodal" in reason

    def test_code_flag(self):
        r = ModelRouter()
        m = r.models["gpt-3.5-turbo"]
        reason = r._generate_routing_reasoning("q", TaskComplexity.SIMPLE, m, False, True)
        assert "code" in reason


class TestCacheKey:
    def test_md5_hex(self):
        r = ModelRouter()
        key = r._generate_cache_key("hello", TaskComplexity.SIMPLE)
        expected = hashlib.md5(b"hello:1").hexdigest()
        assert key == expected

    def test_truncation_100_chars(self):
        r = ModelRouter()
        long_q = "a" * 200
        key = r._generate_cache_key(long_q, TaskComplexity.SIMPLE)
        expected = hashlib.md5(("a" * 100 + ":1").encode()).hexdigest()
        assert key == expected


class TestGetMetrics:
    def test_keys(self):
        r = ModelRouter()
        m = r.get_metrics()
        assert set(m) == {
            "total_models",
            "total_requests",
            "cache_size",
            "budget",
            "model_health",
        }
        assert m["total_models"] == 5
        assert m["total_requests"] == 0
        assert m["cache_size"] == 0
        assert "hourly_remaining" in m["budget"]
        assert "daily_remaining" in m["budget"]

    def test_total_requests_sums(self):
        r = ModelRouter()
        r.record_success("gpt-4-turbo")
        r.record_failure("gpt-3.5-turbo")
        assert r.get_metrics()["total_requests"] == 2


# =============================================================================
# CostControlEngine
# =============================================================================


class TestCostControlEngine:
    def test_init(self):
        e = CostControlEngine(ModelRouter())
        assert e.total_spent == 0.0
        assert e.daily_limit == 100.0
        assert e.monthly_limit == 1000.0

    def test_check_budget_within(self):
        e = CostControlEngine(ModelRouter())
        assert e.check_budget(50.0) is True

    def test_check_budget_exceeds(self, caplog):
        e = CostControlEngine(ModelRouter())
        with caplog.at_level(logging.WARNING):
            assert e.check_budget(150.0) is False
        assert any("Daily budget exceeded" in rec.message for rec in caplog.records)

    def test_record_cost(self):
        e = CostControlEngine(ModelRouter())
        e.record_cost(25.5)
        assert e.total_spent == 25.5

    def test_reset_daily(self):
        e = CostControlEngine(ModelRouter())
        e.record_cost(50.0)
        e.reset_daily()
        assert e.total_spent == 0.0

    def test_spending_report(self):
        e = CostControlEngine(ModelRouter())
        e.record_cost(50.0)
        report = e.get_spending_report()
        assert report["total_spent"] == 50.0
        assert report["daily_limit"] == 100.0
        assert report["monthly_limit"] == 1000.0
        assert report["daily_utilization"] == 0.5
        assert report["monthly_projection"] == 1500.0


# =============================================================================
# SelfCritiqueLoop
# =============================================================================


class TestSelfCritiqueLoop:
    def test_init_defaults(self):
        loop = SelfCritiqueLoop()
        assert loop.max_iterations == 3
        assert loop.confidence_threshold == 0.8

    def test_init_custom(self):
        loop = SelfCritiqueLoop(max_iterations=5, confidence_threshold=0.95)
        assert loop.max_iterations == 5
        assert loop.confidence_threshold == 0.95

    def test_critique_completeness_penalty(self):
        loop = SelfCritiqueLoop(confidence_threshold=0.85)
        result = asyncio.run(loop.critique("short", ["completeness"]))
        assert result["quality_score"] == pytest.approx(0.8)
        assert result["needs_revision"] is True

    def test_critique_coherence_penalty(self):
        loop = SelfCritiqueLoop()
        content = "abrupt... jump"
        result = asyncio.run(loop.critique(content, ["coherence"]))
        assert result["quality_score"] == pytest.approx(0.9)

    def test_critique_accuracy_penalty(self):
        loop = SelfCritiqueLoop()
        result = asyncio.run(loop.critique("this might be correct", ["accuracy"]))
        assert result["quality_score"] == pytest.approx(0.85)

    def test_critique_relevance_penalty(self):
        loop = SelfCritiqueLoop()
        ctx = {"query": "quantum physics theory"}
        result = asyncio.run(loop.critique("cooking is fun and easy", ["relevance"], ctx))
        assert result["quality_score"] == pytest.approx(0.7)

    def test_critique_passes(self):
        loop = SelfCritiqueLoop(confidence_threshold=0.5)
        good = " ".join(["word"] * 100)
        result = asyncio.run(loop.critique(good, ["completeness"]))
        assert result["needs_revision"] is False
        assert result["quality_score"] == 1.0

    def test_revise_adds_detail(self):
        loop = SelfCritiqueLoop()
        out = asyncio.run(loop.revise("text", [], ["Add more detail"]))
        assert "Additional context" in out

    def test_revise_smooth_transition(self):
        loop = SelfCritiqueLoop()
        out = asyncio.run(loop.revise("one...two", [], ["Add smooth transition"]))
        assert "..." not in out
        assert "Additionally" in out

    def test_revise_verify(self):
        loop = SelfCritiqueLoop()
        out = asyncio.run(loop.revise("claim", [], ["Verify facts"]))
        assert "verified" in out

    def test_execute_loop_success(self):
        loop = SelfCritiqueLoop(confidence_threshold=0.5)
        good = " ".join(["word"] * 100)
        result = asyncio.run(loop.execute_loop(good, ["completeness"]))
        assert set(result) == {"content", "iterations", "confidence", "issues_resolved"}
        assert result["iterations"] == 0
        assert result["issues_resolved"] is True

    def test_execute_loop_max_iterations(self):
        loop = SelfCritiqueLoop(max_iterations=2, confidence_threshold=0.99)
        result = asyncio.run(loop.execute_loop("short", ["completeness"]))
        assert set(result) == {
            "content",
            "iterations",
            "confidence",
            "issues_resolved",
            "warning",
        }
        assert result["iterations"] == 2
        assert result["warning"] == "Max iterations reached"
        assert result["issues_resolved"] is False
