# Information Lineage Contract

This document defines the minimal shared contract that links every important system boundary:

- incoming API input
- protocol ingress input
- orchestrator task state
- retrieved memory references
- tool invocations
- final output

## Purpose

The project already had trace IDs, protocol envelopes, and tool execution history. The missing piece was one normalized lineage object propagated automatically across boundaries.

This contract closes that gap.

## Contract Fields

```json
{
  "request_id": "uuid",
  "trace_id": "uuid",
  "session_id": "optional-session-id",
  "parent_task_id": "optional-parent-task-id",
  "source": "task_api | chat_completion | protocol_ingress | tool_execution",
  "source_message_id": "optional-external-message-id",
  "input_hash": "sha256-of-normalized-input",
  "memory_refs": ["memory-id"],
  "tool_invocation_ids": ["invocation-id"],
  "output_ref": null
}
```

## Propagation Rules

1. API ingress creates or normalizes the lineage block.
2. The orchestrator preserves the lineage block and aligns it with the task trace ID.
3. Memory retrieval can append `memory_refs`.
4. Tool execution appends its `invocation_id` to `tool_invocation_ids`.
5. Retries append retry metadata so repeated attempts remain attributable.
6. Successful task completion can attach an `output_ref` for the produced output.
7. Task status responses expose the active lineage block so callers do not need to reconstruct it from separate logs.
8. Task search responses can retrieve lineage-linked tasks directly by `trace_id`, `request_id`, or `source_message_id`.

## Lifecycle Notes

- The lineage object is append-oriented. It starts at ingress and accumulates more references as execution advances.
- `memory_refs` are populated when relevant memory is retrieved for execution context.
- `tool_invocation_ids` are populated at tool execution time.
- `retry_count` is updated when a task is retried after failure.
- `output_ref` is populated when a successful task result is finalized.
- Cancelled tasks retain their last known lineage snapshot even if no output is produced.

## Implemented Surfaces

- `src/api/server.py`
- `src/core/orchestrator.py`
- `src/core/lineage.py`
- `src/tools/tool_registry.py`

## Query Surfaces

- `GET /v1/tasks/{task_id}` returns the lineage snapshot for one task.
- `GET /v1/tasks/search?trace_id=...`
- `GET /v1/tasks/search?request_id=...`
- `GET /v1/tasks/search?source_message_id=...`

The search endpoint scans active, completed, and failed tasks so lineage can be used as an operational lookup key instead of only a propagated payload.

## Why This Matters

This is the project's precise link between input and output. It makes automation more reliable because each downstream action can be tied back to:

- the originating request
- the exact task trace
- the external message if the task came from a protocol adapter
- the memory references consulted during execution
- the tool invocations performed before producing an output

## Current Limitation

The contract is now propagated through the core Python surfaces above and is queryable through task status and task search. It is not yet persisted by a runtime database repository and it is not yet exported as an OpenAPI schema.

## Next High-Value Extensions

1. Persist lineage snapshots in task and workflow execution tables.
2. Add OpenAPI response examples that include lineage.
3. Add event-bus versioned lineage envelopes for async services.
4. Attach `output_ref` for persisted artifacts and reports.
5. Add end-to-end tests that prove one lineage chain across API, orchestrator, tools, and stored outputs.
