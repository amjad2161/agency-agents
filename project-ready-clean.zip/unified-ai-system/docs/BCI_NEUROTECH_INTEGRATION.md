# BCI and Neurotech Integration Notes

This project currently has no native BCI, EEG, or neurophysiology ingestion layer. The references you supplied are relevant and can be integrated in a clean way without distorting the current architecture.

## External References You Supplied

- BCI2000: <https://www.bci2000.org/mediawiki/index.php/Main_Page>
- MNE-Python: <https://mne.tools/stable/index.html>

## Why These Matter

### BCI2000

BCI2000 is a real-time brain-computer interface research platform for signal acquisition, signal processing, stimulus presentation, synchronization, and device control. It is useful here as an upstream acquisition and experiment-control system.

Best fit in this architecture:

- BCI2000 as acquisition and experiment runtime
- `aios` or `unified-ai-system` as orchestration, storage, analytics, and agentic reasoning layer
- a protocol bridge that ingests BCI session metadata, event markers, and exported recordings

### MNE-Python

MNE-Python is the correct Python ecosystem layer for EEG and MEG preprocessing, filtering, visualization, epoching, ICA, spectral analysis, decoding, and connectivity analysis. It is useful here as the preprocessing and analysis engine after acquisition.

Best fit in this architecture:

- MNE as offline or near-real-time preprocessing worker
- feature extraction pushed into the analytics and memory layers
- downstream agent workflows operating on cleaned signals, annotations, and derived features

## Recommended Integration Architecture

```text
BCI Hardware / OpenBCI / BrainFlow / BCI2000
                |
                v
        Acquisition Adapter Layer
                |
                v
      Raw Signal Landing Storage
    (session metadata + markers + files)
                |
                v
      MNE Preprocessing Worker Layer
  (notch, band-pass, ICA, epoching, QC)
                |
                v
 Feature / Event / Embedding Extraction
                |
                v
  unified-ai-system / aios orchestration
                |
                v
    dashboards, agents, analytics, APIs
```

## Immediate High-Value Work

1. Add a neuro-signal ingestion contract for EEG sessions.
2. Add a preprocessing worker that can run MNE pipelines on uploaded recordings.
3. Add a session manifest schema for subject, device, sampling rate, channel map, and event markers.
4. Add a feature store for PSD, bandpower, event-related potentials, and artifact summaries.
5. Add dashboards for session quality, impedance metadata, and filter outcomes.
6. Add traceability from raw recordings to cleaned outputs and derived features.
7. Add connectors for BrainFlow and BCI2000 exports.
8. Add OpenBCI file import flows once those archives are extracted into the workspace.

## About the OpenBCI and Other ZIP Attachments

You provided multiple ZIP archives, including OpenBCI hardware and library projects. They are not mounted as normal workspace files in this session, so they cannot be edited or imported directly from here.

What can be done next:

1. Extract those archives into the workspace.
2. I can then inventory them, validate build health, map reusable modules, and connect them into the current platform.
3. After extraction, I can generate a concrete compatibility matrix between OpenBCI assets, BrainFlow, BCI2000, and MNE.

## Filtering Guidance

Your supplied snippet uses a 1–40 Hz band-pass filter, which is a reasonable baseline for many EEG workflows. For powerline contamination, also apply a notch filter at the local mains frequency before or alongside band-pass filtering.

Typical baseline pipeline:

1. Load raw data.
2. Set channel types and montage.
3. Apply notch filter at 50 Hz or 60 Hz depending on site power.
4. Apply band-pass filter, for example 1–40 Hz.
5. Mark bad channels and bad segments.
6. Re-reference if required.
7. Run ICA or SSP for eye and muscle artifact reduction.
8. Epoch and extract features.

See [mne_bci_preprocessing_example.py](c:/Users/User/Downloads/package/unified-ai-system/examples/mne_bci_preprocessing_example.py) for a project-local example.
