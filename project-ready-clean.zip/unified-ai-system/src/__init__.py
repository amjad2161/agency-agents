"""
AI-OS - Unified AI Operating System
Enterprise-grade AI orchestration platform
"""

__version__ = "1.0.0"
__author__ = "AI-OS Team"

from .config.settings import DEFAULT_CONFIG, ConfigLoader, SystemConfig, config
from .core.aios_bridge import AIOSBridge
from .core.execution_engine import ExecutionEngine, SandboxExecutor
from .core.model_router import ComplexityClassifier, ModelRouter
from .core.orchestrator import Agent, Orchestrator, TaskGraph
from .core.supreme_brainiac import SupremeBrainCore

__all__ = [
    "config",
    "DEFAULT_CONFIG",
    "SystemConfig",
    "ConfigLoader",
    "Orchestrator",
    "Agent",
    "TaskGraph",
    "SupremeBrainCore",
    "ModelRouter",
    "ComplexityClassifier",
    "ExecutionEngine",
    "SandboxExecutor",
    "AIOSBridge",
]
