"""
AI-OS API Server
FastAPI-based REST API with WebSocket support
"""

from .server import APIServer, create_app

__all__ = ["APIServer", "create_app"]
