"""HTTP hosting entrypoint for Foundry supreme agent via Agent Server adapter."""

from __future__ import annotations

from core.foundry_supreme_agent import FoundrySupremeAgentFactory


async def main() -> None:
    try:
        from azure.ai.agentserver.agentframework import from_agent_framework
    except Exception as exc:  # pragma: no cover
        raise RuntimeError(
            "azure-ai-agentserver-agentframework is required. "
            "Install requirements-agent-framework.txt first."
        ) from exc

    config = FoundrySupremeAgentFactory.from_env()
    agent = await FoundrySupremeAgentFactory.create_agent(config)

    async with agent:
        hosting = from_agent_framework(agent)
        await hosting.run_async()


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())
