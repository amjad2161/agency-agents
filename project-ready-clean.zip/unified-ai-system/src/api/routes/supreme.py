"""Supreme control-plane routes with auth, rate limiting, and observability."""

from __future__ import annotations

import os
import secrets
import time
from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter, FastAPI, HTTPException, Request
from pydantic import BaseModel, Field


class SupremeInitRequest(BaseModel):
    """Initialization payload for supreme brain core."""

    directive_text: str = Field(
        ...,
        min_length=1,
        max_length=50_000,
        description="Directive bundle to ingest",
    )


class SupremeCycleRequest(BaseModel):
    """Cycle execution payload for supreme brain core."""

    iterations: int = Field(default=1, ge=1, le=20)


class SupremePresetInitRequest(BaseModel):
    """Preset initialization payload for supreme brain core."""

    append: bool = Field(default=False, description="Append preset tasks to existing queue")


_AUTH_RATE_LIMIT_RESPONSES: dict[int | str, dict[str, Any]] = {
    401: {"description": "Supreme endpoint authentication failed"},
    429: {"description": "Supreme rate limit exceeded"},
}


class _SupremeRouteContext:
    def __init__(self, server: Any):
        self.server = server

    @staticmethod
    def _resolve_auth_token(request: Request) -> str:
        provided = request.headers.get("X-Supreme-Token", "").strip()
        if provided:
            return provided
        auth_header = request.headers.get("Authorization", "").strip()
        if auth_header.lower().startswith("bearer "):
            parts = auth_header.split(None, 1)
            if len(parts) == 2:
                return parts[1].strip()
        return ""

    def require_auth(self, request: Request) -> None:
        configured = os.getenv("SUPREME_API_TOKEN", "").strip()
        if not configured:
            return

        provided = self._resolve_auth_token(request)
        if secrets.compare_digest(provided, configured):
            return

        with self.server._supreme_metrics_lock:
            self.server.supreme_metrics["auth_denied"] += 1
        raise HTTPException(status_code=401, detail="Supreme endpoint authentication failed")

    @staticmethod
    def _rate_limit_setting() -> int:
        legacy_value = os.getenv("SUPREME_RATE_LIMIT_PER_MINUTE")
        if legacy_value is not None and legacy_value.strip():
            return max(1, int(legacy_value))
        return max(
            1,
            int(
                os.getenv(
                    "SUPREME_RATE_LIMIT_PER_WINDOW",
                    "60",
                )
            ),
        )

    def enforce_rate_limit(self, request: Request) -> None:
        per_window = self._rate_limit_setting()
        window_seconds = self.server.rate_limit_window
        now_bucket = int(time.time() // window_seconds)
        client_host = request.client.host if request.client else "unknown"
        key = f"supreme:{client_host}:{now_bucket}"

        with self.server._rate_limit_lock:
            count = self.server.request_counts.get(key, 0) + 1
            self.server.request_counts[key] = count
            self._cleanup_rate_limit_buckets(client_host=client_host, now_bucket=now_bucket)

        if count <= per_window:
            return

        with self.server._supreme_metrics_lock:
            self.server.supreme_metrics["rate_limited"] += 1
        raise HTTPException(status_code=429, detail="Supreme rate limit exceeded")

    def _cleanup_rate_limit_buckets(self, client_host: str, now_bucket: int) -> None:
        stale_prefix = f"supreme:{client_host}:"
        stale_keys = [
            existing_key
            for existing_key in self.server.request_counts
            if existing_key.startswith(stale_prefix)
            and int(existing_key.rsplit(":", 1)[-1]) < now_bucket - 1
        ]
        for stale_key in stale_keys:
            self.server.request_counts.pop(stale_key, None)

        now = time.time()
        if now - self.server._last_rate_limit_cleanup < self.server._rate_limit_cleanup_interval_seconds:
            return

        global_stale = [
            existing_key
            for existing_key in self.server.request_counts
            if int(existing_key.rsplit(":", 1)[-1]) < now_bucket - 2
        ]
        for stale_key in global_stale:
            self.server.request_counts.pop(stale_key, None)
        self.server._last_rate_limit_cleanup = now

    def observe(self, endpoint: str) -> None:
        with self.server._supreme_metrics_lock:
            self.server.supreme_metrics["requests_total"] += 1
            endpoint_calls = self.server.supreme_metrics["endpoint_calls"]
            endpoint_calls[endpoint] = endpoint_calls.get(endpoint, 0) + 1

    def guard(self, request: Request, endpoint: str) -> None:
        self.observe(endpoint)
        self.require_auth(request)
        self.enforce_rate_limit(request)

    async def initialize_supreme_core(self, request: Request, payload: SupremeInitRequest) -> dict[str, Any]:
        self.guard(request, "init")
        return await self.server._initialize_supreme_core(payload.directive_text)

    async def initialize_supreme_omega_core(
        self, request: Request, payload: SupremePresetInitRequest
    ) -> dict[str, Any]:
        self.guard(request, "init_omega")
        return await self.server._initialize_supreme_omega_core(payload.append)

    async def execute_supreme_cycles(self, request: Request, payload: SupremeCycleRequest) -> dict[str, Any]:
        self.guard(request, "cycle")
        return await self.server._execute_supreme_cycles(payload.iterations)

    async def supreme_status(self, request: Request) -> dict[str, Any]:
        self.guard(request, "status")
        return await self.server._get_supreme_status()

    async def supreme_registry(self, request: Request) -> dict[str, Any]:
        self.guard(request, "registry")
        return await self.server._get_supreme_registry()

    async def supreme_metrics(self, request: Request) -> dict[str, Any]:
        self.guard(request, "metrics")
        status = await self.server._get_supreme_status()
        with self.server._supreme_metrics_lock:
            endpoint_calls = dict(self.server.supreme_metrics.get("endpoint_calls", {}))
            api_metrics: dict[str, int | dict[str, int]] = {
                "requests_total": int(self.server.supreme_metrics.get("requests_total", 0)),
                "auth_denied": int(self.server.supreme_metrics.get("auth_denied", 0)),
                "rate_limited": int(self.server.supreme_metrics.get("rate_limited", 0)),
                "endpoint_calls": endpoint_calls,
            }
        return {
            "timestamp": datetime.now(UTC).isoformat(),
            "api": api_metrics,
            "core": {
                "cycle_count": status.get("cycle_count", 0),
                "task_count": status.get("task_count", 0),
                "queued": status.get("queued", 0),
                "completed": status.get("completed", 0),
                "failed": status.get("failed", 0),
                "evolution_score": status.get("evolution_score", 0.0),
            },
        }


def _create_supreme_router(server: Any) -> APIRouter:
    router = APIRouter(prefix="/v1/supreme", tags=["supreme"])
    context = _SupremeRouteContext(server)

    router.add_api_route(
        "/init",
        context.initialize_supreme_core,
        methods=["POST"],
        responses=_AUTH_RATE_LIMIT_RESPONSES,
    )
    router.add_api_route(
        "/init/omega",
        context.initialize_supreme_omega_core,
        methods=["POST"],
        responses=_AUTH_RATE_LIMIT_RESPONSES,
    )
    router.add_api_route(
        "/cycle",
        context.execute_supreme_cycles,
        methods=["POST"],
        responses=_AUTH_RATE_LIMIT_RESPONSES,
    )
    router.add_api_route(
        "/status",
        context.supreme_status,
        methods=["GET"],
        responses=_AUTH_RATE_LIMIT_RESPONSES,
    )
    router.add_api_route(
        "/registry",
        context.supreme_registry,
        methods=["GET"],
        responses=_AUTH_RATE_LIMIT_RESPONSES,
    )
    router.add_api_route(
        "/metrics",
        context.supreme_metrics,
        methods=["GET"],
        responses=_AUTH_RATE_LIMIT_RESPONSES,
    )
    return router


def register_supreme_routes(app: FastAPI, server: Any) -> None:
    """Register Supreme endpoints on the FastAPI app."""

    app.include_router(_create_supreme_router(server))
