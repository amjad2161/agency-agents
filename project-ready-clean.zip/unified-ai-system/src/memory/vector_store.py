"""
AI-OS Memory System - Vector Store and Session Memory
Production-Grade Memory with Semantic Retrieval
"""

import asyncio
import hashlib
import logging
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any

try:
    import openai  # type: ignore
except ImportError:  # pragma: no cover
    openai = None  # type: ignore

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class MemoryType(Enum):
    """Memory type classifications"""

    WORKING = "working"
    EPISODIC = "episodic"
    SEMANTIC = "semantic"
    PROCEDURAL = "procedural"
    USER_PREFERENCE = "user_preference"
    SYSTEM = "system"


class EmbeddingModel(Enum):
    """Embedding model configurations"""

    TEXT_EMBEDDING_3_LARGE = ("text-embedding-3-large", 3072)
    TEXT_EMBEDDING_3 = ("text-embedding-3", 1536)
    TEXT_EMBEDDING_ADA = ("text-embedding-ada-002", 1536)

    def __new__(cls, model_name, dimension):
        obj = object.__new__(cls)
        obj._value_ = (model_name, dimension)
        obj.model_name = model_name
        obj.dimension = dimension
        return obj


@dataclass
class MemoryEntry:
    """Memory entry with metadata"""

    memory_id: str
    memory_type: MemoryType
    content: str

    # Embedding
    embedding: list[float]
    embedding_model: str = "text-embedding-3"

    # Indexing
    chunk_index: int = 0
    parent_memory_id: str | None = None

    # Metadata
    user_id: str | None = None
    session_id: str | None = None
    task_id: str | None = None
    tags: list[str] = field(default_factory=list)
    source_type: str = "user"
    source_id: str | None = None

    # Importance
    importance_score: float = 0.5
    access_count: int = 0
    last_accessed_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    attention_weight: float = 1.0

    # Temporal
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    expires_at: datetime | None = None
    validity_period: dict | None = None

    # Relationships
    related_memories: list[str] = field(default_factory=list)
    references: list[str] = field(default_factory=list)

    # Trust & Confidence
    confidence: float = 1.0
    trust_score: float = 1.0
    verification_count: int = 0

    # State
    is_compressed: bool = False
    compression_ratio: float = 1.0


@dataclass
class RetrievalResult:
    """Memory retrieval result with scoring"""

    memory: MemoryEntry
    relevance_score: float
    recency_score: float
    importance_score: float
    combined_score: float
    match_type: str = "semantic"  # semantic, exact, temporal, relational
    explanation: str = ""


@dataclass
class ContextWindow:
    """Context window for task execution"""

    entries: list[MemoryEntry]
    total_tokens: int
    compression_ratio: float
    coverage_percentage: float
    missing_topics: list[str] = field(default_factory=list)


class VectorStore:
    """
    Vector-based memory store with ANN indexing
    Production-grade semantic search
    """

    def __init__(self, dimension: int = 1536, metric: str = "cosine", index_type: str = "ivfflat"):
        self.dimension = dimension
        self.metric = metric
        self.index_type = index_type

        # Storage
        self.vectors: list[list[float]] = []
        self.metadata: dict[str, Any] = {}

        # Index structures
        self.id_to_index: dict[str, int] = {}
        self.type_index: dict[MemoryType, list[str]] = {}
        self.user_index: dict[str, list[str]] = {}

        # Index state
        self._index_built = False
        self._embedding_model = None

        logger.info(f"VectorStore initialized: dim={dimension}, metric={metric}")

    async def initialize(self):
        """Initialize vector store"""
        # In production, would connect to actual vector DB (Milvus, Pinecone, etc.)
        self._embedding_model = "text-embedding-3"
        logger.info("VectorStore initialized")

    async def add(
        self, content: str, metadata: dict[str, Any], embedding_model: str = "text-embedding-3"
    ) -> str:
        """Add content to vector store"""
        memory_id = f"mem_{uuid.uuid4().hex[:12]}"

        # Generate embedding (simulated - would use actual model)
        embedding = self._generate_embedding(content, embedding_model)

        # Store vector
        index = len(self.vectors)
        self.vectors.append(embedding)
        self.id_to_index[memory_id] = index

        # Store metadata
        memory_entry = MemoryEntry(
            memory_id=memory_id,
            memory_type=metadata.get("memory_type", MemoryType.WORKING),
            content=content,
            embedding=embedding,
            embedding_model=embedding_model,
            user_id=metadata.get("user_id"),
            session_id=metadata.get("session_id"),
            tags=metadata.get("tags", []),
            importance_score=metadata.get("importance_score", 0.5),
        )

        self.metadata[memory_id] = memory_entry

        # Update type index
        mem_type = memory_entry.memory_type
        if mem_type not in self.type_index:
            self.type_index[mem_type] = []
        self.type_index[mem_type].append(memory_id)

        # Update user index
        if memory_entry.user_id:
            if memory_entry.user_id not in self.user_index:
                self.user_index[memory_entry.user_id] = []
            self.user_index[memory_entry.user_id].append(memory_id)

        self._index_built = False  # Mark for rebuild
        return memory_id

    async def retrieve(
        self,
        query: str,
        top_k: int = 5,
        memory_types: list[MemoryType] | None = None,
        user_id: str | None = None,
        session_id: str | None = None,
        recency_weight: float = 0.3,
        importance_weight: float = 0.3,
    ) -> list[RetrievalResult]:
        """Retrieve relevant memories with scoring"""
        # Generate query embedding
        query_embedding = self._generate_embedding(query, self._embedding_model)

        # Search index
        candidates = self._search_index(query_embedding, top_k * 2)

        # Filter by constraints
        if memory_types:
            candidates = [
                c
                for c in candidates
                if c in self.metadata and self.metadata[c].memory_type in memory_types
            ]

        if user_id:
            candidates = [
                c for c in candidates if c in self.metadata and self.metadata[c].user_id == user_id
            ]

        if session_id:
            candidates = [
                c
                for c in candidates
                if c in self.metadata and self.metadata[c].session_id == session_id
            ]

        # Score and rank
        results = []
        for memory_id in candidates[:top_k]:
            memory = self.metadata.get(memory_id)
            if not memory:
                continue

            # Calculate relevance score (cosine similarity)
            similarity = self._cosine_similarity(query_embedding, memory.embedding)

            # Recency score (exponential decay)
            age_hours = (datetime.now(UTC) - memory.created_at).total_seconds() / 3600
            recency_score = 0.95 ** min(age_hours, 72)  # Decay over 72 hours

            # Importance score
            importance = memory.importance_score

            # Combined score with weights
            combined = (
                similarity * (1 - recency_weight - importance_weight)
                + recency_score * recency_weight
                + importance * importance_weight
            )

            results.append(
                RetrievalResult(
                    memory=memory,
                    relevance_score=similarity,
                    recency_score=recency_score,
                    importance_score=importance,
                    combined_score=combined,
                    match_type="semantic",
                    explanation=f"Semantic match with {similarity:.2f} relevance",
                )
            )

        # Sort by combined score
        results.sort(key=lambda x: x.combined_score, reverse=True)

        return results[:top_k]

    def _search_index(self, query_embedding: list[float], top_k: int) -> list[str]:
        """Search vector index (simplified - would use ANN)"""
        scores = []

        for memory_id, memory in self.metadata.items():
            if not memory.embedding:
                continue

            similarity = self._cosine_similarity(query_embedding, memory.embedding)
            scores.append((memory_id, similarity))

        # Sort by score and return IDs
        scores.sort(key=lambda x: x[1], reverse=True)
        return [s[0] for s in scores[:top_k]]

    def _generate_embedding(self, text: str, model: str) -> list[float]:
        """Generate embedding for text (simulated)"""
        # In production, would call actual embedding model
        # Simulated embedding based on text hash
        text_hash = hashlib.sha256(text.encode()).digest()
        embedding = [(b / 255.0) * 2 - 1 for b in text_hash * (self.dimension // 32 + 1)]
        return embedding[: self.dimension]

    def _cosine_similarity(self, a: list[float], b: list[float]) -> float:
        """Calculate cosine similarity between vectors"""
        dot_product = sum(x * y for x, y in zip(a, b, strict=False))
        magnitude_a = sum(x * x for x in a) ** 0.5
        magnitude_b = sum(x * x for x in b) ** 0.5

        if magnitude_a == 0 or magnitude_b == 0:
            return 0.0

        return dot_product / (magnitude_a * magnitude_b)

    def _delete_sync(self, memory_id: str):
        """Synchronous delete by memory ID."""
        if memory_id in self.id_to_index:
            index = self.id_to_index[memory_id]
            self.vectors[index] = [0.0] * self.dimension  # Zero out
            del self.id_to_index[memory_id]

        if memory_id in self.metadata:
            memory = self.metadata[memory_id]
            # Remove from type index
            mem_type = memory.memory_type
            if mem_type in self.type_index:
                self.type_index[mem_type].remove(memory_id)

            # Remove from user index
            if memory.user_id in self.user_index:
                self.user_index[memory.user_id].remove(memory_id)

            del self.metadata[memory_id]

    async def delete(self, memory_id: str):
        """Delete memory by ID"""
        self._delete_sync(memory_id)

    async def get_by_type(self, memory_type: MemoryType, limit: int = 100) -> list[MemoryEntry]:
        """Get memories by type"""
        memory_ids = self.type_index.get(memory_type, [])
        results = []

        for memory_id in memory_ids[:limit]:
            memory = self.metadata.get(memory_id)
            if memory:
                results.append(memory)

        return results


class SessionMemory:
    """
    Session-based working memory
    Manages context within a single session
    """

    def __init__(self, max_size_tokens: int = 128000):
        self.max_size_tokens = max_size_tokens
        self.sessions: dict[str, dict] = {}
        logger.info(f"SessionMemory initialized: max_tokens={max_size_tokens}")

    def create_session(self, session_id: str, user_id: str, config: dict | None = None) -> dict:
        """Create new session"""
        session = {
            "session_id": session_id,
            "user_id": user_id,
            "created_at": datetime.now(UTC),
            "last_activity": datetime.now(UTC),
            "messages": [],
            "context": {},
            "memory_refs": [],
            "config": config or {},
            "state": {
                "task_queue": [],
                "completed_tasks": [],
                "active_goals": [],
                "constraints": {},
            },
        }

        self.sessions[session_id] = session
        return session

    def get_session(self, session_id: str) -> dict | None:
        """Get session by ID"""
        session = self.sessions.get(session_id)
        if session:
            session["last_activity"] = datetime.now(UTC)
        return session

    def add_message(self, session_id: str, role: str, content: str, metadata: dict | None = None):
        """Add message to session history"""
        session = self.get_session(session_id)
        if not session:
            return

        message = {
            "message_id": str(uuid.uuid4()),
            "role": role,
            "content": content,
            "timestamp": datetime.now(UTC).isoformat(),
            "metadata": metadata or {},
        }

        session["messages"].append(message)

        # Update context window
        self._update_context_window(session)

    def _update_context_window(self, session: dict):
        """Update context window with size management"""
        # Calculate total tokens (simplified)
        total_tokens = sum(len(m["content"].split()) * 1.3 for m in session["messages"])

        # If over limit, compress oldest messages
        while total_tokens > self.max_size_tokens and len(session["messages"]) > 2:
            removed = session["messages"].pop(0)
            total_tokens -= len(removed["content"].split()) * 1.3

        session["context"]["total_tokens"] = int(total_tokens)

    def get_recent_messages(self, session_id: str, count: int = 10) -> list[dict]:
        """Get recent messages from session"""
        session = self.get_session(session_id)
        if not session:
            return []

        return session["messages"][-count:]

    def update_context(self, session_id: str, key: str, value: Any):
        """Update session context"""
        session = self.get_session(session_id)
        if not session:
            return

        session["context"][key] = value
        session["last_activity"] = datetime.now(UTC)

    def add_memory_ref(self, session_id: str, memory_id: str, context: str):
        """Add memory reference to session"""
        session = self.get_session(session_id)
        if not session:
            return

        ref = {
            "memory_id": memory_id,
            "context": context,
            "added_at": datetime.now(UTC).isoformat(),
        }

        session["memory_refs"].append(ref)

    def get_context_for_task(self, session_id: str, task_description: str | None = None) -> dict:
        """Get optimized context for task"""
        session = self.get_session(session_id)
        if not session:
            return {}

        # Get recent messages
        recent = self.get_recent_messages(session_id, 10)

        # Build context
        context = {
            "session_id": session_id,
            "user_id": session["user_id"],
            "recent_messages": recent,
            "memory_refs": session["memory_refs"],
            "config": session["config"],
            "task_context": task_description,
        }

        return context

    def cleanup_old_sessions(self, max_age_hours: int = 24):
        """Remove old inactive sessions"""
        now = datetime.now(UTC)
        to_remove = []

        for session_id, session in self.sessions.items():
            inactive = (now - session["last_activity"]).total_seconds() / 3600
            if inactive > max_age_hours:
                to_remove.append(session_id)

        for session_id in to_remove:
            del self.sessions[session_id]

        logger.info(f"Cleaned up {len(to_remove)} old sessions")


class MemoryRetrievalPipeline:
    """
    Multi-stage memory retrieval pipeline
    Combines vector search, symbolic retrieval, and context compression
    """

    def __init__(self, vector_store: VectorStore, session_memory: SessionMemory):
        self.vector_store = vector_store
        self.session_memory = session_memory
        self.recency_weight = 0.25
        self.importance_weight = 0.25
        self.relevance_threshold = 0.5

    async def retrieve(
        self,
        query: str,
        session_id: str,
        top_k: int = 10,
        memory_types: list[MemoryType] | None = None,
    ) -> ContextWindow:
        """Execute full retrieval pipeline"""
        # Stage 1: Vector search
        vector_results = await self.vector_store.retrieve(
            query=query, top_k=top_k * 2, memory_types=memory_types
        )

        # Stage 2: Semantic re-ranking
        reranked = await self._rerank_results(query, vector_results)

        # Stage 3: Recency filter
        filtered = self._filter_by_recency(reranked)

        # Stage 4: Relevance threshold
        relevant = [r for r in filtered if r.combined_score >= self.relevance_threshold]

        # Stage 5: Merge with session memory
        session_context = self.session_memory.get_context_for_task(session_id, query)
        merged = await self._merge_context(relevant, session_context)

        # Stage 6: Compress context
        compressed = self._compress_context(merged, max_tokens=32000)

        # Update access counts
        for result in relevant[:top_k]:
            result.memory.access_count += 1
            result.memory.last_accessed_at = datetime.now(UTC)

        return compressed

    async def _rerank_results(
        self, query: str, results: list[RetrievalResult]
    ) -> list[RetrievalResult]:
        """Re-rank results using cross-encoder model (simulated)"""
        # In production, would use cross-encoder for re-ranking
        query_terms = set(query.lower().split())

        for result in results:
            content_terms = set(result.memory.content.lower().split())
            term_overlap = len(query_terms & content_terms)

            # Boost if significant term overlap
            if term_overlap > 0:
                result.combined_score *= 1 + term_overlap * 0.1

        results.sort(key=lambda x: x.combined_score, reverse=True)
        return results

    def _filter_by_recency(
        self, results: list[RetrievalResult], max_age_hours: int = 168
    ) -> list[RetrievalResult]:
        """Filter out very old results"""
        now = datetime.now(UTC)
        filtered = []

        for result in results:
            age_hours = (now - result.memory.last_accessed_at).total_seconds() / 3600
            if age_hours < max_age_hours:
                filtered.append(result)

        return filtered

    async def _merge_context(
        self, vector_results: list[RetrievalResult], session_context
    ) -> list[MemoryEntry]:
        """Merge vector results with session context.

        Accepts either a session_id string or a context dict with
        'recent_messages', 'user_id', and 'session_id' keys.
        """
        entries = [r.memory for r in vector_results]

        if isinstance(session_context, str):
            session_id = session_context
            recent_messages = self.session_memory.get_recent_messages(session_id, 10)
            sess = self.session_memory.get_session(session_id) or {}
            user_id = sess.get("user_id")
        else:
            ctx = session_context or {}
            recent_messages = ctx.get("recent_messages", [])
            session_id = ctx.get("session_id")
            user_id = ctx.get("user_id")

        for msg in recent_messages[-5:]:
            entries.append(
                MemoryEntry(
                    memory_id=msg["message_id"],
                    memory_type=MemoryType.WORKING,
                    content=f"[{msg['role']}]: {msg['content']}",
                    embedding=[],
                    user_id=user_id,
                    session_id=session_id,
                    importance_score=0.7,
                )
            )

        return entries

    def _compress_context(
        self, entries: list[MemoryEntry], max_tokens: int = 32000
    ) -> ContextWindow:
        """Compress context to fit within token budget"""
        if not entries:
            return ContextWindow(
                entries=[], total_tokens=0, compression_ratio=1.0, coverage_percentage=0.0
            )

        # Calculate total tokens
        total_tokens = sum(len(e.content.split()) * 1.3 for e in entries)

        if total_tokens <= max_tokens:
            return ContextWindow(
                entries=entries,
                total_tokens=int(total_tokens),
                compression_ratio=1.0,
                coverage_percentage=100.0,
            )

        # Compress by keeping high-scoring entries
        compressed = []
        current_tokens = 0

        # Sort by importance and recency
        scored = [
            (e, e.importance_score * 0.7 + (1 if not e.is_compressed else 0) * 0.3) for e in entries
        ]
        scored.sort(key=lambda x: x[1], reverse=True)

        for entry, _score in scored:
            entry_tokens = len(entry.content.split()) * 1.3
            if current_tokens + entry_tokens <= max_tokens:
                compressed.append(entry)
                current_tokens += entry_tokens
            else:
                break

        compression_ratio = total_tokens / max_tokens if max_tokens > 0 else 1.0

        return ContextWindow(
            entries=compressed,
            total_tokens=int(current_tokens),
            compression_ratio=compression_ratio,
            coverage_percentage=len(compressed) / len(entries) * 100,
        )


class MemoryManager:
    """
    Unified memory manager
    Coordinates all memory subsystems
    """

    def __init__(self):
        self.vector_store = VectorStore()
        self.session_memory = SessionMemory()
        self.retrieval_pipeline = MemoryRetrievalPipeline(self.vector_store, self.session_memory)
        self._initialized = False

    async def initialize(self):
        """Initialize memory system"""
        await self.vector_store.initialize()
        self._initialized = True
        logger.info("Memory system initialized")

    async def store(
        self,
        content: str,
        memory_type: MemoryType,
        session_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs,
    ) -> str:
        """Store content in appropriate memory tier"""
        if not self._initialized:
            await self.initialize()

        meta = dict(metadata or {})
        meta["memory_type"] = memory_type
        if session_id:
            meta.setdefault("session_id", session_id)

        memory_id = await self.vector_store.add(content=content, metadata=meta)

        # Update session memory if applicable
        sid = session_id or meta.get("session_id")
        if sid:
            self.session_memory.add_memory_ref(sid, memory_id, content[:200])

        return memory_id

    async def retrieve(
        self,
        query: str,
        session_id: str,
        top_k: int = 10,
        memory_types: list[MemoryType] | None = None,
    ) -> ContextWindow:
        """Retrieve relevant context"""
        if not self._initialized:
            await self.initialize()

        return await self.retrieval_pipeline.retrieve(
            query=query, session_id=session_id, top_k=top_k, memory_types=memory_types
        )

    def create_session(self, session_id: str, user_id: str) -> dict:
        """Create new session"""
        return self.session_memory.create_session(session_id, user_id)

    def get_session(self, session_id: str) -> dict | None:
        """Get session"""
        return self.session_memory.get_session(session_id)

    def clear_session(self, session_id: str):
        """Clear session data (synchronous)."""
        session = self.get_session(session_id)
        if session:
            # Remove associated memories
            memory_ids = [ref["memory_id"] for ref in session.get("memory_refs", [])]
            for memory_id in memory_ids:
                self.vector_store._delete_sync(memory_id)

            # Clear session
            self.session_memory.sessions.pop(session_id, None)


# =============================================================================
# MAIN TEST
# =============================================================================


async def main():
    """Test memory system"""
    memory = MemoryManager()
    await memory.initialize()

    # Create session
    session = memory.create_session("session_001", "user_001")
    print(f"Created session: {session['session_id']}")

    # Store memories
    memories = [
        ("Python is a great programming language", {"tags": ["programming", "python"]}),
        ("The user prefers concise responses", {"tags": ["preference", "style"]}),
        ("Previous task was about data analysis", {"tags": ["task", "analysis"]}),
    ]

    for content, meta in memories:
        memory_id = await memory.store(
            content=content,
            memory_type=MemoryType.SEMANTIC,
            metadata={**meta, "session_id": "session_001", "user_id": "user_001"},
        )
        print(f"Stored memory: {memory_id}")

    # Add session message
    memory.session_memory.add_message("session_001", "user", "I need help with Python programming")
    memory.session_memory.add_message(
        "session_001", "assistant", "I'll help you with Python. What specific topic?"
    )

    # Retrieve
    context = await memory.retrieve(
        query="programming Python help", session_id="session_001", top_k=5
    )

    print("\nRetrieved context:")
    print(f"  Entries: {len(context.entries)}")
    print(f"  Total tokens: {context.total_tokens}")
    print(f"  Compression ratio: {context.compression_ratio:.2f}")
    print(f"  Coverage: {context.coverage_percentage:.1f}%")

    for entry in context.entries[:3]:
        print(f"\n  Memory: {entry.memory_id[:20]}...")
        print(f"  Content: {entry.content[:100]}...")
        print(f"  Importance: {entry.importance_score:.2f}")


if __name__ == "__main__":
    asyncio.run(main())
