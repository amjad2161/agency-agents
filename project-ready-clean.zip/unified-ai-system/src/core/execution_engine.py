"""
AI-OS Execution Engine
Sandboxed Execution with Security and Control
"""

import asyncio
import ipaddress
import logging
import subprocess
import tempfile
import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any, cast
from urllib.parse import urlparse

import httpx

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ExecutionMode(Enum):
    LIVE = "live"
    DRY_RUN = "dry_run"
    SIMULATION = "simulation"
    SANDBOX = "sandbox"


class RiskLevel(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ApprovalStatus(Enum):
    NOT_REQUIRED = "not_required"
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


@dataclass
class ExecutionAction:
    """Action to be executed"""

    action_id: str
    action_type: str  # api_call, code_execution, file_operation, db_write
    target: str  # endpoint, file path, etc.
    parameters: dict[str, Any]
    risk_level: RiskLevel = RiskLevel.LOW
    requires_approval: bool = False
    rollback_action: str | None = None


@dataclass
class ExecutionJob:
    """Execution job with full lifecycle"""

    job_id: str
    task_id: str
    actions: list[ExecutionAction]
    mode: ExecutionMode = ExecutionMode.LIVE

    # State
    status: str = "pending"  # pending, running, completed, failed, rolled_back
    current_action_index: int = 0
    executed_actions: list[dict] = field(default_factory=list)
    action_results: list[dict] = field(default_factory=list)

    # Risk assessment
    overall_risk: RiskLevel = RiskLevel.LOW
    approval_status: ApprovalStatus = ApprovalStatus.NOT_REQUIRED
    approved_by: str | None = None

    # Reasoning reliability metadata from Mythos-style gating
    reasoning_mode: str = "normal"  # normal, cautious, defer
    reasoning_confidence: float = 1.0
    reasoning_defer_reason: str | None = None

    # Timing
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC).replace(tzinfo=None))
    started_at: datetime | None = None
    completed_at: datetime | None = None

    # Error handling
    error: str | None = None
    rollback_executed: bool = False


@dataclass
class SandboxConfig:
    """Sandbox execution configuration"""

    memory_limit_mb: int = 512
    cpu_limit: float = 1.0
    timeout_seconds: int = 30
    network_enabled: bool = False
    filesystem_readonly: bool = False
    allowed_paths: list[str] = field(default_factory=list)
    disallowed_apis: list[str] = field(default_factory=list)


class SecurityScanner:
    """Security scanning for code and parameters"""

    # Dangerous patterns
    DANGEROUS_PATTERNS = [
        # File system operations
        r"rm\s+-rf",
        r"rmdir",
        r"del\s+/[fqs]",
        r"format\s+",
        # Network
        r"eval\s*\(",
        r"exec\s*\(",
        r"__import__",
        r"os\.system",
        r"subprocess.*shell\s*=\s*True",
        # Data exfiltration
        r"curl.*-T",
        r"wget.*--post-data",
        r"requests\.post.*auth",
        # Privilege escalation
        r"sudo",
        r"chmod\s+777",
        r"setfacl",
    ]

    # Suspicious domains
    SUSPICIOUS_DOMAINS = ["evil.com", "malware.net", "phishing.com"]

    def scan_code(self, code: str) -> dict[str, Any]:
        """Scan code for security issues"""
        import re

        findings = []
        severity = "none"

        for pattern in self.DANGEROUS_PATTERNS:
            matches = re.findall(pattern, code, re.IGNORECASE)
            if matches:
                findings.append(
                    {
                        "type": "dangerous_pattern",
                        "pattern": pattern,
                        "matches": matches,
                        "severity": "high",
                    }
                )
                severity = "high"

        # Check for suspicious imports
        suspicious_imports = ["os", "sys", "subprocess", "socket"]
        for imp in suspicious_imports:
            if f"import {imp}" in code or f"from {imp} import" in code:
                findings.append({"type": "suspicious_import", "import": imp, "severity": "medium"})
                if severity != "high":
                    severity = "medium"

        return {"passed": len(findings) == 0, "findings": findings, "severity": severity}

    def scan_params(self, params: dict[str, Any]) -> dict[str, Any]:
        """Scan parameter *values* (recursively) for injection attempts.

        Walks dict/list/tuple structures and only applies regex to string
        leaves. This avoids false positives from Python's ``repr`` of a
        dict (which wraps strings in single quotes) triggering the
        SQL-injection pattern.
        """
        import re

        patterns = [
            ("sql_injection", r"(\bunion\s+select\b|\bor\s+1\s*=\s*1\b|--\s*$|/\*.*\*/)"),
            ("command_injection", r"[;&|`$]"),
            ("path_traversal", r"(\.\./|\.\.\\|%2e%2e)"),
            ("xss", r"(<script|</script|javascript:)"),
        ]
        findings: list[dict[str, Any]] = []

        def _scan_str(s: str, path: str) -> None:
            for name, pat in patterns:
                matches = re.findall(pat, s, re.IGNORECASE)
                if matches:
                    findings.append(
                        {
                            "type": name,
                            "matches": matches,
                            "severity": "high",
                            "path": path or "<root>",
                        }
                    )

        def _walk(val: Any, path: str) -> None:
            if isinstance(val, dict):
                for k, v in val.items():
                    _walk(v, f"{path}.{k}" if path else str(k))
            elif isinstance(val, (list, tuple)):
                for i, item in enumerate(val):
                    _walk(item, f"{path}[{i}]")
            elif isinstance(val, str):
                _scan_str(val, path)

        _walk(params, "")

        return {
            "passed": not findings,
            "findings": findings,
            "severity": "high" if findings else "none",
        }


class SandboxExecutor:
    """Sandboxed code execution environment"""

    def __init__(self, config: SandboxConfig | None = None):
        self.config = config or SandboxConfig()
        self.security_scanner = SecurityScanner()

    async def execute_code(
        self, code: str, language: str = "python", timeout_ms: int = 30000
    ) -> dict[str, Any]:
        """Execute code in sandbox"""
        # Security scan
        scan_result = self.security_scanner.scan_code(code)
        if not scan_result["passed"]:
            return {
                "success": False,
                "error": f"Security scan failed: {scan_result['findings']}",
                "scan_results": scan_result,
            }

        # Handle based on language
        if language == "python":
            return await self._execute_python(code, timeout_ms)
        elif language == "javascript":
            return await self._execute_javascript(code, timeout_ms)
        elif language == "bash":
            return await self._execute_bash(code, timeout_ms)
        else:
            return {"success": False, "error": f"Unsupported language: {language}"}

    async def _execute_python(self, code: str, timeout_ms: int) -> dict[str, Any]:
        """Execute Python code in sandbox"""
        return await asyncio.to_thread(self._run_python_code_blocking, code, timeout_ms)

    def _run_python_code_blocking(self, code: str, timeout_ms: int) -> dict[str, Any]:
        """Run Python code in a blocking worker thread."""
        start_time = time.time()
        # Write to temporary file
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(code)
            temp_path = f.name

        try:
            # Execute with resource limits (simplified)
            result = subprocess.run(
                ["python3", temp_path], capture_output=True, text=True, timeout=timeout_ms / 1000
            )

            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "exit_code": result.returncode,
                "execution_time_ms": int((time.time() - start_time) * 1000),
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "Execution timeout", "execution_time_ms": timeout_ms}
        except Exception as e:
            return {"success": False, "error": str(e)}
        finally:
            # Clean up
            import os

            os.unlink(temp_path)

    async def _execute_javascript(self, code: str, timeout_ms: int) -> dict[str, Any]:
        """Execute JavaScript code in sandbox"""
        return await asyncio.to_thread(self._run_javascript_code_blocking, code, timeout_ms)

    def _run_javascript_code_blocking(self, code: str, timeout_ms: int) -> dict[str, Any]:
        """Run JavaScript code in a blocking worker thread."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".js", delete=False) as f:
            f.write(code)
            temp_path = f.name

        try:
            result = subprocess.run(
                ["node", temp_path], capture_output=True, text=True, timeout=timeout_ms / 1000
            )

            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "exit_code": result.returncode,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
        finally:
            import os

            os.unlink(temp_path)

    async def _execute_bash(self, code: str, timeout_ms: int) -> dict[str, Any]:
        """Execute bash script in sandbox"""
        return await asyncio.to_thread(self._run_bash_code_blocking, code, timeout_ms)

    def _run_bash_code_blocking(self, code: str, timeout_ms: int) -> dict[str, Any]:
        """Run bash code in a blocking worker thread."""
        # Additional security for bash
        scan = self.security_scanner.scan_code(code)
        if not scan["passed"]:
            return {"success": False, "error": "Dangerous bash patterns detected"}

        try:
            result = subprocess.run(
                ["bash", "-c", code], capture_output=True, text=True, timeout=timeout_ms / 1000
            )

            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "exit_code": result.returncode,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}


class ExecutionEngine:
    """
    Central execution engine
    Handles action planning, execution, and rollback
    """

    def __init__(self):
        self.sandbox = SandboxExecutor()
        self.security_scanner = SecurityScanner()
        self.execution_history: list[ExecutionJob] = []

        # Approval callbacks
        self.approval_callback: Callable | None = None

    def _complete_job(
        self, job: ExecutionJob, status: str, error: str | None = None
    ) -> ExecutionJob:
        """Finalize a job with terminal status and persist it to history."""
        job.status = status
        job.error = error
        job.completed_at = datetime.now(UTC).replace(tzinfo=None)
        self.execution_history.append(job)
        return job

    def _normalize_reasoning_mode(self, job: ExecutionJob) -> ExecutionJob | None:
        """Normalize and validate the requested reasoning mode."""
        valid_modes = {"normal", "cautious", "defer"}
        normalized_mode = str(job.reasoning_mode or "normal").lower().strip()
        if normalized_mode not in valid_modes:
            return self._complete_job(
                job, "rejected", f"Invalid reasoning_mode: {job.reasoning_mode}"
            )

        job.reasoning_mode = normalized_mode
        if job.reasoning_mode == "defer":
            return self._complete_job(
                job,
                "rejected",
                job.reasoning_defer_reason or "Deferred by reasoning reliability gate",
            )

        if job.reasoning_mode == "cautious":
            logger.warning(
                "Cautious execution mode enabled for job %s (confidence=%.2f)",
                job.job_id,
                job.reasoning_confidence,
            )

        return None

    def _needs_approval(self, job: ExecutionJob) -> bool:
        """Determine whether this job should be gated on human approval."""
        return any(action.requires_approval for action in job.actions) or job.overall_risk in [
            RiskLevel.HIGH,
            RiskLevel.CRITICAL,
        ]

    async def _check_approval(
        self, job: ExecutionJob, user_context: dict | None
    ) -> ExecutionJob | None:
        """Run the approval gate and return a rejected job when approval is not granted."""
        if not self._needs_approval(job):
            job.approval_status = ApprovalStatus.APPROVED
            return None

        job.approval_status = ApprovalStatus.PENDING
        if self.approval_callback:
            approved = await self.approval_callback(job, user_context)
            if approved:
                job.approval_status = ApprovalStatus.APPROVED
                return None
            return self._complete_job(job, "rejected", "Approval denied")

        return self._complete_job(job, "rejected", "Approval required but no callback configured")

    async def _run_actions(self, job: ExecutionJob) -> None:
        """Execute all actions for a job until failure or completion."""
        for index, action in enumerate(job.actions):
            job.current_action_index = index
            try:
                result = await self._execute_action(action, job.mode)
            except Exception as error:
                job.status = "failed"
                job.error = str(error)
                return

            self._record_action_result(job, action, result)
            if not result.get("success", False):
                await self._handle_failed_action(job, action, result)
                return

    def _record_action_result(
        self, job: ExecutionJob, action: ExecutionAction, result: dict[str, Any]
    ) -> None:
        """Persist an action execution result on the job."""
        job.executed_actions.append(
            {
                "action_id": action.action_id,
                "executed_at": datetime.now(UTC).replace(tzinfo=None).isoformat(),
                "result": result,
            }
        )
        job.action_results.append(result)

    async def _handle_failed_action(
        self,
        job: ExecutionJob,
        action: ExecutionAction,
        result: dict[str, Any],
    ) -> None:
        """Rollback and mark a job failed after an action error."""
        if action.rollback_action:
            await self._execute_rollback(action, job)
        job.status = "failed"
        job.error = result.get("error", "Action failed")

    async def execute_job(
        self, job: ExecutionJob, user_context: dict | None = None
    ) -> ExecutionJob:
        """Execute full job with actions"""
        job.started_at = datetime.now(UTC).replace(tzinfo=None)
        job.status = "running"

        rejected_job = self._normalize_reasoning_mode(job)
        if rejected_job is not None:
            return rejected_job

        approval_failure = await self._check_approval(job, user_context)
        if approval_failure is not None:
            return approval_failure

        await self._run_actions(job)

        if job.status == "running":
            job.status = "completed"

        return self._complete_job(job, job.status, job.error)

    async def _execute_action(self, action: ExecutionAction, mode: ExecutionMode) -> dict[str, Any]:
        """Execute single action"""
        # Handle different action types
        if action.action_type == "code_execution":
            return await self._execute_code_action(action, mode)
        elif action.action_type == "api_call":
            return await self._execute_api_action(action, mode)
        elif action.action_type == "file_operation":
            return await self._execute_file_action(action, mode)
        else:
            return {"success": False, "error": f"Unknown action type: {action.action_type}"}

    async def _execute_code_action(
        self, action: ExecutionAction, mode: ExecutionMode
    ) -> dict[str, Any]:
        """Execute code action"""
        code = action.parameters.get("code", "")
        language = action.parameters.get("language", "python")
        timeout_ms = action.parameters.get("timeout_ms", 30000)

        if mode in [ExecutionMode.DRY_RUN, ExecutionMode.SIMULATION]:
            return {
                "success": True,
                "simulated": True,
                "would_execute": f"{language} code",
                "params_preview": {"code_length": len(code)},
            }

        result = await self.sandbox.execute_code(code, language, timeout_ms)
        if isinstance(result, dict):
            return cast(dict[str, Any], result)
        return {"success": False, "error": "Sandbox returned invalid response shape"}

    async def _execute_api_action(
        self, action: ExecutionAction, mode: ExecutionMode
    ) -> dict[str, Any]:
        """Execute API call action"""
        await asyncio.sleep(0)
        endpoint = action.parameters.get("endpoint", "")
        method = action.parameters.get("method", "GET")

        # Reject unsafe endpoints (SSRF guard) before any other processing
        if mode not in [ExecutionMode.DRY_RUN, ExecutionMode.SIMULATION]:
            if not self._is_safe_http_url(endpoint):
                return {"success": False, "error": "Unsafe HTTP endpoint"}

        # Security scan on parameters (endpoint already validated above via _is_safe_http_url)
        scan = self.security_scanner.scan_params(action.parameters)
        if not scan["passed"]:
            return {"success": False, "error": f"Parameter scan failed: {scan['findings']}"}

        if mode in [ExecutionMode.DRY_RUN, ExecutionMode.SIMULATION]:
            return {"success": True, "simulated": True, "would_call": endpoint, "method": method}

        headers = action.parameters.get("headers", {})
        body = action.parameters.get("body", {})
        query_params = action.parameters.get("params", {})
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.request(
                method, endpoint, headers=headers, json=body if body else None, params=query_params
            )
            content_type = response.headers.get("content-type", "")
            return {
                "success": True,
                "status_code": response.status_code,
                "response": (
                    response.json()
                    if content_type.startswith("application/json")
                    else response.text
                ),
            }

    @staticmethod
    def _is_safe_http_url(url: str) -> bool:
        parsed = urlparse(url)
        hostname = parsed.hostname
        if parsed.scheme not in {"http", "https"} or not hostname:
            return False

        lowered = hostname.lower()
        if lowered in {"localhost", "0.0.0.0"} or lowered.endswith(".local"):
            return False

        try:
            ip = ipaddress.ip_address(hostname)
        except ValueError:
            return True

        return not (
            ip.is_private
            or ip.is_loopback
            or ip.is_link_local
            or ip.is_multicast
            or ip.is_reserved
            or ip.is_unspecified
        )

    async def _execute_file_action(
        self, action: ExecutionAction, mode: ExecutionMode
    ) -> dict[str, Any]:
        """Execute file operation action"""
        await asyncio.sleep(0)
        operation = action.parameters.get("operation")
        path = action.parameters.get("path")
        content = action.parameters.get("content")

        if mode in [ExecutionMode.DRY_RUN, ExecutionMode.SIMULATION]:
            return {"success": True, "simulated": True, "would_do": f"{operation} on {path}"}

        if path is None:
            return {"success": False, "error": "Invalid file path"}

        safe_path = str(path)

        if operation in {"read", "write"}:
            return await asyncio.to_thread(
                self._run_file_operation_blocking, operation, safe_path, content
            )

        return {"success": False, "error": "Unknown operation"}

    def _run_file_operation_blocking(
        self,
        operation: Any,
        safe_path: str,
        content: Any,
    ) -> dict[str, Any]:
        """Run file read/write in a blocking worker thread."""
        import os

        if operation == "read":
            if os.path.exists(safe_path):
                with open(safe_path) as f:
                    return {"success": True, "content": f.read()}
            return {"success": False, "error": "File not found"}

        if operation == "write":
            if not isinstance(content, str):
                return {"success": False, "error": "Write operation requires string content"}
            with open(safe_path, "w") as f:
                f.write(content)
            return {"success": True}

        return {"success": False, "error": "Unknown operation"}

    async def _execute_rollback(self, action: ExecutionAction, job: ExecutionJob):
        """Execute rollback for failed action"""
        if action.rollback_action:
            rollback_job = ExecutionJob(
                job_id=f"rollback_{job.job_id}",
                task_id=job.task_id,
                actions=[
                    ExecutionAction(
                        action_id=f"rollback_{action.action_id}",
                        action_type=action.rollback_action,
                        target=action.target,
                        parameters=action.parameters,
                    )
                ],
            )
            await self.execute_job(rollback_job)
            job.rollback_executed = True

    async def create_job(
        self,
        task_id: str,
        actions: list[dict[str, Any]],
        reasoning_metadata: dict[str, Any] | None = None,
    ) -> ExecutionJob:
        """Create execution job from action specs."""
        await asyncio.sleep(0)
        execution_actions = []

        for action_spec in actions:
            action = ExecutionAction(
                action_id=str(uuid.uuid4()),
                action_type=action_spec["type"],
                target=action_spec.get("target", ""),
                parameters=action_spec.get("parameters", {}),
                risk_level=RiskLevel(action_spec.get("risk_level", "low")),
                requires_approval=action_spec.get("requires_approval", False),
                rollback_action=action_spec.get("rollback_action"),
            )
            execution_actions.append(action)

        # Calculate overall risk (explicit severity order)
        risk_order = {
            RiskLevel.LOW: 1,
            RiskLevel.MEDIUM: 2,
            RiskLevel.HIGH: 3,
            RiskLevel.CRITICAL: 4,
        }
        highest_risk = max(
            execution_actions, key=lambda action: risk_order[action.risk_level]
        ).risk_level

        reasoning_payload = reasoning_metadata or {}
        job = ExecutionJob(
            job_id=str(uuid.uuid4()),
            task_id=task_id,
            actions=execution_actions,
            overall_risk=highest_risk,
            reasoning_mode=reasoning_payload.get("execution_mode", "normal"),
            reasoning_confidence=float(reasoning_payload.get("confidence_score", 1.0)),
            reasoning_defer_reason=reasoning_payload.get("defer_reason"),
        )

        return job


# =============================================================================
# HUMAN-IN-THE-LOOP CONTROL
# =============================================================================


class ApprovalManager:
    """Manage human approval for high-risk actions"""

    def __init__(self):
        self.pending_approvals: dict[str, dict] = {}
        self.auto_approve_low_risk = True

    async def request_approval(self, job: ExecutionJob, user_context: dict | None) -> bool:
        """Request approval for execution"""
        await asyncio.sleep(0)
        approval_id = str(uuid.uuid4())

        # Create approval request
        request = {
            "approval_id": approval_id,
            "job_id": job.job_id,
            "task_id": job.task_id,
            "actions_count": len(job.actions),
            "overall_risk": job.overall_risk.value,
            "action_summaries": [
                {"type": a.action_type, "target": a.target, "risk": a.risk_level.value}
                for a in job.actions
            ],
            "requested_at": datetime.now(UTC).replace(tzinfo=None),
            "requested_by": user_context.get("user_id") if user_context else None,
        }

        self.pending_approvals[approval_id] = request

        # In production, would send notification to human
        # For now, simulate auto-approval for low risk
        if self.auto_approve_low_risk and job.overall_risk == RiskLevel.LOW:
            return True

        if user_context and user_context.get("auto_approve"):
            request["approved_by"] = user_context.get("user_id")
            request["approved_at"] = datetime.now(UTC).replace(tzinfo=None)
            return True

        # Wait for approval (simplified)
        return False

    def approve(self, approval_id: str, approver_id: str) -> bool:
        """Approve pending request"""
        if approval_id in self.pending_approvals:
            self.pending_approvals[approval_id]["approved_by"] = approver_id
            self.pending_approvals[approval_id]["approved_at"] = datetime.now(UTC).replace(
                tzinfo=None
            )
            return True
        return False

    def reject(self, approval_id: str, rejector_id: str, reason: str) -> bool:
        """Reject pending request"""
        if approval_id in self.pending_approvals:
            self.pending_approvals[approval_id]["rejected_by"] = rejector_id
            self.pending_approvals[approval_id]["rejected_at"] = datetime.now(UTC).replace(
                tzinfo=None
            )
            self.pending_approvals[approval_id]["rejection_reason"] = reason
            return True
        return False


# =============================================================================
# MULTI-TENANCY ISOLATION
# =============================================================================


class TenantIsolation:
    """Multi-tenant isolation and access control"""

    def __init__(self):
        self.tenants: dict[str, dict] = {}
        self.resources: dict[str, str] = {}  # resource_id -> tenant_id

    def create_tenant(self, tenant_id: str, config: dict) -> dict:
        """Create new tenant"""
        tenant = {
            "tenant_id": tenant_id,
            "name": config.get("name"),
            "tier": config.get("tier", "standard"),
            "quotas": {
                "max_tasks": config.get("max_tasks", 1000),
                "max_tokens": config.get("max_tokens", 1000000),
                "rate_limit": config.get("rate_limit", 100),
            },
            "features": config.get("features", []),
            "created_at": datetime.now(UTC).replace(tzinfo=None),
        }

        self.tenants[tenant_id] = tenant
        return tenant

    def get_tenant(self, tenant_id: str) -> dict | None:
        """Get tenant by ID"""
        return self.tenants.get(tenant_id)

    def check_access(self, tenant_id: str, resource_id: str) -> bool:
        """Check if tenant has access to resource"""
        if resource_id not in self.resources:
            return False
        return self.resources[resource_id] == tenant_id

    def allocate_resource(self, tenant_id: str, resource_id: str):
        """Allocate resource to tenant"""
        self.resources[resource_id] = tenant_id

    def get_tenant_usage(self, tenant_id: str) -> dict:
        """Get tenant usage metrics"""
        tenant = self.tenants.get(tenant_id)
        if not tenant:
            return {}

        allocated_resources = [r for r, t in self.resources.items() if t == tenant_id]

        return {
            "tenant_id": tenant_id,
            "resources_allocated": len(allocated_resources),
            "quotas": tenant["quotas"],
        }


# =============================================================================
# MAIN TEST
# =============================================================================


async def main():
    """Test execution engine"""
    engine = ExecutionEngine()

    # Create actions
    actions = [
        {
            "type": "code_execution",
            "target": "compute",
            "parameters": {"code": "print('Hello from sandbox')", "language": "python"},
            "risk_level": "low",
        },
        {
            "type": "api_call",
            "target": "https://api.example.com/data",
            "parameters": {"method": "GET"},
            "risk_level": "medium",
            "requires_approval": False,
        },
    ]

    # Create job
    job = await engine.create_job("task_001", actions)

    print(f"Created job: {job.job_id}")
    print(f"Actions: {len(job.actions)}")
    print(f"Overall risk: {job.overall_risk.value}")

    # Execute (dry run)
    job.mode = ExecutionMode.DRY_RUN
    result = await engine.execute_job(job)

    print(f"Job status: {result.status}")
    print(f"Executed actions: {len(result.executed_actions)}")

    # Test security scanner
    scanner = SecurityScanner()
    dangerous_code = "import os; os.system('rm -rf /')"
    scan = scanner.scan_code(dangerous_code)
    print(f"Security scan: {scan['passed']}, severity: {scan['severity']}")


if __name__ == "__main__":
    asyncio.run(main())
