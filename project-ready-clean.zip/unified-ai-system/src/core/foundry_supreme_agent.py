"""Foundry-backed supreme agent wrapper.

Uses Microsoft Agent Framework when installed, and provides explicit runtime
errors if dependencies are missing.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

from dotenv import load_dotenv

load_dotenv(override=False)


@dataclass(frozen=True)
class FoundryAgentConfig:
    project_endpoint: str
    model_deployment_name: str
    name: str = "SupremeBrainiac"
    instructions: str = (
        "You are SupremeBrainiac, an autonomous but safe orchestrator. "
        "Prioritize correctness, deterministic planning, and explicit task state updates."
    )


class FoundrySupremeAgentFactory:
    """Builds a FoundryChatClient based agent lazily."""

    @staticmethod
    async def create_agent(config: FoundryAgentConfig):
        try:
            from agent_framework import Agent
            from azure.identity import DefaultAzureCredential
        except Exception as exc:  # pragma: no cover
            raise RuntimeError(
                "Microsoft Agent Framework dependencies are missing. "
                "Install requirements-agent-framework.txt first."
            ) from exc

        # Agent Framework package layouts differ across release trains.
        # Prefer the original Foundry client import when available, else
        # fallback to the Azure AI client available in rc-era packages.
        client_cls = None
        try:
            from agent_framework.foundry import FoundryChatClient as _ClientClass

            client_cls = _ClientClass
        except Exception:
            try:
                from agent_framework_azure_ai import AzureAIClient as _ClientClass

                client_cls = _ClientClass
            except Exception as exc:  # pragma: no cover
                raise RuntimeError(
                    "No compatible Foundry/Azure AI client was found in the installed "
                    "Agent Framework packages. Reinstall requirements-agent-framework.txt."
                ) from exc

        try:
            credential = DefaultAzureCredential()
        except ValueError:
            # Ignore malformed AZURE_* env placeholders and continue with other
            # credential sources (CLI, managed identity, etc.).
            credential = DefaultAzureCredential(exclude_environment_credential=True)
        try:
            client = client_cls(
                project_endpoint=config.project_endpoint,
                model_deployment_name=config.model_deployment_name,
                credential=credential,
            )
        except TypeError:
            client = client_cls(
                project_endpoint=config.project_endpoint,
                model=config.model_deployment_name,
                credential=credential,
            )

        # Caller controls lifecycle via async context manager.
        return Agent(
            client=client,
            name=config.name,
            instructions=config.instructions,
        )

    @staticmethod
    def from_env() -> FoundryAgentConfig:
        endpoint = os.getenv("FOUNDRY_PROJECT_ENDPOINT", "")
        deployment = os.getenv("FOUNDRY_MODEL_DEPLOYMENT_NAME", "")
        if not endpoint or not deployment:
            raise RuntimeError(
                "FOUNDRY_PROJECT_ENDPOINT and FOUNDRY_MODEL_DEPLOYMENT_NAME must be set"
            )

        return FoundryAgentConfig(
            project_endpoint=endpoint,
            model_deployment_name=deployment,
        )


async def run_one_prompt(prompt: str) -> dict[str, Any]:
    """Helper utility for local smoke testing of the Foundry agent path."""
    config = FoundrySupremeAgentFactory.from_env()
    agent = await FoundrySupremeAgentFactory.create_agent(config)
    async with agent:
        stream = agent.run(prompt, stream=True)
        chunks: list[str] = []
        async for chunk in stream:
            if getattr(chunk, "text", None):
                chunks.append(chunk.text)
        await stream.get_final_response()

    return {
        "model": config.model_deployment_name,
        "content": "".join(chunks).strip(),
    }
