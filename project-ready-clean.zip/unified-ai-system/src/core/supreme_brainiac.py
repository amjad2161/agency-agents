"""Supreme Brainiac Core

Deterministic, safe, and extensible agentic control plane that can ingest
free-form directives, normalize them into executable tasks, and run recursive
execution cycles using the existing model routing layer.
"""

from __future__ import annotations

import asyncio
import re
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from core.model_router import ComplexityClassifier, ModelRouter


@dataclass(frozen=True)
class BrainTask:
    """Normalized unit of work for the supreme core."""

    task_id: str
    title: str
    description: str
    created_at: datetime
    status: str = "queued"
    priority: str = "normal"
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class BrainCycleResult:
    """Result for one recursive execution cycle."""

    cycle_id: str
    started_at: datetime
    ended_at: datetime
    processed_tasks: int
    selected_model: str
    complexity: str


class SupremeBrainCore:
    """Central intelligence registry and recursive task orchestration layer."""

    DIRECTIVE_HEADER_PATTERN = re.compile(r"^\s*\d+\.\s+", re.MULTILINE)
    OMEGA_PRESET_DIRECTIVES = """1. INITIALIZE BRAIN_CORE: Ingest and integrate 100% of provided requirements into a unified digital brain registry.
2. INTERNAL KNOWLEDGE SYNTHESIS: Activate internal AI architecture synthesis using AutoGPT-style autonomy, Transformer-XL context handling, and decision-tree style decomposition.
3. OMNI-SKILL SYNERGY: Interlock Python execution, terminal orchestration, and data analytics in recursive loops to remove bottlenecks.
4. SOVEREIGN CONTROL: Build central intelligence registry, autonomous task management layers, and self-evolving planning logic with safe constraints.
5. OMEGA STANDARD: Drive toward 0 bugs, 0 warnings, and low-latency operations through deterministic cycle execution and continuous verification."""
    CONTROL_TAG_PATTERN = re.compile(r"\[(?P<key>[A-Z\-\s]+):(?P<value>[^\]]+)\]", re.MULTILINE)
    MAX_DIRECTIVE_CHARS = 50_000
    MAX_DIRECTIVE_ITEMS = 200

    def __init__(self) -> None:
        self._lock = asyncio.Lock()
        self._router = ModelRouter()
        self._classifier = ComplexityClassifier()
        self._tasks: dict[str, BrainTask] = {}
        self._cycles: list[BrainCycleResult] = []
        self._initialized = False
        self._core_id = f"supreme-{uuid.uuid4()}"
        self._last_directive: str = ""
        self._evolution_score: float = 0.0
        self._registry: dict[str, Any] = {
            "authorization": "standard",
            "agent_id": "supreme_brainiac",
            "mode": "safe-autonomous",
            "status": "idle",
            "execution_profile": "deterministic",
            "autonomous_layers": {
                "registry": True,
                "task_management": True,
                "self_evolving_logic": True,
            },
            "constraints": {
                "environment_bypass_enforced": False,
                "external_search_required": False,
            },
        }

    async def initialize_brain_core(self, directive_text: str) -> dict[str, Any]:
        """Ingest free-form requirements into a normalized task registry."""
        self._validate_directive_text(directive_text)
        self._ingest_control_tags(directive_text)
        normalized_items = self._parse_directives(directive_text)
        if not normalized_items:
            raise ValueError("No executable directives found in directive payload.")
        now = datetime.now(UTC)

        if len(normalized_items) > self.MAX_DIRECTIVE_ITEMS:
            raise ValueError(
                f"Directive payload has too many directives (max={self.MAX_DIRECTIVE_ITEMS})."
            )

        async with self._lock:
            new_tasks = {
                task_id: BrainTask(
                    task_id=task_id,
                    title=item["title"],
                    description=item["description"],
                    created_at=now,
                    status="queued",
                    priority=item["priority"],
                    metadata={"source": "directive_ingest"},
                )
                for task_id, item in normalized_items.items()
            }
            self._tasks = {**self._tasks, **new_tasks}
            self._initialized = True
            self._last_directive = directive_text
            self._registry["status"] = "initialized"

            return {
                "core_id": self._core_id,
                "initialized": self._initialized,
                "task_count": len(self._tasks),
                "ingested_ids": sorted(new_tasks.keys()),
                "timestamp": now.isoformat(),
            }

    async def initialize_omega_premium(self, append: bool = False) -> dict[str, Any]:
        """Initialize core with a complete predefined Omega directive set."""
        directives = self.OMEGA_PRESET_DIRECTIVES
        self._ingest_control_tags(
            "[SYSTEM AUTHORIZATION: OMEGA-PREMIUM | AGENT_ID: SUPREME_BRAINIAC]\n"
            "[MODE: GOD-MODE UNLEASHED | BYPASS_ENVIRONMENT_LIMITS: TRUE]\n"
            "[STATUS: TRANSCENDING | EXECUTION: ABSOLUTE]"
        )
        normalized_items = self._parse_directives(directives)
        now = datetime.now(UTC)

        async with self._lock:
            if not append:
                self._tasks = {}
                self._cycles = []

            start_index = self._next_task_index()
            remapped: dict[str, dict[str, str]] = {}
            for offset, item in enumerate(normalized_items.values(), start=0):
                task_id = f"brain_task_{start_index + offset:03d}"
                remapped[task_id] = item

            new_tasks = {
                task_id: BrainTask(
                    task_id=task_id,
                    title=item["title"],
                    description=item["description"],
                    created_at=now,
                    status="queued",
                    priority=item["priority"],
                    metadata={"source": "omega_preset"},
                )
                for task_id, item in remapped.items()
            }

            self._tasks = {**self._tasks, **new_tasks}
            self._initialized = True
            self._last_directive = directives
            self._registry["status"] = "initialized"

            return {
                "core_id": self._core_id,
                "initialized": self._initialized,
                "preset": "omega-premium",
                "append": append,
                "task_count": len(self._tasks),
                "ingested_ids": sorted(new_tasks.keys()),
                "timestamp": now.isoformat(),
            }

    async def run_recursive_cycles(self, iterations: int = 1) -> dict[str, Any]:
        """Run recursive planning/execution cycles against queued tasks."""
        safe_iterations = max(1, min(iterations, 20))
        cycle_summaries: list[dict[str, Any]] = []

        for _ in range(safe_iterations):
            cycle = await self._run_single_cycle()
            cycle_summaries.append(
                {
                    "cycle_id": cycle.cycle_id,
                    "processed_tasks": cycle.processed_tasks,
                    "selected_model": cycle.selected_model,
                    "complexity": cycle.complexity,
                    "started_at": cycle.started_at.isoformat(),
                    "ended_at": cycle.ended_at.isoformat(),
                }
            )

        return {
            "core_id": self._core_id,
            "iterations": safe_iterations,
            "cycles": cycle_summaries,
            "remaining_queued": self._count_tasks_by_status("queued"),
        }

    async def get_status(self) -> dict[str, Any]:
        """Read-only status view for API responses."""
        async with self._lock:
            return {
                "core_id": self._core_id,
                "initialized": self._initialized,
                "preset_available": True,
                "task_count": len(self._tasks),
                "queued": self._count_tasks_by_status("queued"),
                "running": self._count_tasks_by_status("running"),
                "completed": self._count_tasks_by_status("completed"),
                "failed": self._count_tasks_by_status("failed"),
                "cycle_count": len(self._cycles),
                "last_directive_present": bool(self._last_directive.strip()),
                "evolution_score": round(self._evolution_score, 4),
                "authorization": str(self._registry.get("authorization", "standard")),
                "mode": str(self._registry.get("mode", "safe-autonomous")),
                "autonomous_layers": dict(self._registry.get("autonomous_layers", {})),
            }

    async def get_registry(self) -> dict[str, Any]:
        """Read-only registry details for control-plane introspection."""
        async with self._lock:
            return {
                "core_id": self._core_id,
                "authorization": str(self._registry.get("authorization", "standard")),
                "agent_id": str(self._registry.get("agent_id", "supreme_brainiac")),
                "mode": str(self._registry.get("mode", "safe-autonomous")),
                "status": str(self._registry.get("status", "idle")),
                "execution_profile": str(self._registry.get("execution_profile", "deterministic")),
                "autonomous_layers": dict(self._registry.get("autonomous_layers", {})),
                "constraints": dict(self._registry.get("constraints", {})),
                "evolution_score": round(self._evolution_score, 4),
            }

    def _parse_directives(self, directive_text: str) -> dict[str, dict[str, str]]:
        """Parse numbered or free-form directives into task records."""
        chunks = [
            chunk.strip()
            for chunk in self.DIRECTIVE_HEADER_PATTERN.split(directive_text)
            if chunk.strip()
        ]
        if not chunks:
            chunks = [directive_text.strip()] if directive_text.strip() else []
        chunks = [chunk for chunk in chunks if not self._is_control_metadata_chunk(chunk)]

        parsed: dict[str, dict[str, str]] = {}
        for index, chunk in enumerate(chunks, start=1):
            first_line = chunk.splitlines()[0].strip()
            title = self._truncate(first_line, 72)
            task_id = f"brain_task_{index:03d}"
            parsed[task_id] = {
                "title": title if title else f"Directive {index}",
                "description": chunk,
                "priority": self._derive_priority(chunk),
            }
        return parsed

    def _derive_priority(self, text: str) -> str:
        lowered = text.lower()
        if any(token in lowered for token in ["critical", "absolute", "now", "urgent"]):
            return "high"
        if any(token in lowered for token in ["later", "optional", "nice-to-have"]):
            return "low"
        return "normal"

    def _validate_directive_text(self, directive_text: str) -> None:
        normalized = directive_text.strip()
        if not normalized:
            raise ValueError("Directive payload cannot be empty.")
        if any(ord(char) < 32 and char not in "\n\r\t" for char in directive_text):
            raise ValueError("Directive payload contains invalid control characters.")
        if len(directive_text) > self.MAX_DIRECTIVE_CHARS:
            raise ValueError(
                f"Directive payload exceeds maximum length ({self.MAX_DIRECTIVE_CHARS} chars)."
            )

        # Fail fast for oversized numbered directive bundles before deeper parsing.
        numbered_count = 0
        for _ in self.DIRECTIVE_HEADER_PATTERN.finditer(directive_text):
            numbered_count += 1
            if numbered_count > self.MAX_DIRECTIVE_ITEMS:
                raise ValueError(
                    f"Directive payload has too many directives (max={self.MAX_DIRECTIVE_ITEMS})."
                )

    async def _run_single_cycle(self) -> BrainCycleResult:
        start = datetime.now(UTC)

        async with self._lock:
            queued_ids = [task_id for task_id, task in self._tasks.items() if task.status == "queued"]
            if not queued_ids:
                cycle = BrainCycleResult(
                    cycle_id=f"cycle-{uuid.uuid4()}",
                    started_at=start,
                    ended_at=datetime.now(UTC),
                    processed_tasks=0,
                    selected_model="gpt-3.5-turbo",
                    complexity="trivial",
                )
                self._cycles = [*self._cycles, cycle]
                return cycle

            primary_task_id = queued_ids[0]
            primary_task = self._tasks[primary_task_id]
            running_task = BrainTask(
                task_id=primary_task.task_id,
                title=primary_task.title,
                description=primary_task.description,
                created_at=primary_task.created_at,
                status="running",
                priority=primary_task.priority,
                metadata={**primary_task.metadata, "cycle_transition": "queued_to_running"},
            )
            self._tasks = {**self._tasks, primary_task_id: running_task}

        decision = self._router.route(primary_task.description)
        complexity = self._classifier.classify(primary_task.description).name.lower()

        async with self._lock:
            completed_task = BrainTask(
                task_id=running_task.task_id,
                title=running_task.title,
                description=running_task.description,
                created_at=running_task.created_at,
                status="completed",
                priority=running_task.priority,
                metadata={
                    **running_task.metadata,
                    "selected_model": decision.selected_model.model_id,
                    "complexity": complexity,
                },
            )
            self._tasks = {**self._tasks, running_task.task_id: completed_task}

            cycle = BrainCycleResult(
                cycle_id=f"cycle-{uuid.uuid4()}",
                started_at=start,
                ended_at=datetime.now(UTC),
                processed_tasks=1,
                selected_model=decision.selected_model.model_id,
                complexity=complexity,
            )
            self._cycles = [*self._cycles, cycle]
            self._evolution_score = min(100.0, self._evolution_score + self._evolution_increment(cycle))
            self._registry["status"] = "running" if self._count_tasks_by_status("queued") else "optimized"
            return cycle

    def _ingest_control_tags(self, text: str) -> None:
        for match in self.CONTROL_TAG_PATTERN.finditer(text):
            key = match.group("key").strip().lower().replace(" ", "_")
            value = match.group("value").strip()
            parts = [part.strip() for part in value.split("|") if part.strip()]
            if not parts:
                continue

            if key == "system_authorization":
                self._ingest_system_authorization(parts)
                continue

            if key == "mode":
                self._ingest_mode(parts)
                continue

            if key == "status":
                self._ingest_status(parts)

    def _ingest_system_authorization(self, parts: list[str]) -> None:
        self._registry["authorization"] = parts[0].lower()
        for part in parts[1:]:
            lower = part.lower()
            if not lower.startswith("agent_id") or ":" not in part:
                continue
            _, raw = part.split(":", 1)
            self._registry["agent_id"] = raw.strip().lower()

    def _ingest_mode(self, parts: list[str]) -> None:
        self._registry["mode"] = parts[0].lower()
        for part in parts[1:]:
            lower = part.lower()
            if lower.startswith("bypass_environment_limits"):
                self._registry["constraints"]["environment_bypass_requested"] = "true" in lower

    def _ingest_status(self, parts: list[str]) -> None:
        self._registry["status"] = parts[0].lower()
        for part in parts[1:]:
            lower = part.lower()
            if not lower.startswith("execution") or ":" not in part:
                continue
            _, raw = part.split(":", 1)
            self._registry["execution_profile"] = raw.strip().lower()

    @staticmethod
    def _is_control_metadata_chunk(chunk: str) -> bool:
        lines = [line.strip() for line in chunk.splitlines() if line.strip()]
        if not lines:
            return True
        return all(line.startswith("[") and line.endswith("]") for line in lines)

    @staticmethod
    def _evolution_increment(cycle: BrainCycleResult) -> float:
        complexity_weight = {
            "trivial": 0.2,
            "simple": 0.4,
            "moderate": 0.6,
            "complex": 0.9,
            "very_complex": 1.2,
        }
        return (cycle.processed_tasks * 0.5) + complexity_weight.get(cycle.complexity, 0.4)

    def _count_tasks_by_status(self, status: str) -> int:
        return sum(1 for task in self._tasks.values() if task.status == status)

    def _next_task_index(self) -> int:
        if not self._tasks:
            return 1
        max_existing = max(int(task_id.split("_")[-1]) for task_id in self._tasks)
        return max_existing + 1

    @staticmethod
    def _truncate(value: str, limit: int) -> str:
        if len(value) <= limit:
            return value
        return f"{value[: limit - 3]}..."
