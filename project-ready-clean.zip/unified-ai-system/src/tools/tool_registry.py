"""
Tool Registry - Dynamic Tool Management System
Production-Grade Tool Discovery, Validation, and Execution
"""

import asyncio
import ipaddress
import json
import logging
import re
import subprocess
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from pathlib import Path
from typing import Any, cast
from urllib.parse import urlparse

import httpx

from config.settings import config
from core.lineage import append_tool_invocation, normalize_lineage
from core.lineage_repository import FileLineageRepository

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ToolCategory(Enum):
    """Tool category classifications"""

    WEB = "web"
    DATA = "data"
    COMPUTATION = "computation"
    MEDIA = "media"
    SYSTEM = "system"
    SECURITY = "security"
    CUSTOM = "custom"


class ToolStatus(Enum):
    """Tool availability status"""

    ACTIVE = "active"
    INACTIVE = "inactive"
    DEPRECATED = "deprecated"
    BETA = "beta"
    MAINTENANCE = "maintenance"


class ExecutionMode(Enum):
    """Tool execution modes"""

    LIVE = "live"
    DRY_RUN = "dry_run"
    SIMULATION = "simulation"
    SANDBOX = "sandbox"


@dataclass
class ToolSchema:
    """JSON Schema for tool input/output validation"""

    name: str
    description: str
    input_schema: dict[str, Any]
    output_schema: dict[str, Any]
    required_params: list[str] = field(default_factory=list)
    optional_params: list[str] = field(default_factory=list)
    examples: list[dict] = field(default_factory=list)


@dataclass
class ToolPermission:
    """Tool access permissions"""

    role: str
    tier: str  # standard, premium, enterprise
    rate_limit_per_minute: int = 100
    max_execution_time_ms: int = 60000
    requires_approval: bool = False
    approval_roles: list[str] = field(default_factory=list)


@dataclass
class Tool:
    """Tool definition with full metadata"""

    tool_id: str
    tool_name: str
    category: ToolCategory
    description: str
    version: str = "1.0.0"

    # Schema
    input_schema: dict[str, Any] = field(default_factory=dict)
    output_schema: dict[str, Any] = field(default_factory=dict)

    # Execution
    implementation_type: str = "function"  # function, api, script, docker, external
    implementation: Any | None = None
    implementation_url: str | None = None

    # Permissions
    permissions: list[ToolPermission] = field(default_factory=list)
    required_permissions: list[str] = field(default_factory=list)

    # Limits
    rate_limit_rpm: int = 100
    max_concurrent: int = 10
    timeout_seconds: int = 60

    # Cost
    cost_per_invocation: float = 0.0
    cost_currency: str = "USD"

    # Status
    status: ToolStatus = ToolStatus.ACTIVE
    security_level: str = "standard"  # standard, elevated, restricted

    # Metadata
    tags: list[str] = field(default_factory=list)
    capabilities: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)

    # Trust & Safety
    trust_score: float = 1.0
    success_rate: float = 1.0
    avg_execution_time_ms: int = 0

    # Observability
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    last_used_at: datetime | None = None
    usage_count: int = 0

    def can_execute(self, user_role: str, user_tier: str) -> bool:
        """Check if user can execute this tool"""
        for perm in self.permissions:
            if perm.role == user_role or perm.role == "*":
                if perm.tier == user_tier or perm.tier == "*":
                    return True
        return False


@dataclass
class ToolInvocation:
    """Tool execution tracking"""

    invocation_id: str
    tool_id: str
    user_id: str | None
    session_id: str | None
    task_id: str | None

    # Input
    params: dict[str, Any]

    # Output
    result: dict | None = None
    error: str | None = None

    # Execution
    execution_mode: ExecutionMode = ExecutionMode.LIVE
    status: str = "pending"  # pending, running, completed, failed, timeout
    started_at: datetime | None = None
    completed_at: datetime | None = None
    execution_time_ms: int = 0

    # Validation
    input_valid: bool = False
    output_valid: bool = False
    validation_errors: list[str] = field(default_factory=list)

    # Security
    risk_level: str = "low"  # low, medium, high, critical
    security_scan_passed: bool = True

    # Cost
    cost_incurred: float = 0.0
    tokens_used: int = 0

    # Trust
    trust_weight: float = 1.0
    confidence: float = 0.0
    lineage: dict[str, Any] = field(default_factory=dict)


class ToolRegistry:
    """
    Central Tool Registry
    Manages tool discovery, validation, execution, and lifecycle
    """

    def __init__(self, lineage_repository: FileLineageRepository | None = None):
        self.tools: dict[str, Tool] = {}
        self.categories: dict[ToolCategory, list[str]] = {}
        self.execution_history: list[ToolInvocation] = []
        self.lineage_repository = lineage_repository or FileLineageRepository(
            Path(config.storage_path) / "lineage"
        )

        # Rate limiting
        self.rate_limiters: dict[str, list[datetime]] = {}

        # Execution pools
        self.executor_pool: asyncio.Semaphore = asyncio.Semaphore(50)

        # Security
        self.security_scanner: Callable | None = None
        self.enforce_security_scanner: bool = True

        logger.info("Tool Registry initialized")

    def register_tool(self, tool: Tool):
        """Register a new tool"""
        self.tools[tool.tool_id] = tool

        # Update category index
        if tool.category not in self.categories:
            self.categories[tool.category] = []
        self.categories[tool.category].append(tool.tool_id)

        logger.info(f"Registered tool: {tool.tool_id} ({tool.tool_name})")

    def get_tool(self, tool_id: str) -> Tool | None:
        """Get tool by ID"""
        return self.tools.get(tool_id)

    def get_tool_by_name(self, name: str) -> Tool | None:
        """Get tool by name"""
        for tool in self.tools.values():
            if tool.tool_name == name:
                return tool
        return None

    def search_tools(
        self,
        query: str | None = None,
        category: ToolCategory | None = None,
        tags: list[str] | None = None,
        capabilities: list[str] | None = None,
    ) -> list[Tool]:
        """Search tools by various criteria"""
        results = list(self.tools.values())

        if query:
            results = [
                t
                for t in results
                if query.lower() in t.tool_name.lower() or query.lower() in t.description.lower()
            ]

        if category:
            results = [t for t in results if t.category == category]

        if tags:
            results = [t for t in results if any(tag in t.tags for tag in tags)]

        if capabilities:
            results = [t for t in results if any(cap in t.capabilities for cap in capabilities)]

        return results

    def get_tools_for_agent(self, agent_capabilities: list[str]) -> list[Tool]:
        """Get tools compatible with agent capabilities"""
        available = []

        for tool in self.tools.values():
            if tool.status != ToolStatus.ACTIVE:
                continue

            # Check if tool capabilities match agent
            if any(cap in tool.capabilities for cap in agent_capabilities):
                available.append(tool)

        return available

    async def execute_tool(  # noqa: C901
        self,
        tool_id: str,
        params: dict[str, Any],
        execution_context: dict[str, Any],
        mode: ExecutionMode = ExecutionMode.LIVE,
    ) -> ToolInvocation:
        """
        Execute tool with full lifecycle management
        1. Validate tool schema
        2. Check permissions
        3. Simulate (optional)
        4. Execute
        5. Validate output
        6. Log
        7. Return structured result
        """
        invocation = ToolInvocation(
            invocation_id=str(uuid.uuid4()),
            tool_id=tool_id,
            user_id=execution_context.get("user_id"),
            session_id=execution_context.get("session_id"),
            task_id=execution_context.get("task_id"),
            params=params,
            execution_mode=mode,
        )
        invocation.lineage = append_tool_invocation(
            normalize_lineage(
                raw_lineage=execution_context.get("_lineage"),
                trace_id=execution_context.get("trace_id"),
                session_id=execution_context.get("session_id"),
                parent_task_id=execution_context.get("task_id"),
                source=execution_context.get("lineage_source", "tool_execution"),
                input_payload=params,
            ),
            invocation.invocation_id,
        )

        tool = self.get_tool(tool_id)
        if not tool:
            invocation.error = f"Tool not found: {tool_id}"
            invocation.status = "failed"
            return invocation

        invocation.started_at = datetime.now(UTC)
        invocation.status = "running"

        try:
            # Step 1: Schema validation
            schema_valid, schema_errors = self._validate_input_schema(params, tool.input_schema)
            if not schema_valid:
                invocation.validation_errors = schema_errors
                invocation.input_valid = False
                invocation.error = f"Input validation failed: {schema_errors}"
                invocation.status = "failed"
                return invocation

            invocation.input_valid = True

            # Step 2: Permission check
            user_role = execution_context.get("user_role", "standard")
            user_tier = execution_context.get("user_tier", "standard")

            if not tool.can_execute(user_role, user_tier):
                invocation.error = "Insufficient permissions"
                invocation.status = "failed"
                return invocation

            # Step 3: Rate limit check
            if not self._check_rate_limit(tool_id, user_role):
                invocation.error = "Rate limit exceeded"
                invocation.status = "failed"
                return invocation

            # Step 4: Dry run / simulation mode
            if mode in [ExecutionMode.DRY_RUN, ExecutionMode.SIMULATION]:
                invocation.result = {
                    "simulated": True,
                    "would_execute": tool.tool_name,
                    "params_preview": self._mask_sensitive_params(params),
                }
                invocation.status = "completed"
                return invocation

            # Step 5: Explicitly block known stub tools in live execution.
            if tool.status == ToolStatus.BETA and "stub" in tool.tags:
                invocation.error = (
                    f"Tool '{tool.tool_name}' is a stub and cannot execute in live mode"
                )
                invocation.status = "failed"
                return invocation

            # Step 6: Security scan (if configured)
            scan_result = await self._run_security_scan(params, tool)
            if not scan_result["passed"]:
                invocation.security_scan_passed = False
                invocation.risk_level = scan_result.get("risk_level", "high")
                invocation.error = f"Security scan failed: {scan_result.get('reason')}"
                invocation.status = "failed"
                return invocation

            # Step 7: Execute tool

            async with self.executor_pool:
                result = await self._execute_tool_impl(tool, params, execution_context)
                invocation.result = result

            # Step 7: Output validation
            output_valid, output_errors = self._validate_output_schema(
                invocation.result, tool.output_schema
            )
            invocation.output_valid = output_valid
            invocation.validation_errors.extend(output_errors)

            # Calculate trust metrics
            invocation.confidence = self._calculate_confidence(invocation)
            invocation.trust_weight = tool.trust_score

            invocation.status = "completed"
            tool.usage_count += 1
            tool.last_used_at = datetime.now(UTC)

        except TimeoutError:
            invocation.status = "timeout"
            invocation.error = "Execution timeout"
        except Exception as e:
            invocation.status = "failed"
            invocation.error = str(e)
            logger.error(f"Tool execution error: {e}")

        finally:
            invocation.completed_at = datetime.now(UTC)
            invocation.execution_time_ms = int(
                (invocation.completed_at - invocation.started_at).total_seconds() * 1000
            )
            invocation.cost_incurred = tool.cost_per_invocation

            # Store in history
            self.execution_history.append(invocation)
            self.lineage_repository.persist_tool_invocation(invocation)

            # Update tool metrics
            if tool.usage_count > 0:
                tool.avg_execution_time_ms = int(
                    (
                        tool.avg_execution_time_ms * (tool.usage_count - 1)
                        + invocation.execution_time_ms
                    )
                    / tool.usage_count
                )
                if invocation.status == "completed":
                    tool.success_rate = (
                        tool.success_rate * (tool.usage_count - 1) + 1
                    ) / tool.usage_count
                else:
                    tool.success_rate = (
                        tool.success_rate * (tool.usage_count - 1)
                    ) / tool.usage_count

        return invocation

    async def _execute_tool_impl(
        self, tool: Tool, params: dict[str, Any], context: dict[str, Any]
    ) -> dict[str, Any]:
        """Execute tool implementation"""
        if tool.implementation_type == "function" and tool.implementation:
            impl_result = tool.implementation(params, context)
            if asyncio.iscoroutine(impl_result) or isinstance(impl_result, Awaitable):
                resolved = await impl_result
            else:
                resolved = impl_result
            if isinstance(resolved, dict):
                return cast(dict[str, Any], resolved)
            raise TypeError("Tool implementation must return a dict")
        elif tool.implementation_type == "api":
            resolved = await self._execute_api_tool(tool, params, context)
            if resolved.get("status") == "error":
                raise RuntimeError(str(resolved.get("error", "API tool execution failed")))
            return cast(dict[str, Any], resolved)
        elif tool.implementation_type == "docker":
            resolved = await self._execute_docker_tool(tool, params, context)
            if resolved.get("status") == "error":
                raise RuntimeError(str(resolved.get("error", "Docker tool execution failed")))
            return cast(dict[str, Any], resolved)
        else:
            raise NotImplementedError(
                f"Implementation type {tool.implementation_type} not supported"
            )

    async def _execute_api_tool(
        self, _tool: Tool, _params: dict[str, Any], _context: dict[str, Any]
    ) -> dict[str, Any]:
        """Execute external API tool"""
        url = _tool.implementation_url or ""
        if not url or not self._is_safe_http_url(url):
            return {"status": "error", "error": "Invalid or unsafe HTTP URL"}

        method = str(_params.get("method", "POST")).upper()
        headers = _params.get("headers", {})
        body = _params.get("body")
        query_params = _params.get("params")
        request_body = (
            body
            if body is not None
            else {
                key: value
                for key, value in _params.items()
                if key not in {"method", "headers", "body", "params"}
            }
        )

        try:
            async with httpx.AsyncClient(timeout=min(max(_tool.timeout_seconds, 1), 300)) as client:
                response = await client.request(
                    method,
                    url,
                    headers=headers if isinstance(headers, dict) else {},
                    json=request_body if method not in {"GET", "DELETE"} else None,
                    params=query_params if isinstance(query_params, dict) else None,
                )
        except httpx.HTTPError as exc:
            return {"status": "error", "error": f"HTTP request failed: {exc}"}

        content_type = response.headers.get("content-type", "")
        parsed_payload: Any
        if content_type.startswith("application/json"):
            try:
                parsed_payload = response.json()
            except ValueError:
                parsed_payload = response.text
        else:
            parsed_payload = response.text

        if response.status_code >= 400:
            return {
                "status": "error",
                "error": f"HTTP {response.status_code}",
                "data": parsed_payload,
            }

        return {
            "status": "success",
            "status_code": response.status_code,
            "data": parsed_payload,
        }

    async def _execute_docker_tool(
        self, _tool: Tool, _params: dict[str, Any], _context: dict[str, Any]
    ) -> dict[str, Any]:
        """Execute Docker container tool"""
        image = _tool.implementation_url or "ubuntu"
        if not self._is_safe_container_image(image):
            return {"status": "error", "error": "Invalid Docker image reference"}

        command = _params.get("command")
        command_args = _params.get("args", [])
        if command is not None and not isinstance(command, str):
            return {"status": "error", "error": "Docker command must be a string"}
        if not isinstance(command_args, list) or not all(
            isinstance(arg, str) for arg in command_args
        ):
            return {"status": "error", "error": "Docker args must be a list of strings"}

        cmd = ["docker", "run", "--rm", "-i", image]
        if isinstance(command, str):
            cmd.extend([command, *command_args])

        stdin_payload = json.dumps(_params.get("input", _params))
        result = await asyncio.to_thread(
            subprocess.run,
            cmd,
            input=stdin_payload,
            capture_output=True,
            text=True,
            timeout=min(max(_tool.timeout_seconds, 1), 300),
        )

        stdout = result.stdout.strip()
        parsed_stdout: Any = stdout
        if stdout:
            try:
                parsed_stdout = json.loads(stdout)
            except json.JSONDecodeError:
                parsed_stdout = stdout

        return {
            "status": "success" if result.returncode == 0 else "error",
            "data": parsed_stdout,
            "stderr": result.stderr[:1000],
        }

    @staticmethod
    def _is_safe_http_url(url: str) -> bool:
        if not ToolRegistry._is_valid_uri(url):
            return False

        parsed = urlparse(url)
        hostname = parsed.hostname
        if parsed.scheme not in {"http", "https"} or not hostname:
            return False

        lowered = hostname.lower()
        if lowered in {"localhost", "0.0.0.0"} or lowered.endswith(".local"):
            return False

        try:
            ip = ipaddress.ip_address(hostname)
        except ValueError:
            return True

        return not (
            ip.is_private
            or ip.is_loopback
            or ip.is_link_local
            or ip.is_multicast
            or ip.is_reserved
            or ip.is_unspecified
        )

    @staticmethod
    def _is_safe_container_image(image: str) -> bool:
        return bool(re.fullmatch(r"[A-Za-z0-9._/@:-]+", image)) and not any(
            char.isspace() for char in image
        )

    @staticmethod
    def _validate_param_type(
        param_name: str, param_type: str | None, param_value: Any
    ) -> str | None:
        """Validate a parameter type from JSON schema and return error text if invalid."""
        if param_type == "string" and not isinstance(param_value, str):
            return f"Parameter {param_name} must be string"
        if param_type == "number" and not isinstance(param_value, (int, float)):
            return f"Parameter {param_name} must be number"
        if param_type == "boolean" and not isinstance(param_value, bool):
            return f"Parameter {param_name} must be boolean"
        if param_type == "array" and not isinstance(param_value, list):
            return f"Parameter {param_name} must be array"
        if param_type == "object" and not isinstance(param_value, dict):
            return f"Parameter {param_name} must be object"
        return None

    def _validate_param_format(
        self, param_name: str, param_format: str | None, param_value: Any
    ) -> str | None:
        """Validate a parameter format from JSON schema and return error text if invalid."""
        if (
            param_format == "email"
            and isinstance(param_value, str)
            and not self._is_valid_email(param_value)
        ):
            return f"Parameter {param_name} must be valid email"
        if (
            param_format == "uri"
            and isinstance(param_value, str)
            and not self._is_valid_uri(param_value)
        ):
            return f"Parameter {param_name} must be valid URI"
        return None

    def _validate_input_schema(
        self, params: dict[str, Any], schema: dict[str, Any]
    ) -> tuple[bool, list[str]]:
        """Validate input against schema"""
        errors = []

        required_params = schema.get("required", [])
        for required_param in required_params:
            if required_param not in params:
                errors.append(f"Missing required parameter: {required_param}")

        properties = schema.get("properties", {})
        for param_name, param_schema in properties.items():
            if param_name not in params:
                continue

            param_value = params[param_name]
            param_type = param_schema.get("type")
            type_error = self._validate_param_type(param_name, param_type, param_value)
            if type_error:
                errors.append(type_error)

            param_format = param_schema.get("format")
            format_error = self._validate_param_format(param_name, param_format, param_value)
            if format_error:
                errors.append(format_error)

        return len(errors) == 0, errors

    def _validate_output_schema(
        self, output: Any, schema: dict[str, Any]
    ) -> tuple[bool, list[str]]:
        """Validate output against schema"""
        errors = []

        # Basic output validation
        if output is None and schema.get("type") != "null":
            errors.append("Output is required but was None")
        elif isinstance(output, dict) and "required" in schema:
            for required_field in schema["required"]:
                if required_field not in output:
                    errors.append(f"Missing required output field: {required_field}")

        return len(errors) == 0, errors

    def _check_rate_limit(self, tool_id: str, user_role: str) -> bool:
        """Check rate limit for tool/user"""
        key = f"{tool_id}:{user_role}"
        now = datetime.now(UTC)

        if key not in self.rate_limiters:
            self.rate_limiters[key] = []

        # Remove expired entries
        self.rate_limiters[key] = [
            t for t in self.rate_limiters[key] if (now - t).total_seconds() < 60
        ]

        tool = self.get_tool(tool_id)
        if tool and len(self.rate_limiters[key]) >= tool.rate_limit_rpm:
            return False

        self.rate_limiters[key].append(now)
        return True

    def _calculate_confidence(self, invocation: ToolInvocation) -> float:
        """Calculate confidence score for invocation"""
        score = 1.0

        # Reduce for validation errors
        score -= len(invocation.validation_errors) * 0.1

        # Reduce for execution time variance
        tool = self.get_tool(invocation.tool_id)
        if tool and tool.avg_execution_time_ms > 0:
            time_ratio = invocation.execution_time_ms / tool.avg_execution_time_ms
            if time_ratio > 2:
                score -= 0.2

        # Reduce for security concerns
        if invocation.risk_level != "low":
            score -= 0.3

        return max(score, 0.0)

    def _mask_sensitive_params(self, params: dict) -> dict:
        """Mask sensitive parameters for dry run"""
        sensitive_keys = ["password", "token", "secret", "key", "api_key"]

        def _walk(node: Any, parent_key: str = "") -> Any:
            if isinstance(node, dict):
                output: dict[str, Any] = {}
                for k, v in node.items():
                    if any(s in k.lower() for s in sensitive_keys):
                        output[k] = "***REDACTED***"
                    else:
                        output[k] = _walk(v, k)
                return output
            if isinstance(node, list):
                return [_walk(item, parent_key) for item in node]
            return node

        masked = _walk(params)
        if isinstance(masked, dict):
            return cast(dict[str, Any], masked)
        return {}

    @staticmethod
    def _flatten_param_values(node: Any) -> list[str]:
        """Flatten nested input into a list of string values for scanning."""
        if node is None:
            return []
        if isinstance(node, str):
            return [node]
        if isinstance(node, (int, float, bool)):
            return [str(node)]
        if isinstance(node, dict):
            nested_values: list[str] = []
            for value in node.values():
                nested_values.extend(ToolRegistry._flatten_param_values(value))
            return nested_values
        if isinstance(node, list):
            list_values: list[str] = []
            for item in node:
                list_values.extend(ToolRegistry._flatten_param_values(item))
            return list_values
        return [str(node)]

    @staticmethod
    def _detect_injection_findings(
        text: str, patterns: list[tuple[str, str]]
    ) -> list[dict[str, Any]]:
        """Return all matched injection findings for a text fragment."""
        lowered = text.lower()
        findings: list[dict[str, Any]] = []
        for injection_type, pattern in patterns:
            if re.search(pattern, lowered, re.IGNORECASE):
                findings.append(
                    {
                        "type": injection_type,
                        "sample": text[:200],
                        "severity": "high",
                    }
                )
        return findings

    async def _run_security_scan(self, params: dict[str, Any], tool: Tool) -> dict[str, Any]:
        """Run default recursive scan and optional external scanner."""
        default_scan = self._scan_params_recursive(params)
        if not default_scan["passed"]:
            return default_scan

        if (
            self.enforce_security_scanner
            and tool.security_level in {"elevated", "restricted"}
            and not self.security_scanner
        ):
            return {
                "passed": False,
                "risk_level": "high",
                "reason": f"security scanner required for {tool.security_level} tool '{tool.tool_name}'",
            }

        if self.security_scanner:
            external_scan = await self.security_scanner(params, tool)
            if not external_scan.get("passed", False):
                return {
                    "passed": False,
                    "risk_level": external_scan.get("risk_level", "high"),
                    "reason": external_scan.get(
                        "reason", "external security scanner blocked execution"
                    ),
                }

        return {"passed": True, "risk_level": "low", "reason": "ok"}

    def _scan_params_recursive(self, value: Any) -> dict[str, Any]:
        """Recursively scan params for basic injection patterns."""
        patterns = [
            ("sql_injection", r"(\bunion\s+select\b|\bor\s+1\s*=\s*1\b|--\s*$|/\*.*\*/)"),
            ("command_injection", r"[;&|`$]"),
            ("path_traversal", r"(\.\./|\.\.\\\\|%2e%2e)"),
            ("xss", r"(<script|</script|javascript:)"),
        ]
        findings: list[dict[str, Any]] = []
        flattened = self._flatten_param_values(value)
        for text in flattened:
            findings.extend(self._detect_injection_findings(text, patterns))

        if findings:
            return {
                "passed": False,
                "risk_level": "high",
                "reason": f"recursive parameter scan detected {len(findings)} issue(s)",
                "findings": findings,
            }

        return {"passed": True, "risk_level": "low", "reason": "ok", "findings": []}

    @staticmethod
    def _is_valid_email(email: str) -> bool:
        import re

        pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        return re.match(pattern, email) is not None

    @staticmethod
    def _is_valid_uri(uri: str) -> bool:
        import re

        pattern = r"^https?://[^\s]+$"
        return re.match(pattern, uri) is not None

    def get_metrics(self) -> dict[str, Any]:
        """Get tool registry metrics"""
        return {
            "total_tools": len(self.tools),
            "active_tools": len([t for t in self.tools.values() if t.status == ToolStatus.ACTIVE]),
            "by_category": {cat.value: len(tool_ids) for cat, tool_ids in self.categories.items()},
            "total_invocations": len(self.execution_history),
            "avg_execution_time_ms": sum(i.execution_time_ms for i in self.execution_history)
            / max(len(self.execution_history), 1),
            "success_rate": len([i for i in self.execution_history if i.status == "completed"])
            / max(len(self.execution_history), 1),
        }


class WebSearchTool:
    """Web Search Tool Implementation"""

    def execute(self, params: dict[str, Any], _context: dict[str, Any]) -> dict[str, Any]:
        """Execute web search"""
        query = params.get("query", "")
        max_results = params.get("max_results", 10)
        search_type = params.get("search_type", "general")

        if not query:
            return {"error": "Query is required", "success": False}

        # In production, would call actual search API
        # Simulating search results
        results = [
            {
                "title": f"Result for {query} - {i+1}",
                "url": f"https://example.com/result{i+1}",
                "snippet": f"Description for {query} from source {i+1}",
                "relevance_score": 0.9 - (i * 0.05),
            }
            for i in range(min(max_results, 5))
        ]

        return {
            "success": True,
            "query": query,
            "results": results,
            "count": len(results),
            "search_type": search_type,
        }


class CodeExecutionTool:
    """Code Execution Tool Implementation"""

    def execute(self, params: dict[str, Any], _context: dict[str, Any]) -> dict[str, Any]:
        """Execute code in sandbox"""
        code = params.get("code", "")
        language = params.get("language", "python")

        if not code:
            return {"error": "Code is required", "success": False}

        # In production, would execute in sandboxed environment
        # Simulating execution
        return {
            "success": True,
            "language": language,
            "stdout": f"Executed {language} code successfully",
            "stderr": "",
            "exit_code": 0,
            "execution_time_ms": 150,
        }


# =============================================================================
# TOOL REGISTRY INITIALIZATION
# =============================================================================


def create_tool_registry(lineage_repository: FileLineageRepository | None = None) -> ToolRegistry:
    """Create and configure tool registry with default tools"""
    registry = ToolRegistry(lineage_repository=lineage_repository)

    # Register Web Search Tool
    web_search_tool = Tool(
        tool_id="web_search",
        tool_name="web_search",
        category=ToolCategory.WEB,
        description="Search the web for information",
        input_schema={
            "type": "object",
            "required": ["query"],
            "properties": {
                "query": {"type": "string", "description": "Search query"},
                "max_results": {"type": "number", "default": 10},
                "search_type": {"type": "string", "enum": ["general", "news", "images"]},
            },
        },
        output_schema={
            "type": "object",
            "properties": {
                "success": {"type": "boolean"},
                "results": {"type": "array"},
                "count": {"type": "number"},
            },
        },
        capabilities=["search", "information_retrieval"],
        implementation=WebSearchTool().execute,
        rate_limit_rpm=60,
    )
    registry.register_tool(web_search_tool)

    # Register Code Execution Tool
    code_exec_tool = Tool(
        tool_id="code_execution",
        tool_name="code_execution",
        category=ToolCategory.COMPUTATION,
        description="Execute code in sandboxed environment",
        input_schema={
            "type": "object",
            "required": ["code"],
            "properties": {
                "code": {"type": "string", "description": "Code to execute"},
                "language": {"type": "string", "enum": ["python", "javascript", "bash"]},
                "timeout_ms": {"type": "number", "default": 30000},
            },
        },
        output_schema={
            "type": "object",
            "properties": {
                "success": {"type": "boolean"},
                "stdout": {"type": "string"},
                "stderr": {"type": "string"},
                "exit_code": {"type": "number"},
            },
        },
        capabilities=["execution", "computation", "programming"],
        implementation=CodeExecutionTool().execute,
        rate_limit_rpm=30,
        timeout_seconds=60,
    )
    registry.register_tool(code_exec_tool)

    # Register Database Query Tool
    db_tool = Tool(
        tool_id="database_query",
        tool_name="database_query",
        category=ToolCategory.DATA,
        description="Execute database queries",
        input_schema={
            "type": "object",
            "required": ["query"],
            "properties": {"query": {"type": "string"}, "params": {"type": "object"}},
        },
        output_schema={
            "type": "object",
            "properties": {
                "success": {"type": "boolean"},
                "rows": {"type": "array"},
                "count": {"type": "number"},
            },
        },
        capabilities=["database", "data_retrieval"],
        security_level="elevated",
        status=ToolStatus.BETA,
        tags=["stub", "not-implemented"],
        rate_limit_rpm=20,
    )
    registry.register_tool(db_tool)

    # Register Document Analysis Tool
    doc_tool = Tool(
        tool_id="document_analysis",
        tool_name="document_analysis",
        category=ToolCategory.DATA,
        description="Analyze documents and extract information",
        input_schema={
            "type": "object",
            "required": ["document"],
            "properties": {
                "document": {"type": "string"},
                "analysis_type": {"type": "string", "enum": ["summary", "entities", "sentiment"]},
            },
        },
        output_schema={
            "type": "object",
            "properties": {"success": {"type": "boolean"}, "analysis": {"type": "object"}},
        },
        capabilities=["document_processing", "analysis"],
        status=ToolStatus.BETA,
        tags=["stub", "not-implemented"],
        rate_limit_rpm=50,
    )
    registry.register_tool(doc_tool)

    # Register Image Analysis Tool
    image_tool = Tool(
        tool_id="image_analysis",
        tool_name="image_analysis",
        category=ToolCategory.MEDIA,
        description="Analyze images and extract visual information",
        input_schema={
            "type": "object",
            "required": ["image_url"],
            "properties": {
                "image_url": {"type": "string", "format": "uri"},
                "analysis_type": {"type": "string", "enum": ["objects", "text", "faces", "scene"]},
            },
        },
        output_schema={
            "type": "object",
            "properties": {"success": {"type": "boolean"}, "analysis": {"type": "object"}},
        },
        capabilities=["vision", "image_processing"],
        status=ToolStatus.BETA,
        tags=["stub", "not-implemented"],
        rate_limit_rpm=30,
    )
    registry.register_tool(image_tool)

    return registry


# =============================================================================
# MAIN TEST
# =============================================================================


async def main():
    """Test tool registry"""
    registry = create_tool_registry()

    # Test web search
    result = await registry.execute_tool(
        tool_id="web_search",
        params={"query": "artificial intelligence trends 2024", "max_results": 5},
        execution_context={"user_role": "standard", "user_tier": "standard"},
    )

    print(f"Web Search Result: {result}")

    # Test code execution
    code_result = await registry.execute_tool(
        tool_id="code_execution",
        params={"code": "print('Hello, AI-OS!')", "language": "python"},
        execution_context={"user_role": "standard", "user_tier": "standard"},
    )

    print(f"Code Execution Result: {code_result}")

    # Get metrics
    metrics = registry.get_metrics()
    print(f"Registry Metrics: {metrics}")


if __name__ == "__main__":
    asyncio.run(main())
