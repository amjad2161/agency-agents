"""Protocol ingress adapters and normalized task interfaces."""

from .a2a_acp_adapter import (
    parse_protocol_message,
    task_to_protocol_response,
    to_normalized_task,
    verify_message_auth,
)
from .models import (
    AgentActionType,
    AgentIdentity,
    NormalizedTask,
    ProtocolEnvelope,
    ProtocolMessageType,
)
from .registry import ProtocolRegistry

__all__ = [
    "ProtocolRegistry",
    "parse_protocol_message",
    "to_normalized_task",
    "task_to_protocol_response",
    "verify_message_auth",
    "ProtocolEnvelope",
    "ProtocolMessageType",
    "AgentActionType",
    "AgentIdentity",
    "NormalizedTask",
]
