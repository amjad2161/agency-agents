from __future__ import annotations

import hmac
from typing import Any

from protocols.models import (
    AgentActionType,
    AgentIdentity,
    NormalizedTask,
    ProtocolEnvelope,
    ProtocolMessageType,
)

DEFAULT_PROTOCOL_VERSION = "1.0"
DEFAULT_AGENT_ID = "unknown"
DEFAULT_ROLE = "worker"
DEFAULT_ACTION = "think"
DEFAULT_TASK_TITLE = "External delegated task"

SUPPORTED_PROTOCOLS = {"a2a", "acp"}
REQUIRED_FIELDS = ("protocol", "correlation_id", "message_type", "action", "source")


def _coerce_message_type(value: str) -> ProtocolMessageType:
    return ProtocolMessageType(value.lower())


def _coerce_action(value: str) -> AgentActionType:
    return AgentActionType(value.lower())


def verify_message_auth(raw: dict[str, Any], shared_token: str) -> bool:
    """Best-effort shared-token verification stub for protocol ingress hardening.

    The expected token must be provided out-of-band by deployment config.
    """
    if not shared_token:
        return False

    metadata = raw.get("metadata") or {}
    if not isinstance(metadata, dict):
        return False

    incoming_token = str(metadata.get("auth_token", "")).strip()
    return bool(incoming_token) and hmac.compare_digest(incoming_token, shared_token)


def parse_protocol_message(raw: dict[str, Any]) -> ProtocolEnvelope:
    missing = [field for field in REQUIRED_FIELDS if field not in raw]
    if missing:
        raise ValueError(f"Missing required protocol fields: {missing}")

    protocol = str(raw.get("protocol", "")).lower()
    if protocol not in SUPPORTED_PROTOCOLS:
        raise ValueError(f"Unsupported protocol: {protocol}")

    correlation_id = str(raw.get("correlation_id", "")).strip()
    if not correlation_id:
        raise ValueError("correlation_id cannot be empty")

    source_raw = raw.get("source") or {}
    target_raw = raw.get("target") or {}
    if not isinstance(source_raw, dict):
        raise ValueError("source must be an object")
    if target_raw and not isinstance(target_raw, dict):
        raise ValueError("target must be an object")

    source = AgentIdentity(
        agent_id=str(source_raw.get("agent_id", DEFAULT_AGENT_ID)),
        role=str(source_raw.get("role", DEFAULT_ROLE)),
        tenant_id=source_raw.get("tenant_id"),
    )

    target = None
    if target_raw:
        target = AgentIdentity(
            agent_id=str(target_raw.get("agent_id", DEFAULT_AGENT_ID)),
            role=str(target_raw.get("role", DEFAULT_ROLE)),
            tenant_id=target_raw.get("tenant_id"),
        )

    return ProtocolEnvelope(
        protocol=protocol,
        version=str(raw.get("version", DEFAULT_PROTOCOL_VERSION)),
        message_type=_coerce_message_type(str(raw.get("message_type", "request"))),
        correlation_id=correlation_id,
        source=source,
        target=target,
        action=_coerce_action(str(raw.get("action", DEFAULT_ACTION))),
        payload=dict(raw.get("payload", {})),
        metadata=dict(raw.get("metadata", {})),
    )


def to_normalized_task(envelope: ProtocolEnvelope) -> NormalizedTask:
    payload = envelope.payload
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")

    task_id = str(payload.get("task_id") or envelope.correlation_id)

    constraints_raw = payload.get("constraints", {})
    context_raw = payload.get("context", {})
    if not isinstance(constraints_raw, dict):
        raise ValueError("constraints must be an object")
    if not isinstance(context_raw, dict):
        raise ValueError("context must be an object")

    constraints = dict(constraints_raw)
    context = dict(context_raw)

    return NormalizedTask(
        task_id=task_id,
        title=str(payload.get("title") or DEFAULT_TASK_TITLE),
        objective=str(payload.get("objective", payload.get("instruction", ""))),
        constraints=constraints,
        context=context,
        source_protocol=envelope.protocol,
        source_message_id=envelope.correlation_id,
    )


def task_to_protocol_response(
    task_id: str, status: str, result: dict[str, Any], protocol: str = "a2a"
) -> dict[str, Any]:
    protocol_norm = protocol.lower()
    if protocol_norm not in SUPPORTED_PROTOCOLS:
        raise ValueError(f"Unsupported protocol: {protocol_norm}")

    return {
        "protocol": protocol_norm,
        "version": DEFAULT_PROTOCOL_VERSION,
        "message_type": "response",
        "correlation_id": task_id,
        "action": "complete",
        "payload": {
            "task_id": task_id,
            "status": status,
            "result": result,
        },
    }
