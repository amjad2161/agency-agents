"""Production-readiness check for Supreme endpoints.

Runs:
1. Configuration preflight checks.
2. Auth and endpoint sanity checks.
3. Burst load test.
4. Soak test.

Usage example:
    uv run python scripts/supreme_production_readiness.py \
      --base-url http://127.0.0.1:8010 \
      --token secret-token \
      --burst-requests 120 \
      --burst-concurrency 30 \
      --soak-seconds 120 \
      --soak-rps 8 \
      --strict
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import statistics
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import httpx


@dataclass
class HttpSummary:
    total: int
    status_2xx: int
    status_4xx: int
    status_5xx: int
    status_401: int
    status_429: int
    latency_avg_ms: float
    latency_p95_ms: float


@dataclass
class ReadinessReport:
    timestamp_unix: float
    base_url: str
    strict_mode: bool
    preflight_passed: bool
    preflight_findings: list[str]
    auth_check_passed: bool
    auth_check_detail: str
    burst: HttpSummary
    soak: HttpSummary
    metrics_snapshot: dict[str, Any]
    overall_ready: bool


def _percentile(values: list[float], q: float) -> float:
    if not values:
        return 0.0
    sorted_values = sorted(values)
    idx = int((len(sorted_values) - 1) * q)
    return sorted_values[idx]


def run_preflight(strict: bool) -> tuple[bool, list[str]]:
    findings: list[str] = []
    passed = True

    token = os.getenv("SUPREME_API_TOKEN", "").strip()
    if strict and not token:
        findings.append("FAIL: SUPREME_API_TOKEN is not set in strict mode.")
        passed = False
    elif not token:
        findings.append("WARN: SUPREME_API_TOKEN is not set (auth may be open if deployment allows).")
    else:
        findings.append("PASS: SUPREME_API_TOKEN is set.")

    rl = os.getenv("SUPREME_RATE_LIMIT_PER_WINDOW", os.getenv("SUPREME_RATE_LIMIT_PER_MINUTE", "")).strip()
    if not rl:
        findings.append("WARN: No explicit Supreme rate-limit env var set; default will apply.")
    else:
        findings.append(f"PASS: Supreme rate-limit env is set to {rl}.")

    cors = os.getenv("CORS_ALLOW_ORIGINS", "").strip()
    if strict and not cors:
        findings.append("FAIL: CORS_ALLOW_ORIGINS is empty in strict mode.")
        passed = False
    elif not cors:
        findings.append("WARN: CORS_ALLOW_ORIGINS not set explicitly.")
    else:
        findings.append("PASS: CORS_ALLOW_ORIGINS is set.")

    return passed, findings


async def _one_request(client: httpx.AsyncClient, url: str, headers: dict[str, str]) -> tuple[int, float]:
    start = time.perf_counter()
    response = await client.get(url, headers=headers)
    latency_ms = (time.perf_counter() - start) * 1000.0
    return response.status_code, latency_ms


def summarize(statuses: list[int], latencies: list[float]) -> HttpSummary:
    total = len(statuses)
    if total == 0:
        return HttpSummary(0, 0, 0, 0, 0, 0, 0.0, 0.0)
    return HttpSummary(
        total=total,
        status_2xx=sum(1 for s in statuses if 200 <= s < 300),
        status_4xx=sum(1 for s in statuses if 400 <= s < 500),
        status_5xx=sum(1 for s in statuses if 500 <= s < 600),
        status_401=statuses.count(401),
        status_429=statuses.count(429),
        latency_avg_ms=statistics.fmean(latencies),
        latency_p95_ms=_percentile(latencies, 0.95),
    )


async def burst_test(base_url: str, token: str, total: int, concurrency: int) -> HttpSummary:
    url = f"{base_url}/v1/supreme/status"
    headers = {"X-Supreme-Token": token} if token else {}

    statuses: list[int] = []
    latencies: list[float] = []

    semaphore = asyncio.Semaphore(concurrency)

    async with httpx.AsyncClient(timeout=10.0) as client:
        async def run_one() -> None:
            async with semaphore:
                status, latency = await _one_request(client, url, headers)
                statuses.append(status)
                latencies.append(latency)

        await asyncio.gather(*(run_one() for _ in range(total)))

    return summarize(statuses, latencies)


async def soak_test(base_url: str, token: str, seconds: int, rps: float) -> HttpSummary:
    url = f"{base_url}/v1/supreme/status"
    headers = {"X-Supreme-Token": token} if token else {}

    interval = 1.0 / rps if rps > 0 else 1.0
    statuses: list[int] = []
    latencies: list[float] = []

    deadline = time.monotonic() + seconds
    async with httpx.AsyncClient(timeout=10.0) as client:
        while time.monotonic() < deadline:
            status, latency = await _one_request(client, url, headers)
            statuses.append(status)
            latencies.append(latency)
            await asyncio.sleep(interval)

    return summarize(statuses, latencies)


async def auth_check(base_url: str, token: str) -> tuple[bool, str]:
    async with httpx.AsyncClient(timeout=10.0) as client:
        unauthorized = await client.get(f"{base_url}/v1/supreme/status")
        authorized = await client.get(
            f"{base_url}/v1/supreme/status",
            headers={"X-Supreme-Token": token} if token else {},
        )

    if token:
        if unauthorized.status_code == 401 and authorized.status_code == 200:
            return True, "PASS: Unauthorized blocked (401) and authorized accepted (200)."
        return (
            False,
            f"FAIL: Expected 401/200 but got {unauthorized.status_code}/{authorized.status_code}.",
        )

    if authorized.status_code == 200:
        return True, "PASS: Endpoint reachable without token (non-strict mode)."
    return False, f"FAIL: No token provided and status endpoint returned {authorized.status_code}."


async def get_metrics(base_url: str, token: str) -> dict[str, Any]:
    headers = {"X-Supreme-Token": token} if token else {}
    async with httpx.AsyncClient(timeout=10.0) as client:
        response = await client.get(f"{base_url}/v1/supreme/metrics", headers=headers)
        try:
            payload = response.json()
        except Exception:
            payload = {"raw": response.text}
    return {"status_code": response.status_code, "payload": payload}


def determine_ready(report: ReadinessReport) -> bool:
    if not report.preflight_passed:
        return False
    if not report.auth_check_passed:
        return False
    if report.burst.status_5xx > 0 or report.soak.status_5xx > 0:
        return False
    return True


async def main() -> None:
    parser = argparse.ArgumentParser(description="Supreme production-readiness runner")
    parser.add_argument("--base-url", default="http://127.0.0.1:8000")
    parser.add_argument("--token", default=os.getenv("SUPREME_API_TOKEN", ""))
    parser.add_argument("--burst-requests", type=int, default=120)
    parser.add_argument("--burst-concurrency", type=int, default=30)
    parser.add_argument("--soak-seconds", type=int, default=120)
    parser.add_argument("--soak-rps", type=float, default=8.0)
    parser.add_argument("--strict", action="store_true")
    parser.add_argument("--output", default="")
    args = parser.parse_args()

    preflight_passed, preflight_findings = run_preflight(strict=args.strict)
    auth_passed, auth_detail = await auth_check(args.base_url, args.token)
    burst = await burst_test(
        base_url=args.base_url,
        token=args.token,
        total=args.burst_requests,
        concurrency=args.burst_concurrency,
    )
    soak = await soak_test(
        base_url=args.base_url,
        token=args.token,
        seconds=args.soak_seconds,
        rps=args.soak_rps,
    )
    metrics_snapshot = await get_metrics(args.base_url, args.token)

    report = ReadinessReport(
        timestamp_unix=time.time(),
        base_url=args.base_url,
        strict_mode=args.strict,
        preflight_passed=preflight_passed,
        preflight_findings=preflight_findings,
        auth_check_passed=auth_passed,
        auth_check_detail=auth_detail,
        burst=burst,
        soak=soak,
        metrics_snapshot=metrics_snapshot,
        overall_ready=False,
    )
    report.overall_ready = determine_ready(report)

    payload = asdict(report)
    print(json.dumps(payload, indent=2))

    if args.output:
        serialized = json.dumps(payload, indent=2)
        await asyncio.to_thread(Path(args.output).write_text, serialized, encoding="utf-8")


if __name__ == "__main__":
    asyncio.run(main())
