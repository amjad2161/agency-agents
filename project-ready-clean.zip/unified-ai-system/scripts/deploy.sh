#!/bin/bash
# AI-OS Deployment Script
# Complete deployment automation for local and production environments

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default values
DEPLOYMENT_TYPE="local"
IMAGE_TAG="latest"
NAMESPACE="aios"

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

show_help() {
    cat << EOF
AI-OS Deployment Script

Usage: $0 [OPTIONS]

OPTIONS:
    -t, --type TYPE         Deployment type: local, docker, kubernetes (default: local)
    -i, --image-tag TAG     Docker image tag (default: latest)
    -n, --namespace NS      Kubernetes namespace (default: aios)
    -s, --skip-build        Skip Docker image build
    -d, --skip-db           Skip database initialization
    -h, --help              Show this help message

EXAMPLES:
    $0 -t local                    # Local development
    $0 -t docker                   # Docker Compose deployment
    $0 -t kubernetes -n production # Kubernetes production deployment

EOF
}

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -t|--type)
            DEPLOYMENT_TYPE="$2"
            shift 2
            ;;
        -i|--image-tag)
            IMAGE_TAG="$2"
            shift 2
            ;;
        -n|--namespace)
            NAMESPACE="$2"
            shift 2
            ;;
        -s|--skip-build)
            SKIP_BUILD=true
            shift
            ;;
        -d|--skip-db)
            SKIP_DB=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            show_help
            exit 1
            ;;
    esac
done

# Deployment functions
deploy_local() {
    log_info "Deploying AI-OS for local development..."

    # Create virtual environment if needed
    if [ ! -d "venv" ]; then
        log_info "Creating Python virtual environment..."
        python3 -m venv venv
        source venv/bin/activate
        pip install -r requirements.txt
    else
        source venv/bin/activate
    fi

    # Install pre-commit hooks
    if command -v pre-commit &> /dev/null; then
        pre-commit install
    fi

    # Initialize database
    if [ "${SKIP_DB:-false}" != "true" ]; then
        log_info "Initializing database..."
        psql -h localhost -U postgres -d postgres -c "CREATE DATABASE aios;" 2>/dev/null || true
        psql -h localhost -U postgres -d aios -f scripts/init-db.sql
    fi

    # Start Redis
    if ! pgrep -x "redis-server" > /dev/null; then
        log_info "Starting Redis..."
        redis-server --daemonize yes
    fi

    # Run API server
    log_info "Starting API server..."
    cd /workspace/unified-ai-system
    uvicorn src.api.server:app --host 0.0.0.0 --port 8000 --reload &
    API_PID=$!

    log_success "AI-OS deployed locally!"
    log_info "API Server running at http://localhost:8000"
    log_info "API Documentation at http://localhost:8000/docs"
    log_info "API PID: $API_PID"

    echo ""
    echo "To stop the server: kill $API_PID"
}

deploy_docker() {
    log_info "Deploying AI-OS with Docker Compose..."

    # Build Docker image
    if [ "${SKIP_BUILD:-false}" != "true" ]; then
        log_info "Building Docker image..."
        docker build -t aios/api:${IMAGE_TAG} --target production .
        docker build -t aios/worker:${IMAGE_TAG} --target production .
    fi

    # Start services
    log_info "Starting services..."
    docker-compose up -d

    # Wait for services
    log_info "Waiting for services to be ready..."
    sleep 10

    # Check health
    if curl -sf http://localhost:8000/health > /dev/null; then
        log_success "AI-OS deployed successfully with Docker!"
    else
        log_warning "Services may still be starting..."
    fi

    log_info "API Server: http://localhost:8000"
    log_info "Grafana: http://localhost:3000"
    log_info "Prometheus: http://localhost:9090"

    # Show status
    docker-compose ps
}

deploy_kubernetes() {
    log_info "Deploying AI-OS to Kubernetes..."

    # Check kubectl
    if ! command -v kubectl &> /dev/null; then
        log_error "kubectl not found. Please install kubectl first."
        exit 1
    fi

    # Check context
    if ! kubectl cluster-info &> /dev/null; then
        log_error "Kubernetes cluster not accessible."
        exit 1
    fi

    # Create namespace
    log_info "Creating namespace: $NAMESPACE"
    kubectl create namespace "$NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -

    # Apply manifests
    log_info "Applying Kubernetes manifests..."
    kubectl apply -f k8s/namespace.yaml
    kubectl apply -f k8s/namespace.yaml -n "$NAMESPACE"

    # Wait for deployments
    log_info "Waiting for deployments..."
    kubectl wait --for=condition=available --timeout=300s deployment/ai-os-api -n "$NAMESPACE" || true
    kubectl wait --for=condition=available --timeout=300s deployment/ai-os-worker -n "$NAMESPACE" || true

    # Show status
    log_success "AI-OS deployed to Kubernetes!"
    kubectl get pods -n "$NAMESPACE"
    kubectl get services -n "$NAMESPACE"
}

# Main execution
main() {
    log_info "AI-OS Deployment Script"
    log_info "Deployment type: $DEPLOYMENT_TYPE"
    echo ""

    case $DEPLOYMENT_TYPE in
        local)
            deploy_local
            ;;
        docker)
            deploy_docker
            ;;
        kubernetes)
            deploy_kubernetes
            ;;
        *)
            log_error "Unknown deployment type: $DEPLOYMENT_TYPE"
            show_help
            exit 1
            ;;
    esac

    echo ""
    log_success "Deployment complete!"
}

# Run main
main
